/*---------------------------------------------------------------------
         ___ __  __ ____   ___  ____ _____  _    _   _ _____
        |_ _|  \/  |  _ \ / _ \|  _ \_   _|/ \  | \ | |_   _|
         | || |\/| | |_) | | | | |_) || | / _ \ |  \| | | |
         | || |  | |  __/| |_| |  _ < | |/ ___ \| |\  | | |
        |___|_|  |_|_|    \___/|_| \_\|_/_/   \_\_| \_| |_|
         .
  -> -> -> EDITING THIS FILE HAS A HIGH CHANCE TO BREAK THE SHADER PACK
  -> -> -> DO NOT CHANGE ANYTHING UNLESS YOU KNOW WHAT YOU ARE DOING
  -> -> -> DO NOT EXPECT SUPPORT AFTER MODIFYING SHADER FILES
---------------------------------------------------------------------*/

//User Settings//
    #define SHADER_STYLE 1 //[1 4]

    #define RP_MODE 1 //[1 0 3 2]

    #define VOXEL_DETAIL_AMOUNT 6 //[1 2 3 4 5 6 7 8]
    #define VX_VOL_SIZE 1 //[0 1 2 3]
    const float voxelDistance = 32;
    #if VX_VOL_SIZE == 0
        const ivec3 voxelVolumeSize = ivec3(96, 64, 96);
    #elif VX_VOL_SIZE == 1
        const ivec3 voxelVolumeSize = ivec3(128, 96, 128);
    #elif VX_VOL_SIZE == 2
        const ivec3 voxelVolumeSize = ivec3(256, 128, 256);
    #elif VX_VOL_SIZE == 3
        const ivec3 voxelVolumeSize = ivec3(512, 128, 512);
    #endif

    #define SDF_UPDATE_INTERVAL 0 //[0 1 2 3 4 5 6 8 10 13 16 20]
    #define PER_PIXEL_LIGHT
    #define LONGER_LIGHT_LISTS
    #ifndef PER_PIXEL_LIGHT
        #define PER_BLOCK_LIGHT
    #endif

    #define DIRECTION_UPDATING_CONETRACE

    #define R2_FALLOFF 1 //[0 1]

    #define GI_STRENGTH 2 //[0 1 2]

    #if GI_STRENGTH > 0
        #define GI
        #define GI_SAMPLE_COUNT 13 //[1 3 7 13]
        #define GI_AMBIENT_MIN 0.50 //[0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
    #endif

    #define BLOCKLIGHT_I 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 6.0 7.0 8.5 10.0]
    #define BLOCKLIGHT_RESOLUTION 3 //[10 8 6 4 3 2 1]
    #define LIGHT_TRACE_LENGTH 30.0 //[10.0 12.0 15.0 18.0 22.0 26.0 30.0 35.0 40.0 47.0 55.0 65.0 76.0 88.0 100.0]
    #define LIGHT_COLOR_SATURATION 0.5 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
    #define LIGHTSOURCE_SIZE_MULT 0.6 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
    #define MAX_TRACE_COUNT 64 //[1 2 4 8 16 24 32 48 64 96 128 192 256]
    #define RT_STEPS 70 //[30 50 70 100]
    #define TRANSLUCENT_LIGHT_TINT
    //#define LIGHT_CLUMPING
    #define COLORED_LIGHT_FOG
    #define COLORED_LIGHT_FOG
    #define COLORED_LIGHT_FOG_I 0.65 //[0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50]
    #define VBL_NETHER_MULT 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0 1.2 1.5 1.8 2.2 2.6 3.0 3.5 4.0 4.7 5.5 6.4 8.2 9.0 10.0]
    #define VBL_END_MULT 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0 1.2 1.5 1.8 2.2 2.6 3.0 3.5 4.0 4.7 5.5 6.4 8.2 9.0 10.0]

    #ifdef END
        #define CONWAY 0 //[0 1 2]
        #define CONWAY_HEIGHT 10.1
    #endif
    #ifdef OVERWORLD
        #define FRACTAL_GALAXY 0 //[0 1 2 3]
    #endif
    #if !defined DH_TERRAIN && !defined DH_WATER
        #define VOXEL_RT_REFLECTIONS
    #endif
  //#define WHITE_WORLD
    #define REALTIME_SHADOWS
    #define SHADOW_QUALITY 2 //[-1 0 1 2 3 4 5]
    const float shadowDistance = 128.0; //[64.0 80.0 96.0 112.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0 512.0 768.0 1024.0]
    #define PLAYER_VOXELIZATION
    #define FOLIAGE_VOXELIZATION
    #define ENTITY_SHADOWS_DEFINE 1 //[-1 1]
    #if ENTITY_SHADOWS_DEFINE > 0
        #define ENTITY_VOXELIZATION
    #endif
  //#define SLANTED_BLOCK_EDGES

    #define SSAO_QUALI_DEFINE 2 //[0 2 3]
    #define FXAA_DEFINE 1 //[-1 1]
    #define DETAIL_QUALITY 2 //[0 2 3]
    #define CLOUD_QUALITY 2 //[0 1 2 3]
    #define LIGHTSHAFT_QUALI_DEFINE 2 //[0 1 2 3 4]
    #define WATER_REFLECT_QUALITY 2 //[-1 0 1 2]
    #define BLOCK_REFLECT_QUALITY 3 //[0 1 2 3]
    #define ANISOTROPIC_FILTER 0 //[0 4 8 16]

    #if defined PER_PIXEL_LIGHT && BLOCK_REFLECT_QUALITY > 0
        #define BLOCKLIGHT_HIGHLIGHT
    #endif

    #if !(defined DH_TERRAIN || defined DH_WATER)
        #define PORTAL_EDGE_EFFECT
        #ifndef IRIS_HAS_CONNECTED_TEXTURES
            #define CONNECTED_GLASS_EFFECT
        #endif

        #if defined CONNECTED_GLASS_EFFECT || defined PORTAL_EDGE_EFFECT
            #define COLORED_LIGHTING_INTERNAL 1
            #define ACL_VOXELIZATION
        #endif
    #endif

    #define WATER_STYLE_DEFINE 4 //[-1 1 2 3 4]
    #define WATER_CAUSTIC_STYLE_DEFINE 4 //[-1 1 3 4]
    #define WATER_REFRACTION_INTENSITY 2.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
    #define WATER_FOAM_I 100 //[0 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150]
    #define WATER_ALPHA_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900]
    #define WATER_FOG_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900]
    #define WATERCOLOR_MODE 3 //[3 2 0]
    #define BRIGHT_CAVE_WATER
    #define WATERCOLOR_R 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define WATERCOLOR_G 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define WATERCOLOR_B 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define UNDERWATERCOLOR_R 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150]
    #define UNDERWATERCOLOR_G 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150]
    #define UNDERWATERCOLOR_B 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150]
    #define WATER_BUMPINESS 1.25 //[0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.65 0.80 1.00 1.25 1.50 2.00 2.50]
    #define WATER_BUMP_SMALL 0.75 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define WATER_BUMP_MED 1.70 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define WATER_BUMP_BIG 2.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define WATER_SPEED_MULT 1.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define WATER_SIZE_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    // ---- Eclipse water mode (Iteration 25: "Hydro-Voxel Fusion") ----------
    // Eclipse water is now a native Water Style (Iteration 29): selecting
    // "Eclipse" in the Water Style option (WATER_STYLE_DEFINE == 4) enables the
    // whole Eclipse pipeline. The internal ECLIPSE_WATER flag is DERIVED from
    // WATER_STYLE == 4 further down (after WATER_STYLE is resolved), so there is
    // no separate toggle. The sliders below only tune Eclipse and are ignored in
    // every other Water Style, so the fallback stays byte-identical.
    #define ECLIPSE_WATER_WAVE_STRENGTH 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define ECLIPSE_WATER_WAVE_SPEED 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define ECLIPSE_PATCHY_WAVE_BLEND 1.0 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define ECLIPSE_WAVE_DISPLACEMENT 100 //[0 25 50 75 100 125 150 175 200]
    #define ECLIPSE_WAVE_DISPLACEMENT_M (ECLIPSE_WAVE_DISPLACEMENT * 0.01)
    #define ECLIPSE_WAVES_A_RADIUS 1.0 //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]
    #define ECLIPSE_WAVES_B_RADIUS 0.15 //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]
    #define ECLIPSE_HYPER_DETAILED_WAVES 1 //[0 1]
    // Iteration 27 -- Eclipse water OPTICS (per-channel Beer-Lambert absorption,
    // ported from Eclipse's Water_Absorb_R/G/B; R absorbs fastest -> blue-green
    // deep ocean) and INTERACTION (procedural player wake). All only consumed
    // when ECLIPSE_WATER == 1, so the OFF path stays byte-identical.
    #define ECLIPSE_WATER_ABSORB_R 0.40 //[0.0 0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.24 0.28 0.32 0.36 0.4 0.44 0.48 0.52 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]
    #define ECLIPSE_WATER_ABSORB_G 0.10 //[0.0 0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.24 0.28 0.32 0.36 0.4 0.44 0.48 0.52 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]
    #define ECLIPSE_WATER_ABSORB_B 0.06 //[0.0 0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.24 0.28 0.32 0.36 0.4 0.44 0.48 0.52 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]
    #define ECLIPSE_WATER_ABSORB_MULT 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define ECLIPSE_WATER_SPECULAR 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define ECLIPSE_WATER_INTERACTION 1 //[0 1]
    #define ECLIPSE_WATER_WAKE_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

    #define SHADOW_SMOOTHING 4 //[1 2 3 4]
    #define RAIN_PUDDLES 2 //[0 1 2 3 4]
    #define SSAO_I 100 //[0 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define VANILLAAO_I 100 //[0 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]

    #define AURORA_STYLE_DEFINE -1 //[-1 0 1 2]
    #define AURORA_CONDITION 3 //[0 1 2 3 4]
    //#define NIGHT_NEBULA
    #define NIGHT_NEBULA_I 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define WEATHER_TEX_OPACITY 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900]
    #define SPECIAL_BIOME_WEATHER
    #define RAIN_STYLE 1 //[1 2]
    #define SUN_MOON_STYLE_DEFINE 2 //[-1 1 2 3]
    #define SUN_MOON_HORIZON
    #define SUN_MOON_DURING_RAIN

    // ---- Sky colour (Iteration 44) --------------------------------------
    // SKY_STYLE 1 keeps the original Reimagined gradient. SKY_STYLE 2 swaps the
    // clear sky for a Rayleigh/Mie/ozone atmosphere adapted from Photon and
    // calibrated against Photon's own scattering LUT -- deeper zenith blues,
    // warm horizons at sunrise/sunset, a real blue hour. Rain always falls back
    // to the gradient sky, so overcast weather is untouched either way.
    // See lib/atmospherics/physicalSky.glsl for the derivation.
    // CC_MODE is declared up here, ahead of the sky block below, because the
    // preprocessor resolves SKY_STYLE against it. An undefined macro evaluates
    // to 0 in #if, so declaring it further down silently forced SKY_STYLE to 1
    // and the physical sky never engaged in Realistic mode.
    #define CC_MODE 0 //[0 1 2]

    #define SKY_STYLE_DEFINE -1 //[-1 1 2]
    #if SKY_STYLE_DEFINE == -1
        // "Set by Color Correction Mode": every mode now uses the gradient sky.
        // Realistic used to force the Rayleigh/Mie atmosphere here, but in game
        // it read as a flat pink-grey haze rather than the deep blue it models,
        // so it is opt-in through Sky Style instead of being a mode default.
        #define SKY_STYLE 1
    #else
        #define SKY_STYLE SKY_STYLE_DEFINE
    #endif
    // Azure boost for the sky, luminance-preserving so it does not darken.
    #define SKY_BLUE 1.50 //[0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.75 2.00]
    // Fog keeps its own blue amount so tinting the sky never drags the haze
    // on distant terrain along with it.
    #define SKY_BLUE_FOG 1.00 //[0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.75 2.00]
    #define FOG_SATURATION 0.70 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40]
    #define FOG_TINT_R 1.00 //[0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30]
    #define FOG_TINT_G 1.00 //[0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30]
    #define FOG_TINT_B 1.00 //[0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30]
    #define SKY_BRIGHTNESS 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.75 2.00]
    // The value SKY_SATURATION has to sit at for the gradient sky to
    // be unsaturated, i.e. exactly as BV 1.3 drew it. Modes 0 and 1
    // divide by it so their DEFAULT is identity while the slider stays live.
    #define SKY_SATURATION_V13_NEUTRAL 1.10
    #define SKY_SATURATION 1.10 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.80 2.00]
    #define SKY_DAY_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.75 2.00]
    #define SKY_NIGHT_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]
    #define SKY_TWILIGHT_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]
    #define SKY_MULTI_SCATTER 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]
    #define SKY_MIE_G 0.77 //[0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.72 0.74 0.76 0.77 0.78 0.80 0.82 0.84 0.86 0.88 0.90]
    #define SKY_HORIZON_LIFT 0.04 //[0.00 0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15 0.20]
    #define SKY_MIE_STRENGTH 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.50 2.00]
    #define SKY_ZENITH_BLUE 1.00 //[0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]
    #define SKY_HORIZON_DESAT 0.70 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
    #define SKY_HORIZON_STRETCH 0.05 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.75 1.00]
    // v1.4.1: raised from 0.50 to 1.00. The slider now drives the gradient sky
    // as well as the physical one (it used to be ignored there), and at 0.50
    // that halved a halo the pack has always relied on: the sun DISC is drawn
    // as vec3(0.9,0.5,0.3)*10 in gbuffers_skybasic and only looks white because
    // it blows out, so the glare is what hides the orange rim at its partially
    // blown edge. 1.00 keeps the long-standing look; lower it if the sky
    // bleaching around the sun bothers you more than the rim does.
    #define SKY_GLARE 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.50]
    #define SKY_GROUND_DIM 0.70 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
    #define SKY_QUALITY 4 //[2 3 4 6 8]
    #define SKY_QUALITY_LOW 2 //[1 2 3 4 6]

    // Samsung Space Zoom Moon: as you zoom in (OptiFine/Zoomify lowers the FOV)
    // the procedural moon defocuses and cross-fades to the HD photo texture,
    // snapping into sharp crater relief at full zoom. Only active while zoomed
    // (focusProgress > 0), so normal play is untouched. START_FOV = where the
    // defocus begins, READY_FOV = where the HD texture is fully in focus.
    #define SAMSUNG_MOON_ZOOM 1 //[0 1]
    #define MOON_ZOOM_TRIGGER_FOV 17.0 //[8.0 10.0 12.0 14.0 15.0 16.0 17.0 18.0 20.0 22.0 25.0 30.0 40.0]
    #define MOON_ZOOM_BLUR_IN_TIME 0.1 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
    #define MOON_ZOOM_BLUR_OUT_TIME 0.3 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
    #define MOON_ZOOM_FLASH 0.4 //[0.0 0.05 0.1 0.2 0.3 0.4 0.5 0.7 1.0 1.4 2.0 2.8 4.0]
    #define MOON_ZOOM_DISK_SIZE 4.2 //[2.0 2.4 2.8 3.0 3.2 3.4 3.6 3.8 4.0 4.2 4.5 4.8 5.0 5.5 6.0]
    #define MOON_ZOOM_BRIGHTNESS 1.2 //[0.2 0.4 0.6 0.8 0.9 1.0 1.1 1.2 1.4 1.6 2.0]
    #define MOON_ZOOM_SKY_DARKNESS 0.20 //[0.0 0.05 0.10 0.15 0.20 0.30 0.50 0.70]
    #define MOON_ZOOM_BLOOM 0.0 //[0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.8 1.0 1.3 1.6 2.0]
    #define MOON_ZOOM_BLOOM_SIZE 2.0 //[1.3 1.5 1.8 2.0 2.5 3.0 3.5 4.0 5.0]
    #define MOON_ZOOM_FOCUS_BLUR 0.050 //[0.005 0.010 0.015 0.020 0.030 0.040 0.050 0.065 0.080 0.100 0.130]
    #define NIGHT_STAR_AMOUNT 2 //[2 3]
    #define RAINBOWS 1 //[0 1 3]
    #define CLOUD_STYLE_DEFINE 2 //[-1 0 1 2 50]
    #define CLOUD_SHADOWS
    #define CLOUD_CLOSED_AREA_CHECK
    #define CLOUD_ALT1 192 //[-96 -92 -88 -84 -80 -76 -72 -68 -64 -60 -56 -52 -48 -44 -40 -36 -32 -28 -24 -20 -16 -10 -8 -4 0 4 8 12 16 20 22 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 256 260 264 268 272 276 280 284 288 292 296 300 304 308 312 316 320 324 328 332 336 340 344 348 352 356 360 364 368 372 376 380 384 388 392 396 400 404 408 412 416 420 424 428 432 436 440 444 448 452 456 460 464 468 472 476 480 484 488 492 496 500 510 520 530 540 550 560 570 580 590 600 610 620 630 640 650 660 670 680 690 700 710 720 730 740 750 760 770 780 790 800]
    #define CLOUD_SPEED_MULT 375 //[0 5 7 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900]
    // Cinematic time-transition speed, in SECONDS -- the exponential time
    // constant of the glide. Iteration 37: the self-contained tracker
    // (lib/misc/eclipseTimeTracker.glsl) pursues the native time with the
    // EXACT Iteration 31 exponential-decay curve (eclipseEaseExpOut /
    // eclipseAdvanceTime, lib/misc/timeInterpolation.glsl): each frame it
    // closes 1 - exp(-dt / THIS_VALUE) of the remaining gap -- the fast,
    // organic start and gentle asymptotic landing of the build that felt
    // perfect. Higher = slower, more cinematic. DEFAULT 0.6 (Iteration 38):
    // a quick, responsive glide out of the box.
    // 0.0 == OFF (Instant): time snaps like vanilla.
    // Only has any effect while ECLIPSE_TIME_ACTIVE is 2 (Sky) or 3 (Sky+Water).
    #define TIME_TRANSITION_SPEED 0.6 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 7.0 10.0]
    // Eclipse-style GLOBAL cinematic smooth time (Performance screen).
    // Iteration 33: a strict THREE-STATE selector, default 2:
    //   1 = OFF          : real time everywhere; the transition system is
    //       compiled out and the pack behaves like the stock build.
    //   2 = Sky (DEFAULT): the native celestial timeAngle is replaced by one
    //       reconstructed from the engine-smoothed sin/cos of the sun angle, so
    //       the ENTIRE sun-vector pipeline -- sky gradient, atmospheric
    //       scattering, terrain light direction and cloud lighting -- glides
    //       smoothly across a /time set, bed-sleep or time-plugin jump. The
    //       water wave-speed parameters are NOT scaled or touched in this mode:
    //       the Eclipse wave clock advects on steady real time.
    //   3 = Sky + Water  : the same sky transition, and the Eclipse wave clock
    //       additionally rides the eased visual timeline, so the wave-speed
    //       equations time-lapse warp together with the sky.
    // (The Iris-rendered shadow map and the vanilla sun/moon/star sprites are
    // positioned by the engine from real time and still snap; engine-side.)
    #define ECLIPSE_TIME_ACTIVE 2 //[1 2 3]
    #define CLOUD_R 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define CLOUD_G 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define CLOUD_B 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]

    #define CLOUD_UNBOUND_AMOUNT 1.00 //[0.70 0.71 0.72 0.73 0.74 0.75 0.76 0.77 0.78 0.79 0.80 0.81 0.82 0.83 0.84 0.85 0.86 0.87 0.88 0.89 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98 0.99 1.00 1.02 1.04 1.06 1.08 1.10 1.12 1.14 1.16 1.18 1.20 1.22 1.24 1.26 1.28 1.30 1.32 1.34 1.36 1.38 1.40 1.42 1.44 1.46 1.48 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.10 2.20 2.30 2.40 2.50 2.60 2.70 2.80 2.90 3.00]
    #define CLOUD_UNBOUND_SIZE_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define CLOUD_UNBOUND_RAIN_ADD 0.40 //[0.00 0.05 0.06 0.07 0.08 0.09 0.10 0.12 0.14 0.16 0.18 0.22 0.26 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50]
    // How far rain lowers the Unbound coverage cutoff, in percent. RAIN_ADD
    // above controls DENSITY (fatter cells); this controls COVERAGE (fewer
    // gaps). 0 = the pre-v1.4.1 patchy storm sky, 80 = a nearly solid overcast
    // deck. See GetCloudNoise() in lib/atmospherics/clouds/unboundClouds.glsl.
    #define CLOUD_RAIN_OVERCAST 80 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95]

    // Altitude of the cloud deck. Still referenced by the ambience logic in
    // deferred1.glsl / final.glsl (the "above the clouds" test), so it stays even
    // though the volumetric layer options it used to accompany are gone.
    #define CloudLayer0_height 250 //[-100 -50 0 50 100 150 192 200 250 300 350 400 450 500 600 700 800 900 1000 1500 2000]

    #define CLOUD_ALT2 288 //[-96 -92 -88 -84 -80 -76 -72 -68 -64 -60 -56 -52 -48 -44 -40 -36 -32 -28 -24 -20 -16 -10 -8 -4 0 4 8 12 16 20 22 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 256 260 264 268 272 276 280 284 288 292 296 300 304 308 312 316 320 324 328 332 336 340 344 348 352 356 360 364 368 372 376 380 384 388 392 396 400 404 408 412 416 420 424 428 432 436 440 444 448 452 456 460 464 468 472 476 480 484 488 492 496 500 510 520 530 540 550 560 570 580 590 600 610 620 630 640 650 660 670 680 690 700 710 720 730 740 750 760 770 780 790 800]

    #define NETHER_VIEW_LIMIT 256.0 //[96.0 112.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0 512.0 768.0 1024.0 99999.0]
    #define NETHER_COLOR_MODE 3 //[3 2 0]
    #define NETHER_STORM
    #define NETHER_STORM_LOWER_ALT 28 //[-296 -292 -288 -284 -280 -276 -272 -268 -264 -260 -256 -252 -248 -244 -240 -236 -232 -228 -224 -220 -216 -212 -208 -204 -200 -196 -192 -188 -184 -180 -176 -172 -168 -164 -160 -156 -152 -148 -144 -140 -136 -132 -128 -124 -120 -116 -112 -108 -104 -100 -96 -92 -88 -84 -80 -76 -72 -68 -64 -60 -56 -52 -48 -44 -40 -36 -32 -28 -24 -20 -16 -12 -8 -4 0 4 8 12 16 20 22 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 256 260 264 268 272 276 280 284 288 292 296 300]
    #define NETHER_STORM_HEIGHT 200 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900]
    #define NETHER_STORM_I 0.40 //[0.05 0.06 0.07 0.08 0.09 0.10 0.12 0.14 0.16 0.18 0.22 0.26 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50]

    #define BORDER_FOG
    // How dark the border fog drags terrain at night. Realistic (CC_MODE 2)
    // only -- see DoBorderFog() in lib/atmospherics/fog/mainFog.glsl.
    // 1.00 = off (the pre-v1.4.1 behaviour), lower = the render edge sinks
    // further into darkness after sundown.
    #define BORDER_FOG_NIGHT_DARKEN 0.35 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
    #define ATM_FOG_MULT 0.95 //[0.50 0.65 0.80 0.95]
    #define ATM_FOG_DISTANCE 100 //[10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define ATM_FOG_ALTITUDE 63 //[0 5 10 15 20 25 30 35 40 45 50 52 54 56 58 60 61 62 63 64 65 66 67 68 69 70 72 74 76 78 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 210 220 230 240 250 260 270 280 290 300]
    #define CAVE_FOG
    // v1.4.1: was 3 (Extreme), which the option's own tooltip flags as not
    // recommended for general gameplay and a severe performance hit -- and it
    // is what filled the distance with volumetric haze. 1 is Scene Aware, the
    // mode the pack itself marks [+]: it switches between regular and extreme
    // where each actually helps.
    #define LIGHTSHAFT_BEHAVIOUR 1 //[0 1 2 3]
    #define LIGHTSHAFT_DAY_I 100 //[1 3 5 7 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]
    #define LIGHTSHAFT_NIGHT_I 100 //[1 3 5 7 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]
    #define LIGHTSHAFT_RAIN_I 100 //[1 3 5 7 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]
    #define LIGHTSHAFT_SMOKE
    #define SPECIAL_PALE_GARDEN_LIGHTSHAFTS

    #define BLOOM
    #define BLOOM_STRENGTH 0.12 //[0.027 0.036 0.045 0.054 0.063 0.072 0.081 0.09 0.10 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.21 0.23 0.25 0.28 0.32 10.00]
    #define IMAGE_SHARPENING 5 //[0 1 2 3 4 5 6 7 8 9 10]
    #define MOTION_BLURRING
    #define MOTION_BLURRING_STRENGTH 2.00 //[0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define VIGNETTE_R
    #define CHROMA_ABERRATION 0 //[0 1 2 3 4 5 6 7 8]
    #define UNDERWATER_DISTORTION
    #define LENSFLARE_MODE 1 //[0 1 2]
    #define LENSFLARE_I 1.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.25 4.50 4.75 5.00]
    #define TAA_MODE 1 //[1 2 0]
    #define DISTANT_LIGHT_BOKEH

    #define WORLD_BLUR 2 //[0 1 2]
    #define WB_FOV_SCALED
    //#define WB_CHROMATIC
    #define WB_ANAMORPHIC
    #define WB_DOF_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DOF_FOCUS 0 //[-1 0 1 2 3 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 65 67 69 72 74 76 79 81 83 86 88 91 94 96 99 102 104 107 110 113 115 118 121 124 127 130 133 136 140 143 146 149 153 156 160 163 167 170 174 178 182 185 189 193 197 201 206 210 214 219 223 227 232 237 242 246 251 256 261 267 272 277 283 288 294 300 306 312 318 324 330 337 344 350 357 364 371 379 386 394 402 410 418 427 435 444 453 462 472 481 491 501 512 530 550 575 600 625 650 675 700 725 750 800 850 900]
    #define WB_DB_DAY_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DB_NIGHT_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DB_RAIN_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DB_WATER_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DB_NETHER_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]
    #define WB_DB_END_I 64.0 //[1.0 1.5 2.0 3.0 4.5 6.0 9.0 12.0 18.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3072.0 4096.0]

    #define ENTITY_GN_AND_CT
    #define GENERATED_NORMAL_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 250 300 400]
    #define COATED_TEXTURE_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]

    #define GLOWING_ORE_MASTER 1 //[0 1 2]
    #define GLOWING_ORE_MULT 1.00 //[0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #if GLOWING_ORE_MASTER == 2 || SHADER_STYLE == 4 && GLOWING_ORE_MASTER == 1
        #define GLOWING_ORE_IRON
        #define GLOWING_ORE_GOLD
        #define GLOWING_ORE_COPPER
        #define GLOWING_ORE_REDSTONE
        #define GLOWING_ORE_LAPIS
        #define GLOWING_ORE_EMERALD
        #define GLOWING_ORE_DIAMOND
        #define GLOWING_ORE_NETHERQUARTZ
        #define GLOWING_ORE_NETHERGOLD
        #define GLOWING_ORE_GILDEDBLACKSTONE
        #define GLOWING_ORE_ANCIENTDEBRIS
        #define GLOWING_ORE_MODDED
    #endif

    #define GLOWING_AMETHYST 1 //[0 1 2]
    #define GLOWING_LICHEN 1 //[0 1 2]
    #define EMISSIVE_REDSTONE_BLOCK
    #define EMISSIVE_LAPIS_BLOCK
    #define EMISSIVE_EMERALD_BLOCK
    #define GLOWING_ARMOR_TRIM

    #define IPBR_EMISSIVE_MODE 1 //[1 3 2]
    #define IPBR_COMPATIBILITY_MODE

    #define NORMAL_MAP_STRENGTH 100 //[0 10 15 20 30 40 60 80 100 120 140 160 180 200]
    #define CUSTOM_EMISSION_INTENSITY 100 //[0 5 7 10 15 20 25 30 35 40 45 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 225 250]
    #define POM_DEPTH 0.80 //[0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define POM_QUALITY 128 //[16 32 64 128 256 512]
    #define POM_DISTANCE 32 //[16 24 32 48 64 128 256 512 1024]
    #define POM_LIGHTING_MODE 2 //[1 2]
    #define POM_ALLOW_CUTOUT
    #define DIRECTIONAL_BLOCKLIGHT 11 //[0 3 7 11]

    #define CAVE_LIGHTING 100 //[0 5 7 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300 325 350 375 400 425 450 475 500 550 600 650 700 750 800 850 900 950 1000 1100 1200 1300 1400 1500 1600]
    #define HELD_LIGHTING_MODE 2 //[0 1 2]
    #define BLOCKLIGHT_FLICKERING 4 //[0 2 3 4 5 6 7 8 9 10]
    #define AMBIENT_MULT 100 //[50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]
    #define PLAYER_SHADOW 1 //[-1 1]

    #define WAVING_SPEED 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define WAVING_I 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 50.0]
    #define WAVING_I_RAIN_MULT 100 //[25 50 75 100 125 150 175 200]
    #define NO_WAVING_INDOORS
    #define WAVING_FOLIAGE
    #define WAVING_LEAVES
    #define WAVING_LAVA
    #define WAVING_LILY_PAD
    #define WAVING_WATER_VERTEX
    #define WAVING_RAIN

    #define LEAVES_PHYSICS_MODE 3 //[0 1 2 3]
    #define LEAVES_PHYSICS_STRENGTH 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

    #define SPECIAL_PORTAL_EFFECTS

    #define SUN_ANGLE -40 //[-1 0 -20 -30 -40 -50 -60 60 50 40 30 20]

    #define SELECT_OUTLINE 1 //[0 1 3 4 2]
    //#define SELECT_OUTLINE_AUTO_HIDE
    #define SELECT_OUTLINE_I 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define SELECT_OUTLINE_R 1.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define SELECT_OUTLINE_G 0.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define SELECT_OUTLINE_B 1.75 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    //#define WORLD_OUTLINE
    #define WORLD_OUTLINE_THICKNESS 1 //[1 2 3 4]
    #define WORLD_OUTLINE_I 1.50 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00]
    #define WORLD_OUTLINE_ON_ENTITIES
    //#define DARK_OUTLINE
    #define DARK_OUTLINE_THICKNESS 1 //[1 2]

    #define HAND_SWAYING 0 //[0 1 2 3]
    #define SHOW_LIGHT_LEVEL 0 //[0 1 2 3]
    //#define REDUCE_CLOSE_PARTICLES
    //#define LESS_LAVA_FOG
    //#define SNOWY_WORLD
    //#define COLOR_CODED_PROGRAMS
    //#define GLOWING_COLORED_PARTICLES

    #define MOON_PHASE_INF_LIGHT
    #define MOON_PHASE_INF_ATMOSPHERE
    #define MOON_PHASE_INF_REFLECTION
    #define MOON_PHASE_FULL 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define MOON_PHASE_PARTIAL 0.85 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define MOON_PHASE_DARK 0.60 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

    //#define PIXELATED_SHADOWS
    //#define PIXELATED_BLOCKLIGHT
    //#define PIXELATED_AO
    #define PIXEL_SCALE 1 //[-2 -1 1 2 3 4 5]
    #define TEXTURE_RES 16 //[1 2 4 8 16 32 64 128 256]

    // ---- Color Correction (Iteration 45) --------------------------------
    // CC_MODE selects a tonemap + grading baseline; every slider below stays
    // live in all three modes and layers on top of it. At default slider values
    // CC_MODE 0 reproduces the pack's previous output exactly.
    //   0 Default       the pack's inherited BSL curve
    //   1 Complementary Complementary Reimagined r5.8.1's DoCompTonemap
    //   2 Realistic     Bliss's AgX + crosstalk + split-tone grading
    // See lib/post/colorCorrection.glsl.
    #define CC_SATURATION 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_CONTRAST 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_BRIGHTNESS 1.00 //[0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
    #define CC_CROSSTALK 0.00 //[-1.00 -0.80 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00]
    #define CC_CURVE_LOWER 0.00 //[-1.00 -0.80 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00]
    #define CC_CURVE_UPPER 0.00 //[-1.00 -0.80 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00]

    // Mode 2 (Realistic / AgX) emitter chroma rescue. AgX walks bright colours
    // toward white, which washes lava, fire and glowstone out compared to the
    // Complementary mode; this restores their hue at the tonemapped luminance.
    // Integer percent, because the GLSL preprocessor cannot compare floats and
    // the module gates on it with #if.
    //
    // DEFAULT 0 -- OFF, and that is deliberate. The final pass sees only colour
    // and depth, never block ids, so "this pixel is lava" has to be guessed from
    // brightness and saturation alone. A sunlit meadow under a clear sky clears
    // any such threshold just as easily as lava does, and the whole scene goes
    // neon. At 0 the block below is not compiled at all and Realistic is
    // bit-for-bit the grade it has always been. Raise it only if you actually
    // want the trade, and check a bright daytime scene, not just the lava.
    #define CC_EMITTER_CHROMA 0 //[0 10 20 30 40 50 60 70 80 90 100]

    // Mode 2 (Realistic / AgX) SKY chroma rescue. Same idea as the emitter one
    // above, but restricted by DEPTH to pixels with no geometry -- which is what
    // makes it safe where the emitter version was not. AgX flattens the sky's
    // blue to white; Complementary's Lottes curve, given the identical sky,
    // keeps it. This hands the sky's own chromaticity back at the luminance AgX
    // chose. Neutral input stays neutral, so clouds and the sun disc are not
    // tinted. 0 = untouched AgX sky, 100 = the sky's full original hue.
    #define CC_SKY_CHROMA 5 //[0 5 10 15 20 25 30 35 40 45 50 60 70 75 80 90 100]

    // How far the drawn sky loses its tint toward the horizon, in percent.
    // Real skies pale out low down; this reproduces that in the Default and
    // Complementary modes, where Realistic gets it for free from the chroma
    // rescue fading out at the same elevation. Affects the SKY only -- distance
    // fog takes a different path and is untouched. 0 = flat tint all the way
    // down, which is what it used to do.
    #define CC_SKY_HORIZON_FADE 55 //[0 10 20 30 40 50 55 60 70 80 90 100]

    // Mode 1 (Complementary) tonemap parameters
    #define TM_CONTRAST 1.05 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.60 1.70 1.80 1.90 2.00]
    #define TM_WHITE_PATH 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define TM_DARK_DESATURATION 0.25 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00]

    // Split toning: RGB tint per luma range. 1/1/1 leaves a range untouched.
    #define CC_SHADOW_R 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_SHADOW_G 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_SHADOW_B 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_SHADOW_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_MID_R 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_MID_G 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_MID_B 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_MID_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_HIGH_R 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_HIGH_G 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_HIGH_B 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
    #define CC_HIGH_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]

    // Sky colour balance: horizon vs zenith tint, and how far up the horizon
    // colour reaches. Works with either Sky Style.
    #define CC_SKY_BLEND 1.00 //[0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00 4.00]
    #define CC_HORIZON_R 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_HORIZON_G 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_HORIZON_B 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_HORIZON_I 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.75 2.00]
    #define CC_ZENITH_R 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_ZENITH_G 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_ZENITH_B 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
    #define CC_ZENITH_I 1.00 //[0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.75 2.00]

    #define T_EXPOSURE 1.40 //[0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.10 2.20 2.30 2.40 2.50 2.60 2.70 2.80]
    #define TM_WHITE_CURVE 2.0 //[1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
    #define T_LOWER_CURVE 1.10 //[0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define T_UPPER_CURVE 1.30 //[0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define T_SATURATION 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define T_VIBRANCE 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    //#define COLORGRADING
    #define GR_RR 100 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_RG 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_RB 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_RC 1.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define GR_GR 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_GG 100 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_GB 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_GC 1.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #define GR_BR 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_BG 0 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_BB 100 //[0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 108 116 124 132 140 148 156 164 172 180 188 196 200 212 224 236 248 260 272 284 296 300 316 332 348 364 380 396 400 424 448 472 496 500]
    #define GR_BC 1.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]

    #define LIGHT_COLOR_MULTS
    #define ATM_COLOR_MULTS
    // A non-default Color Correction Mode drives the environment palette
    // through these two multiplier chains, so they have to be live for it.
    #if CC_MODE > 0
        #ifndef LIGHT_COLOR_MULTS
            #define LIGHT_COLOR_MULTS
        #endif
        #ifndef ATM_COLOR_MULTS
            #define ATM_COLOR_MULTS
        #endif
    #endif
    #define LIGHT_MORNING_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_MORNING_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_MORNING_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_MORNING_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_MORNING_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_MORNING_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_MORNING_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_MORNING_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NOON_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NOON_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NOON_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NOON_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NOON_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NOON_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NOON_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NOON_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NIGHT_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NIGHT_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NIGHT_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NIGHT_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NIGHT_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NIGHT_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NIGHT_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NIGHT_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_RAIN_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_RAIN_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_RAIN_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_RAIN_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_RAIN_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_RAIN_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_RAIN_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_RAIN_I 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NETHER_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NETHER_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NETHER_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_NETHER_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NETHER_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NETHER_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NETHER_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_NETHER_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_END_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_END_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_END_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define LIGHT_END_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_END_R 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_END_G 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_END_B 1.00 //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define ATM_END_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

    #define XLIGHT_R 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define XLIGHT_G 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define XLIGHT_B 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
    #define XLIGHT_I 1.00 //[0.01 0.03 0.05 0.07 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

    //#define DREAM_TWEAKED_LIGHTING
    //#define DREAM_TWEAKED_BORDERFOG
    //#define FOLIAGE_ALT_SUBSURFACE

//Internal Settings//
    #define SIDE_SHADOWING
    #define SHADOW_FILTERING

    #define GLASS_OPACITY 0.25

    #define DIRECTIONAL_SHADING

    #define ATMOSPHERIC_FOG
    #define BLOOM_FOG

    #define GLOWING_ENTITY_FIX
    #define FLICKERING_FIX
    //#define SAFER_GENERATED_NORMALS

    #define SHADOW_FRUSTUM_FIT
//Extensions//

//Information//
    #define info0 0 //[0]
    #define info1 0 //[0]
    #define info2 0 //[0]
    #define info3 0 //[0]
    #define info4 0 //[0]
    #define info5 0 //[0]
    #define info6 0 //[0]
    #define info7 0 //[0]
    #define info8 0 //[0]
    #define info9 0 //[0]
    #define info10 0 //[0]

//Visual Style and Performance Setting Handling//
    #if RP_MODE == 1
        #define IPBR
        #define IPBR_PARTICLE_FEATURES
        #define GENERATED_NORMALS
        #define COATED_TEXTURES
        #define FANCY_GLASS
        //#define GREEN_SCREEN_LIME
    #endif
    #if RP_MODE >= 2
        #define CUSTOM_PBR
        #define POM
    #endif

    #if SHADER_STYLE == 1
        #define WATER_STYLE_DEFAULT 1
        //#define WATER_CAUSTIC_STYLE_DEFAULT 1
        #define AURORA_STYLE_DEFAULT 1
        #define SUN_MOON_STYLE_DEFAULT 1
        #define CLOUD_STYLE_DEFAULT 1
    #elif SHADER_STYLE == 4
        #define WATER_STYLE_DEFAULT 3
        //#define WATER_CAUSTIC_STYLE_DEFAULT 3
        #define AURORA_STYLE_DEFAULT 2
        #define SUN_MOON_STYLE_DEFAULT 2
        #define CLOUD_STYLE_DEFAULT 2
    #endif
    #if WATER_STYLE_DEFINE == -1
        #define WATER_STYLE WATER_STYLE_DEFAULT
    #else
        #define WATER_STYLE WATER_STYLE_DEFINE
    #endif
    #if WATER_CAUSTIC_STYLE_DEFINE == -1
        #define WATER_CAUSTIC_STYLE WATER_STYLE
    #else
        #define WATER_CAUSTIC_STYLE WATER_CAUSTIC_STYLE_DEFINE
    #endif
    // Iteration 29: Eclipse water is Water Style 4. Derive the internal flag the
    // whole Eclipse pipeline gates on (ECLIPSE_WATER == 1) from it, so choosing
    // "Eclipse" turns on the physics waves AND the full optical styling at once,
    // and any other Water Style (Vanilla / Reimagined / Unbound) leaves it 0 --
    // a byte-identical fallback to the Iteration 22 baseline. WATER_STYLE == 4
    // also satisfies RV's own WATER_STYLE >= 2 / >= 3 high-quality gates, so the
    // base water pipeline (tbnMatrix, normal maps, alpha) is fully active for
    // Eclipse to override.
    #if WATER_STYLE == 4
        #define ECLIPSE_WATER 1
    #else
        #define ECLIPSE_WATER 0
    #endif
    #if AURORA_STYLE_DEFINE == -1
        #define AURORA_STYLE AURORA_STYLE_DEFAULT
    #else
        #define AURORA_STYLE AURORA_STYLE_DEFINE
    #endif
    #if SUN_MOON_STYLE_DEFINE == -1
        #define SUN_MOON_STYLE SUN_MOON_STYLE_DEFAULT
    #else
        #define SUN_MOON_STYLE SUN_MOON_STYLE_DEFINE
    #endif
    #if CLOUD_STYLE_DEFINE == -1
        #define CLOUD_STYLE CLOUD_STYLE_DEFAULT
    #else
        #define CLOUD_STYLE CLOUD_STYLE_DEFINE
    #endif
    // Thanks to SpacEagle17 and isuewo for the sun angle handling
    #ifdef END
        const float sunPathRotation = 0.0;
    #else
        #if SUN_ANGLE == -1
            #if SHADER_STYLE == 1
                const float sunPathRotation = 0.0;
                #define PERPENDICULAR_TWEAKS
            #elif SHADER_STYLE == 4
                const float sunPathRotation = -40.0;
            #endif
        #elif SUN_ANGLE == 0
            const float sunPathRotation = 0.0;
            #define PERPENDICULAR_TWEAKS
        #elif SUN_ANGLE == 20
            const float sunPathRotation = 20.0;
        #elif SUN_ANGLE == 30
            const float sunPathRotation = 30.0;
        #elif SUN_ANGLE == 40
            const float sunPathRotation = 40.0;
        #elif SUN_ANGLE == 50
            const float sunPathRotation = 50.0;
        #elif SUN_ANGLE == 60
            const float sunPathRotation = 60.0;
        #elif SUN_ANGLE == -20
            const float sunPathRotation = -20.0;
        #elif SUN_ANGLE == -30
            const float sunPathRotation = -30.0;
        #elif SUN_ANGLE == -40
            const float sunPathRotation = -40.0;
        #elif SUN_ANGLE == -50
            const float sunPathRotation = -50.0;
        #elif SUN_ANGLE == -60
            const float sunPathRotation = -60.0;
        #endif
    #endif

    #if defined IRIS_FEATURE_HIGHER_SHADOWCOLOR && WATER_STYLE >= 2
        #define INTERACTIVE_WATER
        #define WATER_BUMP_INTERACTIVE 1.00 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
    #endif

    #if SHADOW_QUALITY >= 1
        #if SHADOW_QUALITY > 4 || SHADOW_SMOOTHING < 3
            const int shadowMapResolution = 4096;
        #else
            const int shadowMapResolution = 2048;
        #endif
    #else
        const int shadowMapResolution = 1024;
    #endif

    #if SSAO_I > 0
        #define SSAO_QUALI SSAO_QUALI_DEFINE
    #else
        #define SSAO_QUALI 0
    #endif
    #if LIGHTSHAFT_BEHAVIOUR > 0
        #define LIGHTSHAFT_QUALI LIGHTSHAFT_QUALI_DEFINE
    #else
        #define LIGHTSHAFT_QUALI 0
    #endif

    #if BLOCK_REFLECT_QUALITY >= 1
        #define LIGHT_HIGHLIGHT
    #endif
    #if BLOCK_REFLECT_QUALITY >= 2 && RP_MODE >= 1
        #define PBR_REFLECTIONS
    #endif
    #if BLOCK_REFLECT_QUALITY >= 3 && RP_MODE >= 1
        #define TEMPORAL_FILTER
    #endif

    #if DETAIL_QUALITY == 0 // Potato
        #undef PERPENDICULAR_TWEAKS
        #define LOW_QUALITY_NETHER_STORM
        #define LOW_QUALITY_ENDER_NEBULA
        #define WATER_MAT_QUALITY 1
    #endif
    #if DETAIL_QUALITY >= 1 // not an option for now
        #if TAA_MODE >= 1
            #define TAA
        #endif
        #define WATER_MAT_QUALITY 1
    #endif
    #if DETAIL_QUALITY >= 2 // Medium
        #undef WATER_MAT_QUALITY
        #define WATER_MAT_QUALITY 2
        #define FXAA_TAA_INTERACTION
        #define TAA_MOVEMENT_IMPROVEMENT_FILTER
    #endif
    #if DETAIL_QUALITY >= 3 // High
        #undef WATER_MAT_QUALITY
        #define WATER_MAT_QUALITY 3 // we use DETAIL_QUALITY >= 3 when writing in gbuffers_water because optifine bad
        #define HQ_NIGHT_NEBULA
        #define SKY_EFFECT_REFLECTION
        #define CONNECTED_GLASS_CORNER_FIX
        #define ACL_CORNER_LEAK_FIX
        #define DO_NETHER_VINE_WAVING_OUTSIDE_NETHER
        #define DO_MORE_FOLIAGE_WAVING
        #if RAIN_PUDDLES > 0
            #define PUDDLE_VOXELIZATION
        #endif
        #if CLOUD_QUALITY >= 3 && CLOUD_STYLE > 0 && CLOUD_STYLE != 50
            #define ENTITY_TAA_NOISY_CLOUD_FIX
        #endif
    #endif

//Define Handling//
    #ifdef OVERWORLD
        #if CLOUD_STYLE > 0 && CLOUD_STYLE != 50 && CLOUD_QUALITY > 0
            #define VL_CLOUDS_ACTIVE
            #if CLOUD_STYLE == 1
                #define CLOUDS_REIMAGINED
            #else
                // Unbound, and the catch-all. Styles 2 and 4 (the retired volumetric
                // pipeline) may still be sitting in an old options file; resolving
                // them here rather than leaving them unhandled keeps such a config
                // loading instead of failing to compile.
                #define CLOUDS_UNBOUND
            #endif
        #endif
    #else
        #undef LIGHT_HIGHLIGHT
        #undef CAVE_FOG
        #undef CLOUD_SHADOWS
        #undef SNOWY_WORLD
        #undef LIGHTSHAFT_SMOKE
    #endif
    #ifdef NETHER
        #undef ATMOSPHERIC_FOG
        #undef NO_WAVING_INDOORS
    #else
        #undef NETHER_STORM
    #endif
    #ifdef END
        #undef BLOOM_FOG
    #endif

    #ifndef BLOOM
        #undef BLOOM_FOG
    #endif

    #if defined PIXELATED_SHADOWS || defined PIXELATED_BLOCKLIGHT || defined PIXELATED_AO
        #if !defined GBUFFERS_BASIC && !defined DH_TERRAIN && !defined DH_WATER
            #define DO_PIXELATION_EFFECTS
        #endif
    #endif

    #if !defined GBUFFERS_TERRAIN && !defined PREPARE4
        #undef PIXELATED_BLOCKLIGHT
    #endif

    #ifdef BLOOM_FOG
        #if WORLD_BLUR > 0
            #define BLOOM_FOG_COMPOSITE3
        #elif defined MOTION_BLURRING
            #define BLOOM_FOG_COMPOSITE2
        #else
            #define BLOOM_FOG_COMPOSITE
        #endif
    #endif

    #if defined GBUFFERS_HAND || defined GBUFFERS_ENTITIES
        #undef SNOWY_WORLD
        #undef DISTANT_LIGHT_BOKEH
    #endif
    #if defined GBUFFERS_TEXTURED || defined GBUFFERS_BASIC
        #undef LIGHT_HIGHLIGHT
        #undef DIRECTIONAL_SHADING
        #undef SIDE_SHADOWING
    #endif
    #ifdef GBUFFERS_WATER
        #undef LIGHT_HIGHLIGHT
    #endif

    #ifndef GLOWING_ENTITY_FIX
        #undef GBUFFERS_ENTITIES_GLOWING
    #endif

    #if LIGHTSHAFT_QUALI > 0 && defined OVERWORLD && SHADOW_QUALITY > -1 || defined END
        #define LIGHTSHAFTS_ACTIVE
    #endif

    #if defined WAVING_FOLIAGE || defined WAVING_LEAVES || defined WAVING_LAVA || defined WAVING_LILY_PAD
        #define WAVING_ANYTHING_TERRAIN
    #endif

    #if LEAVES_PHYSICS_MODE == 1 || LEAVES_PHYSICS_MODE == 3
        #define LEAVES_PHYSICS_ENTITIES
    #endif
    #if LEAVES_PHYSICS_MODE == 2 || LEAVES_PHYSICS_MODE == 3
        #define LEAVES_PHYSICS_WEATHER
    #endif
    #if LEAVES_PHYSICS_MODE > 0
        #define LEAVES_PHYSICS
    #endif

    #if WATERCOLOR_R != 100 || WATERCOLOR_G != 100 || WATERCOLOR_B != 100
        #define WATERCOLOR_RM WATERCOLOR_R * 0.01
        #define WATERCOLOR_GM WATERCOLOR_G * 0.01
        #define WATERCOLOR_BM WATERCOLOR_B * 0.01
        #define WATERCOLOR_CHANGED
    #endif

    #if UNDERWATERCOLOR_R != 100 || UNDERWATERCOLOR_G != 100 || UNDERWATERCOLOR_B != 100
        #define UNDERWATERCOLOR_RM UNDERWATERCOLOR_R * 0.01
        #define UNDERWATERCOLOR_GM UNDERWATERCOLOR_G * 0.01
        #define UNDERWATERCOLOR_BM UNDERWATERCOLOR_B * 0.01
        #define UNDERWATERCOLOR_CHANGED
    #endif

    #if defined IS_IRIS && !defined IRIS_HAS_TRANSLUCENCY_SORTING
        #undef FANCY_GLASS
    #endif

    #ifdef DISTANT_HORIZONS
        #undef DISTANT_LIGHT_BOKEH
    #endif

    #if defined MC_GL_VENDOR_AMD || defined MC_GL_VENDOR_ATI
        #ifndef DEFERRED1
            #define FIX_AMD_REFLECTION_CRASH //BFARC: Fixes a driver crashing problem on AMD GPUs
        #endif
    #endif

//Activate Settings//
    #ifdef POM_ALLOW_CUTOUT
    #endif
    #ifdef BRIGHT_CAVE_WATER
    #endif
    #ifdef IPBR_PARTICLE_FEATURES
    #endif
    #ifdef COLORED_CANDLE_LIGHT
    #endif
    #ifdef PIXELATED_AO
    #endif
    #ifdef PIXELATED_BLOCKLIGHT
    #endif

//Very Common Stuff//
    #include "/lib/uniforms.glsl"

    #if ECLIPSE_TIME_ACTIVE >= 2
        // Iteration 36: self-contained cinematic time tracker (persistent
        // custom image + frameTimeCounter timeline + delta-trigger). Declares
        // the read interface for every program; the single-invocation writer
        // is compiled only in the compute wrappers (CSH).
        #include "/lib/misc/eclipseTimeTracker.glsl"
    #endif

    // Space Zoom Moon: persistent 1x1 timed-animation clock. Declares the
    // read interface everywhere; the single-invocation writer compiles only
    // in the compute wrappers (CSH). Same pattern as the eclipse tracker.
    #include "/lib/misc/moonZoomState.glsl"

    #if SHADOW_QUALITY == -1
      float blissNativeTimeAngle = worldTime / 24000.0;
    #else
      float tAmin     = fract(sunAngle - 0.033333333);
      float tAlin     = tAmin < 0.433333333 ? tAmin * 1.15384615385 : tAmin * 0.882352941176 + 0.117647058824;
      float hA        = tAlin > 0.5 ? 1.0 : 0.0;
      float tAfrc     = fract(tAlin * 2.0);
      float tAfrs     = tAfrc*tAfrc*(3.0-2.0*tAfrc);
      float tAmix     = hA < 0.5 ? 0.3 : -0.1;
      float blissNativeTimeAngle = (tAfrc * (1.0-tAmix) + tAfrs * tAmix + hA) * 0.5;
    #endif

    #if ECLIPSE_TIME_ACTIVE >= 2
      // ---- Iteration 36: 100% SELF-CONTAINED VISUAL CLOCK. ----
      // The Iris engine-side smooth() uniforms are abandoned for the animation
      // timeline: they could not be flushed from the shader, so back-to-back
      // time commands collapsed their (sin, cos) average into a degenerate
      // low-magnitude state that accumulated across triggers (2nd trigger
      // froze, 3rd snapped). Iteration 35's attempted re-base also crashed
      // compilation: its cloud-clock wrap used a bare "eclCloudD -= ..."
      // ASSIGNMENT STATEMENT at common.glsl global scope, which is illegal
      // GLSL (this scope only allows declarations with initializers) -- the
      // ANTLR ParseCancellationException at 'eclCloudD -='. Both problems are
      // gone: lib/misc/eclipseTimeTracker.glsl owns explicit state in a tiny
      // persistent custom image, updated once per frame by one shadowcomp
      // compute invocation. A wrap-aware DELTA-TRIGGER on the raw native sun
      // angle detects every /time set, bed sleep or dimension switch and
      // restarts a fresh smoothstep routine from t = 0 (from the current
      // visual angle, so mid-glide jumps hand over seamlessly); the timeline
      // runs purely on frameTimeCounter and completes in exactly
      // TIME_TRANSITION_SPEED seconds. State is fully overwritten on every
      // trigger, so the 1st, 2nd and 100th jump are identical -- no freeze,
      // no snap, no accumulation. This block only READS the tracker (one
      // texelFetch) and is pure declarations-with-initializers.
      // Slider 0.0 == OFF (Instant): the routine duration floors at 0.05 s.
      const bool eclEnabled = (TIME_TRANSITION_SPEED > 0.05);
      float eclSunAngle = eclEnabled ? EclipseVisualSunAngle() : fract(sunAngle);
      // RV's own sunAngle -> timeAngle remap, applied to the tracked visual
      // angle; in steady state the tracker equals native time exactly.
      float eTAmin = fract(eclSunAngle - 0.033333333);
      float eTAlin = eTAmin < 0.433333333 ? eTAmin * 1.15384615385 : eTAmin * 0.882352941176 + 0.117647058824;
      float eHA    = eTAlin > 0.5 ? 1.0 : 0.0;
      float eTAfrc = fract(eTAlin * 2.0);
      float eTAfrs = eTAfrc * eTAfrc * (3.0 - 2.0 * eTAfrc);
      float eTAmix = eHA < 0.5 ? 0.3 : -0.1;
      float eclEasedTimeAngle = (eTAfrc * (1.0 - eTAmix) + eTAfrs * eTAmix + eHA) * 0.5;
      float timeAngle = eclEnabled ? eclEasedTimeAngle : blissNativeTimeAngle;
      const bool eclActive = eclEnabled;
      float blissCloudTimeBase = eclEnabled
          ? (mod(worldDay, 100) * 24000.0 + eclSunAngle * 24000.0)
          : (worldTime + mod(worldDay, 100) * 24000.0);
    #else
      float timeAngle = blissNativeTimeAngle;
      float blissCloudTimeBase = (worldTime + mod(worldDay, 100) * 24000.0);
    #endif

    // ---- v1.4.1: SHADOWS FOLLOW THE CINEMATIC SUN --------------------------
    // Smooth Time Transition glides the DRAWN sun (GetSunVector reads the eased
    // timeAngle above), but the shadow map is projected with shadowModelView,
    // which the engine rebuilds from the raw game time -- so it snapped to the
    // new time instantly and the shadows sat still while the sun slid across
    // the sky. There is no uniform for "move the shadow projection", and the
    // engine will not walk the sun through the intermediate positions for us.
    //
    // The shadow map is our own data, though. Rotating world positions by the
    // same matrix on the way IN (program/shadow.glsl, when the depth is
    // rasterised) and on the way OUT (PlayerToShadow, when it is sampled)
    // leaves the map perfectly self-consistent, and swings the direction light
    // effectively arrives from. Storing R*P makes a pair of points shadow each
    // other when R*(P1-P2) lies along the engine's light axis, i.e. when
    // P1-P2 lies along inverse(R) * that axis -- so building R to carry the
    // VISUAL sun onto the NATIVE one lands the effective light exactly on the
    // sun the player can see.
    //
    // Both directions go through the SAME formula, and only their DIFFERENCE is
    // used, so whatever offset the pack's own time remap already puts between
    // its drawn sun and the engine's shadow light is preserved untouched.
    // Outside a transition the tracker sits on native time to within its own
    // steady-state pursuit lag -- about 0.0005 turns, i.e. a fifth of a degree
    // of rotation -- so ordinary play is visually untouched, and what little
    // there is now matches the sun that is actually drawn.
    //
    // Both sun directions lie in one fixed plane (the sun path), so this is a
    // plain rotation about that plane's normal by the angle between them. No
    // axis has to be derived from a cross product, which means no singularity
    // at the half-day jump where the two suns are exactly opposite.
    //
    // SHADOW_QUALITY -1 is excluded: it has no shadow map at all, and it also
    // derives blissNativeTimeAngle from worldTime instead of sunAngle, so the
    // two angles would not be comparable there.
    #if ECLIPSE_TIME_ACTIVE >= 2 && SHADOW_QUALITY > -1
        // Sun-path angle in TURNS, matching GetSunVector()'s own easing of
        // timeAngle. Kept unscaled so the two can be differenced with wrap.
        float eclSunPathTurns(float tA) {
            float a = fract(tA - 0.25);
            return a + (cos(a * 3.14159265358979) * -0.5 + 0.5 - a) / 3.0;
        }

        // Rodrigues rotation of phi radians about the unit axis n, column-major.
        mat3 eclAxisRotation(vec3 n, float phi) {
            float s = sin(phi);
            float c = cos(phi);
            float t = 1.0 - c;
            return mat3(
                t * n.x * n.x + c,       t * n.x * n.y + s * n.z, t * n.x * n.z - s * n.y,
                t * n.x * n.y - s * n.z, t * n.y * n.y + c,       t * n.y * n.z + s * n.x,
                t * n.x * n.z + s * n.y, t * n.y * n.z - s * n.x, t * n.z * n.z + c
            );
        }

        // GetSunVector() builds the sun as -sin(ang) * (1,0,0) + cos(ang) *
        // (0, cos(spr), -sin(spr)); the sun-path normal is the cross product of
        // those two basis vectors, which comes out as (0, sin(spr), cos(spr)) --
        // already unit length for any sunPathRotation. Left non-const on
        // purpose: GLSL 1.30 does not count built-in calls as constant
        // expressions, and half the programs here are #version 130.
        vec3 eclSunPathAxis = vec3(0.0, sin(sunPathRotation * 0.01745329251994),
                                        cos(sunPathRotation * 0.01745329251994));

        // Shortest signed arc from the visual sun to the native one.
        float eclShadowPhi = eclEnabled
            ? (fract(eclSunPathTurns(blissNativeTimeAngle) - eclSunPathTurns(eclEasedTimeAngle) + 0.5) - 0.5)
              * 6.28318530717959
            : 0.0;

        mat3 eclShadowRotation = eclAxisRotation(eclSunPathAxis, eclShadowPhi);

        #define ECLIPSE_SHADOW_ROTATION
    #endif

    #include "/lib/util/commonFunctions.glsl"

    #ifndef DISTANT_HORIZONS
        float renderDistance = far;
    #else
        float renderDistance = float(dhRenderDistance);
    #endif

    const float shadowMapBias = 1.0 - 25.6 / shadowDistance;
    #ifndef DREAM_TWEAKED_LIGHTING
        float noonFactor = sqrt(max(sin(timeAngle*6.28318530718),0.0));
    #else
        float noonFactor = pow(max(sin(timeAngle*6.28318530718),0.0), 0.2);
    #endif
    float nightFactor = max(sin(timeAngle*(-6.28318530718)),0.0);
    float invNightFactor = 1.0 - nightFactor;
    float rainFactor2 = rainFactor * rainFactor;
    float invRainFactor = 1.0 - rainFactor;
    float invNoonFactor = 1.0 - noonFactor;
    float invNoonFactor2 = invNoonFactor * invNoonFactor;

    float vsBrightness = clamp(screenBrightness, 0.0, 1.0);

    int modifiedWorldDay = int(mod(worldDay, 100) + 5.0);
    float syncedTime = (worldTime + modifiedWorldDay * 24000) * 0.05;

    float blissCloudSyncedTime = (blissCloudTimeBase + 120000.0) * 0.05;

    const float pi = 3.14159265359;
    const float goldenRatio = 1.61803398875;

    const float oceanAltitude = 61.9;

    #if IRIS_VERSION >= 10800
        vec3 cameraPositionBestFract = cameraPositionFract;
    #else
        vec3 cameraPositionBestFract = fract(cameraPosition);
    #endif

    #include "/lib/colors/ccPalette.glsl"
    #include "/lib/colors/blocklightColors.glsl"

    const vec3 caveFogColorRaw = vec3(0.13, 0.13, 0.15);
    #if CAVE_LIGHTING < 100
        vec3 caveFogColor = caveFogColorRaw * 0.7;
    #elif CAVE_LIGHTING == 100
        vec3 caveFogColor = caveFogColorRaw * (0.7 + 0.3 * vsBrightness); // Default
    #elif CAVE_LIGHTING > 100
        vec3 caveFogColor = caveFogColorRaw;
    #endif

    #if WATERCOLOR_MODE >= 2
        vec3 underwaterColorM1 = pow(fogColor, vec3(0.33, 0.21, 0.26));
    #else
        vec3 underwaterColorM1 = vec3(0.46, 0.62, 1.0);
    #endif
    #ifndef UNDERWATERCOLOR_CHANGED
        vec3 underwaterColorM2 = underwaterColorM1;
    #else
        vec3 underwaterColorM2 = underwaterColorM1 * vec3(UNDERWATERCOLOR_RM, UNDERWATERCOLOR_GM, UNDERWATERCOLOR_BM);
    #endif
    #if ECLIPSE_WATER == 1
        vec3 eclipseWaterAbsorb = vec3(ECLIPSE_WATER_ABSORB_R, ECLIPSE_WATER_ABSORB_G, ECLIPSE_WATER_ABSORB_B) * ECLIPSE_WATER_ABSORB_MULT;
        vec3 waterFogColor = exp(-eclipseWaterAbsorb * 6.0) * (0.2 + 0.1 * vsBrightness);
    #else
        vec3 waterFogColor = underwaterColorM2 * vec3(0.2 + 0.1 * vsBrightness);
    #endif

    #if NETHER_COLOR_MODE == 3
        float netherColorMixer = inNetherWastes + inCrimsonForest + inWarpedForest + inBasaltDeltas + inSoulValley;
        vec3 netherColor = mix(
            fogColor * 0.6 + 0.2 * normalize(fogColor + 0.0001),
            (
                inNetherWastes * vec3(0.38, 0.15, 0.05) + inCrimsonForest * vec3(0.33, 0.07, 0.04) +
                inWarpedForest * vec3(0.18, 0.1, 0.25) + inBasaltDeltas * vec3(0.25, 0.235, 0.23) +
                inSoulValley * vec3(0.1, vec2(0.24))
            ),
            netherColorMixer
        );
    #elif NETHER_COLOR_MODE == 2
        vec3 netherColor = fogColor * 0.6 + 0.2 * normalize(fogColor + 0.0001);
    #elif NETHER_COLOR_MODE == 0
        vec3 netherColor = vec3(0.7, 0.26, 0.08) * 0.6;
    #endif
    vec3 lavaLightColor = vec3(0.15, 0.06, 0.01);

    const vec3 endSkyColor = vec3(0.095, 0.07, 0.15) * 1.5;

    #if WEATHER_TEX_OPACITY == 100
        const float rainTexOpacity = 0.25;
        const float snowTexOpacity = 0.5;
    #else
        #define WEATHER_TEX_OPACITY_M 100.0 / WEATHER_TEX_OPACITY
        const float rainTexOpacity = pow(0.25, WEATHER_TEX_OPACITY_M);
        const float snowTexOpacity = pow(0.5, WEATHER_TEX_OPACITY_M);
    #endif

    #ifdef FRAGMENT_SHADER
        ivec2 texelCoord = ivec2(gl_FragCoord.xy);
    #endif

    const int cloudAlt1i = int(CLOUD_ALT1); // Old setting files can send float values
    const int cloudAlt2i = int(CLOUD_ALT2);

    const float OSIEBCA = 1.0 / 255.0; // One Step In Eight Bit Color Attachment
    /* materialMask steps
    0 to 240 - PBR Dependant:
        IntegratedPBR:
            0 to 99: deferredMaterials
                OSIEBCA * 0.0 = *Unused as 0.0 is the default value*
                OSIEBCA * 1.0 = Intense Fresnel
                OSIEBCA * 2.0 = Copper Fresnel
                OSIEBCA * 3.0 = Gold Fresnel
                OSIEBCA * 4.0 =
                OSIEBCA * 5.0 = Redstone Fresnel
            100 to 199: Exact copy of deferredMaterials but toned down reflection handling for entities
                materialMask += OSIEBCA * 100.0; // Entity Reflection Handling
            200 to 240: Random checks
                OSIEBCA * 240.0 = Green Screen Lime Blocks
        seuspbr:
            0 to 240: Increasing metalness
        labPBR:
            0 to 229: Increasing f0
            230 to 240: Consistent metalness with still increasing f0
    241 to 255 - PBR Independant:
        OSIEBCA * 241.0 = Water

        OSIEBCA * 252.0 = Versatile Selection Outline
        OSIEBCA * 253.0 = Reduced Edge TAA
        OSIEBCA * 254.0 = No SSAO, No TAA
        OSIEBCA * 255.0 = *Unused as 1.0 is the clear color*
    */

// 62 75 74 20 74 68 4F 73 65 20 77 68 6F 20 68 6F 70 65 20 69 6E 20 74 68 65 20 6C 69 6D 69 4E 61 6C 0A 77 69 6C 6C 20 72 65 6E 65 77 20 74 68 65 69 72 20 73 54 72 65 6E 67 74 48 2E 0A 74 68 65 79 20 77 69 6C 6C 20 73 6F 41 72 20 6F 6E 20 65 6C 79 54 72 61 73 20 6C 69 6B 65 20 70 68 61 6E 74 6F 6D 73 3B 0A 74 68 65 79 20 77 69 6C 6C 20 72 75 6E 20 61 6E 44 20 6E 6F 74 20 67 72 6F 77 20 77 65 41 72 79 2C 0A 74 68 65 59 20 77 69 6C 6C 20 77 61 6C 6B 20 61 6E 64 20 6E 6F 74 20 62 65 20 66 61 69 6E 74 2E
