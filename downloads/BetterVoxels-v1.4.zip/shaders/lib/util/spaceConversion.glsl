#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

vec3 ScreenToView(vec3 pos) {
    vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x,
                          gbufferProjectionInverse[1].y,
                          gbufferProjectionInverse[2].zw);
    vec3 p3 = pos * 2.0 - 1.0;
    vec4 viewPos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return viewPos.xyz / viewPos.w;
}

vec3 ViewToPlayer(vec3 pos) {
    return mat3(gbufferModelViewInverse) * pos + gbufferModelViewInverse[3].xyz;
}

vec3 PlayerToShadow(vec3 pos) {
    #ifdef ECLIPSE_SHADOW_ROTATION
        // Sampling side of the cinematic-sun shadow swing. program/shadow.glsl
        // rasterises the map through the same rotation, so the two stay in
        // lockstep; see the eclShadowRotation block in lib/common.glsl. The
        // matrix is the identity whenever the clock is not mid-transition.
        pos = eclShadowRotation * pos;
    #endif
    vec3 shadowpos = mat3(shadowModelView) * pos + shadowModelView[3].xyz;
    return projMAD(shadowProjection, shadowpos);
}

vec3 ShadowClipToShadowView(vec3 pos) {
    return mat3(shadowProjectionInverse) * pos;
}

vec3 ShadowViewToPlayer(vec3 pos) {
    #ifdef ECLIPSE_SHADOW_ROTATION
        // Inverse of the swing above. A rotation's inverse is its transpose,
        // and pos * M is transpose(M) * pos in GLSL.
        return (mat3(shadowModelViewInverse) * pos) * eclShadowRotation;
    #else
        return mat3(shadowModelViewInverse) * pos;
    #endif
}