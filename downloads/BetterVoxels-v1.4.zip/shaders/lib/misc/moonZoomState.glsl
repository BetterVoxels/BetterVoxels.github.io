// =============================================================================
//  SAMSUNG SPACE ZOOM MOON -- TIMED FOCUS CLOCK
// -----------------------------------------------------------------------------
//  The zoom effect has to play as a TIMED animation once the view passes a
//  trigger FOV -- not as a direct function of FOV. Mouse-wheel zoom moves the
//  FOV in discrete jumps (press C, scroll, scroll), so anything driven straight
//  off FOV can only snap between those steps: the "half-defocused" look was
//  simply an intermediate zoom step, never an animation. FOV is also NOT
//  available to shaders.properties, so the engine smooth() uniforms cannot time
//  it either (they can only read biome/weather/eyeBrightness/lightning).
//
//  So this module keeps its own clock, exactly like the proven pattern in
//  lib/misc/eclipseTimeTracker.glsl.
//
//  STATE (image.moonzoom_img, 1x1 RGBA32F, never cleared between frames):
//    texel (0,0): x = init magic (1234.5 -> state is valid)
//                 y = animation phase, 0 (idle) .. 1 (fully focused)
//                 z = last frame's frameTimeCounter (reset/wrap guard)
//
//  WRITER: MoonZoomUpdateState(), executed by EXACTLY ONE compute invocation per
//  frame (shadowcomp.csh -- the earliest always-on compute pass). Compiled only
//  where CSH is defined.
//
//  READER: MoonZoomPhase() -- a single texelFetch, core GLSL 1.30, so the
//  #version 130 programs read it exactly like the 430 ones.
// =============================================================================
#if SAMSUNG_MOON_ZOOM == 1
#ifndef INCLUDE_MOON_ZOOM_STATE
#define INCLUDE_MOON_ZOOM_STATE

// Where the defocus tops out, in animation phase. This is the seam between the
// two duration sliders, and the effect module centres its swap and blowout on
// it, so it lives here where both the writer and the reader can see it.
#define MZ_BLUR_PEAK 0.35

uniform sampler2D moonzoom_sampler;

// Read interface: the eased animation phase maintained by the writer below.
float MoonZoomPhase() {
    return texelFetch(moonzoom_sampler, ivec2(0, 0), 0).g;
}

#ifdef CSH
    layout(rgba32f) uniform image2D moonzoom_img;

    // Runs once per frame from a single shadowcomp invocation.
    void MoonZoomUpdateState() {
        // Vertical FOV from the inverse projection: proj^-1[1][1] = tan(fovy/2).
        float fov  = degrees(2.0 * atan(gbufferProjectionInverse[1][1]));
        float nowT = frameTimeCounter;

        vec4 s = imageLoad(moonzoom_img, ivec2(0, 0));

        if (s.x != 1234.5 || nowT < s.z - 0.5) {
            // Cold start, shader reload, or frameTimeCounter reset/wrap:
            // flush back to idle so the routine always begins from scratch.
            s = vec4(1234.5, 0.0, nowT, 0.0);
        } else {
            // dt is clamped to one second so a hitched frame eases gracefully
            // instead of leaping the whole animation in a single step.
            float dt = clamp(nowT - s.z, 0.0, 1.0);

            // Crossing the trigger FOV flips the target; the phase then walks
            // toward it at a fixed real-time rate, which is what makes this an
            // animation rather than an FOV readout.
            float target = fov <= MOON_ZOOM_TRIGGER_FOV ? 1.0 : 0.0;

            // The routine is split at MZ_BLUR_PEAK and each half owns its own
            // duration, so going soft and resolving sharp are paced separately.
            // Only the RATE changes per segment -- the phase still runs 0..1, so
            // every curve downstream stays expressed in phase and untouched.
            // Rewinding retraces the same per-segment timings.
            bool  lowSeg  = s.y < MZ_BLUR_PEAK;
            bool  goingIn = target > s.y;
            float tIn     = max(MOON_ZOOM_BLUR_IN_TIME, 0.05);
            float tOut    = max(MOON_ZOOM_BLUR_OUT_TIME, 0.05);
            float segLen  = lowSeg ? MZ_BLUR_PEAK : 1.0 - MZ_BLUR_PEAK;
            float segTime = lowSeg ? (goingIn ? tIn : tOut) : (goingIn ? tOut : tIn);

            s.y = clamp(s.y + sign(target - s.y) * dt * segLen / segTime, 0.0, 1.0);
            s.z = nowT;
        }

        imageStore(moonzoom_img, ivec2(0, 0), s);
    }
#endif

#endif // INCLUDE_MOON_ZOOM_STATE
#endif // SAMSUNG_MOON_ZOOM
