#ifndef INCLUDE_CC_PALETTE
    #define INCLUDE_CC_PALETTE

/*==============================================================================
    CC_MODE ENVIRONMENT PALETTES

    These feed the pack's existing light/atmosphere multiplier chain, so the
    mode reaches sunlight, moonlight, ambient, the sky gradient, horizon haze,
    atmospheric and border fog, clouds, reflections and block light -- not just
    the tonemap at the end of the frame.

    The user's own sliders in Color Correction multiply ON TOP of these, so
    every manual control stays live in every mode.

    Where the numbers come from
    ---------------------------
    Mode 1 values are measured differences between Complementary Reimagined
    r5.8.1 and what this pack currently ships, e.g. its noon sun
    vec3(0.65,0.55,0.375)*2.05 against ours vec3(0.7,0.55,0.4)*1.9, its 0.9x
    night light, its vec3(0.85,0.92,0.81) noon zenith tint that we lack, and its
    slightly less green torch vec3(0.1775,0.104,0.077).

    Because this pack is itself Complementary-derived, that delta is genuinely
    small -- Mode 1 is a correction towards stock Complementary, not a new look.

    Mode 2 values are hue ratios between Bliss v2.1.2's illuminants and ours:
    its sun vec3(1.0,0.91,0.81), moon vec3(0.908,0.9121,0.8948) and torch
    vec3(1.0,0.75,0.65). Each ratio is normalised against Rec.709 luminance, so
    it moves the palette without moving exposure. The result is a cooler, less
    orange daylight, a near-neutral moon instead of a blue one, and a softer
    torch -- which is what makes Bliss read as photographic.
==============================================================================*/

    #if CC_MODE == 1
        // ---- Complementary ----------------------------------------------
        const vec3 ccLightMorning = vec3(1.0000, 1.0000, 1.0000);
        const vec3 ccLightNoon    = vec3(1.0019, 1.0789, 1.0115);
        const vec3 ccLightNight   = vec3(0.9000, 0.9000, 0.9000);
        const vec3 ccLightRain    = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccAtmMorning   = vec3(0.9000, 0.9000, 0.8103);
        const vec3 ccAtmNoon      = vec3(0.8500, 0.9200, 0.8100);
        const vec3 ccAtmNight     = vec3(0.9000, 0.9000, 0.9000);
        const vec3 ccAtmRain      = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccBlocklight   = vec3(1.0000, 0.9630, 0.9935);

        // ---- SKY: Complementary's own, untouched ------------------------
        // This block was briefly given Realistic's saturation lift during the
        // v1.4.1 sky swap and it made the mode read far too bright -- the whole
        // point of Complementary is that it matches stock Complementary
        // Reimagined, so it keeps its own gradient AND its own ccSkyGradSat of
        // 1.00. Only Default took the vivid sky. See the Default block below.

        // Redistribution only: both ends stay at unit luminance, so this
        // shapes the gradient without changing how bright the sky is.
        const vec3 ccSkyHorizon   = vec3(1.0);
        const vec3 ccSkyZenith    = vec3(1.0);

        // Sky gradient base colours. Measured against Complementary Reimagined
        // r5.8.1: its noon zenith carries a vec3(0.85,0.92,0.81) factor we lack,
        // and its middle band is pow(skyColorM,1.5)*1.3 where ours is
        // skyColorM*1.15 -- together a cleaner, less red blue.
        const vec3 ccSkyNoonUp     = vec3(1.0);
        const vec3 ccSkyNoonMid    = vec3(1.0);
        const vec3 ccSkyNoonDown   = vec3(1.0);
        const vec3 ccSkySunsetUp   = vec3(1.0);
        const vec3 ccSkySunsetMid  = vec3(1.0);
        // Complementary's sunset constants match ours exactly, so this last
        // one is a deliberate lift of the blue end: it walks the horizon band
        // from pure orange towards the orange-pink Complementary is known for,
        // and takes some of the yellow out of it.
        const vec3 ccSkySunsetDown = vec3(1.0);
        // Night: Complementary's formula matches ours, so this is a small
        // deliberate desaturation so the moon disc reads clean white rather
        // than yellow against an over-blue sky.
        const vec3 ccSkyNightUp    = vec3(1.0);
        const vec3 ccSkyNightMid   = vec3(1.0);
        const vec3 ccSkyNightDown  = vec3(1.0);

        const float ccBlocklightI  = 1.00;

        // Physical-sky knobs (only consulted when Sky Style is Photon/Bliss)
        const vec3  ccSkyRayleigh   = vec3(1.0);
        const float ccSkyExposureDay   = 1.00;
        const float ccSkyExposureNight = 1.00;
        const float ccSkySatBoost      = 1.00;
        const vec3  ccSkyZenithTint    = vec3(1.0);
        const float ccSkyMieStrength   = 1.00;
        const float ccSkyGradSat       = 1.0 / SKY_SATURATION_V13_NEUTRAL;
        const float ccSkyLevel         = 1.00;
        
        // v1.3 sky port. SKY_BLUE ships at 1.50 and SKY_GLARE/CC_SKY_HORIZON
        // _FADE are v1.4 additions v1.3 never had, so each mode carries the
        // point at which those controls are IDENTITY. Neutral at the shipped default, as in v1.3.
        const float ccSkyBlueNeutral   = 1.50;
        const float ccSkyHorizonFade   = 0.0;
    #elif CC_MODE == 2
        // ---- Realistic (Bliss) ------------------------------------------
        const vec3 ccLightMorning = vec3(0.8107, 1.0762, 1.3505);
        const vec3 ccLightNoon    = vec3(0.8849, 1.0249, 1.2543);
        const vec3 ccLightNight   = vec3(0.9743, 1.0486, 0.7201);
        const vec3 ccLightRain    = vec3(1.0000, 1.0000, 1.0000);

        // The sky is lit by the same illuminants, but swings less far than the
        // direct light does, so these are the light ratios pulled back.
        const vec3 ccAtmMorning   = vec3(0.9148, 1.0343, 1.1577);
        const vec3 ccAtmNoon      = vec3(0.9309, 1.0149, 1.1526);
        const vec3 ccAtmNight     = vec3(0.9846, 1.0291, 0.8320);
        const vec3 ccAtmRain      = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccBlocklight   = vec3(0.8535, 1.0520, 1.2705);

        // ---- SKY: Complementary's sky, verbatim --------------------------
        // Realistic now renders the SAME sky as Complementary, value for
        // value. The two modes differ only in their tonemap, and that is the
        // whole problem: the identical blue that survives Complementary's
        // Lottes curve comes out of AgX white. Chasing it with a bluer palette
        // does not work -- AgX saturates all three channels before the ratio
        // between them can survive, so more chroma in, same white out.
        //
        // The compensation is done where the damage happens instead, by
        // ccRestoreSkyChroma() in lib/post/colorCorrection.glsl, which puts the
        // sky's own chromaticity back at the luminance AgX chose. That is a
        // ratio operation, so unlike a palette guess it does not depend on
        // knowing the sky's absolute brightness.
        const vec3 ccSkyHorizon   = vec3(1.03, 1.00, 0.97);
        const vec3 ccSkyZenith    = vec3(0.98, 0.99, 1.03);

        const vec3 ccSkyNoonUp     = vec3(0.8500, 0.9200, 0.8100);
        const vec3 ccSkyNoonMid    = vec3(0.9331, 1.0117, 1.0437);
        const vec3 ccSkyNoonDown   = vec3(0.9821, 0.9875, 0.9587);
        const vec3 ccSkySunsetUp   = vec3(0.9000, 0.9000, 0.8103);
        const vec3 ccSkySunsetMid  = vec3(1.0000, 0.9900, 1.0400);
        const vec3 ccSkySunsetDown = vec3(1.0000, 0.9600, 1.1200);
        const vec3 ccSkyNightUp    = vec3(1.0300, 1.0000, 0.9500);
        const vec3 ccSkyNightMid   = vec3(1.0200, 1.0000, 0.9650);
        const vec3 ccSkyNightDown  = vec3(1.0200, 1.0000, 0.9700);

        const float ccBlocklightI  = 0.92;

        // Bliss's own Rayleigh coefficients and zenith solve. These only apply
        // when Sky Style is set to Photon/Bliss, which is not the default, but
        // Realistic is the mode that mode was authored for, so it keeps them.
        const vec3  ccSkyRayleigh   = vec3(0.7196, 0.8078, 0.8113);
        const float ccSkyExposureDay   = 0.0999;
        const float ccSkyExposureNight = 0.3500;
        const float ccSkySatBoost      = 1.0512;
        const vec3  ccSkyZenithTint    = vec3(0.287, 0.701, 2.544);
        const float ccSkyMieStrength   = 0.70;
        const float ccSkyGradSat       = 1.00;
        const float ccSkyLevel         = 1.00;
        
        // v1.3 sky port. SKY_BLUE ships at 1.50 and SKY_GLARE/CC_SKY_HORIZON
        // _FADE are v1.4 additions v1.3 never had, so each mode carries the
        // point at which those controls are IDENTITY. Realistic keeps v1.4 behaviour unchanged.
        const float ccSkyBlueNeutral   = 1.00;
        const float ccSkyHorizonFade   = 1.0;
    #else
        // ---- Default: lighting neutral, output unchanged ------------------
        const vec3 ccLightMorning = vec3(1.0);
        const vec3 ccLightNoon    = vec3(1.0);
        const vec3 ccLightNight   = vec3(1.0);
        const vec3 ccLightRain    = vec3(1.0);

        const vec3 ccAtmMorning   = vec3(1.0);
        const vec3 ccAtmNoon      = vec3(1.0);
        const vec3 ccAtmNight     = vec3(1.0);
        const vec3 ccAtmRain      = vec3(1.0);

        const vec3 ccBlocklight   = vec3(1.0);

        // ---- SKY SWAP (v1.4.1) -------------------------------------------
        // The three modes' SKIES were exchanged on request: Default and
        // Complementary now render the shaped, saturated gradient that used to
        // belong to Realistic, and Realistic renders the plain azure sky that
        // used to be Default's.
        //
        // Only the ccSky* entries moved. ccLight*, ccAtm* and ccBlocklight*
        // stayed where they were, because those are what actually give each
        // mode its identity -- Complementary's warmer sun, Realistic's cooler
        // Bliss illuminant and dimmer block light are all still in place. So a
        // mode still grades the world its own way; only the backdrop swapped.
        //
        // Consequence worth knowing: Default is no longer a pure passthrough
        // for the sky. Its lighting is still untouched, but the sky gradient
        // now carries Complementary's shape plus the 1.45 saturation lift.
        const vec3 ccSkyHorizon   = vec3(1.0);
        const vec3 ccSkyZenith    = vec3(1.0);

        const vec3 ccSkyNoonUp     = vec3(1.0);
        const vec3 ccSkyNoonMid    = vec3(1.0);
        const vec3 ccSkyNoonDown   = vec3(1.0);
        const vec3 ccSkySunsetUp   = vec3(1.0);
        const vec3 ccSkySunsetMid  = vec3(1.0);
        const vec3 ccSkySunsetDown = vec3(1.0);
        const vec3 ccSkyNightUp    = vec3(1.0);
        const vec3 ccSkyNightMid   = vec3(1.0);
        const vec3 ccSkyNightDown  = vec3(1.0);

        const float ccBlocklightI  = 1.00;

        const vec3  ccSkyRayleigh   = vec3(0.7196, 0.8078, 0.8113);
        const float ccSkyExposureDay   = 0.0999;
        const float ccSkyExposureNight = 0.3500;
        const float ccSkySatBoost      = 1.0512;
        const vec3  ccSkyZenithTint    = vec3(0.287, 0.701, 2.544);
        const float ccSkyMieStrength   = 0.70;
        const float ccSkyGradSat       = 1.0 / SKY_SATURATION_V13_NEUTRAL;
        const float ccSkyLevel         = 1.00;
        
        // v1.3 sky port. SKY_BLUE ships at 1.50 and SKY_GLARE/CC_SKY_HORIZON
        // _FADE are v1.4 additions v1.3 never had, so each mode carries the
        // point at which those controls are IDENTITY. Neutral at the shipped default, as in v1.3.
        const float ccSkyBlueNeutral   = 1.50;
        const float ccSkyHorizonFade   = 0.0;
    #endif

#endif //INCLUDE_CC_PALETTE
