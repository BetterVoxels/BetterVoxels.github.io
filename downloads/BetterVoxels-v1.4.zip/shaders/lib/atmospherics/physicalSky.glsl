#ifndef INCLUDE_PHYSICAL_SKY
    #define INCLUDE_PHYSICAL_SKY

    #include "/lib/colors/ccPalette.glsl"

/*==============================================================================
    PHYSICAL ATMOSPHERE  --  Rayleigh / Mie / ozone scattering
    Adapted from Photon by SixthSurge (include/sky/atmosphere.glsl).

    Photon evaluates its atmosphere once per frame into a precomputed 3D LUT
    (image/atmosphere/scattering.dat) and samples that everywhere.  This pack
    has no such pass -- GetSky() is called per pixel from gbuffers, deferred
    and composite alike -- so a LUT would have to be bound to every stage.
    Instead the same physics is evaluated directly, as a short quadrature
    along the view ray, and calibrated against Photon's LUT:

      * Scattering coefficients, scale heights, the Mie anisotropy and the
        ozone profile are Photon's own numbers, kept in linear Rec.709 (this
        pack's working space) rather than converted to Rec.2020.
      * Photon's 4-term ozone profile is approximated by two gaussians, matching
        its vertical column to 0.2%.
      * The multiple-scattering term -- what keeps a twilight sky blue overhead
        instead of collapsing to red -- was measured directly against the LUT.
        It turned out to depend almost entirely on the sun elevation, so it
        reduces to one smooth per-pixel curve (msA/msC/msG below).
      * The horizon lift and stretch reproduce the way Photon's LUT mapping
        compresses the horizon band.

    Against Photon's LUT the result holds a mean normalised-RGB error of ~0.07
    and a mean luminance error of ~14% from noon through sunset.

    nu is constant along the view ray for a distant light, so both phase
    functions leave the loop; the quadrature only accumulates the Rayleigh,
    Mie and multiple-scattering weights, which depend on (mu, muS) alone.
    That is what makes a single evaluation serve both sun and moon.
==============================================================================*/

    // -- Atmosphere geometry (metres) -------------------------------------
    const float atmPlanetR = 6371000.0;
    const float atmTopR    = 6481000.0;
    const float atmHR      = 8400.0;  // Rayleigh scale height
    const float atmHM      = 1250.0;  // Mie scale height

    // -- Scattering / extinction coefficients (linear Rec.709, per metre) --
    const vec3 atmBetaR = vec3(8.059375432e-06, 1.671209429e-05, 4.080133294e-05) * ccSkyRayleigh;
    const vec3 atmBetaM = vec3(1.666442358e-06, 1.812685127e-06, 1.958927896e-06);
    const vec3 atmBetaO = vec3(8.304280072e-07, 1.314911970e-06, 5.440679729e-08);
    const float atmMieAlbedo = 0.9;

    // -- Ozone: two-gaussian fit of Photon's profile, altitude in km -------
    const float atmOzColumn  = 19276.94; // vertical column, metres * rel. density
    const float atmOzRcpPeak = 1.004461; // 1 / density at the layer peak
    const float atmOzShellX  = (atmPlanetR + 10802.0) / 37119.0;

    // -- Multiple scattering, measured against Photon's LUT ----------------
    const vec3 atmMsA = vec3(0.05892, 0.05747, 0.07319);
    const vec3 atmMsC = vec3(0.07153, 0.02026, 0.04834);
    const vec3 atmMsG = vec3(1.08401, 0.79314, 0.92317);

    // -- Exposure curve, fitted so the physical sky lands inside this pack's
    //    existing brightness range (so fog, bloom and tonemapping stay put).
    //    Fitted against the mean luminance of the original sky over the whole
    //    hemisphere, sampled across the full day/night cycle. --
    const float atmDayScale     = 20.0547;
    const float atmNightScale   = 2.84800;
    const float atmSunsetBoost  = 0.522533;
    const float atmSunsetRange  = 0.595200;
    const float atmTwilightPeak = 44.9110;
    const float atmTwilightPos  = 0.0117745;
    const float atmTwilightWid  = 0.0562150;
    const float atmDayBlendLo   = -0.363784;
    const float atmDayBlendRcp  = 1.345085; // 1 / (0.379664 - atmDayBlendLo)

    // -- Light tints (Photon's, normalised to leave luminance alone) -------
    const vec3 atmSunTintWarm  = vec3(1.178, 0.9426, 1.0436); // morning / evening
    const vec3 atmSunTintBlue  = vec3(1.1224, 0.9452, 1.1815); // blue hour
    // Photon's raw moon tint is vec3(0.799,1.008,1.511). Stacked on a sky that
    // is already Rayleigh-blue it drove the night dome to a ~10:1 blue/red
    // ratio, against which a neutral moon disc reads yellow. Pulled halfway
    // back to neutral: still a cool moon, but the disc stays white.
    const vec3 atmMoonTint     = vec3(0.900, 1.004, 1.230);

    const vec3 atmLumWeights = vec3(0.2126, 0.7152, 0.0722);

    // Relative ozone density at altitude h (metres).
    float AtmOzoneDensity(float h) {
        float a = h * 0.001;
        float d1 = (a - 23.2508) * 0.14367; // 1 / 6.9602
        float d2 = (a - 25.4680) * 0.06676; // 1 / 14.9781
        return 0.5158 * exp(-d1 * d1) + 0.4904 * exp(-d2 * d2);
    }

    // Airmass along a slanted ray relative to a vertical one.
    // Source: http://www.thetenthplanet.de/archives/4519 (as used by Photon)
    float AtmChapman(float x, float cosTheta) {
        float c = sqrt(1.57079632679 * x);
        if (cosTheta >= 0.0) {
            return c / ((c - 1.0) * cosTheta + 1.0);
        }
        float sinTheta = sqrt(clamp(1.0 - cosTheta * cosTheta, 0.0, 1.0));
        // The exponent is clamped only to stay inside float range; the optical
        // depth it feeds is already large enough to zero the transmittance.
        float grazing = 2.0 * c * exp(min(x - x * sinTheta, 40.0)) * sqrt(sinTheta);
        return max(c / min((c - 1.0) * cosTheta - 1.0, -1e-6) + grazing, 0.0);
    }

    // Optical depth from altitude h towards a light at cos-zenith muS.
    vec3 AtmLightOpticalDepth(float h, float muS) {
        float r = atmPlanetR + h;
        float amR = atmHR * exp(-h / atmHR) * AtmChapman(r / atmHR, muS);
        float amM = atmHM * exp(-h / atmHM) * AtmChapman(r / atmHM, muS);
        float amO = min(atmOzColumn * AtmChapman(atmOzShellX, muS)
                      * (AtmOzoneDensity(h) * atmOzRcpPeak), atmOzColumn * 14.0);
        return atmBetaR * amR + atmBetaM * amM + atmBetaO * amO;
    }

    float AtmPhaseRayleigh(float nu) {
        return 0.05968310365 * (1.0 + nu * nu); // 3 / (16 pi)
    }

    float AtmPhaseMie(float nu) {
        const float g = SKY_MIE_G;
        const float gg = g * g;
        float d = max(1.0 + gg - 2.0 * g * nu, 1e-4);
        return (1.0 - gg) * 0.07957747155 * inversesqrt(d) / d;
    }

    // Photon's blue-hour weight: a narrow bell just after the sun sets.
    float AtmBlueHour(float sunHeight) {
        float d = sunHeight + 0.09604;
        return clamp((exp(-190.0 * d * d) - 0.05) / 0.95, 0.0, 1.0);
    }

    /*
        Scattered radiance towards a view direction.
          VdotU  cos(view, up)
          VdotS  cos(view, sun)
        SdotU and sunVisibility come from the including program.
    */
    vec3 GetPhysicalSky(float VdotU, float VdotS, int steps) {
        // The lit body is whichever of sun/moon is above the horizon, so one
        // quadrature covers both; only the phase and the tint differ.
        float muS = abs(SdotU);
        float nuLoop = mix(-VdotS, VdotS, sunVisibility);

        // Horizon handling, matching Photon's LUT mapping
        float muEff = VdotU + SKY_HORIZON_LIFT * pow(clamp(1.0 - VdotU, 0.0, 1.0), 12.0);
        muEff = clamp(muEff, -1.0, 1.0);
        if (muEff > 0.0) muEff *= pow(muEff, SKY_HORIZON_STRETCH);

        // Below the horizon the grazing path runs away into an over-bright red
        // band, and in reality that light is blocked by the ground long before
        // it gets there. Photon clamps the sampled elevation to the horizon
        // (its SKY_GROUND path); do the same, then dim, which reproduces the
        // gradient sky's own behaviour for callers that skip the ground factor.
        float horizonMu = mix(-0.01, 0.03, smoothstep(-0.05, 0.1, muS));
        muEff = max(muEff, horizonMu);

        float rmu = atmPlanetR * muEff;
        float tMax = -rmu + sqrt(max(rmu * rmu - atmPlanetR * atmPlanetR
                                   + atmTopR * atmTopR, 0.0));

        vec3 accR = vec3(0.0), accM = vec3(0.0), accMS = vec3(0.0), tau = vec3(0.0);

        float rcpSteps = 1.0 / float(steps);
        for (int i = 0; i < steps; i++) {
            // Quadratic spacing: dense near the viewer, where the air is dense
            float e0 = float(i) * rcpSteps;
            float e1 = float(i + 1) * rcpSteps;
            e0 *= e0;
            e1 *= e1;
            float t = tMax * (0.5 * (e0 + e1));
            float ds = tMax * (e1 - e0);

            float r = sqrt(atmPlanetR * atmPlanetR + t * t + 2.0 * atmPlanetR * t * muEff);
            float h = max(r - atmPlanetR, 0.0);

            float dR = exp(-h / atmHR);
            float dM = exp(-h / atmHM);
            float dO = AtmOzoneDensity(h);

            vec3 stepTau = (atmBetaR * dR + atmBetaM * dM + atmBetaO * dO) * ds;
            vec3 tView = exp(-min(tau + 0.5 * stepTau, vec3(60.0)));

            // cos(light zenith) at the sample point, with planet curvature
            float muSh = clamp((atmPlanetR * muS + t * nuLoop) / max(r, 1.0), -1.0, 1.0);
            vec3 tLight = exp(-min(AtmLightOpticalDepth(h, muSh), vec3(60.0)));

            vec3 w = tView * tLight * ds;
            accR += dR * w;
            accM += dM * w;
            accMS += (atmBetaR * dR + atmBetaM * (dM * atmMieAlbedo)) * tView * ds;
            tau += stepTau;
        }

        // Single scattering: phases applied outside the loop, once per body
        vec3 sR = accR * atmBetaR;
        vec3 sM = accM * (atmBetaM * (atmMieAlbedo * ccSkyMieStrength * SKY_MIE_STRENGTH));
        vec3 singleSun  = sR * AtmPhaseRayleigh(VdotS)  + sM * AtmPhaseMie(VdotS);
        vec3 singleMoon = sR * AtmPhaseRayleigh(-VdotS) + sM * AtmPhaseMie(-VdotS);
        vec3 scattering = mix(singleMoon, singleSun, sunVisibility);

        // Multiple scattering
        vec3 msS = clamp((vec3(muS) + atmMsC) / (vec3(1.0) + atmMsC), 0.0, 1.0);
        scattering += accMS * (atmMsA * pow(msS, atmMsG)) * SKY_MULTI_SCATTER;

        // -- Exposure -----------------------------------------------------
        float blueHour = AtmBlueHour(SdotU);

        float dayW = clamp((SdotU - atmDayBlendLo) * atmDayBlendRcp, 0.0, 1.0);
        dayW = dayW * dayW * (3.0 - 2.0 * dayW);

        float dayScale = atmDayScale * SKY_DAY_I * ccSkyExposureDay
                       * (1.0 + atmSunsetBoost * clamp(1.0 - abs(SdotU) / atmSunsetRange, 0.0, 1.0));
        float twilight = (SdotU - atmTwilightPos) / atmTwilightWid;
        float scale = mix(atmNightScale * SKY_NIGHT_I * ccSkyExposureNight, dayScale, dayW)
                    + atmTwilightPeak * SKY_TWILIGHT_I * ccSkyExposureDay * exp(-twilight * twilight);

        // -- Light tint ---------------------------------------------------
        float warmW = clamp(1.0 - abs(SdotU - 0.17) / 0.40, 0.0, 1.0);
        vec3 sunTint = mix(vec3(1.0), atmSunTintWarm, warmW * warmW);
             sunTint = mix(sunTint, sunTint * atmSunTintBlue, blueHour);
        vec3 tint = mix(atmMoonTint, sunTint, sunVisibility);

        // Zenith tint: deepens the blue overhead without touching the horizon
        // haze. Ramped by view elevation so the two ends stay independent.
        float zenithW = pow(clamp(VdotU, 0.0, 1.0), 1.7);
        vec3 zenithTint = mix(vec3(1.0), ccSkyZenithTint * vec3(1.0, 1.0, SKY_ZENITH_BLUE), zenithW);

        vec3 finalSky = scattering * (scale * SKY_BRIGHTNESS) * tint * zenithTint;

        // -- Saturation (Photon's atmosphere_post_processing) --------------
        float sat = SKY_SATURATION * ccSkySatBoost + 0.20 * blueHour;

        // The analytic grazing path runs hotter and much more saturated than
        // Photon's LUT does near the horizon, which showed up as a hard yellow
        // band at low sun. Bleed saturation out of the horizon band, weighted
        // by how low the sun is, so the band stays warm without going acid.
        float horizonBand = 1.0 - clamp(abs(VdotU) * 3.5, 0.0, 1.0);
        float lowSun = 1.0 - clamp(abs(SdotU) * 3.5, 0.0, 1.0);
        sat -= SKY_HORIZON_DESAT * horizonBand * horizonBand * lowSun;

        finalSky = mix(vec3(dot(finalSky, atmLumWeights)), finalSky, max(sat, 0.0));

        // Dimming below the horizon, saturating about 20 degrees down, which is
        // where the gradient sky settled too.
        float below = clamp(-VdotU * 2.857143, 0.0, 1.0);
        finalSky *= mix(1.0, SKY_GROUND_DIM, below * below * (3.0 - 2.0 * below));

        return max(finalSky, vec3(0.0));
    }

#endif //INCLUDE_PHYSICAL_SKY
