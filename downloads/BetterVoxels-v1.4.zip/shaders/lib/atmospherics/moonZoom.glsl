// =============================================================================
//  SAMSUNG SPACE ZOOM MOON  (experimental)
// -----------------------------------------------------------------------------
//  Once the view zooms past MOON_ZOOM_TRIGGER_FOV, a TIMED animation plays out
//  over BLUR_IN + BLUR_OUT seconds: the moon defocuses, its exposure blows
//  out, and it resolves as a sharp HD photo while the sky sinks toward deep
//  space. The clock is NOT derived from FOV here -- mouse-wheel zoom steps the
//  FOV in discrete jumps, so an FOV-driven curve could only snap. The phase
//  comes from lib/misc/moonZoomState.glsl (a persistent 1x1 image ticked once
//  per frame).
//
//  Called in gbuffers_skybasic AFTER the pack's procedural moon has been drawn,
//  so the HD disc lands on top of it; the darkening step then dims that
//  procedural moon + its glare, which removes the "two moons" look. Both discs
//  are centred on -sunVec, so they are concentric by construction.
//
//  The HD moon photo is bound to colortex10 for the gbuffers stage only (see
//  shaders.properties); colortex10 is never read by any gbuffers program, so it
//  is a free sampler there. Disk size / brightness / sky darkening / defocus /
//  bloom / flash are all sliders, since this was authored without a renderer.
// =============================================================================
#if SAMSUNG_MOON_ZOOM == 1
#ifndef INCLUDE_MOON_ZOOM
#define INCLUDE_MOON_ZOOM

uniform sampler2D colortex10;

// Moon phase, replicated VERBATIM from the pack's own carving in
// gbuffers_skybasic (the SUN_MOON_STYLE >= 2 branch), so the HD disc's
// terminator lands exactly where the procedural moon's does.
//
// A hand-rolled terminator cannot be made to line up by tuning: the pack does
// not shade along a straight line at all. It rebuilds a SECOND celestial vector
// offset in time by moonCrescentOffset and carves the crescent with the dot
// product against it, so the lit fraction follows that offset, not the phase
// index. Matching therefore means running the same math on the same inputs.
float mzPhaseShade(vec3 nViewPosM) {
    #if SUN_MOON_STYLE >= 2
        if (moonPhase < 1) return 1.0;   // full moon: the pack carves nothing

        #if SUN_MOON_STYLE == 2
            float moonCrescentOffset = 0.0055;
            float moonPhaseFactor1 = 2.45;
            float moonPhaseFactor2 = 750.0;
        #else
            float moonCrescentOffset = 0.0042;
            float moonPhaseFactor1 = 2.2;
            float moonPhaseFactor2 = 1000.0;
        #endif

        float moonPhaseOffset = moonPhase != 4 ? moonCrescentOffset : 0.0;
        if (moonPhase > 4) moonPhaseOffset = -moonPhaseOffset;

        float ang = fract(timeAngle - (0.25 + moonPhaseOffset));
        ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
        vec2 sunRotationData2 = vec2(cos(sunPathRotation * 0.01745329251994),
                                    -sin(sunPathRotation * 0.01745329251994));
        vec3 rawSunVec2 = (gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData2) * 2000.0, 1.0)).xyz;

        float moonPhaseVdosS = dot(nViewPosM, normalize(rawSunVec2));
        return pow2(1.0 - min1(pow(abs(moonPhaseVdosS), moonPhaseFactor2) * moonPhaseFactor1));
    #else
        return 1.0;   // styles below 2 use vanilla textures, which carry the phase
    #endif
}

// Blend the zoomed HD moon over the existing sky colour, or return it unchanged.
vec3 ApplyMoonZoom(vec3 sky, vec3 nViewPos, vec3 sunVecM, vec3 upVecM, float sunVisibilityM) {
    // Timed animation phase: 0 = idle (nothing drawn), 1 = fully focused.
    float phase = MoonZoomPhase();
    if (phase <= 0.001 || sunVisibilityM > 0.5) return sky;   // moon side only

    // --- choreography -------------------------------------------------------
    // Sine ease-out on every term: quick off the mark, gently settling, and
    // smooth throughout because its derivative is continuous.
    //   - A symmetric sin(phase*PI) curve was ease-IN: the picture hung soft and
    //     only snapped sharp at the very end, and that late snap read as the swap.
    //   - An exponential 1-2^-10t overcorrected: it completes ~99% of the move in
    //     the first third and then sits still, which reads as a snap followed by
    //     dead time -- harsh and unnatural.
    // sin(t*PI/2) sits between the two: at the halfway point it is 0.71 done, so
    // the motion stays visible across the whole routine instead of front-loading.
    // Darkening runs on a compressed schedule -- done by 40% of the routine --
    // so the backdrop is already deep space while the moon is still resolving,
    // instead of still creeping darker at the very end.
    float darkT = sin(min(phase / 0.40, 1.0) * 1.5707963);

    // Defocus eases into its peak at MZ_BLUR_PEAK, then eases back out to sharp.
    float blurAmount;
    if (phase < MZ_BLUR_PEAK) {
        blurAmount = sin(phase / MZ_BLUR_PEAK * 1.5707963);
    } else {
        blurAmount = 1.0 - sin((phase - MZ_BLUR_PEAK) / (1.0 - MZ_BLUR_PEAK) * 1.5707963);
    }

    // The HD moon washes in on the same gentle ease-out, so it is already there
    // while the blowout still covers it and has no late arrival to notice.
    float revealT = sin(clamp((phase - 0.20) / 0.80, 0.0, 1.0) * 1.5707963);

    // Applied to EVERYTHING already drawn (sky + the pack's procedural moon +
    // its glare + stars), so the bright procedural crescent is crushed and only
    // the HD disc remains prominent.
    sky *= mix(vec3(1.0), vec3(0.62, 0.72, 1.0) * MOON_ZOOM_SKY_DARKNESS, darkT);

    vec3 moonDir = -sunVecM;
    float VdotMoon = dot(nViewPos, moonDir);
    float moonCos = cos(radians(MOON_ZOOM_DISK_SIZE));   // angular radius slider

    // Configurable bloom halo radiating from the HD moon. Gaussian spread (not a
    // plain exponential) so there is no visible ring at the limb; near-white cool
    // tint so it reads as moonlight spilling into the sky, not a blue vignette.
    float centerAng = acos(clamp(VdotMoon, -1.0, 1.0));      // radians from centre
    float diskR     = radians(MOON_ZOOM_DISK_SIZE);
    float bloomOut  = diskR * MOON_ZOOM_BLOOM_SIZE;
    float bt        = clamp((centerAng - diskR) / max(bloomOut - diskR, 1e-4), 0.0, 1.0);
    float glow      = exp(-bt * bt * 3.5) * MOON_ZOOM_BLOOM * revealT;
    sky += vec3(0.68, 0.76, 0.90) * glow;

    // --- exposure blowout ---------------------------------------------------
    // Realised as EXPOSURE on the object, not as a white overlay: the disc's own
    // radiance is multiplied up until it clips, the way a real overexposure eats
    // detail. Centred on MZ_BLUR_PEAK, where the hand-over happens, and confined
    // to the moon -- full across the disc, gone just past the limb. Its width is
    // a fixed slice of the routine, so Animation Length stays the only speed
    // control and stretches the flash along with everything else.
    float fd       = (phase - MZ_BLUR_PEAK) / 0.28;
    float diskFall = 1.0 - smoothstep(diskR * 0.85, diskR * 1.25, centerAng);
    float flash    = exp(-fd * fd * 3.0) * diskFall * MOON_ZOOM_FLASH;

    vec3 result = sky;

    if (VdotMoon > moonCos) {
        // Tangent-plane disk UV around the moon centre.
        vec3 mUp    = normalize(upVecM - moonDir * dot(upVecM, moonDir));
        vec3 mRight = cross(moonDir, mUp);
        float scale = sqrt(max(1.0 - moonCos * moonCos, 1e-5));
        vec2 diskUV = vec2(dot(nViewPos, mRight), dot(nViewPos, mUp)) / scale * 0.5 + 0.5;

        if (!(any(lessThan(diskUV, vec2(0.0))) || any(greaterThan(diskUV, vec2(1.0))))) {
            // Blur-to-focus: defocus peaks mid-animation, dead sharp when it lands.
            // The old 5-tap cross was far too sparse -- at these radii the taps
            // never merged, so each one stayed readable as a ghosted copy of the
            // limb (the "outlines" visible inside the blur), and sampling only
            // along the two axes made it square. This walks two concentric rings
            // of 8 directions, 17 taps total, for a proper round bokeh disc.
            // Below a threshold it collapses back to the single centre tap, so
            // the settled moon costs exactly one fetch and only the animation
            // itself pays for the rings.
            float blurRad = blurAmount * MOON_ZOOM_FOCUS_BLUR;
            vec4 hd = texture2D(colortex10, diskUV);
            if (blurRad > 0.0005) {
                for (int i = 0; i < 8; i++) {
                    float a = float(i) * 0.7853981634;   // 45 degrees apart
                    vec2 dir = vec2(cos(a), sin(a));
                    hd += texture2D(colortex10, diskUV + dir * blurRad);
                    hd += texture2D(colortex10, diskUV + dir * blurRad * 0.55);
                }
                hd *= 0.058823529;                       // 1/17
            }
            // Cool blue-white grade so the neutral-grey photo matches the pack's
            // (Unbound) moon tone instead of reading as a plain grey ball.
            vec3 hdCol = hd.rgb * mzPhaseShade(nViewPos) * MOON_ZOOM_BRIGHTNESS * vec3(0.82, 0.88, 1.03);

            // The texture's own alpha carves the round disc (transparent surround
            // shows the darkened sky + halo through).
            float textureMix = revealT * clamp(hd.a, 0.0, 1.0);
            result = mix(sky, hdCol, textureMix);
        }
    }

    // Exposure gain applied last, so it lifts whatever the disc currently holds
    // -- procedural moon, blurred photo or sharp photo alike. Multiplicative, so
    // the sky outside the disc (flash == 0) is untouched.
    // The slider IS the extra exposure: 0.5 = 1.5x, 4.0 = 5x. It used to be
    // scaled by 12, which made even 0.1 a 2.2x blowout on an already-bright disc
    // against a near-black sky -- unusably hot at the bottom of the range.
    return result * (1.0 + flash);
}

#endif // INCLUDE_MOON_ZOOM
#endif // SAMSUNG_MOON_ZOOM
