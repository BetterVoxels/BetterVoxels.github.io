#ifndef INCLUDE_SKY
    #define INCLUDE_SKY

    #include "/lib/colors/lightAndAmbientColors.glsl"
    #include "/lib/colors/skyColors.glsl"

    #if SKY_STYLE == 2
        #include "/lib/atmospherics/physicalSky.glsl"
    #endif

    #ifdef CAVE_FOG
        #include "/lib/atmospherics/fog/caveFactor.glsl"
    #endif

    // Reimagined gradient sky (the pack's original look). Still used verbatim
    // as the overcast sky under rain, where a clear-air scattering model has
    // nothing to say, and selectable on its own via Sky Style.
    vec3 GetGradientSky(float VdotU, float VdotS) {
        // Prepare variables
        float nightFactorSqrt2 = sqrt2(nightFactor);
        float nightFactorM = sqrt2(nightFactorSqrt2) * 0.4;
        float VdotSM1 = pow2(max(VdotS, 0.0));
        float VdotSM2 = pow2(VdotSM1);
        float VdotSM3 = pow2(pow2(max(-VdotS, 0.0)));

        float VdotUmax0 = max(VdotU, 0.0);

        // Prepare colors
        vec3 upColor = mix(nightUpSkyColor * (1.5 - 0.5 * nightFactorSqrt2 + nightFactorM * VdotSM3 * 1.5), dayUpSkyColor, sunFactor);
        vec3 middleColor = mix(nightMiddleSkyColor * (3.0 - 2.0 * nightFactorSqrt2), dayMiddleSkyColor * (1.0 + VdotSM2 * 0.3), sunFactor);
        vec3 downColor = mix(nightDownSkyColor, dayDownSkyColor, (sunFactor + sunVisibility) * 0.5);

        // Mix the colors
            // Set sky gradient
            float VdotUM1 = pow2(1.0 - VdotUmax0);
                  VdotUM1 = pow(VdotUM1, 1.0 - VdotSM2 * 0.4);
                  VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.15);
            vec3 finalSky = mix(upColor, middleColor, VdotUM1);

            // Add sunset color
            float VdotUM2 = pow2(1.0 - abs(VdotU));
                  VdotUM2 = VdotUM2 * VdotUM2 * (3.0 - 2.0 * VdotUM2);
                  VdotUM2 *= (0.7 - nightFactorM + VdotSM1 * (0.3 + nightFactorM)) * invNoonFactor * sunFactor;
            finalSky = mix(finalSky, sunsetDownSkyColorP * (1.0 + VdotSM1 * 0.3), VdotUM2 * invRainFactor);

            // Add sky ground with fake light scattering
            float VdotUM3 = min(max0(-VdotU + 0.08) / 0.35, 1.0);
                  VdotUM3 = smoothstep1(VdotUM3);
            vec3 scatteredGroundMixer = vec3(VdotUM3 * VdotUM3, sqrt1(VdotUM3), sqrt3(VdotUM3));
                 scatteredGroundMixer = mix(vec3(VdotUM3), scatteredGroundMixer, 0.75 - 0.5 * rainFactor);
            finalSky = mix(finalSky, downColor, scatteredGroundMixer);
        //

        return finalSky;
    }

    // Horizon/zenith colour balance from the Color Correction hub. Applied to
    // the sky itself, not to the sun glare drawn on top, and shared by both sky
    // styles. All-default sliders make this exactly identity.
    vec3 ApplySkyBalance(vec3 sky, float VdotU) {
        float up = pow(clamp(VdotU, 0.0, 1.0), CC_SKY_BLEND);
        vec3 horizonTint = vec3(CC_HORIZON_R, CC_HORIZON_G, CC_HORIZON_B) * CC_HORIZON_I * ccSkyHorizon;
        vec3 zenithTint  = vec3(CC_ZENITH_R,  CC_ZENITH_G,  CC_ZENITH_B)  * CC_ZENITH_I  * ccSkyZenith;
        return sky * mix(horizonTint, zenithTint, up);
    }

    // Saturation for the gradient sky. The physical sky solves SKY_SATURATION
    // inside its own scattering pass, so this covers the gradient path only --
    // applying it in both places would compound it. Clamped at zero because a
    // saturation above 1 can drive the weakest channel negative.
    vec3 ApplySkySaturation(vec3 sky) {
        float sat = SKY_SATURATION * ccSkyGradSat;
        if (sat == 1.0) return sky;

        return max(mix(vec3(GetLuminance(sky)), sky, sat), vec3(0.0));
    }

    // Azure boost. Rotates the sky's chroma towards blue while holding its
    // brightness, so it reads as a lighter, cleaner blue rather than going navy.
    // Sits after ApplySkyBalance, so it covers both sky styles and every
    // CC_MODE. Fades out under rain, where the pack's grey overcast palette is
    // the correct one.
    vec3 ApplySkyBlue(vec3 sky, float blueAmt) {
        float amt = (blueAmt - 1.0) * invRainFactor;
        if (amt == 0.0) return sky;

        // Green carries over half of perceived brightness, so a pale sky is pale
        // mostly because of its green, not its red -- pulling green down with
        // red is what separates "blue" from "bright bluish white".
        vec3 tinted = sky * vec3(1.0 - 0.65 * amt, 1.0 - 0.30 * amt, 1.0 + 0.50 * amt);

        // Restoring luminance in full caps how deep the blue can get: the sky
        // keeps its original brightness and can only hue-rotate, which is why a
        // washed-out sky stayed washed out. Hand back less of it as the boost
        // grows, so a strong setting is allowed to darken into a real blue.
        float lum  = GetLuminance(sky);
        float lumT = GetLuminance(tinted);
        float keep = 1.0 / (1.0 + 0.6 * max(amt, 0.0));
        return tinted * mix(1.0, lum / max(lumT, 1e-5), keep);
    }

    // Base sky colour before the shared extras (ground, glare, fogs, dither).
    vec3 GetSkyBase(float VdotU, float VdotS, int steps, float blueAmt) {
        #if SKY_STYLE == 2
            vec3 finalSky = GetPhysicalSky(VdotU, VdotS, steps);

            // Rain is overcast: the clear-air model does not describe it, so
            // hand the sky back to the gradient path as the storm rolls in.
            // rainFactor is frame-uniform, so this branch never diverges.
            if (rainFactor > 0.0) {
                finalSky = mix(finalSky, GetGradientSky(VdotU, VdotS), rainFactor);
            }

            return ApplySkyBlue(ApplySkyBalance(finalSky, VdotU), blueAmt);
        #else
            return ApplySkyBlue(ApplySkySaturation(ApplySkyBalance(GetGradientSky(VdotU, VdotS), VdotU)), blueAmt);
        #endif
    }

    vec3 GetSkyTinted(float VdotU, float VdotS, float dither, bool doGlare, bool doGround, float blueAmt) {
        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);
        float VdotSML = sunVisibility > 0.5 ? VdotS : -VdotS;

        vec3 finalSky = GetSkyBase(VdotU, VdotS, SKY_QUALITY, blueAmt);

        // Sky Ground
        if (doGround)
            finalSky *= smoothstep1(pow2(1.0 + min(VdotU, 0.0)));

        // Apply Underwater Fog
        if (isEyeInWater == 1)
            finalSky = mix(finalSky * 3.0, waterFogColor, VdotUmax0M);

        // Sun/Moon Glare
        if (doGlare) {
            if (0.0 < VdotSML) {
                float glareScatter = 4.0 * (2.0 - clamp01(VdotS * 1000.0));
                float VdotSM4 = pow(abs(VdotS), glareScatter);

                float visfactor = 0.075;
                float glare = visfactor / (1.0 - (1.0 - visfactor) * VdotSM4) - visfactor;

                glare *= 0.5 + pow2(noonFactor) * 1.2;
                glare *= 1.0 - rainFactor * 0.5;

                float glareWaterFactor = isEyeInWater * sunVisibility;
                vec3 glareColor = mix(vec3(0.38, 0.4, 0.5) * 0.7, vec3(0.5), sunVisibility);
                     glareColor = glareColor + glareWaterFactor * vec3(7.0);

                // v1.4.1: this used to be #if SKY_STYLE == 2, which left the
                // slider dead on the DEFAULT sky style -- and there the
                // hand-drawn glare is not a top-up over a Mie lobe, it is the
                // entire sun scatter, running unscalable at full strength. It
                // adds up to +0.65 of flat white a few degrees off the sun,
                // which is what bleached the sky white around it while the same
                // sky read blue looking away. The slider now governs both
                // styles, so the wash is finally adjustable. Rain still gets
                // the full glare: an overcast sun really is a big soft blob.
                glare *= mix(SKY_GLARE, 1.0, rainFactor);

                finalSky += glare * shadowTime * glareColor;
            }
        }

        #ifdef CAVE_FOG
            // Apply Cave Fog
            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        // Dither to fix banding
        finalSky += (dither - 0.5) / 128.0;

        return finalSky;
    }

    // The sky drawn on screen and the sky used to colour distance fog are the
    // same function, so the azure boost has to be opt-in per caller -- otherwise
    // tinting the sky silently tints the fog on terrain too.
    vec3 GetSky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {
        vec3 sky = GetSkyTinted(VdotU, VdotS, dither, doGlare, doGround,
                                 1.0 + (SKY_BLUE - ccSkyBlueNeutral));

        // ---- Horizon whitening + per-mode level (v1.4.1) -----------------
        // Deliberately applied HERE rather than inside GetSkyTinted: this is
        // the entry point for the sky that actually gets drawn (and the sample
        // the clouds sit against), while distance fog calls GetSkyTinted
        // directly with SKY_BLUE_FOG. Keeping it out of that path lets the sky
        // be reshaped without the fog on terrain moving with it.
        //
        // The fade pulls the sky toward its own luminance as the view drops to
        // the horizon -- the sky there is bright, so losing the tint reads as
        // white rather than grey. Realistic gets none of it: its horizon is
        // already pale, because ccRestoreSkyChroma is faded out by the same
        // elevation and simply leaves AgX's own white there.
        #if CC_SKY_HORIZON_FADE > 0
            float skyFadeUp = 1.0 - smoothstep(0.0, 0.45, clamp(VdotU, 0.0, 1.0));
            sky = mix(sky, vec3(GetLuminance(sky)),
                      CC_SKY_HORIZON_FADE * 0.01 * ccSkyHorizonFade * skyFadeUp);
        #endif

        return sky * ccSkyLevel;
    }

    vec3 GetLowQualitySky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {
        // Prepare variables
        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);

        #if SKY_STYLE == 2
            vec3 finalSky = GetSkyBase(VdotU, VdotS, SKY_QUALITY_LOW, SKY_BLUE);

            // Sky Ground
            finalSky *= pow2(pow2(1.0 + min(VdotU, 0.0)));

            // Apply Underwater Fog
            if (isEyeInWater == 1)
                finalSky = mix(finalSky, waterFogColor, VdotUmax0M);
        #else
            // Prepare colors
            vec3 upColor = mix(nightUpSkyColor, dayUpSkyColor, sunFactor);
            vec3 middleColor = mix(nightMiddleSkyColor, dayMiddleSkyColor, sunFactor);

            // Mix the colors
                // Set sky gradient
                float VdotUM1 = pow2(1.0 - VdotUmax0);
                      VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.2);
                vec3 finalSky = mix(upColor, middleColor, VdotUM1);

                // Add sunset color
                float VdotUM2 = pow2(1.0 - abs(VdotU));
                      VdotUM2 *= invNoonFactor * sunFactor * (0.8 + 0.2 * VdotS);
                finalSky = mix(finalSky, sunsetDownSkyColorP * (shadowTime * 0.6 + 0.2), VdotUM2 * invRainFactor);
            //

            // Sky Ground
            finalSky *= pow2(pow2(1.0 + min(VdotU, 0.0)));

            // Apply Underwater Fog
            if (isEyeInWater == 1)
                finalSky = mix(finalSky, waterFogColor, VdotUmax0M);

            // Sun/Moon Glare
            finalSky *= 1.0 + mix(nightFactor, 0.5 + 0.7 * noonFactor, VdotS * 0.5 + 0.5) * pow2(pow2(pow2(VdotS)));

            finalSky = ApplySkyBlue(ApplySkySaturation(ApplySkyBalance(finalSky, VdotU)),
                                      1.0 + (SKY_BLUE - ccSkyBlueNeutral));
        #endif

        #ifdef CAVE_FOG
            // Apply Cave Fog
            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        // This is the sky as REFLECTED by water, so it has to get the same
        // horizon whitening and per-mode level as the drawn sky in GetSky() --
        // otherwise water mirrors a brighter, bluer sky than the one overhead.
        #if CC_SKY_HORIZON_FADE > 0
            float lqFadeUp = 1.0 - smoothstep(0.0, 0.45, clamp(VdotU, 0.0, 1.0));
            finalSky = mix(finalSky, vec3(GetLuminance(finalSky)),
                           CC_SKY_HORIZON_FADE * 0.01 * ccSkyHorizonFade * lqFadeUp);
        #endif

        return finalSky * ccSkyLevel;
    }

#endif //INCLUDE_SKY
