// =============================================================================
//  EFFECT 3 -- LENS FOGGING  (Iteration 43)
// -----------------------------------------------------------------------------
//  Condensation creeping in from the edges of the lens: a milky vignette with a
//  breath-like noise structure and a real blur underneath it, building up while
//  the player exerts themselves and evaporating when they stop.
//
//  RISE / FALL DECOUPLING -- the interesting part of this module.
//  A post pass has no frame-to-frame memory, so the buildup must come from an
//  engine-side smooth() uniform. But smooth() takes ONE fade-up and ONE
//  fade-down constant, while the GUI exposes fade-in and dissipation as two
//  INDEPENDENT settings -- and a define cannot be interpolated into a
//  shaders.properties expression, so a 3x4 preprocessor cross-product would be
//  the naive way out.
//
//  Instead shaders.properties declares the SAME exertion signal at three fixed
//  rates (fxFogFast / fxFogMed / fxFogSlow), and this module composes the two it
//  needs. The trick: for two signals tracking one source,
//      max(a, b) rises at the rate of the FASTER and falls at the rate of the SLOWER
//      min(a, b) rises at the rate of the SLOWER and falls at the rate of the FASTER
//  so picking the rise source, the fall source, and then max/min depending on
//  which of the two is faster reproduces every combination exactly -- at the
//  cost of one extra uniform and one ALU op.
//
//  EXERTION SIGNAL. There is no "is sprinting" uniform, so the raw signal is
//  camera translation per frame (the difSum variable the pack already computes
//  for its movement detection), thresholded at a walking pace. This is an
//  APPROXIMATION: it reacts to fast movement, which includes sprinting, riding
//  and falling, and it does not know about hunger or the player's air supply.
// =============================================================================
#ifndef INCLUDE_FX_LENS_FOGGING
#define INCLUDE_FX_LENS_FOGGING

// ------------------------------- Settings ------------------------------------
#define LENS_FOGGING 0 //[0 1]
#define LENS_FOG_RADIUS 1 //[0 1 2]
#define LENS_FOG_FADE_IN 1 //[0 1 2]
#define LENS_FOG_DISSIPATION 2 //[0 1 2 3]
#define LENS_FOG_ENVIRONMENTAL 1 //[0 1]
#define LENS_FOG_BLUR_AMOUNT 1 //[0 1 2 3]

#if LENS_FOGGING == 1

// New to this module -- declared in shaders.properties under the matching #if.
uniform float fxFogFast;
uniform float fxFogMed;
uniform float fxFogSlow;

// inSnowy, rainFactor, eyeAltitude and isEyeInWater already come from
// lib/uniforms.glsl via common.glsl; redeclaring them would be a compile error.

// Vignette coverage: how far in from the border the condensation reaches.
#if LENS_FOG_RADIUS == 0
    #define FX_FOG_INNER 0.72        // Tight Edges
    #define FX_FOG_OUTER 1.05
#elif LENS_FOG_RADIUS == 1
    #define FX_FOG_INNER 0.42        // Medium
    #define FX_FOG_OUTER 0.98
#else
    #define FX_FOG_INNER 0.04        // Full Lens
    #define FX_FOG_OUTER 0.92
#endif

// Blur tap radius in pixels, and whether a tint-only path is enough.
#if LENS_FOG_BLUR_AMOUNT == 0
    #define FX_FOG_BLUR_PX 0.0       // Soft Tint (no blur taps at all)
#elif LENS_FOG_BLUR_AMOUNT == 1
    #define FX_FOG_BLUR_PX 2.0       // Light
#elif LENS_FOG_BLUR_AMOUNT == 2
    #define FX_FOG_BLUR_PX 4.5       // Strong
#else
    #define FX_FOG_BLUR_PX 8.0       // Heavy Gaussian Blur
#endif

// Compose the buildup signal out of the three fixed-rate trackers. Both the
// source selection and the max/min choice collapse at compile time.
float fxFogSignal() {
    #if LENS_FOG_FADE_IN == 0
        float riseSrc = fxFogSlow;   // Slow
        #define FX_FOG_RISE_RANK 0
    #elif LENS_FOG_FADE_IN == 1
        float riseSrc = fxFogMed;    // Normal
        #define FX_FOG_RISE_RANK 1
    #else
        float riseSrc = fxFogFast;   // Instant
        #define FX_FOG_RISE_RANK 2
    #endif

    #if LENS_FOG_DISSIPATION == 0
        float fallSrc = fxFogSlow;   // Very Slow
        #define FX_FOG_FALL_RANK 0
    #elif LENS_FOG_DISSIPATION == 1
        float fallSrc = fxFogSlow;   // Slow
        #define FX_FOG_FALL_RANK 0
    #elif LENS_FOG_DISSIPATION == 2
        float fallSrc = fxFogMed;    // Normal
        #define FX_FOG_FALL_RANK 1
    #else
        float fallSrc = fxFogFast;   // Fast
        #define FX_FOG_FALL_RANK 2
    #endif

    // Higher rank == faster tracker. max() keeps the faster rise and the slower
    // fall, which is what we want whenever the rise source is the faster of the
    // pair; otherwise min() gives the mirrored behaviour.
    #if FX_FOG_RISE_RANK >= FX_FOG_FALL_RANK
        return max(riseSrc, fallSrc);
    #else
        return min(riseSrc, fallSrc);
    #endif
}

// Environment multiplier: cold, wet and thin air fog the lens far more readily.
float fxFogEnvironment() {
    #if LENS_FOG_ENVIRONMENTAL == 1
        // Altitude: nothing below y=80, ramping to full by roughly y=200.
        float altitude = clamp((eyeAltitude - 80.0) / 120.0, 0.0, 1.0);
        // Snowy biomes are the strongest driver, rain a moderate one.
        float climate = clamp(inSnowy * 1.0 + rainFactor * 0.45, 0.0, 1.0);
        // Baseline so the effect still exists in a temperate biome at sea level.
        return clamp(0.35 + 0.65 * max(altitude, climate), 0.0, 1.0);
    #else
        return 1.0;
    #endif
}

vec3 ApplyLensFogging(vec3 color, sampler2D src, vec2 uv) {
    float fog = clamp(fxFogSignal(), 0.0, 1.0) * fxFogEnvironment();

    // Submerged the lens is already fully wet -- the underwater stack owns that
    // look, so this module stays out of the way.
    if (fog <= 0.01 || isEyeInWater != 0) return color;

    // Radial coverage, aspect-corrected so the fog ring stays circular.
    vec2 centred = (uv - 0.5) * fxAspect();
    float radial = length(centred) / length(fxAspect() * 0.5);

    // Breath structure: slow, large-scale noise that drifts, so the condensation
    // has patches and streaks instead of being a uniform wash.
    float breath = fxFbm2(uv * fxAspect() * 3.5 + vec2(0.0, frameTimeCounter * 0.035));
    breath = 0.55 + 0.45 * breath;

    float coverage = smoothstep(FX_FOG_INNER, FX_FOG_OUTER, radial * breath) * fog;
    if (coverage <= 0.002) return color;

    // Blur underneath the tint. Six taps on a rotated hexagon plus the centre --
    // cheap, isotropic enough at these radii, and array-free.
    if (FX_FOG_BLUR_PX > 0.0) {
        vec2 texel = FX_FOG_BLUR_PX * coverage / vec2(viewWidth, viewHeight);
        vec3 blurred = color;
        blurred += texture2D(src, clamp(uv + vec2( 0.866,  0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.000,  1.000) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2(-0.866,  0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2(-0.866, -0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.000, -1.000) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.866, -0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        color = mix(color, blurred / 7.0, clamp(coverage, 0.0, 1.0));
    }

    // Milky condensate on top. Lifted toward white and desaturated, weighted by
    // the local breath noise so the film is not flat.
    float milk = coverage * (0.55 + 0.45 * breath);
    vec3 condensate = mix(color, vec3(fxLuma(color) * 0.55 + 0.45), 0.85);
    return mix(color, condensate, clamp(milk * 0.75, 0.0, 1.0));
}

#endif // LENS_FOGGING == 1

#endif // INCLUDE_FX_LENS_FOGGING
