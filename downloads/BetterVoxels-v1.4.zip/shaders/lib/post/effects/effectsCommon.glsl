// =============================================================================
//  EFFECTS -- SHARED FOUNDATION  (Iteration 43)
// -----------------------------------------------------------------------------
//  Common ground for the five "Effects" modules. Everything in this directory
//  follows the same contract as the Iteration 39-42 post stack:
//
//    * Compiled and executed ONLY inside program/final.glsl, strictly on the
//      finalized frame buffer. Nothing reads or writes voxel data, shadow maps,
//      lighting buffers or any mid-pipeline resource.
//    * Every module owns its own settings. The #define block at the top of a
//      module IS the GUI: shaders.properties only references the names.
//    * Every module is OFF by default. With all five toggles OFF each entry
//      point compiles to the identity and the output is bit-identical to
//      Iteration 42.
//    * All symbols are "fx"/"FX_" prefixed and collision-free against the
//      existing PP_/pp, WD_/wd and WB_ namespaces.
//
//  GLSL DIALECT RULES (learned the hard way in Iterations 39-41, keep them):
//    * No nested functions -- every helper lives at global scope.
//    * No array declarations. Iris's parser is strict about array syntax in the
//      flattened final program; use if-chains or vector component indexing.
//    * No comment may end in a backslash.
//    * Guard every module body with its own toggle so an OFF effect costs
//      literally zero instructions.
//
//  TEMPORAL STATE. A post pass has no memory between frames, so anything that
//  needs to build up or decay is driven by engine-side smooth() uniforms
//  declared in shaders.properties (the mechanism the pack already uses for
//  exitWater / rainFactor / starter). Shaping of those raw signals -- curve,
//  duration, mode -- happens here in GLSL so that a slider does not require a
//  preprocessor branch per value.
// =============================================================================
#ifndef INCLUDE_FX_COMMON
#define INCLUDE_FX_COMMON

// ------------------------------ Hash / noise ---------------------------------
// Same construction as the pack's established noise bridge (screenDroplets.glsl)
// so every Effects module shares one correlation length and one look.
float fxHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 fxHash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

// Quintic-interpolated value noise. Cheap stand-in for Simplex; one texture-free
// lookup, C1 continuous, which is what the distortion fields need.
float fxNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = fxHash12(i);
    float b = fxHash12(i + vec2(1.0, 0.0));
    float c = fxHash12(i + vec2(0.0, 1.0));
    float d = fxHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Two-octave fBm. Two octaves is the deliberate ceiling: the Effects stack must
// not add measurable cost to the final pass.
float fxFbm2(vec2 p) {
    return fxNoise(p) * 0.65 + fxNoise(p * 2.03 + 17.7) * 0.35;
}

// ------------------------------ Small utilities ------------------------------
float fxLuma(vec3 c) {
    return dot(c, vec3(0.2125, 0.7154, 0.0721));
}

// Screen aspect, used by every module that must stay circular/round on screen.
vec2 fxAspect() {
    return vec2(viewWidth / viewHeight, 1.0);
}

// World-space view direction. final.glsl has no varying for it, so it is
// reconstructed from the inverse modelview -- column 2 is the camera's backward
// axis, hence the negation. Only .y is ever used (how far up the player looks).
vec3 fxViewDir() {
    return -normalize(gbufferModelViewInverse[2].xyz);
}

// Linearised depth in blocks, for the effects that need a distance weight.
float fxLinearDepth(float depth) {
    return 2.0 * near * far / (far + near - (2.0 * depth - 1.0) * (far - near));
}

// ------------------------------ Easing curves --------------------------------
// The two exponential easings requested for the droplet lifecycle, in their
// canonical forms (exp2(x) == 2^x, a core GLSL builtin). Both map [0,1] -> [0,1].
//
//   Ease-Out Expo : 1 - 2^(-10 t)   -- snaps up fast, then eases into the finish.
//                                       Used for a droplet GROWING in.
//   Ease-In  Expo : 2^(10 (t - 1))  -- near-flat, then rushes to the finish.
//                                       Used for a droplet EVAPORATING out.
float fxEaseOutExpo(float t) {
    t = clamp(t, 0.0, 1.0);
    return t >= 1.0 ? 1.0 : 1.0 - exp2(-10.0 * t);
}
float fxEaseInExpo(float t) {
    t = clamp(t, 0.0, 1.0);
    return t <= 0.0 ? 0.0 : exp2(10.0 * (t - 1.0));
}

// ---------------------- Retiming an engine smooth() --------------------------
// A shaders.properties smooth() has FIXED fade constants -- a define cannot be
// substituted into that expression (the pack never does it, so we don't rely on
// it). These two helpers instead retime a fixed-rate smoothed signal to any
// continuous-seconds slider, entirely in GLSL.
//
// The identity: an engine smooth is a first-order exponential. If a rising
// signal is  P = 1 - exp(-t / tauFixed)  then
//     1 - (1 - P)^(tauFixed / tauTarget) = 1 - exp(-t / tauTarget)
// exactly -- i.e. the same signal it WOULD have had with time-constant
// tauTarget. fxRetimeDecay is the mirror for a signal decaying from 1 toward 0.
// (Exact when the smooth approaches 1 / decays from 1; a smooth that approaches
// a partial target is retimed monotonically but not perfectly -- good enough for
// a cosmetic coverage envelope, and documented as such at the call sites.)
float fxRetimeApproach(float P, float tauFixed, float tauTarget) {
    return 1.0 - pow(max(1.0 - clamp(P, 0.0, 1.0), 0.0), tauFixed / max(tauTarget, 0.0001));
}
float fxRetimeDecay(float P, float tauFixed, float tauTarget) {
    return pow(clamp(P, 0.0, 1.0), tauFixed / max(tauTarget, 0.0001));
}

#endif // INCLUDE_FX_COMMON
