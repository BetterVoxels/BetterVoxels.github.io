// =============================================================================
//  EFFECT 1 -- EXPOSURE SPIKE  (Iteration 43; lightning-only since v1.4.1)
// -----------------------------------------------------------------------------
//  A lightning strike overwhelms the camera's exposure: the frame is thrown
//  bright, tinted toward the selected preset, and then eased back to normal as
//  the "sensor" re-adapts.
//
//  EVENT SOURCE -- LIGHTNING, AND NOTHING ELSE.
//  lightningBoltPosition.w is non-zero on the frames a bolt exists. The
//  engine-side smooth() uniform fxBoltFlash latches to 1.0 instantly
//  (fade-up 0) and decays over a fixed 3 s window (fade-down 3), which is the
//  widest recovery the slider can ask for.
//
//  WHY THERE IS NO SECOND CHANNEL ANY MORE. Up to v1.4 this module also ran a
//  two-rate adaptation detector on eyeBrightness.x (fast tracker minus slow
//  tracker) to stand in for explosions, since the engine exposes no explosion
//  event. eyeBrightness.x is the BLOCK light at the player's head, so placing a
//  torch, walking up to a furnace or riding a lava-lit corridor moves it just
//  as fast as an explosion does -- no threshold can separate "a torch appeared
//  next to me" from "something detonated", because to that uniform they are the
//  same measurement. The detector was therefore removed outright: the effect now
//  fires on real lightning only, which is exactly what it claims to do.
//
//  RECOVERY SHAPING. The engine smooth decays linearly over its fixed 3 s
//  window; EXPOSURE_RECOVERY_SPEED reshapes that tail in GLSL with a power
//  curve, so a 19-stop slider costs zero preprocessor branches:
//      shaped = pow(raw, 1.0 / EXPOSURE_RECOVERY_SPEED)
//  0.1 -> collapses almost immediately, 1.0 -> the linear 3 s default,
//  3.0 -> a long, lingering bloom-out.
// =============================================================================
#ifndef INCLUDE_FX_EXPOSURE_SPIKE
#define INCLUDE_FX_EXPOSURE_SPIKE

// ------------------------------- Settings ------------------------------------
#define EXPOSURE_SPIKE 1 //[0 1]
#define EXPOSURE_SPIKE_MODE 0 //[0 1 2]
#define EXPOSURE_RECOVERY_SPEED 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
#define EXPOSURE_MAX_INTENSITY 3.0 //[1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0]
#define EXPOSURE_TINT_PRESET 0 //[0 1 2 3 4]
#define EXPOSURE_TINT_R 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define EXPOSURE_TINT_G 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define EXPOSURE_TINT_B 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// -- Lightning distance attenuation (v1.3.1) ----------------------------------
#define LIGHTNING_DISTANCE_ATTENUATION 1 //[0 1]
#define LIGHTNING_MAX_DISTANCE 128 //[10 16 24 32 48 64 80 96 112 128 160 192 224 256 320 384 448 500]
#define LIGHTNING_MIN_FLASH_MULT 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LIGHTNING_FALLOFF_CURVE 2 //[0 1 2]

#if EXPOSURE_SPIKE == 1

// Engine-side event timers (declared in shaders.properties under the matching
// #if, so they only exist when the effect is compiled in).
uniform float fxBoltFlash;

#if LIGHTNING_DISTANCE_ATTENUATION == 1
    // Latched squared view-space distance to the bolt. The engine smooth uses
    // the SAME instant-rise / 3 s-decay dynamics as fxBoltFlash, so both are the
    // strike value times one common decay curve:
    //     fxBoltDistSq = D^2 * decay(t),   fxBoltFlash = 1 * decay(t)
    // and their ratio reconstructs the strike-time D^2 for the whole decay,
    // with no per-frame position needed once the bolt entity is gone. Only used
    // where fxBoltFlash is already known non-zero, so the divide is safe.
    uniform float fxBoltDistSq;

    // Distance multiplier for the lightning flash: 1.0 point-blank, falling to
    // LIGHTNING_MIN_FLASH_MULT at (and beyond) LIGHTNING_MAX_DISTANCE.
    float fxLightningAtten() {
        float d2 = fxBoltDistSq / max(fxBoltFlash, 0.0001);      // blocks^2
        float dn = clamp(sqrt(max(d2, 0.0)) / float(LIGHTNING_MAX_DISTANCE), 0.0, 1.0);
        float dimming;
        #if LIGHTNING_FALLOFF_CURVE == 0
            dimming = dn;                       // Linear
        #elif LIGHTNING_FALLOFF_CURVE == 1
            dimming = 1.0 - exp2(-6.0 * dn);    // Exponential -- fast early dimming
        #else
            dimming = dn * dn;                  // Inverse Square -- dims with distance^2
        #endif
        return mix(1.0, float(LIGHTNING_MIN_FLASH_MULT), clamp(dimming, 0.0, 1.0));
    }
#endif

// Preset -> tint colour. Resolved at compile time; only one branch survives.
vec3 fxExposureTint() {
    #if EXPOSURE_TINT_PRESET == 0
        return vec3(1.0, 1.0, 1.0);                 // White (Default)
    #elif EXPOSURE_TINT_PRESET == 1
        return vec3(0.62, 0.78, 1.0);               // Desaturated Blue
    #elif EXPOSURE_TINT_PRESET == 2
        return vec3(1.0, 0.86, 0.66);               // Sepia
    #elif EXPOSURE_TINT_PRESET == 3
        return vec3(1.0, 0.45, 0.16);               // Thermal
    #else
        return vec3(EXPOSURE_TINT_R, EXPOSURE_TINT_G, EXPOSURE_TINT_B);
    #endif
}

// Raw 0..1 event strength for this frame. Lightning is the only source, so
// nothing the player builds, lights or walks past can trigger the effect.
float fxExposureEvent() {
    float boltEvent = clamp(fxBoltFlash, 0.0, 1.0);
    #if LIGHTNING_DISTANCE_ATTENUATION == 1
        // Scale by distance: a strike overhead still blinds; a strike near the
        // horizon becomes a soft flicker. Gated on the flash being present so the
        // reconstruction divide never sees 0/0.
        if (boltEvent > 0.0001) boltEvent *= fxLightningAtten();
    #endif

    return boltEvent;
}

// Mode -> response curve over the raw event.
float fxExposureCurve(float e) {
    #if EXPOSURE_SPIKE_MODE == 0
        // Dynamic -- smoothstep in, eased out. The natural-looking default.
        return e * e * (3.0 - 2.0 * e);
    #elif EXPOSURE_SPIKE_MODE == 1
        // Instant -- full amplitude the moment the event fires, then falls off
        // hard. Harsh, "cheap camera" response.
        return sqrt(e);
    #else
        // Progressive -- ramps in slowly and lets go slowly. Cinematic.
        return e * e * e;
    #endif
}

vec3 ApplyExposureSpike(vec3 color) {
    float event = fxExposureEvent();
    if (event <= 0.001) return color;

    // Recovery shaping. EXPOSURE_RECOVERY_SPEED acts as a duration multiplier on
    // the fixed 3 s engine window (see the header).
    float shaped = pow(event, 1.0 / EXPOSURE_RECOVERY_SPEED);
    float strength = fxExposureCurve(clamp(shaped, 0.0, 1.0));

    // Exposure lift: a multiplicative gain toward EXPOSURE_MAX_INTENSITY, so the
    // spike behaves like a real exposure change (highlights blow first) rather
    // than a flat white overlay.
    float gain = mix(1.0, EXPOSURE_MAX_INTENSITY, strength);
    vec3 tint = fxExposureTint();

    vec3 lifted = color * gain;

    // The tint is applied to the ADDED energy only, so a White preset is a pure
    // exposure change and a coloured preset washes the frame toward its hue
    // without staining the parts that were already correctly exposed.
    vec3 added = max(lifted - color, vec3(0.0));
    return color + added * tint;
}

#endif // EXPOSURE_SPIKE == 1

#endif // INCLUDE_FX_EXPOSURE_SPIKE
