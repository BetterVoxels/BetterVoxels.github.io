// =============================================================================
//  EFFECT 4 -- LIGHT BLOOM & HALOS  (Iteration 43)
// -----------------------------------------------------------------------------
//  Soft radial halos and anamorphic streaks around bright emissive sources, with
//  optional chromatic dispersion in the halo itself.
//
//  PIPELINE. Classic bright-pass plus gather, done in a single final-pass
//  function rather than as extra composite targets:
//    1. BRIGHT PASS -- everything above HALO_BRIGHTNESS_THRESHOLD is kept, with
//       a soft knee so a light source does not pop in as it brightens.
//    2. RADIAL GATHER -- a golden-angle spiral of taps around the pixel. A
//       spiral is used instead of a separable two-pass blur because the final
//       pass has exactly one shot at the buffer; the golden angle keeps the tap
//       distribution even at any count, and the sample count is fixed per
//       HALO_SIZE tier so cost is predictable.
//    3. STREAKS -- an additional 1D gather along the selected axis, which is
//       what actually reads as an anamorphic flare.
//    4. DISPERSION -- R, G and B are gathered at slightly different radii, so
//       the halo fringes warm-to-cool outward like a real lens.
//
//  COST NOTE. This is the most expensive module in the Effects set: Cinematic
//  Large costs 24 spiral taps plus up to 12 streak taps per pixel of the final
//  pass. That is a deliberate, opt-in trade -- the effect is OFF by default and
//  the tier system exists so the cost is a conscious choice.
// =============================================================================
#ifndef INCLUDE_FX_LIGHT_HALOS
#define INCLUDE_FX_LIGHT_HALOS

// ------------------------------- Settings ------------------------------------
#define LIGHT_HALOS 0 //[0 1]
#define HALO_SIZE 1 //[0 1 2]
#define HALO_BRIGHTNESS_THRESHOLD 1 //[0 1 2]
#define ANAMORPHIC_STREAKS 0 //[0 1 2 3]
#define HALO_COLOR_DISPERSION 0.30 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_R 0.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_G 0.55 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_B 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#if LIGHT_HALOS == 1

// Halo radius in screen fraction, and the spiral tap budget.
#if HALO_SIZE == 0
    #define FX_HALO_RADIUS 0.020     // Small
    #define FX_HALO_TAPS 10
#elif HALO_SIZE == 1
    #define FX_HALO_RADIUS 0.045     // Medium
    #define FX_HALO_TAPS 16
#else
    #define FX_HALO_RADIUS 0.090     // Cinematic Large
    #define FX_HALO_TAPS 24
#endif

// Bright-pass knee. Lower threshold == more of the scene blooms.
#if HALO_BRIGHTNESS_THRESHOLD == 0
    #define FX_HALO_KNEE 1.15        // Only Extreme Lights
#elif HALO_BRIGHTNESS_THRESHOLD == 1
    #define FX_HALO_KNEE 0.72        // Torches & Above
#else
    #define FX_HALO_KNEE 0.38        // All Emissives
#endif

#if ANAMORPHIC_STREAKS > 0
    #if ANAMORPHIC_STREAKS == 1
        #define FX_STREAK_AXIS vec2(1.0, 0.0)   // Horizontal
    #elif ANAMORPHIC_STREAKS == 2
        #define FX_STREAK_AXIS vec2(0.0, 1.0)   // Vertical
    #else
        #define FX_STREAK_AXIS vec2(1.0, 0.0)   // Anamorphic Blue (horizontal)
    #endif
#endif

// Soft-knee bright pass. Returns only the energy above the threshold, so the
// halo carries the light's own colour rather than a white blob.
vec3 fxBrightPass(vec3 c) {
    float l = fxLuma(c);
    float w = clamp((l - FX_HALO_KNEE) / max(FX_HALO_KNEE * 0.5, 0.001), 0.0, 1.0);
    return c * (w * w);
}

vec3 ApplyLightHalos(vec3 color, sampler2D src, vec2 uv) {
    vec2 aspect = fxAspect();
    // Keep the halo circular on screen: scale x down by the aspect ratio.
    vec2 radiusScale = vec2(1.0 / aspect.x, 1.0) * FX_HALO_RADIUS;

    vec3 halo = vec3(0.0);
    float weightSum = 0.0;

    // Golden-angle spiral. i / N gives the radius, i * 2.39996 the angle.
    for (int i = 0; i < FX_HALO_TAPS; i++) {
        float fi = float(i) + 0.5;
        float t = fi / float(FX_HALO_TAPS);
        float ang = fi * 2.39996323;
        float rad = sqrt(t);                      // even area distribution
        vec2 dir = vec2(cos(ang), sin(ang)) * rad;

        // Chromatic dispersion: each channel gathers at its own radius.
        float disp = HALO_COLOR_DISPERSION * 0.35;
        vec2 offR = dir * radiusScale * (1.0 + disp);
        vec2 offG = dir * radiusScale;
        vec2 offB = dir * radiusScale * (1.0 - disp);

        vec3 tapR = fxBrightPass(texture2D(src, clamp(uv + offR, vec2(0.0), vec2(1.0))).rgb);
        vec3 tapG = fxBrightPass(texture2D(src, clamp(uv + offG, vec2(0.0), vec2(1.0))).rgb);
        vec3 tapB = fxBrightPass(texture2D(src, clamp(uv + offB, vec2(0.0), vec2(1.0))).rgb);

        // Gaussian-ish falloff with radius.
        float w = exp(-2.5 * t);
        halo += vec3(tapR.r, tapG.g, tapB.b) * w;
        weightSum += w;
    }
    halo /= max(weightSum, 0.0001);

    #if ANAMORPHIC_STREAKS > 0
        // 1D gather along the flare axis, four times the halo reach.
        vec3 streak = vec3(0.0);
        float streakWeight = 0.0;
        for (int j = 1; j <= 6; j++) {
            float fj = float(j) / 6.0;
            vec2 off = FX_STREAK_AXIS * radiusScale * fj * 4.0;
            float w = 1.0 - fj;
            streak += fxBrightPass(texture2D(src, clamp(uv + off, vec2(0.0), vec2(1.0))).rgb) * w;
            streak += fxBrightPass(texture2D(src, clamp(uv - off, vec2(0.0), vec2(1.0))).rgb) * w;
            streakWeight += 2.0 * w;
        }
        streak /= max(streakWeight, 0.0001);

        #if ANAMORPHIC_STREAKS == 3
            // Anamorphic Blue: the classic cine-lens flare is tinted, not white.
            streak *= vec3(ANAMORPHIC_TINT_R, ANAMORPHIC_TINT_G, ANAMORPHIC_TINT_B) * 1.6;
        #endif
        halo += streak * 0.75;
    #endif

    // Additive, which is what a lens actually does with scattered light.
    return color + halo;
}

#endif // LIGHT_HALOS == 1

#endif // INCLUDE_FX_LIGHT_HALOS
