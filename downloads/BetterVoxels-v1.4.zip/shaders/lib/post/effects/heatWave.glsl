// =============================================================================
//  EFFECT 5 -- HEAT WAVE DISTORTION  (Iteration 43)
// -----------------------------------------------------------------------------
//  Rising hot air that bends the image above fire, lava and hot blocks, plus an
//  optional constant shimmer in hot biomes.
//
//  THIS IS A UV-STAGE EFFECT. It runs BEFORE the frame is fetched, exactly like
//  RetroPostUV() in the retro stack, so the distortion bends the real image
//  instead of smearing an already-composited one. Entry point:
//      vec2 HeatWaveUV(vec2 uv)
//
//  HEAT SOURCE DETECTION -- read this before judging the result.
//  The final pass has no access to voxel data, block IDs or the emissive
//  buffer; it has the finished colour and the depth buffer. So "where are the
//  hot blocks" is answered in SCREEN SPACE: a pixel is treated as a heat source
//  when it is bright AND warm-hued (red dominant, blue suppressed), which is
//  what fire, lava, torches, campfires and magma all look like after tonemapping.
//  The mask is sampled from BELOW the current pixel, so heat rises off the
//  source rather than surrounding it.
//
//  Consequences of that approximation, stated plainly:
//    * A bright orange wool block or an orange sunset near the horizon can
//      register as heat. HEAT_BLOCK_SOURCES tightens the hue window to reduce
//      this -- "Lava Only" is the strictest.
//    * A heat source hidden behind geometry does not shimmer, because its pixels
//      are not on screen. Physically that is arguably correct.
//  A voxel-accurate version would have to classify blocks during voxelization
//  and carry a heat channel through the pipeline. That is a much larger change
//  and is deliberately out of scope for this module.
//
//  NOISE FIELD. Two-octave value noise scrolling upward, sampled at a frequency
//  that stays stable under camera motion because it is anchored to screen UV.
//  Amplitude falls off with distance so far-away shimmer does not turn into
//  visible pixel crawl.
// =============================================================================
#ifndef INCLUDE_FX_HEAT_WAVE
#define INCLUDE_FX_HEAT_WAVE

// ------------------------------- Settings ------------------------------------
#define HEAT_DISTORTION 1 //[0 1]
#define HEAT_WAVE_SPEED 1.0 //[0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 3.5 4.0]
#define HEAT_WAVE_INTENSITY 1 //[0 1 2]
#define HEAT_BLOCK_SOURCES 0 //[0 1 2]
#define HEAT_BIOME_HAZE 0 //[0 1 2 3]
#define HEAT_RISE_HEIGHT 3 //[1 2 3 4 5]

#if HEAT_DISTORTION == 1

// Distortion amplitude in UV units.
#if HEAT_WAVE_INTENSITY == 0
    #define FX_HEAT_AMPLITUDE 0.0016     // Subtle
#elif HEAT_WAVE_INTENSITY == 1
    #define FX_HEAT_AMPLITUDE 0.0035     // Realistic
#else
    #define FX_HEAT_AMPLITUDE 0.0075     // Heavy
#endif

#if HEAT_BIOME_HAZE > 0 && !defined NETHER
    // Overworld hot-biome trackers, declared in shaders.properties.
    uniform float fxInDesert;
    uniform float fxInBadlands;
#endif

// Is this pixel a heat source? Returns 0..1.
float fxHeatSourceMask(vec3 c) {
    float l = fxLuma(c);
    // Warmth: red over blue, normalised. Fire and lava sit near 1, a white lamp
    // near 0.15, the sky below 0.
    float warmth = clamp((c.r - c.b) / max(c.r + c.b, 0.001), 0.0, 1.0);

    #if HEAT_BLOCK_SOURCES == 0
        // Torches & Fire -- moderate brightness, clearly warm.
        return clamp((l - 0.45) * 2.2, 0.0, 1.0) * clamp((warmth - 0.20) * 3.0, 0.0, 1.0);
    #elif HEAT_BLOCK_SOURCES == 1
        // Lava Only -- the strictest window: very bright and very orange.
        return clamp((l - 0.65) * 2.8, 0.0, 1.0) * clamp((warmth - 0.42) * 4.0, 0.0, 1.0);
    #else
        // All Hot Blocks -- also catches magma, campfires, dim embers.
        return clamp((l - 0.28) * 1.8, 0.0, 1.0) * clamp((warmth - 0.10) * 2.2, 0.0, 1.0);
    #endif
}

// Constant biome shimmer, independent of any on-screen source.
float fxHeatBiomeHaze() {
    #if HEAT_BIOME_HAZE == 0
        return 0.0;
    #else
        #ifdef NETHER
            #if HEAT_BIOME_HAZE == 2 || HEAT_BIOME_HAZE == 3
                return 1.0;              // Nether Only / Both
            #else
                return 0.0;
            #endif
        #else
            #if HEAT_BIOME_HAZE == 1 || HEAT_BIOME_HAZE == 3
                return clamp(fxInDesert + fxInBadlands, 0.0, 1.0);  // Desert & Badlands / Both
            #else
                return 0.0;
            #endif
        #endif
    #endif
}

vec2 HeatWaveUV(vec2 uv) {
    // Underwater has its own refraction; stacking them looks wrong.
    if (isEyeInWater != 0) return uv;

    // --- source-driven heat ---------------------------------------------------
    // Look downward from this pixel for something hot. HEAT_RISE_HEIGHT is given
    // in blocks, converted to a screen-space reach that shrinks with distance
    // (a torch 40 blocks away occupies far fewer pixels than one at arm's
    // length). The 0.045 constant is the empirical UV-per-block at 1 block
    // depth for a default FOV; it is a calibration constant, not a projection.
    float depth = fxLinearDepth(texture2D(depthtex0, uv).r);
    float riseUv = float(HEAT_RISE_HEIGHT) * 0.045 / max(depth * 0.25, 1.0);

    // Three probes down the rising column. More would be smoother, but this is
    // the final pass and three is enough to make the column continuous.
    float srcMask = 0.0;
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 0.33), vec2(0.0), vec2(1.0))).rgb) * 1.00);
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 0.66), vec2(0.0), vec2(1.0))).rgb) * 0.66);
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 1.00), vec2(0.0), vec2(1.0))).rgb) * 0.33);

    // --- biome haze -----------------------------------------------------------
    float haze = fxHeatBiomeHaze();
    // Haze builds with distance: the air column between you and a far surface is
    // what shimmers, so a wall in your face stays sharp.
    haze *= clamp(depth / 48.0, 0.0, 1.0);

    float heat = max(srcMask, haze * 0.55);
    if (heat <= 0.002) return uv;

    // --- distortion field -----------------------------------------------------
    // Two lookups at different frequencies and phases give x and y independent
    // motion, which is what makes it read as turbulence instead of a wobble.
    float t = frameTimeCounter * HEAT_WAVE_SPEED;
    vec2 p = uv * fxAspect() * 26.0;
    float nx = fxFbm2(p + vec2(0.0, -t * 1.15));
    float ny = fxFbm2(p * 1.31 + vec2(11.3, -t * 1.55));

    vec2 offset = (vec2(nx, ny) - 0.5) * 2.0 * FX_HEAT_AMPLITUDE * heat;
    // Hot air moves up, so the vertical component is biased and stronger.
    offset.y = offset.y * 1.6 + FX_HEAT_AMPLITUDE * heat * 0.35;

    return clamp(uv + offset, vec2(0.0), vec2(1.0));
}

#endif // HEAT_DISTORTION == 1

#endif // INCLUDE_FX_HEAT_WAVE
