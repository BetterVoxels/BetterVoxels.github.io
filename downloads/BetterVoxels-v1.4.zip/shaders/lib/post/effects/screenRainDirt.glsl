#ifndef INCLUDE_FX_SCREEN_RAIN
#define INCLUDE_FX_SCREEN_RAIN

// ------------------------------- Settings ------------------------------------
#define SCREEN_DROPLETS 0 //[0 1]
#define DROPLET_AMOUNT 1 //[0 1 2 3]
#define DROPLET_SLIDE_SPEED 1.0 //[0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
#define DROPLET_REFRACTION_FORCE 0.50 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SCREEN_DIRT_INTENSITY 30 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
#define DROPLET_GLARE_STRENGTH 0.60 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00]
#define DROPLET_LOOK_UP_SENSITIVITY 0 //[0 1 2]

// -- Advanced dynamics (v1.3.1) -----------------------------------------------
#define DROPLET_BASE_SCALE 1.15 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.15 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define DROPLET_SPAWN_TIME 4.0 //[0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]
#define DROPLET_GROWTH_DURATION 0.75 //[0.01 0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.75 0.9 1.0 1.25 1.5 1.75 2.0]
#define DROPLET_DRY_DURATION 5.0 //[0.5 1.0 1.5 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 12.0 15.0]
#define DROPLET_WATER_EXIT_BURST 0 //[0 1]
#define DROPLET_SHELTER_DRYING 1 //[0 1]

#if SCREEN_DROPLETS == 1

// rainStrength, eyeBrightness, isEyeInWater, frameTimeCounter are all declared
// in lib/uniforms.glsl (via common.glsl); do NOT redeclare them.
uniform float fxDropCoverage;
#if DROPLET_WATER_EXIT_BURST == 1
    uniform float fxDropExit;
#endif

// Cells across the screen width. More cells = more, smaller drops.
#if DROPLET_AMOUNT == 0
    #define FX_DROP_CELLS 7.0        // Sparse
#elif DROPLET_AMOUNT == 1
    #define FX_DROP_CELLS 11.0       // Medium
#elif DROPLET_AMOUNT == 2
    #define FX_DROP_CELLS 16.0       // Heavy
#else
    #define FX_DROP_CELLS 23.0       // Torrential
#endif

// How much of the lens the weather can reach, as a function of pitch.
float fxDropLookMask() {
    #if DROPLET_LOOK_UP_SENSITIVITY == 2
        return 1.0;
    #else
        float lookUp = fxViewDir().y;
        #if DROPLET_LOOK_UP_SENSITIVITY == 0
            return clamp((lookUp - 0.25) * 2.5, 0.0, 1.0);   // Strict
        #else
            return clamp((lookUp + 0.35) * 1.4, 0.0, 1.0);   // Moderate
        #endif
    #endif
}

// Single drop, size-driven life-cycle. Returns the drop mask in .x and the
// cell-local offset from the drop centre in .yz (differentiated into a
// refraction normal by the caller). `wet` is the global phase; `grow` selects
// the ease direction (true = growing in, false = evaporating out).
vec3 fxDropField(vec2 uv, float wet, bool grow) {
    vec2 cellUv = uv * fxAspect() * FX_DROP_CELLS;
    vec2 cellId = floor(cellUv);
    vec2 cellLocal = fract(cellUv) - 0.5;

    vec2 rnd = fxHash22(cellId);
    if (rnd.x < 0.35) return vec3(0.0);    // ~65% of cells ever hold a drop

    // Birth threshold: the phase level at which this drop is fully present.
    // Spread across the sparse range so drops pop in one-by-one as `wet` climbs.
    float birth = rnd.x;

    // Per-drop growth window as a fraction of the whole sweep. Smaller
    // GROWTH_DURATION relative to SPAWN_TIME -> snappier individual pop-in.
    float growFrac = clamp(DROPLET_GROWTH_DURATION / max(DROPLET_SPAWN_TIME, 0.01), 0.02, 1.0);

    // 0 while the phase is a full window below birth, 1 once it reaches birth.
    // As the phase recedes this falls again -> the drop shrinks in place.
    float t = clamp((wet - birth) / growFrac + 1.0, 0.0, 1.0);
    float size = grow ? fxEaseOutExpo(t) : fxEaseInExpo(t);
    if (size < 0.02) return vec3(0.0);

    // Centre: stable x, and a gentle downward settle drift on y (honours
    // DROPLET_SLIDE_SPEED). The drift is a slow saw-tooth sweeping the drop from
    // the top edge (-0.42) to the bottom edge (0.42) of the cell and wrapping;
    // the edge fade below takes the mask to 0 at both edges, so the wrap is
    // invisible -- no pop. Disappearance is driven by `size` (evaporation in
    // place), never by this motion, and the drift coefficient is small so a
    // drying drop barely moves before it vanishes.
    float driftPhase = fract(rnd.x + frameTimeCounter * DROPLET_SLIDE_SPEED * 0.02 * (0.6 + 0.8 * rnd.y));
    vec2 centre = vec2((rnd.x - 0.5) * 0.5, mix(-0.42, 0.42, driftPhase));
    vec2 d = cellLocal - centre;

    // Base radius (unchanged from v1.3) times the size envelope and the user
    // scale -- the 1.15 default is the "+15% bigger base" the spec asks for.
    float radius = (0.10 + rnd.y * 0.13) * DROPLET_BASE_SCALE * size;
    if (radius < 0.003) return vec3(0.0);

    float mask = 1.0 - smoothstep(radius * 0.45, radius, length(d));
    // Soft cell-edge fade so the drift wrap (and any over-large drop) fades out
    // at the border instead of clipping.
    mask *= 1.0 - smoothstep(0.40, 0.5, max(abs(cellLocal.x), abs(cellLocal.y)));

    return vec3(mask, d);
}

vec3 ApplyScreenRainDirt(vec3 color, sampler2D src, vec2 uv) {
    // --- global wetness phase --------------------------------------------------
    // Instantaneous "should be wetting" condition, evaluated here (all uniforms
    // are available) so we know whether fxDropCoverage is rising or falling and
    // can retime it with the correct seconds-slider.
    float skyOpen = clamp(float(eyeBrightness.y) / 240.0, 0.0, 1.0);
    float rainNow = clamp(rainStrength, 0.0, 1.0);
    #if DROPLET_SHELTER_DRYING == 1
        float wetCond = rainNow * skyOpen * float(isEyeInWater == 0);
    #else
        float wetCond = rainNow * float(isEyeInWater == 0);
    #endif

    float P = clamp(fxDropCoverage, 0.0, 1.0);
    float rainWet = (wetCond > 0.05)
        ? fxRetimeApproach(P, 4.0, DROPLET_SPAWN_TIME)   // accumulating
        : fxRetimeDecay(P, 6.0, DROPLET_DRY_DURATION);   // sheltered / rain over

    // Look-up is a SMOOTH WHOLE-LAYER gate, NOT part of the per-drop phase.
    // THIS IS THE FIX: folding the camera pitch into the phase made each drop
    // pop on/off as you tilted (the "raise a bit -> 3 more drops" stepping) and
    // freeze part-grown at a constant angle. Now the pitch only fades the whole
    // finished drop layer in/out; the per-drop life-cycle is driven purely by the
    // timer, so at a constant look-up angle the drops always finish growing.
    float lookGate = fxDropLookMask();

    float burst = 0.0;
    #if DROPLET_WATER_EXIT_BURST == 1
        // Resurfacing burst covers the whole screen regardless of pitch, and
        // dries over DROPLET_DRY_DURATION (retimed from the 5 s reference).
        burst = fxRetimeDecay(clamp(fxDropExit, 0.0, 1.0), 5.0, DROPLET_DRY_DURATION);
    #endif

    // Per-drop life-cycle phase: the ANGLE-FREE rain timer (or the burst). This
    // drives the Exponential-Out grow and Exponential-In dry over the user's
    // durations and never depends on where the camera points.
    float wet = max(rainWet, burst);
    if (isEyeInWater != 0) wet = 0.0;    // never on the lens while submerged

    // Growing while active rain is the rising source; otherwise evaporating.
    bool grow = (wetCond > 0.05) && (rainWet >= burst);

    // --- static grime ----------------------------------------------------------
    #if SCREEN_DIRT_INTENSITY > 0
        float grime = fxFbm2(uv * fxAspect() * 9.0);
        grime = smoothstep(0.55, 0.95, grime);
        vec2 edge = (uv - 0.5) * 2.0;
        grime *= 0.35 + 0.65 * dot(edge, edge);
        float dirtAmount = grime * (SCREEN_DIRT_INTENSITY * 0.01) * (0.45 + 0.55 * clamp(wet, 0.0, 1.0));
        color = mix(color, color * vec3(0.72, 0.70, 0.66), clamp(dirtAmount, 0.0, 1.0));
    #endif

    if (wet <= 0.004) return color;

    vec3 field = fxDropField(uv, wet, grow);
    float mask = field.x;
    // Whole-layer look-up fade: rain drops need the open sky in view, so they
    // fade in/out as ONE group with the pitch; the resurfacing burst shows
    // regardless of pitch. rainDominance selects between the two smoothly.
    float rainDominance = clamp((rainWet - burst) * 8.0 + 0.5, 0.0, 1.0);
    mask *= mix(1.0, lookGate, rainDominance);
    if (mask <= 0.001) return color;

    // Refraction: the offset from the drop centre is the lens normal, so no
    // finite differencing is needed. (Float define -> runtime compare, since the
    // GLSL preprocessor cannot evaluate a float in #if.)
    if (DROPLET_REFRACTION_FORCE > 0.0) {
        vec2 refractOffset = field.yz * mask * DROPLET_REFRACTION_FORCE * 0.35;
        vec2 refractUv = clamp(uv - refractOffset, vec2(0.0), vec2(1.0));
        color = mix(color, texture2D(src, refractUv).rgb, clamp(mask, 0.0, 1.0));
    }

    // Specular glint on the upper-left shoulder, scaled by scene brightness.
    if (DROPLET_GLARE_STRENGTH > 0.0) {
        float shoulder = 1.0 - smoothstep(0.0, 0.35, length(field.yz + vec2(0.045, 0.045)));
        float sceneLight = clamp(fxLuma(color) * 1.5, 0.0, 1.0);
        color += vec3(shoulder * mask * sceneLight * DROPLET_GLARE_STRENGTH * 0.5);
    }

    return color;
}

#endif // SCREEN_DROPLETS == 1

#endif // INCLUDE_FX_SCREEN_RAIN
