#ifndef INCLUDE_SCREEN_DROPLETS
#define INCLUDE_SCREEN_DROPLETS

#define WATER_DROPLETS // Water droplets on the camera when leaving water

#ifdef WATER_DROPLETS

// Wetness timer, maintained by Iris across frames (declared in
// shaders.properties; reads 0 when dry, so the effect self-disables).
uniform float exitWater;

float wdHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float wdNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = wdHash12(i);
    float b = wdHash12(i + vec2(1.0, 0.0));
    float c = wdHash12(i + vec2(0.0, 1.0));
    float d = wdHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

#define WD_NOISE_RES (512.0 / 20.0)

vec3 ApplyWaterDroplets(vec3 color, sampler2D src, vec2 uv) {
    if (isEyeInWater == 1 || exitWater <= 0.01) return color;

    float wdAspect = viewWidth / viewHeight;

    // Resurfacing field, ported from applyGameplayEffects(): it stretches
    // vertically as it dries (scale.y grows with exitWater^2) and SLIDES
    // DOWN the screen (the -exitWater offset shrinks with the timer), so
    // the drops run downward while thinning out.
    vec2 wdScaleXY = vec2(0.5, 0.25 + (exitWater * exitWater) * 0.25) * vec2(wdAspect, 1.0);
    float wdSlide = exitWater;

    float waterDrops = wdNoise((uv - vec2(0.0, wdSlide)) * wdScaleXY * WD_NOISE_RES);
    waterDrops = sqrt(min(max(waterDrops - (1.0 - sqrt(exitWater)) * 0.7, 0.0) * (1.0 + exitWater), 1.0)) * 0.3;

    // Iteration 42: SEAMLESS FADE-OUT. The refraction strength is attenuated
    // linearly by the decaying timer itself, so the physical distortion has
    // already reached imperceptibility by the time the 0.01 gate closes --
    // no end-of-animation pop.
    waterDrops *= exitWater;

    vec2 wdZoomUV = vec2(0.5) + (uv - vec2(0.5)) * (1.0 - waterDrops);
    return texture2D(src, wdZoomUV).rgb;
}

#endif // WATER_DROPLETS

#endif // INCLUDE_SCREEN_DROPLETS
