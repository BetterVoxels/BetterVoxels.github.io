#ifndef INCLUDE_COLOR_CORRECTION
    #define INCLUDE_COLOR_CORRECTION

/*==============================================================================
    COLOR CORRECTION  --  three grading profiles plus per-parameter tweaks

    CC_MODE picks a tonemap + grading baseline; every slider below stays live in
    all three modes, layered on top of that baseline. At default slider values
    CC_MODE 0 is bit-for-bit the pack's previous output.

      0  Default       the pack's inherited BSL tonemap (unchanged)
      1  Complementary DoCompTonemap from Complementary Reimagined r5.8.1:
                       a Lottes curve with dark-lift, path-to-white and dark
                       desaturation. This is the look Reimagined/Unbound ship.
      2  Realistic     AgX (minimal, Benjamin Wrensch's fit of Troy Sobotka's
                       AgX) as used by Bliss, plus Bliss's crosstalk, luminance
                       curve and split-tone grading.

    Grading order is display-referred, after the tonemap, which is where both
    Complementary and Bliss do theirs:
      saturation/vibrance -> crosstalk -> luminance curve -> brightness ->
      split toning.
==============================================================================*/

    // ---- per-mode baselines --------------------------------------------
    // Slider values are layered on top of these, so the sliders keep working
    // whichever mode is selected.
    #if CC_MODE == 1
        const float ccModeSaturation = 0.07;  // Complementary's own bump
        const float ccModeCrosstalk  = 0.00;
        const float ccModeCurveLower = 0.00;
        const float ccModeCurveUpper = 0.00;
        const vec3  ccModeShadows    = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.00, 1.00, 1.00);
    #elif CC_MODE == 2
        // AgX already carries the filmic roll-off, so the baseline only adds
        // the photographic touches: highlights drift to white, shadows cool,
        // highlights warm.
        const float ccModeSaturation = 0.00;
        const float ccModeCrosstalk  = 0.20;
        const float ccModeCurveLower = -0.10;
        const float ccModeCurveUpper = 0.10;
        const vec3  ccModeShadows    = vec3(0.98, 1.00, 1.06);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.05, 1.01, 0.96);
    #else
        const float ccModeSaturation = 0.00;
        const float ccModeCrosstalk  = 0.00;
        const float ccModeCurveLower = 0.00;
        const float ccModeCurveUpper = 0.00;
        const vec3  ccModeShadows    = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.00, 1.00, 1.00);
    #endif

    void ccLinearToRGB(inout vec3 color) {
        const vec3 k = vec3(0.055);
        color = mix((vec3(1.0) + k) * pow(color, vec3(1.0 / 2.4)) - k, 12.92 * color,
                    lessThan(color, vec3(0.0031308)));
    }

    // ---- Mode 0: the pack's inherited BSL tonemap ------------------------
    void ccTonemapDefault(inout vec3 color) {
        color = T_EXPOSURE * color;
        color = color / pow(pow(color, vec3(TM_WHITE_CURVE)) + 1.0, vec3(1.0 / TM_WHITE_CURVE));
        color = pow(color, mix(vec3(T_LOWER_CURVE), vec3(T_UPPER_CURVE), sqrt(color)));

        color = pow(color, vec3(1.0 / 2.2));
    }

    // ---- Mode 1: Complementary Reimagined r5.8.1 -------------------------
    // Lottes 2016, "Advanced Techniques and Optimization of HDR Color
    // Pipelines", as modified for Complementary Shaders.
    void ccTonemapComplementary(inout vec3 color) {
        color = T_EXPOSURE * color;

        float initialLuminance = GetLuminance(color);

        vec3 a      = vec3(TM_CONTRAST); // General contrast
        vec3 d      = vec3(1.0);         // Roll-off control
        vec3 hdrMax = vec3(8.0);         // Maximum input brightness
        vec3 midIn  = vec3(0.25);        // Input middle gray
        vec3 midOut = vec3(0.25);        // Output middle gray

        vec3 a_d = a * d;
        vec3 hdrMaxA = pow(hdrMax, a);
        vec3 hdrMaxAD = pow(hdrMax, a_d);
        vec3 midInA = pow(midIn, a);
        vec3 midInAD = pow(midIn, a_d);
        vec3 HM1 = hdrMaxA * midOut;
        vec3 HM2 = hdrMaxAD - midInAD;

        vec3 b = (-midInA + HM1) / (HM2 * midOut);
        vec3 c = (hdrMaxAD * midInA - HM1 * midInAD) / (HM2 * midOut);

        vec3 colorOut = pow(color, a) / (pow(color, a_d) * b + c);

        ccLinearToRGB(colorOut);

        // Remove tonemapping from darker colors for better readability
        const float darkLiftStart = 0.1;
        const float darkLiftMix = 0.75;
        float darkLift = smoothstep(darkLiftStart, 0.0, initialLuminance);
        vec3 smoothColor = pow(color, vec3(1.0 / 2.2));
        colorOut = mix(colorOut, smoothColor,
                       darkLift * darkLiftMix * max(0.55 - abs(1.05 - TM_CONTRAST), 0.0) / 0.55);

        // Path to White
        const float wpInputCurveStart = 0.0;
        const float wpInputCurveMax = 16.0;
        float modifiedLuminance = pow(initialLuminance / wpInputCurveMax, 2.0 - TM_WHITE_PATH) * wpInputCurveMax;
        float whitePath = smoothstep(wpInputCurveStart, wpInputCurveMax, modifiedLuminance);
        colorOut = mix(colorOut, vec3(1.0), whitePath);

        // Desaturate dark colors
        const float dpInputCurveStart = 0.1;
        const float dpInputCurveMax = 0.0;
        float desaturatePath = smoothstep(dpInputCurveStart, dpInputCurveMax, initialLuminance);
        colorOut = mix(colorOut, vec3(GetLuminance(colorOut)), desaturatePath * TM_DARK_DESATURATION);

        // Complementary's shaping curve, without re-applying exposure
        colorOut = pow(colorOut, mix(vec3(T_LOWER_CURVE - 0.10), vec3(T_UPPER_CURVE - 0.30), sqrt(colorOut)));

        color = clamp01(colorOut);
    }

    // ---- Mode 2: AgX (minimal), as shipped by Bliss ----------------------
    vec3 ccAgxContrastApprox(vec3 x) {
        vec3 x2 = x * x;
        vec3 x4 = x2 * x2;

        return + 15.5 * x4 * x2
            - 40.14 * x4 * x
            + 31.96 * x4
            - 6.868 * x2 * x
            + 0.4298 * x2
            + 0.1191 * x
            - 0.00232;
    }

    vec3 ccAgxLook(vec3 val) {
        const vec3 lw = vec3(0.2126, 0.7152, 0.0722);
        float luma = dot(val, lw);
        const float sat = 1.25;

        return luma + sat * (val - luma);
    }

    void ccTonemapRealistic(inout vec3 color) {
        // AgX constants from Benjamin Wrensch's minimal implementation
        const mat3 agxInset = mat3(
            0.842479062253094, 0.0423282422610123, 0.0423756549057051,
            0.0784335999999992, 0.878468636469772, 0.0784336,
            0.0792237451477643, 0.0791661274605434, 0.879142973793104);

        const mat3 agxOutset = mat3(
            1.19687900512017, -0.0528968517574562, -0.0529716355144438,
            -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
            -0.0990297440797205, -0.0989611768448433, 1.15107367264116);

        // LOG2_MIN = -10.0, LOG2_MAX = +6.5, MIDDLE_GRAY = 0.18
        const float agxMinEv = -12.47393;
        const float agxMaxEv = 4.026069;

        color = max(T_EXPOSURE * color, vec3(0.0));

        #if CC_EMITTER_CHROMA > 0
            // ---- Emitter chroma rescue (v1.4.1) -------------------------
            // AgX's inset matrix walks every channel toward the achromatic
            // axis on the way into the log curve. That is exactly what makes
            // it forgiving on skies and skin -- and it is also why lava, fire
            // and glowstone came out of Realistic as pale orange-white puddles
            // while Complementary's Lottes curve keeps them burning. Remember
            // the source chromaticity here so the sigmoid's output can be
            // pulled back toward it after the transform.
            vec3  preAgx = color;
            float preLum = max(GetLuminance(preAgx), 0.0001);
            float preMax = max(preAgx.r, max(preAgx.g, preAgx.b));
            float preSat = (preMax - min(preAgx.r, min(preAgx.g, preAgx.b))) / max(preMax, 0.0001);
        #endif

        color = agxInset * color;

        // Log2 encoding
        color = clamp(log2(color), agxMinEv, agxMaxEv);
        color = (color - agxMinEv) / (agxMaxEv - agxMinEv);

        // Sigmoid, then the AgX look transform
        color = ccAgxContrastApprox(color);
        color = ccAgxLook(color);

        color = agxOutset * color;

        // Bliss linearises here with pow(2.2) because the rest of its pipeline
        // is linear; this pack wants a display-encoded result out of the
        // tonemap, so that pow and our pow(1/2.2) would cancel. Both dropped.
        color = clamp01(color);

        #if CC_EMITTER_CHROMA > 0
            // Measure how much saturation the transform actually ate, rather
            // than guessing an absolute "this is an emitter" brightness: the
            // loss IS the symptom being corrected, and it is near zero for
            // everything AgX handles well. A luminance gate keeps deep,
            // strongly-tinted shadows out, so only genuinely bright sources
            // get their hue back.
            float outMax = max(color.r, max(color.g, color.b));
            float outSat = (outMax - min(color.r, min(color.g, color.b))) / max(outMax, 0.0001);

            float chromaLoss = clamp01((preSat - outSat) * 3.0);
            float emitter    = chromaLoss * smoothstep(0.5, 2.0, preLum);

            if (emitter > 0.0) {
                // The source hue re-imposed at the tonemapped luminance:
                // preAgx / preLum is unit-luminance chroma, so this only
                // changes the colour, never the brightness AgX chose. The
                // clamp lets the dominant channel pin at white instead of
                // running past it, which is what makes it read as "hot".
                vec3 restored = clamp01(preAgx * (GetLuminance(color) / preLum));
                color = mix(color, restored, emitter * CC_EMITTER_CHROMA * 0.01);
            }
        #endif
    }

    // ---- Sky chroma rescue for AgX (v1.4.1) -----------------------------
    // AgX walks bright colours toward white by construction. On terrain that is
    // the look people want from it; on the SKY it removes the blue outright --
    // the same view rendered in Complementary, whose Lottes curve keeps the
    // channel ratios, comes out properly blue while Realistic comes out white.
    // No amount of chroma in the palette fixes that, because the curve saturates
    // all three channels before the difference between them can survive.
    //
    // So the sky's own chromaticity is re-imposed at the luminance AgX picked.
    // The caller gates this on DEPTH, i.e. pixels with no geometry, which is why
    // it is safe where the general-purpose version was not: it cannot reach lit
    // terrain, only the backdrop. Neutral input stays neutral, so clouds and the
    // sun disc keep their white -- only what was already coloured gets it back.
    #if CC_MODE == 2 && CC_SKY_CHROMA > 0
        // skyUp is the cosine of the view elevation: 0 at the horizon, 1 straight
        // up. It is what makes the sky FADE TO WHITE toward the horizon the way
        // Complementary's does, instead of holding one flat blue all the way
        // down and meeting the distance haze at a hard line.
        //
        // Elevation has to come from the view direction, not from the colour:
        // measured at the horizon this sky is still 0.65 "cool" against 0.84 at
        // the zenith, so a hue test cannot separate them, and its luminance is
        // not monotonic with height either (the middle band is the brightest
        // part of the gradient). The geometry is the only honest signal.
        void ccRestoreSkyChroma(inout vec3 color, vec3 preTonemap, float skyUp) {
            // COOL PIXELS ONLY. Depth alone is not a fine enough gate: the sun
            // and moon discs are drawn into the sky too, and handing a disc its
            // own chromaticity back turns a blown-out white sun into an orange
            // ball with a red rim -- it is supposed to clip to white, that is
            // what "blown out" means. Blue sky and a warm disc are trivially
            // separable by which side of neutral they sit on, and unlike a
            // brightness threshold that test needs no knowledge of the scene's
            // absolute levels. Warm skies (sunset) are excluded by the same
            // measure and keep AgX's own rendering, which was never the
            // complaint.
            float cool = clamp01((preTonemap.b - preTonemap.r)
                              / max(preTonemap.b, 0.0001));
            float amount = CC_SKY_CHROMA * 0.01
                         * smoothstep(0.05, 0.35, cool)
                         * smoothstep(0.0, 0.45, skyUp);
            if (amount <= 0.0) return;

            float preLum = max(GetLuminance(preTonemap), 0.0001);
            vec3 restored = clamp01(preTonemap * (GetLuminance(color) / preLum));
            color = mix(color, restored, amount);
        }
    #endif

    void DoTonemap(inout vec3 color) {
        #if CC_MODE == 1
            ccTonemapComplementary(color);
        #elif CC_MODE == 2
            ccTonemapRealistic(color);
        #else
            ccTonemapDefault(color);
        #endif
    }

    // ---- Bliss luminance curve ------------------------------------------
    float ccLowerCurve(float x) {
        return clamp(16.0 * x * (0.5 - x) * 0.1, 0.0, 1.0);
    }

    float ccUpperCurve(float x) {
        return clamp(16.0 * (0.5 - x) * (x - 1.0) * 0.1, 0.0, 1.0);
    }

    // Normalised split-tone target. A neutral (1,1,1) target normalises to
    // 1/sqrt(3) per channel and the sqrt(3) below cancels it, so neutral
    // sliders leave the image untouched.
    vec3 ccGradeTarget(vec3 t) {
        float len = length(t);
        return len < 0.001 ? vec3(0.0) : t * (1.7320508076 / len);
    }

    void DoColorGrade(inout vec3 color) {
        // ---- 1. Vibrance + saturation (the pack's existing BSL pass) -----
        float saturationFactor = T_SATURATION * CC_SATURATION + ccModeSaturation;

        float grayVibrance = (color.r + color.g + color.b) / 3.0;
        float graySaturation = grayVibrance;
        if (saturationFactor < 1.00) graySaturation = dot(color, vec3(0.299, 0.587, 0.114));

        float mn = min(color.r, min(color.g, color.b));
        float mx = max(color.r, max(color.g, color.b));
        float sat = (1.0 - (mx - mn)) * (1.0 - mx) * grayVibrance * 5.0;
        vec3 lightness = vec3((mn + mx) * 0.5);

        color = mix(color, mix(color, lightness, 1.0 - T_VIBRANCE), sat);
        color = mix(color, lightness, (1.0 - lightness) * (2.0 - T_VIBRANCE) / 2.0 * abs(T_VIBRANCE - 1.0));
        color = color * saturationFactor - graySaturation * (saturationFactor - 1.0);

        // ---- 2. Crosstalk: bright colours drift towards white (Bliss) ----
        float crosstalk = CC_CROSSTALK + ccModeCrosstalk;
        if (crosstalk != 0.0) {
            float luminance = GetLuminance(color);
            color += (color - luminance) * (-luminance * crosstalk);
        }

        // ---- 3. Luminance curve / contrast (Bliss) -----------------------
        // Contrast is the simple knob: it crushes the lower curve and lifts the
        // upper one. The two curve sliders then offset each end independently.
        float contrast = CC_CONTRAST - 1.0;
        float curveLower = ccModeCurveLower + CC_CURVE_LOWER - contrast;
        float curveUpper = ccModeCurveUpper + CC_CURVE_UPPER + contrast;
        if (curveLower != 0.0 || curveUpper != 0.0) {
            color.r += curveLower * ccLowerCurve(color.r) + curveUpper * ccUpperCurve(color.r);
            color.g += curveLower * ccLowerCurve(color.g) + curveUpper * ccUpperCurve(color.g);
            color.b += curveLower * ccLowerCurve(color.b) + curveUpper * ccUpperCurve(color.b);
        }

        // ---- 4. Brightness ----------------------------------------------
        color *= CC_BRIGHTNESS;

        // ---- 5. Split toning by luma range (Bliss colorGrading) ----------
        vec3 shadowTint = vec3(CC_SHADOW_R, CC_SHADOW_G, CC_SHADOW_B) * ccModeShadows;
        vec3 midTint    = vec3(CC_MID_R,    CC_MID_G,    CC_MID_B)    * ccModeMids;
        vec3 highTint   = vec3(CC_HIGH_R,   CC_HIGH_G,   CC_HIGH_B)   * ccModeHighlights;

        float gradeLuma = dot(color, vec3(1.0 / 3.0));
        float shadowsAmount    = clamp(-6.0 * gradeLuma + 2.75, 0.0, 1.0);
        float midsAmount       = clamp(-abs(6.0 * gradeLuma - 3.0) + 1.25, 0.0, 1.0);
        float highlightsAmount = clamp(6.0 * gradeLuma - 3.25, 0.0, 1.0);

        color = color * (ccGradeTarget(shadowTint) * (CC_SHADOW_I * shadowsAmount)
                       + ccGradeTarget(midTint)    * (CC_MID_I    * midsAmount)
                       + ccGradeTarget(highTint)   * (CC_HIGH_I   * highlightsAmount));
    }

#endif //INCLUDE_COLOR_CORRECTION
