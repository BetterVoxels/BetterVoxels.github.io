/////////////////////////////////////
// Complementary Shaders by EminGT //
/////////////////////////////////////

//Common//
#include "/lib/common.glsl"

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FRAGMENT_SHADER

noperspective in vec2 texCoord;

//Pipeline Constants//
#include "/lib/pipelineSettings.glsl"

//Common Variables//
#if defined MC_ANISOTROPIC_FILTERING || COLORED_LIGHTING > 0
    #define ANY_ERROR_MESSAGE
#endif

#ifdef MC_ANISOTROPIC_FILTERING
    #define OPTIFINE_AF_ERROR
#endif

#if !defined IS_IRIS
    #define OPTIFINE_ACL_ERROR
#endif

#if COLORED_LIGHTING > 0 && defined MC_OS_MAC
    #define APPLE_ACL_ERROR
#endif

#if COLORED_LIGHTING > 0
    #define COORDINATES_ACL_ERROR
    #define SHADOWDISTANCE_ACL_ERROR
#endif

//Common Functions//
#if IMAGE_SHARPENING > 0
    vec2 viewD = 1.0 / vec2(viewWidth, viewHeight);

    vec2 sharpenOffsets[4] = vec2[4](
        vec2( viewD.x,  0.0),
        vec2( 0.0,  viewD.x),
        vec2(-viewD.x,  0.0),
        vec2( 0.0, -viewD.x)
    );

    void SharpenImage(inout vec3 color, vec2 texCoordM) {
        #ifdef TAA
            float sharpenMult = IMAGE_SHARPENING;
        #else
            float sharpenMult = IMAGE_SHARPENING * 0.5;
        #endif
        float mult = 0.0125 * sharpenMult;
        color *= 1.0 + 0.05 * sharpenMult;

        for (int i = 0; i < 4; i++) {
            color -= texture2D(colortex3, texCoordM + sharpenOffsets[i]).rgb * mult;
        }
    }
#endif

//Includes//
#ifdef ANY_ERROR_MESSAGE
    #include "/lib/textRendering/textRenderer.glsl"

    void beginTextM(int textSize, vec2 offset) {
        float scale = 860;
        beginText(ivec2(vec2(scale * viewWidth / viewHeight, scale) * texCoord) / textSize, ivec2(0 + offset.x, scale / textSize - offset.y));
        text.bgCol = vec4(0.0);
    }
#endif

#define WRITE_TO_SSBOS
#include "/lib/vx/SSBOs.glsl"

// Iteration 39: isolated retro post-processing overlay stack. Applied ONLY in
// this final pass, strictly on the finalized frame buffer; with every toggle
// OFF both entry points compile to the identity and the output is
// bit-identical to Iteration 38.
#include "/lib/post/retroVcr.glsl"
#include "/lib/post/asciiMode.glsl"
#include "/lib/post/bodyCam.glsl"
#include "/lib/post/screenDroplets.glsl"
// Iteration 42: underwater low-visibility disc blur (Camera menu slider).
#include "/lib/post/underwaterBlur.glsl"

// Iteration 43: the "Effects" stack. Five independent, individually configurable
// effects, each owning its own settings block and its own submenu. Same contract
// as the retro stack above: final pass only, finalized frame only, every effect
// OFF by default -- with all five off these entry points compile away entirely
// and the output is bit-identical to Iteration 42.
#include "/lib/post/effects/effectsCommon.glsl"
#include "/lib/post/effects/exposureSpike.glsl"
#include "/lib/post/effects/screenRainDirt.glsl"
#include "/lib/post/effects/lensFogging.glsl"
#include "/lib/post/effects/lightHalos.glsl"
#include "/lib/post/effects/heatWave.glsl"

//Program//
void main() {
    vec2 texCoordM = texCoord;

    #ifdef UNDERWATER_DISTORTION
        if (isEyeInWater == 1)
            texCoordM += WATER_REFRACTION_INTENSITY * 0.00035 * sin((texCoord.x + texCoord.y) * 25.0 + frameTimeCounter * 3.0);
    #endif

    #if PP_CRT_CURVATURE == 1 || PP_VHS_TAPE_DISTORTION == 1 || PP_RETRO_PIXELATE == 1
        // Iteration 39: UV-stage retro effects bend the fetch coordinate of the
        // finalized frame (screen curvature, tape distortion, pixelation).
        texCoordM = RetroPostUV(texCoordM);
    #endif

    // Iteration 43: Effects UV stage. Heat shimmer must bend the fetch
    // coordinate rather than smear an already-composited frame, so it runs here,
    // alongside the retro UV effects and before the buffer is read.
    #if HEAT_DISTORTION == 1
        texCoordM = HeatWaveUV(texCoordM);
    #endif

    vec3 color = texture2D(colortex3, texCoordM).rgb;

    #if CHROMA_ABERRATION > 0
        vec2 scale = vec2(1.0, viewHeight / viewWidth);
        vec2 aberration = (texCoordM - 0.5) * (2.0 / vec2(viewWidth, viewHeight)) * scale * CHROMA_ABERRATION;
        color.rb = vec2(texture2D(colortex3, texCoordM + aberration).r, texture2D(colortex3, texCoordM - aberration).b);
    #endif

    #if IMAGE_SHARPENING > 0
        SharpenImage(color, texCoordM);
    #endif

    /*ivec2 boxOffsets[8] = ivec2[8](
        ivec2( 1, 0),
        ivec2( 0, 1),
        ivec2(-1, 0),
        ivec2( 0,-1),
        ivec2( 1, 1),
        ivec2( 1,-1),
        ivec2(-1, 1),
        ivec2(-1,-1)
    );

    for (int i = 0; i < 8; i++) {
        color = max(color, texelFetch(colortex3, texelCoord + boxOffsets[i], 0).rgb);
    }*/

    #ifdef OPTIFINE_AF_ERROR
        #include "/lib/textRendering/error_optifine_af.glsl"
    #elif defined OPTIFINE_ACL_ERROR
        #include "/lib/textRendering/error_optifine_acl.glsl"
    #elif defined APPLE_ACL_ERROR
        #include "/lib/textRendering/error_apple_acl.glsl"
    #else
        #ifdef COORDINATES_ACL_ERROR
            ivec2 absCameraPositionIntXZ = abs(cameraPositionInt.xz);
            if (cameraPositionInt.y == -98257195) {
                absCameraPositionIntXZ = ivec2(abs(cameraPosition.xz));
            }
            if (max(absCameraPositionIntXZ.x, absCameraPositionIntXZ.y) > 8388550) {
                #include "/lib/textRendering/error_coordinates_acl.glsl"
            }
        #endif
        #ifdef SHADOWDISTANCE_ACL_ERROR
            if (COLORED_LIGHTING_INTERNAL > shadowDistance*2) {
                #include "/lib/textRendering/error_shadowdistance_acl.glsl"
            }
        #endif
    #endif

    #ifdef VIGNETTE_R
        vec2 texCoordMin = texCoordM.xy - 0.5;
        float vignette = 1.0 - dot(texCoordMin, texCoordMin) * (1.0 - GetLuminance(color));
        color *= vignette;
    #endif

    // Iteration 42: underwater blur (submerged only), then the resurfacing
    // water droplets (surface only) -- mutually exclusive by construction.
    #if UNDERWATER_BLUR > 0
        color = ApplyUnderwaterBlur(color, colortex3, texCoordM);
    #endif

    #ifdef WATER_DROPLETS
        color = ApplyWaterDroplets(color, colortex3, texCoordM);
    #endif

    // Iteration 43: Effects colour stage, in physical order along the light
    // path: light scattered inside the lens (halos) -> what is stuck ON the
    // lens (rain, grime) -> what is condensed on the glass (fogging) -> and
    // finally the sensor's own exposure response to all of it. Each stage is
    // independently OFF by default and fully isolated.
    #if LIGHT_HALOS == 1
        color = ApplyLightHalos(color, colortex3, texCoordM);
    #endif
    #if SCREEN_DROPLETS == 1
        // Rain-on-lens is disabled only once the camera is physically ABOVE the
        // whole cloud deck (base + ~100-block layer thickness); at/below the deck
        // aboveCloudFactor is strictly 0 so rain still falls on the ground.
        float aboveCloudFactor = clamp((cameraPosition.y - (float(CloudLayer0_height) + 100.0)) / 20.0, 0.0, 1.0);
        vec3 rainedColor = ApplyScreenRainDirt(color, colortex3, texCoordM);
        color = mix(rainedColor, color, aboveCloudFactor);
    #endif
    #if LENS_FOGGING == 1
        color = ApplyLensFogging(color, colortex3, texCoordM);
    #endif
    #if EXPOSURE_SPIKE == 1
        color = ApplyExposureSpike(color);
    #endif

    // Iteration 39/40: retro overlay injection -- the absolute end of the
    // pipeline. BodyCam first (it re-photographs the finished frame through
    // its own lens mapping), then ASCII Mode (it reconstructs the frame from
    // the glyph matrix), then the CRT/VCR effects layer on top of the result.
    // Each stage is independently OFF by default and fully isolated.
    #if PP_BODYCAM == 1
        color = ApplyBodyCam(colortex3, texCoord);
    #endif
    #if PP_ASCII_MODE == 1
        color = ApplyAsciiMode(colortex3, texCoordM);
    #endif
    #ifdef PP_RETRO_COLOR_STAGE
        ApplyRetroVcr(color, colortex3, texCoordM, texCoord);
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);

    int index = int(gl_FragCoord.x) + int(viewWidth + 0.5) * int(gl_FragCoord.y);
    int clearPerFragment = 1 + 4 * (1<<18) / int(viewWidth * viewHeight + 0.5);
    if (index < 4 * (1<<18) / clearPerFragment) {
        for (int j = 0; j < clearPerFragment; j++) {
            globalLightHashMap[index * clearPerFragment + j] = uint(0);
        }
    }

    if (gl_FragCoord.x < 0.0) gl_FragData[0] = texture(shadowcolor0, vec2(0.5));
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

//Attributes//

//Common Variables//

//Common Functions//

//Includes//
#define WRITE_TO_SSBOS
#include "/lib/vx/SSBOs.glsl"

//Program//
void main() {
    gbufferPreviousModelViewInverse = gbufferModelViewInverse;
    gbufferPreviousProjectionInverse = gbufferProjectionInverse;
    gl_Position = ftransform();
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
