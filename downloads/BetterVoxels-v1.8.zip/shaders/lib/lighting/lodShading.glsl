#ifndef INCLUDE_LOD_SHADING
#define INCLUDE_LOD_SHADING

vec3 LodViewPos(vec2 uv, float depth) {
    vec4 p = lodProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

vec3 GetLodNormal(ivec2 texel, vec3 P) {
    vec2 res = vec2(viewWidth, viewHeight);
    ivec2 tR = texel + ivec2(1, 0), tL = texel - ivec2(1, 0);
    ivec2 tU = texel + ivec2(0, 1), tD = texel - ivec2(0, 1);
    vec3 R = LodViewPos((vec2(tR) + 0.5) / res, texelFetch(lodDepthTex0, tR, 0).r);
    vec3 L = LodViewPos((vec2(tL) + 0.5) / res, texelFetch(lodDepthTex0, tL, 0).r);
    vec3 U = LodViewPos((vec2(tU) + 0.5) / res, texelFetch(lodDepthTex0, tU, 0).r);
    vec3 D = LodViewPos((vec2(tD) + 0.5) / res, texelFetch(lodDepthTex0, tD, 0).r);
    vec3 dx = abs(R.z - P.z) < abs(P.z - L.z) ? R - P : P - L;
    vec3 dy = abs(U.z - P.z) < abs(P.z - D.z) ? U - P : P - D;
    vec3 N = normalize(cross(dx, dy));
    return dot(N, P) > 0.0 ? -N : N;
}

#ifdef LOD_VOXY

    bool GetLodWaterGap(ivec2 texel, vec3 hitView, out vec3 waterView, out ivec2 waterTexel) {
        waterView = hitView;
        waterTexel = texel;
        vec3 hitPlayer = mat3(gbufferModelViewInverse) * hitView;
        if (hitPlayer.y >= 0.0 || length(hitPlayer.xz) < far - 32.0) return false;

        vec2 res = vec2(viewWidth, viewHeight);
        float offset = 1.0;
        for (int k = 0; k < 9; k++) {
            ivec2 q = texel + ivec2(0, int(offset));
            offset *= 2.0;
            if (q.y >= int(res.y)) return false;
            float qTrans = texelFetch(lodDepthTex0, q, 0).r;
            if (qTrans >= texelFetch(lodDepthTex1, q, 0).r) continue;

            float waterY = (mat3(gbufferModelViewInverse) * LodViewPos((vec2(q) + 0.5) / res, qTrans)).y;
            if (waterY > -0.05 || hitPlayer.y > waterY - 0.05) return false;
            vec3 crossing = hitPlayer * (waterY / hitPlayer.y);
            float crossingDist = length(crossing.xz);
            if (crossingDist < far - 64.0 || crossingDist > far + 32.0) return false;

            waterView = mat3(gbufferModelView) * crossing;
            waterTexel = q;
            return true;
        }
        return false;
    }
#endif

#if LOD_DISTANT_SHADOWS == 1

    float GetLodShadow(vec3 P, vec3 N, float dither) {
        if (dot(N, lightVec) < 0.02) return 1.0;
        vec2 res = vec2(viewWidth, viewHeight);
        float dist = length(P);
        vec3 start = P + N * (0.4 + dist * 0.003);
        float stepLen = 1.0 + dist * 0.005;
        float t = stepLen * dither;
        for (int i = 0; i < 14; i++) {
            t += stepLen;
            stepLen *= 1.4;
            vec3 S = start + lightVec * t;
            vec4 clip = lodProjection * vec4(S, 1.0);
            if (clip.w <= 0.0) break;
            vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) break;
            float d = texelFetch(lodDepthTexOccluder, ivec2(uv * res), 0).r;
            if (d < 1.0) {
                float ahead = LodViewPos(uv, d).z - S.z;
                if (ahead > 0.0 && ahead < 12.0 + t * 0.2) return 0.0;
            }
        }
        return 1.0;
    }
#endif

#if LOD_DISTANT_AO == 1

    float GetLodAO(vec3 P, vec3 N, ivec2 texel, float dither) {
        vec2 res = vec2(viewWidth, viewHeight);
        float dist = max(length(P), 1.0);
        float pxPerBlock = lodProjection[1][1] * 0.5 * res.y / dist;
        float radiusPx = clamp((3.0 + dist * 0.006) * pxPerBlock, 2.0, 40.0);
        float radius = radiusPx / pxPerBlock;
        float ao = 0.0;
        for (int i = 0; i < 8; i++) {
            float fi = float(i) + dither;
            float a = fi * 2.3999632;
            vec2 offset = vec2(cos(a), sin(a)) * radiusPx * sqrt(fi * 0.125);
            ivec2 st = clamp(texel + ivec2(offset), ivec2(0), ivec2(res) - 1);
            float d = texelFetch(lodDepthTexOccluder, st, 0).r;
            if (d >= 1.0) continue;
            vec3 v = LodViewPos((vec2(st) + 0.5) / res, d) - P;
            float l2 = dot(v, v);
            float falloff = max(1.0 - l2 / (radius * radius * 4.0), 0.0);
            ao += max(dot(N, v) * inversesqrt(l2 + 0.0001) - 0.15, 0.0) * falloff;
        }
        return 1.0 - min(ao * 0.25, 0.6);
    }
#endif

#endif
