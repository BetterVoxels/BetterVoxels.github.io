#if TAA_MODE == 1
    float blendMinimum = 0.3;
    float blendVariable = 0.2;
    float blendConstant = 0.7;

    float regularEdge = 20.0;
    float extraEdgeMult = 3.0;
#elif TAA_MODE == 2
    float blendMinimum = 0.6;
    float blendVariable = 0.2;
    float blendConstant = 0.7;

    float regularEdge = 5.0;
    float extraEdgeMult = 3.0;
#endif

#ifdef TAA_MOVEMENT_IMPROVEMENT_FILTER

    vec3 textureCatmullRom(sampler2D colortex, vec2 texcoord, vec2 view) {
        vec2 position = texcoord * view;
        vec2 centerPosition = floor(position - 0.5) + 0.5;
        vec2 f = position - centerPosition;
        vec2 f2 = f * f;
        vec2 f3 = f * f2;

        float c = 0.7;
        vec2 w0 =        -c  * f3 +  2.0 * c         * f2 - c * f;
        vec2 w1 =  (2.0 - c) * f3 - (3.0 - c)        * f2         + 1.0;
        vec2 w2 = -(2.0 - c) * f3 + (3.0 -  2.0 * c) * f2 + c * f;
        vec2 w3 =         c  * f3 -                c * f2;

        vec2 w12 = w1 + w2;
        vec2 tc12 = (centerPosition + w2 / w12) / view;

        vec2 tc0 = (centerPosition - 1.0) / view;
        vec2 tc3 = (centerPosition + 2.0) / view;
        vec4 color = vec4(texture2DLod(colortex, vec2(tc12.x, tc0.y ), 0).rgb, 1.0) * (w12.x * w0.y ) +
                    vec4(texture2DLod(colortex, vec2(tc0.x,  tc12.y), 0).rgb, 1.0) * (w0.x  * w12.y) +
                    vec4(texture2DLod(colortex, vec2(tc12.x, tc12.y), 0).rgb, 1.0) * (w12.x * w12.y) +
                    vec4(texture2DLod(colortex, vec2(tc3.x,  tc12.y), 0).rgb, 1.0) * (w3.x  * w12.y) +
                    vec4(texture2DLod(colortex, vec2(tc12.x, tc3.y ), 0).rgb, 1.0) * (w12.x * w3.y );
        return color.rgb / color.a;
    }
#endif

#ifdef CLOUDS_VOLUMETRIC
    #include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#endif
#if defined CLOUDS_VOLUMETRIC && VC_TEMPORAL == 1

    #define VC_CLOUD_TAA 1
    #include "/lib/atmospherics/clouds/volumetricWind.glsl"

    #include "/lib/atmospherics/clouds/volumetricGenus.glsl"

    vec3 vcToYCoCg(vec3 c) {
        return vec3(dot(c, vec3(0.25, 0.5, 0.25)),
                    dot(c, vec3(0.5, 0.0, -0.5)),
                    dot(c, vec3(-0.25, 0.5, -0.25)));
    }

    vec3 vcFromYCoCg(vec3 c) {
        return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z);
    }

    uniform sampler2D colortex15;

    vec2 vcCloudReprojection(vec4 viewPos1) {
        vec3 dir = normalize(mat3(gbufferModelViewInverse) * viewPos1.xyz);

        float dy = float(VC_G_ALT) + 0.5 * VC_G_THICK - cameraPosition.y;
        float s = dy >= 0.0 ? 1.0 : -1.0;
        float d = clamp(abs(dy) / max(dir.y * s, 0.03), 64.0, float(VC_REACH));
        vec3 v = vcWindVelocity();

        vec4 rp = texture2D(colortex15, texCoord);
        if (rp.a > 0.01) {
            d = clamp(rp.r / rp.a, 64.0, float(VC_REACH));
            v = vec3(rp.g / rp.a, 0.0, rp.b / rp.a);
        }

        vec3 prev = dir * d + (cameraPosition - previousCameraPosition)
                  - v * frameTime;
        vec4 pv = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prev, 1.0));
        return pv.xy / pv.w * 0.5 + 0.5;
    }
#endif

vec2 Reprojection(vec4 viewPos1) {
    vec4 pos = gbufferModelViewInverse * viewPos1;
    vec4 previousPosition = pos + vec4(cameraPosition - previousCameraPosition, 0.0);
    previousPosition = gbufferPreviousModelView * previousPosition;
    previousPosition = gbufferPreviousProjection * previousPosition;
    return previousPosition.xy / previousPosition.w * 0.5 + 0.5;
}

vec3 ClipAABB(vec3 q, vec3 aabb_min, vec3 aabb_max){
    vec3 p_clip = 0.5 * (aabb_max + aabb_min);
    vec3 e_clip = 0.5 * (aabb_max - aabb_min) + 0.00000001;

    vec3 v_clip = q - vec3(p_clip);
    vec3 v_unit = v_clip.xyz / e_clip;
    vec3 a_unit = abs(v_unit);
    float ma_unit = max(a_unit.x, max(a_unit.y, a_unit.z));

    if (ma_unit > 1.0)
        return vec3(p_clip) + v_clip / ma_unit;
    else
        return q;
}

ivec2 neighbourhoodOffsets[8] = ivec2[8](
    ivec2( 1, 1),
    ivec2( 1,-1),
    ivec2(-1, 1),
    ivec2(-1,-1),
    ivec2( 1, 0),
    ivec2( 0, 1),
    ivec2(-1, 0),
    ivec2( 0,-1)
);

void NeighbourhoodClamping(vec3 color, inout vec3 tempColor, float z0, float z1, inout float edge) {
    vec3 minclr = color;
    vec3 maxclr = minclr;

    int cc = 2;
    ivec2 texelCoordM1 = clamp(texelCoord, ivec2(cc), ivec2(view) - cc);
    for (int i = 0; i < 8; i++) {
        ivec2 texelCoordM2 = texelCoordM1 + neighbourhoodOffsets[i];

        float z0Check = texelFetch(depthtex0, texelCoordM2, 0).r;
        float z1Check = texelFetch(depthtex1, texelCoordM2, 0).r;
        if (max(abs(GetLinearDepth(z0Check) - GetLinearDepth(z0)), abs(GetLinearDepth(z1Check) - GetLinearDepth(z1))) > 0.09) {
            edge = regularEdge;

            if (int(texelFetch(colortex6, texelCoordM2, 0).g * 255.1) == 253)
                edge *= extraEdgeMult;
        }

        vec3 clr = texelFetch(colortex3, texelCoordM2, 0).rgb;
        minclr = min(minclr, clr); maxclr = max(maxclr, clr);
    }

    tempColor = ClipAABB(tempColor, minclr, maxclr);
}

#ifdef VC_CLOUD_TAA

    float vcCloudClip(vec3 color, inout vec3 tempColor) {
        vec3 c0 = vcToYCoCg(color);
        vec3 m1 = c0;
        vec3 m2 = c0 * c0;
        float n = 1.0;

        #if VC_HALF_RES == 1
            const int vcStride = VC_HALF_BLOCK;
            #if VC_Q_FIXED_STEPS > 0
                const float vcGamma = 2.0;
            #else
                const float vcGamma = 1.25;
            #endif
        #else
            const int vcStride = 1;
            const float vcGamma = 1.0;
        #endif
        int cc = 2 * vcStride;
        ivec2 texelCoordM1 = clamp(texelCoord, ivec2(cc), ivec2(view) - cc);
        for (int i = 0; i < 8; i++) {
            ivec2 texelCoordM2 = texelCoordM1 + neighbourhoodOffsets[i] * vcStride;
            if (texelFetch(depthtex1, texelCoordM2, 0).r < 1.0) continue;
            #ifdef LOD_ACTIVE
                if (texelFetch(lodDepthTex0, texelCoordM2, 0).r < 1.0) continue;
            #endif
            vec3 c = vcToYCoCg(texelFetch(colortex3, texelCoordM2, 0).rgb);
            m1 += c;
            m2 += c * c;
            n += 1.0;
        }

        vec3 mu = m1 / n;
        vec3 sigma = sqrt(max(m2 / n - mu * mu, vec3(0.0)));
        vec3 h = vcToYCoCg(tempColor);
        vec3 hc = ClipAABB(h, mu - sigma * vcGamma, mu + sigma * vcGamma);
        tempColor = vcFromYCoCg(hc);
        return length(h - hc) / max(mu.x, 0.0001);
    }
#endif

void DoTAA(inout vec3 color, inout vec3 temp, float z1) {
    int materialMask = int(texelFetch(colortex6, texelCoord, 0).g * 255.1);

    vec4 screenPos1 = vec4(texCoord, z1, 1.0);
    vec4 viewPos1 = gbufferProjectionInverse * (screenPos1 * 2.0 - 1.0);
    viewPos1 /= viewPos1.w;

    #ifdef ENTITY_TAA_NOISY_CLOUD_FIX
        float cloudLinearDepth =  texture2D(colortex4, texCoord).r;
        float lViewPos1 = length(viewPos1);

        if (pow2(cloudLinearDepth) * renderDistance < min(lViewPos1, renderDistance)) {
            materialMask = 0;
        }
    #endif

    if (materialMask == 254) {
        #ifndef CUSTOM_PBR
            if (z1 <= 0.56) return;
        #endif
        int i = 0;
        while (i < 4) {
            int mms = int(texelFetch(colortex6, texelCoord + neighbourhoodOffsets[i], 0).g * 255.1);
            if (mms != materialMask) break;
            i++;
        }
        if (i == 4) return;
    }

    float z0 = texelFetch(depthtex0, texelCoord, 0).r;

    vec2 prvCoord = texCoord;
    if (z1 > 0.56) prvCoord = Reprojection(viewPos1);
    #ifdef VC_CLOUD_TAA
        bool vcSky = z1 >= 1.0
            #ifdef LOD_ACTIVE
                && texelFetch(lodDepthTex0, texelCoord, 0).r >= 1.0
            #endif
            ;
        if (vcSky) prvCoord = vcCloudReprojection(viewPos1);
    #endif

    #ifndef TAA_MOVEMENT_IMPROVEMENT_FILTER
        vec3 tempColor = texture2D(colortex2, prvCoord).rgb;
    #else
        vec3 tempColor = textureCatmullRom(colortex2, prvCoord, view);
    #endif

    if (tempColor == vec3(0.0) || any(isnan(tempColor))) {
        temp = color;
        return;
    }

    float edge = 0.0;
    #ifdef VC_CLOUD_TAA
        float vcClip = 0.0;
        if (vcSky) vcClip = vcCloudClip(color, tempColor);
        else NeighbourhoodClamping(color, tempColor, z0, z1, edge);
    #else
        NeighbourhoodClamping(color, tempColor, z0, z1, edge);
    #endif

    if (materialMask == 253)
        edge *= extraEdgeMult;

    #ifdef LOD_ACTIVE
        if (z0 == 1.0) {
            blendMinimum = 0.75;
            blendVariable = 0.05;
            blendConstant = 0.9;
            edge = 1.0;
        }
    #endif

    vec2 velocity = (texCoord - prvCoord.xy) * view;
    float blendFactor = float(prvCoord.x > 0.0 && prvCoord.x < 1.0 &&
                              prvCoord.y > 0.0 && prvCoord.y < 1.0);
    float velocityFactor = dot(velocity, velocity) * 10.0;
    blendFactor *= max(exp(-velocityFactor) * blendVariable + blendConstant - length(cameraPosition - previousCameraPosition) * edge, blendMinimum);

    #ifdef VC_CLOUD_TAA
        if (vcSky) {
            float onScreen = float(prvCoord.x > 0.0 && prvCoord.x < 1.0 &&
                                   prvCoord.y > 0.0 && prvCoord.y < 1.0);
            blendFactor = onScreen * mix(0.7, 1.0 - 1.0 / float(VC_TEMPORAL_FRAMES),
                                         exp(-velocityFactor));
        }
    #endif

    color = mix(color, tempColor, blendFactor);
    temp = color;

    #if defined VC_CLOUD_TAA && VC_DEBUG == 10
        if (vcSky) color = vec3(clamp(vcClip * 4.0, 0.0, 1.0), blendFactor, 0.0);
        else color *= 0.25;
    #endif

}
