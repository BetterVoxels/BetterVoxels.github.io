
#ifndef INCLUDE_BV_STATE_SAMPLER
#define INCLUDE_BV_STATE_SAMPLER

#ifndef VOXY_PATCH
uniform sampler2D bv_state_sampler;
#endif

#define BV_ST_SMOOTH_X      0
#define BV_ST_AUTOEXP       ivec2(4, 0)
#define BV_ST_MOONZOOM      ivec2(5, 0)
#define BV_ST_CBIOME_BULK   ivec2(6, 0)
#define BV_ST_CBIOME_OUT    ivec2(7, 0)
#define BV_ST_PLIGHT_ROW0   1
#define BV_ST_RAIN          ivec2(64, 0)

#endif

#if (defined CSH || defined BV_AUTO_EXPOSURE_WRITER || defined BV_CUSTOM_BIOME_WRITER) && !defined INCLUDE_BV_STATE_IMAGE
#define INCLUDE_BV_STATE_IMAGE

layout(rgba32f) uniform image2D bvStateImg;

#endif
