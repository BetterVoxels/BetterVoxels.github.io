
#ifndef INCLUDE_SMOOTH_TIME_TRACKER
#define INCLUDE_SMOOTH_TIME_TRACKER

#define SMOOTH_TIME_JUMP_THRESHOLD 0.004

#include "/lib/misc/bvStateImage.glsl"

float SmoothTimeVisualSunAngle() {
    return texelFetch(bv_state_sampler, ivec2(BV_ST_SMOOTH_X + 1, 0), 0).r;
}

vec3 SmoothTimeVisualSkyColor() {
    return texelFetch(bv_state_sampler, ivec2(BV_ST_SMOOTH_X + 3, 0), 0).rgb;
}

#ifdef CSH

    #include "/lib/misc/timeInterpolation.glsl"

    void SmoothTimeUpdateState() {
        float nativeAngle = fract(sunAngle);
        float nowT = frameTimeCounter;

        float tIn  = max(TIME_TRANSITION_IN, 0.0);
        float tOut = max(TIME_TRANSITION_OUT, 0.0);
        float dur  = max(tIn + tOut, 0.05);

        vec4 s0 = imageLoad(bvStateImg, ivec2(BV_ST_SMOOTH_X + 0, 0));
        vec4 s1 = imageLoad(bvStateImg, ivec2(BV_ST_SMOOTH_X + 1, 0));
        vec4 cStart = imageLoad(bvStateImg, ivec2(BV_ST_SMOOTH_X + 2, 0));
        vec4 cEased = imageLoad(bvStateImg, ivec2(BV_ST_SMOOTH_X + 3, 0));

        if (s0.x != 1234.5 || nowT < s1.y - 0.5) {
            s0 = vec4(1234.5, nativeAngle, nowT - 2.0 * dur, nativeAngle);
            s1 = vec4(nativeAngle, nowT, 0.0, 0.0);
            cStart = vec4(skyColor, 0.0);
            cEased = vec4(skyColor, 0.0);
        } else {
            float dNative = fract(nativeAngle - s0.y + 0.5) - 0.5;
            if (abs(dNative) > SMOOTH_TIME_JUMP_THRESHOLD) {
                s0.z = nowT;
                s0.w = s1.x;
                cStart.rgb = cEased.rgb;

                float latched = fract(nativeAngle - s1.x + 0.5) - 0.5;
                s1.z = abs(abs(latched) - 0.5) < 0.001 ? 0.5 : latched;
            }
            s0.y = nativeAngle;

            float elapsed = nowT - s0.z;
            float p;
            if (elapsed >= dur) {
                p = 1.0;
            } else if (elapsed < tIn) {
                p = tIn > 0.0001 ? 0.5 * (elapsed / tIn) : 0.5;
            } else {
                p = tOut > 0.0001 ? 0.5 + 0.5 * ((elapsed - tIn) / tOut) : 1.0;
            }
            p = clamp(p, 0.0, 1.0);

            if (p >= 1.0) {
                s1.x = nativeAngle;
                s0.w = nativeAngle;
                cEased.rgb = skyColor;
                cStart.rgb = skyColor;
            } else {
                s1.x = fract(s0.w + s1.z * smoothTimeCurve(p));
                cEased.rgb = mix(cStart.rgb, skyColor, smoothTimeCurve(p));
            }
            s1.y = nowT;
        }

        imageStore(bvStateImg, ivec2(BV_ST_SMOOTH_X + 0, 0), s0);
        imageStore(bvStateImg, ivec2(BV_ST_SMOOTH_X + 1, 0), s1);
        imageStore(bvStateImg, ivec2(BV_ST_SMOOTH_X + 2, 0), cStart);
        imageStore(bvStateImg, ivec2(BV_ST_SMOOTH_X + 3, 0), cEased);
    }
#endif

#endif
