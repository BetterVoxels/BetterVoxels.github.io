
#ifndef INCLUDE_FUN_WORLD
#define INCLUDE_FUN_WORLD

#if FUN_CIRCLE == 1 || FUN_DISCO == 1 || FUN_SHUFFLE == 1
    vec3 bvFunBlockPos() {
        vec3 fractCam = cameraPositionInt.y == -98257195
                      ? fract(cameraPosition) : cameraPositionFract;
        return fract(vertexPos + fractCam) - 0.5;
    }

    vec3 bvFunBlockCell() {
        vec3 fractCam = cameraPositionInt.y == -98257195
                      ? fract(cameraPosition) : cameraPositionFract;
        return floor(vertexPos + fractCam);
    }

    float bvFunHash(vec2 p) {
        return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
    }
#endif

#if FUN_SHUFFLE == 1
    vec2 bvFunShuffleUV(vec2 uv) {
        vec2 tile = absMidCoordPos * 2.0;
        vec2 inTile = uv - midCoord;

        vec3 cell = bvFunBlockCell();
        float tick = floor(frameTimeCounter * 0.5);
        vec2 seed = cell.xz + cell.y * 37.0 + tick;

        vec2 jump = floor(vec2(bvFunHash(seed), bvFunHash(seed + 91.7)) * 16.0);
        return fract(midCoord + jump * tile) + inTile;
    }
#endif

#if FUN_CIRCLE == 1 || FUN_DISCO == 1
    const float funBallR = 0.5;

    void ApplyFunBlock(inout vec4 color, inout vec3 normalM) {
        vec3 inBlock = bvFunBlockPos();

        #if FUN_CIRCLE == 1
            vec3 n = normalize(ViewToPlayer(normalM * 10000.0));
            vec2 face;
            vec3 bulge;
            if (abs(n.y) > 0.5) {
                face = inBlock.xz;
                bulge = vec3(face.x, 0.0, face.y);
            } else if (abs(n.x) > 0.5) {
                face = inBlock.zy;
                bulge = vec3(0.0, face.y, face.x);
            } else {
                face = inBlock.xy;
                bulge = vec3(face.x, face.y, 0.0);
            }

            float r = length(face);
            if (r > funBallR) discard;

            float h = sqrt(max(funBallR * funBallR - r * r, 0.0)) / funBallR;
            normalM = normalize(mat3(gbufferModelView) * normalize(n * h + bulge / funBallR));
        #endif

        #if FUN_DISCO == 1
            vec3 cell = bvFunBlockCell();
            float phase = dot(cell, vec3(0.13, 0.27, 0.41)) * 0.1
                        + frameTimeCounter * 1.0 * 0.25;
            vec3 disco = 0.5 + 0.5 * cos(6.2831853 * (phase + vec3(0.0, 0.33, 0.67)));
            color.rgb = mix(color.rgb, color.rgb * disco * 2.0, 1.0);
        #endif
    }
#endif

#endif
