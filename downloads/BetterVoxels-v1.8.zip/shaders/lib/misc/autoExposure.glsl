#if AUTO_EXPOSURE == 1
#ifndef INCLUDE_AUTO_EXPOSURE
#define INCLUDE_AUTO_EXPOSURE

#include "/lib/misc/bvStateImage.glsl"

float bvAutoExposure() {
    float stored = texelFetch(bv_state_sampler, BV_ST_AUTOEXP, 0).g;
    if (stored <= 0.0) return 1.0;
    return mix(1.0, stored, AE_STRENGTH * 0.01);
}

#ifdef BV_AUTO_EXPOSURE_WRITER

    #include "/lib/misc/bvStateImage.glsl"

    const vec2 bvAeR2 = vec2(0.75487766624669276, 0.56984029099805327);

    vec2 bvAeSamplePoint(int i, vec2 jitter) {
        return fract(jitter + bvAeR2 * float(i));
    }

    float bvAeSoftPlus(float y, float k) {
        return 0.5 * (y + sqrt(y * y + k * k)) - 0.5 * k;
    }

    void bvAutoExposureUpdate(sampler2D scene, sampler2D sceneDepth) {
        vec4 s = imageLoad(bvStateImg, BV_ST_AUTOEXP);
        bool warm = (s.r == 4321.5) && (s.g > 0.0);
        float prevMean = warm ? s.a : 0.0;

        int n = AE_SAMPLES;

        vec2 jitter = fract(vec2(0.5) + bvAeR2 * float(frameCounter & 255));

        float logSum = 0.0, wSum = 0.0;
        float darkSum = 0.0, darkW = 0.0;
        float briteSum = 0.0, briteW = 0.0;

        for (int i = 0; i < n; i++) {
            vec2 uv = bvAeSamplePoint(i, jitter);

            float r = clamp(length(uv - 0.5) * 2.0, 0.0, 1.0);
            float w = mix(1.0, 1.0 - r * r, AE_CENTRE * 0.01);
            #if AE_SKY_WEIGHT < 100
                if (texture2D(sceneDepth, uv).r >= 1.0) w *= AE_SKY_WEIGHT * 0.01;
            #endif
            if (w <= 0.0) continue;

            float l = dot(texture2D(scene, uv).rgb, vec3(0.2125, 0.7154, 0.0721));
            l = clamp(l, 0.0001, 64.0);

            logSum += log(l) * w;
            wSum += w;

            if (l < prevMean) { darkSum += l * w; darkW += w; }
            else { briteSum += l * w; briteW += w; }
        }

        float invW = 1.0 / max(wSum, 0.0001);
        float base = exp(logSum * invW);
        float hot = (darkSum + briteSum) * invW;

        if (darkW > 0.0 && briteW > 0.0) {
            float kd = (darkW * invW) * (AE_DARK_WEIGHT * 0.01);
            float kb = (briteW * invW) * (AE_BRIGHT_WEIGHT * 0.01);
            hot = ((darkSum / darkW) * kd + (briteSum / briteW) * kb)
                / max(kd + kb, 0.0001);
        }

        float reference = min(base, AE_TARGET * 0.016);
        float excess = max(hot / max(reference * AE_HIGHLIGHT_KNEE * 0.01, 0.0001), 1.0);

        float ev = -(AE_HIGHLIGHT_RESPONSE * 0.01) * log2(excess);

        #if AE_LEVEL_RESPONSE > 0
            ev += (AE_LEVEL_RESPONSE * 0.01)
                * log2(max(AE_TARGET * 0.01, 0.0001) / max(base, 0.0001));
        #endif

        #if AE_DARKEN != 100 || AE_BRIGHTEN != 100
            ev *= ev < 0.0 ? AE_DARKEN * 0.01 : AE_BRIGHTEN * 0.01;
        #endif

        float lo = log2(max(AE_MIN * 0.01, 0.0001));
        float hi = log2(max(AE_MAX * 0.01, 0.0001));
        const float knee = 0.35;
        ev = hi - bvAeSoftPlus(hi - ev, knee);
        ev = lo + bvAeSoftPlus(ev - lo, knee);

        float want = exp2(ev);

        #if AE_MODE == 1
            want = min(want, 1.0);
        #elif AE_MODE == 2
            want = max(want, 1.0);
        #endif

        float now = frameTimeCounter;
        float adapted = want;

        if (warm && now >= s.b - 0.5) {
            float dt = clamp(now - s.b, 0.0, 1.0);
            float tau = want < s.g ? max(AE_SPEED_DOWN * 0.01, 0.02)
                                   : max(AE_SPEED_UP * 0.01, 0.02);
            adapted = mix(s.g, want, clamp(1.0 - exp(-dt / tau), 0.0, 1.0));
        }

        imageStore(bvStateImg, BV_ST_AUTOEXP, vec4(4321.5, adapted, now, hot));
    }
#endif

#endif
#endif
