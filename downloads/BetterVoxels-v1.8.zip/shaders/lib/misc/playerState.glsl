#ifndef INCLUDE_PLAYER_STATE
#define INCLUDE_PLAYER_STATE

uniform float currentPlayerAir;
uniform float maxPlayerAir;
uniform float currentPlayerArmor;

#endif
