#ifndef INCLUDE_SEASONS
#define INCLUDE_SEASONS

#ifdef SEASONS_ACTIVE

float bvSeasonPos() {
    #if SEASONS > 1
        return float(SEASONS - 2);
    #else
        float day = float(worldDay) + float(worldTime) / 24000.0;
        return mod(day / float(SEASON_LENGTH) + float(SEASON_START), 4.0);
    #endif
}

float bvSeasonBlend(float t) {
    #if SEASON_TRANSITION_START == 0
        return t;
    #elif SEASON_TRANSITION_START == 1
        return smoothstep(0.50, 1.0, t);
    #elif SEASON_TRANSITION_START == 2
        return smoothstep(0.66, 1.0, t);
    #elif SEASON_TRANSITION_START == 3
        return smoothstep(0.75, 1.0, t);
    #elif SEASON_TRANSITION_START == 4
        return smoothstep(0.80, 1.0, t);
    #else
        return smoothstep(0.90, 1.0, t);
    #endif
}

float bvSeasonWeight(int want) {
    float pos = bvSeasonPos();
    int s0 = int(pos);
    int s1 = (s0 + 1) & 3;
    float blend = bvSeasonBlend(fract(pos));
    return (s0 == want ? 1.0 - blend : 0.0) + (s1 == want ? blend : 0.0);
}

float bvSeasonWinterAmount() {
    return bvSeasonWeight(3);
}

vec3 bvSeasonGrassTint(int s) {
    if (s == 0) return vec3(1.05, 1.09, 0.86);
    if (s == 1) return vec3(1.00, 1.00, 1.00);
    if (s == 2) return vec3(1.24, 0.94, 0.54);
    return vec3(0.84, 0.88, 0.95);
}

vec3 bvSeasonLeafTint(int s) {
    if (s == 0) return vec3(1.04, 1.07, 0.88);
    if (s == 1) return vec3(1.00, 1.00, 1.00);
    if (s == 2) return vec3(1.48, 0.80, 0.36);
    return vec3(0.80, 0.84, 0.93);
}

float bvSeasonDesat(int s) {
    if (s == 2) return 0.55;
    if (s == 3) return 1.00;
    return 0.0;
}

float bvSeasonHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void bvSeasonFlowerLook(float pick, out vec3 petalCol, out vec3 heartCol, out int shape) {
    if (pick < 0.14) {
        petalCol = vec3(0.98, 0.84, 0.20); heartCol = vec3(0.99, 0.90, 0.32); shape = 0;
    } else if (pick < 0.26) {
        petalCol = vec3(0.96, 0.96, 0.94); heartCol = vec3(0.99, 0.86, 0.25); shape = 0;
    } else if (pick < 0.35) {
        petalCol = vec3(0.97, 0.97, 0.95); heartCol = vec3(0.98, 0.82, 0.15); shape = 1;
    } else if (pick < 0.43) {
        petalCol = vec3(0.85, 0.20, 0.18); heartCol = vec3(0.25, 0.18, 0.12); shape = 0;
    } else if (pick < 0.50) {
        petalCol = vec3(0.38, 0.45, 0.88); heartCol = vec3(0.75, 0.80, 0.95); shape = 0;
    } else if (pick < 0.56) {
        petalCol = vec3(0.80, 0.78, 0.92); heartCol = vec3(0.98, 0.90, 0.35); shape = 1;
    } else if (pick < 0.62) {
        petalCol = vec3(0.93, 0.55, 0.72); heartCol = vec3(0.86, 0.40, 0.58); shape = 0;
    } else if (pick < 0.68) {
        petalCol = vec3(0.95, 0.55, 0.18); heartCol = vec3(0.80, 0.34, 0.10); shape = 0;
    } else if (pick < 0.73) {
        petalCol = vec3(0.95, 0.95, 0.93); heartCol = vec3(0.83, 0.84, 0.80); shape = 0;
    } else if (pick < 0.78) {
        petalCol = vec3(0.68, 0.42, 0.85); heartCol = vec3(0.54, 0.30, 0.72); shape = 1;
    } else if (pick < 0.83) {
        petalCol = vec3(0.45, 0.75, 0.85); heartCol = vec3(0.95, 0.92, 0.60); shape = 0;
    } else if (pick < 0.88) {
        petalCol = vec3(0.96, 0.96, 0.94); heartCol = vec3(0.55, 0.70, 0.35); shape = 1;
    } else if (pick < 0.94) {
        petalCol = vec3(0.94, 0.94, 0.90); heartCol = vec3(0.94, 0.94, 0.90); shape = 3;
    } else {
        petalCol = vec3(0.99, 0.88, 0.25); heartCol = vec3(0.99, 0.88, 0.25); shape = 3;
    }
}

#if SEASON_AUTUMN_VARIETY == 1
    float bvAutumnNoise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(mix(bvSeasonHash(i), bvSeasonHash(i + vec2(1.0, 0.0)), f.x),
                   mix(bvSeasonHash(i + vec2(0.0, 1.0)), bvSeasonHash(i + vec2(1.0, 1.0)), f.x), f.y);
    }

    vec3 bvAutumnLeaf(vec3 leaf, vec3 tinted, vec3 worldPos) {
        float n = bvAutumnNoise(worldPos.xz / 9.0) * 0.7 + bvAutumnNoise(worldPos.xz / 31.0 + 17.0) * 0.3;
        n = clamp((n - 0.2) / 0.6, 0.0, 1.0);
        if (n < 0.12) return tinted;
        vec3 hue = n < 0.4 ? mix(vec3(0.95, 0.78, 0.22), vec3(0.97, 0.55, 0.14), (n - 0.12) / 0.28)
                 : n < 0.7 ? mix(vec3(0.97, 0.55, 0.14), vec3(0.85, 0.24, 0.10), (n - 0.4) / 0.3)
                 :           mix(vec3(0.85, 0.24, 0.10), vec3(0.58, 0.20, 0.12), (n - 0.7) / 0.3);
        const vec3 lumW = vec3(0.299, 0.587, 0.114);
        vec3 turned = hue * (dot(leaf, lumW) * mix(1.3, 0.95, n) / dot(hue, lumW));
        return mix(tinted, turned, smoothstep(0.12, 0.2, n));
    }
#endif

void bvApplySeasonEx(inout vec3 color, int mat, vec3 worldPos, float upFacing, bool withFlowers) {
    bool isLeaf = mat == 10009 || mat == 10013;
    bool isPlant = mat == 10005 || mat == 10021;
    bool isGrassBlock = mat == 10132;
    if (!isLeaf && !isPlant && !isGrassBlock) return;

    float pos = bvSeasonPos();
    int s0 = int(pos);
    int s1 = (s0 + 1) & 3;
    float blend = bvSeasonBlend(fract(pos));

    vec3 tint = isLeaf ? mix(bvSeasonLeafTint(s0), bvSeasonLeafTint(s1), blend)
                       : mix(bvSeasonGrassTint(s0), bvSeasonGrassTint(s1), blend);

    #if SEASON_AUTUMN_VARIETY == 1
        vec3 bvLeafBase = color;
    #endif
    color *= tint;
    #if SEASON_AUTUMN_VARIETY == 1

        if (isLeaf && worldPos != vec3(0.0)) {
            float autumnW = (s0 == 2 ? 1.0 - blend : 0.0) + (s1 == 2 ? blend : 0.0);
            if (autumnW > 0.001) color = mix(color, bvAutumnLeaf(bvLeafBase, color, worldPos), autumnW);
        }
    #endif

    float desat = mix(bvSeasonDesat(s0), bvSeasonDesat(s1), blend) * SEASON_COLOR_DESATURATION;
    color = mix(color, vec3(dot(color, vec3(0.299, 0.587, 0.114))), desat);

    #if SEASON_FLOWERS == 1 || SEASON_SNOW == 1
        float springAmount = (s0 == 0 ? 1.0 - blend : 0.0) + (s1 == 0 ? blend : 0.0);
        float winterAmount = (s0 == 3 ? 1.0 - blend : 0.0) + (s1 == 3 ? blend : 0.0);
    #endif

    #if SEASON_FLOWERS == 1
        if (withFlowers && isGrassBlock && upFacing > 0.5 && springAmount > 0.01) {
            vec2 cell = floor(worldPos.xz * 2.0);

            float clump = bvSeasonHash(floor(worldPos.xz / 7.0) + 5.0);
            clump = bvSeasonHash(floor(worldPos.xz / 2.5) + 61.0) * 0.35 + clump * 0.65;

            if (bvSeasonHash(cell) < mix(0.02, 0.55, clump * clump) * SEASON_FLOWER_DENSITY) {
                vec2 jitter = floor(vec2(bvSeasonHash(cell + 11.0),
                                         bvSeasonHash(cell + 23.0)) * 7.0) - 3.0;
                vec2 centre = floor((cell + 0.5) * 8.0) + jitter;

                vec2 diff = abs(floor(worldPos.xz * 16.0) - centre);
                float manhattan = diff.x + diff.y;
                bool isHeart = manhattan < 0.5;
                bool isPlus = manhattan > 0.5 && manhattan < 1.5;
                bool isDiag = diff.x > 0.5 && diff.y > 0.5 && max(diff.x, diff.y) < 1.5;

                vec3 petalCol, heartCol;
                int shape;
                bvSeasonFlowerLook(bvSeasonHash(cell + 37.0), petalCol, heartCol, shape);

                bool hit = isHeart
                        || (shape == 0 && isPlus)
                        || (shape == 1 && isDiag)
                        || (shape == 2 && (isPlus || isDiag));

                if (hit) {
                    vec3 petal = isHeart ? heartCol : petalCol;
                    petal *= 0.6 + 0.4 * dot(color, vec3(0.3333));
                    color = mix(color, petal, springAmount * 0.9);
                }
            }
        }
    #endif

    #if SEASON_SNOW == 1
        if (winterAmount > 0.01) {
            float frost = 1.0;
            if (isGrassBlock && upFacing <= 0.5) {
                frost = smoothstep(0.72, 0.94, fract(worldPos.y));
            }
            color = mix(color, vec3(0.90, 0.93, 0.98), winterAmount * 0.62 * frost);
        }
    #endif
}

void bvApplySeason(inout vec3 color, int mat, vec3 worldPos, float upFacing) {
    bvApplySeasonEx(color, mat, worldPos, upFacing, true);
}

void bvApplySeasonVoxel(inout vec3 color, int mat) {
    bvApplySeasonEx(color, mat, vec3(0.0), 1.0, false);
}

#endif

#endif
