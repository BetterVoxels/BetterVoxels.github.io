#ifndef INCLUDE_VOXELIZATION
    #define INCLUDE_VOXELIZATION
    float effectiveACLdistance = min(float(voxelVolumeSize.x), shadowDistance * 2.0);

    vec3 transform(mat4 m, vec3 pos) {
        return mat3(m) * pos + m[3].xyz;
    }

    vec3 SceneToVoxel(vec3 scenePos) {
        return scenePos + cameraPositionBestFract + (0.5 * vec3(voxelVolumeSize));
    }

    bool CheckInsideVoxelVolume(vec3 voxelPos) {
        #ifndef SHADOW
            voxelPos -= voxelVolumeSize / 2;
            voxelPos += sign(voxelPos) * 0.95;
            voxelPos += voxelVolumeSize / 2;
        #endif
        voxelPos /= vec3(voxelVolumeSize);
        return clamp01(voxelPos) == voxelPos;
    }

    int GetVoxelIDs(int mat) {
        #define ALWAYS_DO_IPBR_LIGHTS

        #if defined IPBR || defined ALWAYS_DO_IPBR_LIGHTS
            #define DO_IPBR_LIGHTS
        #endif

        if (mat < 10564) {
            if (mat < 10356) {
                if (mat < 10300) {
                    if (mat < 10228) {
                        if (mat == 10056) return  14;
                        if (mat == 10068) return  13;
                        if (mat == 10072) return   5;
                        if (mat == 10076) return  27;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10216) return  62;
                        if (mat == 10224) return  63;
                        #endif
                    } else {
                        if (mat == 10228) return 255;
                        #if defined GLOWING_ORE_ANCIENTDEBRIS && defined DO_IPBR_LIGHTS
                        if (mat == 10252) return  52;
                        #endif
                        #if defined GLOWING_ORE_IRON && defined DO_IPBR_LIGHTS
                        if (mat == 10272) return  43;
                        if (mat == 10276) return  43;
                        #endif
                        #if defined GLOWING_ORE_COPPER && defined DO_IPBR_LIGHTS
                        if (mat == 10284) return  45;
                        if (mat == 10288) return  45;
                        #endif
                    }
                } else {
                    if (mat < 10332) {
                        #if defined GLOWING_ORE_GOLD && defined DO_IPBR_LIGHTS
                        if (mat == 10300) return  44;
                        if (mat == 10304) return  44;
                        #endif
                        #if defined GLOWING_ORE_NETHERGOLD && defined DO_IPBR_LIGHTS
                        if (mat == 10308) return  50;
                        #endif
                        #if defined GLOWING_ORE_DIAMOND && defined DO_IPBR_LIGHTS
                        if (mat == 10320) return  48;
                        if (mat == 10324) return  48;
                        #endif
                    } else {
                        if (mat == 10332) return  36;
                        #if defined GLOWING_ORE_EMERALD && defined DO_IPBR_LIGHTS
                        if (mat == 10340) return  47;
                        if (mat == 10344) return  47;
                        #endif
                        #if defined EMISSIVE_LAPIS_BLOCK && defined DO_IPBR_LIGHTS
                        if (mat == 10352) return  42;
                        #endif
                    }
                }
            } else {
                if (mat < 10496) {
                    if (mat < 10448) {
                        #if defined GLOWING_ORE_LAPIS && defined DO_IPBR_LIGHTS
                        if (mat == 10356) return  46;
                        if (mat == 10360) return  46;
                        #endif
                        #if defined GLOWING_ORE_NETHERQUARTZ && defined DO_IPBR_LIGHTS
                        if (mat == 10368) return  49;
                        #endif
                        if (mat == 10396) return  11;
                        if (mat == 10404) return   6;
                        if (mat == 10412) return  10;
                    } else {
                        if (mat == 10448) return  18;
                        if (mat == 10452) return  37;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10456) return  60;
                        #endif
                        if (mat == 10476) return  26;
                        #if defined GLOWING_ORE_GILDEDBLACKSTONE && defined DO_IPBR_LIGHTS
                        if (mat == 10484) return  51;
                        #endif
                    }
                } else {
                    if (mat < 10528) {
                        if (mat == 10496) return   2;
                        if (mat == 10500) return   3;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10508) return  39;
                        if (mat == 10512) return  39;
                        #endif
                        if (mat == 10516) return  21;
                    } else {
                        if (mat == 10528) return  28;
                        if (mat == 10544) return  34;
                        if (mat == 10548) return  33;
                        if (mat == 10556) return  58;
                        if (mat == 10560) return  12;
                    }
                }
            }
        } else {
            if (mat < 10696) {
                if (mat < 10620) {
                    if (mat < 10592) {
                        if (mat == 10564) return  29;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10572) return  38;
                        #endif
                        if (mat == 10576) return  22;
                        if (mat == 10580) return  23;
                    } else {
                        if (mat == 10592) return  17;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10596) return  66;
                        #endif
                        if (mat == 10604) return  35;
                        #if defined EMISSIVE_REDSTONE_BLOCK && defined DO_IPBR_LIGHTS
                        if (mat == 10608) return  41;
                        #endif
                        #if defined GLOWING_ORE_REDSTONE && defined DO_IPBR_LIGHTS
                        if (mat == 10612) return  32;
                        #endif
                        if (mat == 10616) return  31;
                    }
                } else {
                    if (mat < 10648) {
                        #if defined GLOWING_ORE_REDSTONE && defined DO_IPBR_LIGHTS
                        if (mat == 10620) return  32;
                        #endif
                        if (mat == 10624) return  31;
                        if (mat == 10632) return  20;
                        if (mat == 10640) return  16;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10644) return  67;
                        if (mat == 10646) return  66;
                        #endif
                    } else {
                        if (mat == 10648) return  19;
                        if (mat == 10652) return  15;
                        if (mat == 10656) return  30;
                        if (mat == 10680) return   7;
                        if (mat == 10684) return   8;
                        if (mat == 10688) return   9;
                    }
                }
            } else {
                if (mat < 10868) {
                    if (mat < 10780) {
                        if (mat == 10696) return  57;
                        if (mat == 10700) return  57;
                        if (mat == 10704) return  57;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10708) return  53;
                        if (mat == 10736) return  64;
                        if (mat == 10776) return  61;
                        #endif
                    } else {
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10780) return  61;
                        #endif
                        if (mat == 10784) return  36;
                        if (mat == 10788) return  36;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10836) return  40;
                        #endif
                        if (mat == 10852) return  55;
                        if (mat == 10856) return  56;
                    }
                } else {
                    if (mat < 30020) {
                        if (mat == 10868) return  54;
                        if (mat == 10872) return  68;
                        if (mat == 10876) return  69;
                        #ifdef DO_IPBR_LIGHTS
                        if (mat == 10884) return  65;
                        #endif
                        #ifndef COLORED_CANDLE_LIGHT
                        if (mat >= 10900 && mat <= 10922) return 24;
                        #else
                        if (mat == 10900) return  24;
                        if (mat == 10902) return  70;
                        if (mat == 10904) return  71;
                        if (mat == 10906) return  72;
                        if (mat == 10908) return  73;
                        if (mat == 10910) return  74;
                        if (mat == 10912) return  75;
                        if (mat == 10914) return  76;
                        if (mat == 10916) return  77;
                        if (mat == 10918) return  78;
                        if (mat == 10920) return  79;
                        if (mat == 10922) return  80;
                        #endif
                        if (mat == 10948) return  82;
                        if (mat == 10972) return  83;
                        if (mat == 10976) return  81;
                        if (mat == 10980) return  81;
                        if (mat == 30008) return 254;
                        if (mat == 30012) return 213;
                        if (mat == 30016) return 201;
                    } else {
                        if (mat == 30020) return  25;
                        if (mat >= 31000 && mat < 32000) return 200 + (mat - 31000) / 2;
                        if (mat == 32004) return 216;
                        if (mat == 32008) return 217;
                        if (mat == 32012) return 218;
                        if (mat == 32016) return   4;
                    }
                }
            }
        }

        return 1;
    }

    #if defined SHADOW && defined VERTEX_SHADER
        void UpdateVoxelMap(int mat) {
            if (mat == 32000
            || mat < 30000 && mat % 4 == 1
            || mat < 10000
            ) return;

            vec3 modelPos = gl_Vertex.xyz + at_midBlock.xyz / 64.0;
            vec3 viewPos = transform(gl_ModelViewMatrix, modelPos);
            vec3 scenePos = transform(shadowModelViewInverse, viewPos);
            vec3 voxelPos = SceneToVoxel(scenePos);

            bool isEligible = any(equal(ivec4(renderStage), ivec4(
                MC_RENDER_STAGE_TERRAIN_SOLID,
                MC_RENDER_STAGE_TERRAIN_TRANSLUCENT,
                MC_RENDER_STAGE_TERRAIN_CUTOUT,
                MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED)));

            if (isEligible && CheckInsideVoxelVolume(voxelPos)) {
                int voxelData = GetVoxelIDs(mat);

                imageStore(voxel_img, ivec3(voxelPos), uvec4(voxelData, 0u, 0u, 0u));
            }
        }
    #endif

#endif
