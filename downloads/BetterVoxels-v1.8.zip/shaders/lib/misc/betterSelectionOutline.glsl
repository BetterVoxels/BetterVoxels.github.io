#ifndef INCLUDE_BETTER_SELECTION_OUTLINE
#define INCLUDE_BETTER_SELECTION_OUTLINE

#ifdef BETTER_SELECTION_OUTLINE_ACTIVE

uniform vec3 currentSelectedBlockPos;

bool BvSelectionOutlineRim(vec3 playerPos, vec3 worldNormal, int matId, vec2 texCoordM,
                           vec2 midCoordM, vec2 absMidM, vec2 texGrad) {
    if (currentSelectedBlockPos.x < -255.0) return false;

    #if SELECT_OUTLINE_BETTER_IGNORE_LEAVES == 1
        if (matId == 10009 || matId == 10013) return false;
    #endif

    vec3 inward = playerPos - 0.012 * worldNormal;
    if (any(greaterThan(abs(inward - currentSelectedBlockPos), vec3(0.5)))) return false;

    vec2 lo = midCoordM - absMidM;
    vec2 hi = midCoordM + absMidM;
    vec2 radius = texGrad * SELECT_OUTLINE_BETTER_WIDTH;

    for (int k = 0; k < 8; k++) {
        float a = float(k) * 0.7853981634;
        vec2 p = clamp(texCoordM + vec2(cos(a), sin(a)) * radius, lo, hi);
        if (textureLod(tex, p, 0.0).a > 0.1) return true;
    }
    return false;
}

vec3 BvSelectionOutlineColor(vec3 playerPos) {
    #if SELECT_OUTLINE == 2
        float posFactor = playerPos.x + playerPos.y + playerPos.z
                        + cameraPosition.x + cameraPosition.y + cameraPosition.z;
        return clamp(abs(mod(fract(frameTimeCounter * 0.25 + posFactor * 0.2) * 6.0
                             + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0,
                     0.0, 1.0) * vec3(3.0, 2.0, 3.0) * SELECT_OUTLINE_I;
    #else
        return vec3(SELECT_OUTLINE_R, SELECT_OUTLINE_G, SELECT_OUTLINE_B) * SELECT_OUTLINE_I;
    #endif
}

#endif

#endif
