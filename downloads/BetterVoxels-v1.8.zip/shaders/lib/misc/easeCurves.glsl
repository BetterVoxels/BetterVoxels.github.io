#ifndef INCLUDE_EASE_CURVES
#define INCLUDE_EASE_CURVES

float bvEaseCurve(float p, int mode) {
    p = clamp(p, 0.0, 1.0);

    if (mode == 0) {
        return p;
    } else if (mode == 1) {
        return p * p;
    } else if (mode == 2) {
        float q = 1.0 - p;
        return 1.0 - q * q;
    } else if (mode == 3) {
        return p * p * (3.0 - 2.0 * p);
    } else if (mode == 4) {
        return p * p * p * (p * (p * 6.0 - 15.0) + 10.0);
    } else if (mode == 5) {
        return p >= 1.0 ? 1.0 : 1.0 - exp2(-10.0 * p);
    } else if (mode == 6) {
        if (p <= 0.0) return 0.0;
        if (p >= 1.0) return 1.0;
        float raw = p < 0.5 ? 0.5 * exp2(20.0 * p - 10.0)
                            : 1.0 - 0.5 * exp2(-20.0 * p + 10.0);
        float lo6 = 0.5 * exp2(-10.0);
        return (raw - lo6) / (1.0 - 2.0 * lo6);
    } else if (mode == 7) {
        return 0.5 - 0.5 * cos(3.14159265358979 * p);
    }

    float k = 12.0;
    float lo = 1.0 / (1.0 + exp(k * 0.5));
    float hi = 1.0 / (1.0 + exp(-k * 0.5));
    return (1.0 / (1.0 + exp(-k * (p - 0.5))) - lo) / (hi - lo);
}

#endif
