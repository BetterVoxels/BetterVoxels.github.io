
#ifndef INCLUDE_WORLD_CURVATURE
#define INCLUDE_WORLD_CURVATURE

#ifdef WORLD_CURVATURE_ACTIVE

float bvCurveScale() {
    #if WORLD_CURVATURE == 2
        return clamp((cameraPosition.y - 62.0) / float(WORLD_CURVATURE_AUTO_ALT),
                     0.0, WORLD_CURVATURE_AUTO_MAX);
    #else
        return 1.0;
    #endif
}

float bvCurveDrop(vec2 offsetXZ) {
    float curve = (WORLD_CURVATURE_I * 0.01) * 0.0004 * bvCurveScale();
    #ifdef LOD_ACTIVE
        float lodEdge = lodRenderDistanceRaw;
        float curveCap = 0.7 * max(cameraPosition.y - 62.0, 16.0) / max(lodEdge * lodEdge, 1.0);
        curve = clamp(curve, -curveCap, curveCap);
    #endif
    return dot(offsetXZ, offsetXZ) * curve;
}

vec3 bvCurveWorld(vec3 playerPos) {
    playerPos.y -= bvCurveDrop(playerPos.xz);
    return playerPos;
}

#ifdef VERTEX_SHADER
    vec4 bvCurveFTransform() {
        vec4 p = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
        p.xyz = bvCurveWorld(p.xyz);
        return gl_ProjectionMatrix * (gbufferModelView * p);
    }
#endif

#endif

#endif
