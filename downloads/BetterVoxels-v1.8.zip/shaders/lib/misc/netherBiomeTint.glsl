#ifndef INCLUDE_NETHER_BIOME_TINT
#define INCLUDE_NETHER_BIOME_TINT

#if NETHER_BIOME_PORTAL == 1 || NETHER_BIOME_LAVA == 1

    float bvNetherBiomeWeight() {
        return clamp(bvBiomeNetherwastes + bvBiomeCrimson + bvBiomeWarped
                   + bvBiomeBasalt + bvBiomeSoulvalley, 0.0, 1.0);
    }

    vec3 bvNetherBiomeHue(vec3 wastes, vec3 crimson, vec3 warped,
                          vec3 basalt, vec3 soul) {
        vec3 acc = wastes * bvBiomeNetherwastes + crimson * bvBiomeCrimson
                 + warped * bvBiomeWarped + basalt * bvBiomeBasalt
                 + soul * bvBiomeSoulvalley;
        return acc / max(bvNetherBiomeWeight(), 0.0001);
    }

    vec3 bvNetherBiomeSteer(vec3 base, vec3 hue, float strength) {
        const vec3 lumW = vec3(0.2125, 0.7154, 0.0721);
        float baseLum = dot(base, lumW);
        float hueLum = max(dot(hue, lumW), 0.0001);
        vec3 matched = hue * (baseLum / hueLum);
        return mix(base, matched, clamp(strength, 0.0, 1.0) * bvNetherBiomeWeight());
    }
#endif

#if NETHER_BIOME_PORTAL == 1
    vec3 bvNetherPortalTint(vec3 base) {
        vec3 hue = bvNetherBiomeHue(
            vec3(0.62, 0.24, 1.00),
            vec3(1.00, 0.20, 0.34),
            vec3(0.16, 1.00, 0.86),
            vec3(0.55, 0.62, 0.80),
            vec3(0.24, 0.62, 1.00));
        return bvNetherBiomeSteer(base, hue, NETHER_PORTAL_TINT_I * 0.01);
    }
#endif

#if NETHER_BIOME_LAVA == 1
    vec3 bvNetherLavaTint(vec3 base) {
        vec3 hue = bvNetherBiomeHue(
            vec3(1.00, 0.42, 0.10),
            vec3(1.00, 0.26, 0.10),
            vec3(0.40, 1.00, 0.72),
            vec3(1.00, 0.56, 0.22),
            vec3(0.52, 0.72, 1.00));
        return bvNetherBiomeSteer(base, hue, NETHER_LAVA_TINT_I * 0.01);
    }
#endif

#endif
