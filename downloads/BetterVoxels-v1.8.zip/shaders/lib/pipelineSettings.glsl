/*
const int colortex0Format = R11F_G11F_B10F;
const int colortex1Format = R32F;
const int colortex2Format = RGB16F;
const int colortex3Format = RGBA8;
const int colortex4Format = RGBA8;
const int colortex5Format = RGBA8_SNORM;
const int colortex6Format = RGBA8;
const int colortex7Format = RGBA16F;
const int colortex8Format = RGBA16F;
const int colortex9Format = R32UI;
const int colortex10Format= RGBA16F;
const int colortex11Format= RGBA16I;
const int colortex12Format= RGBA16F;
const int colortex13Format= RGBA16F;
const int colortex14Format= RGBA16F;
const int colortex15Format= RGBA16F;

const int shadowcolor2Format = RGBA16f;
*/

const bool colortex0Clear = true;
const bool colortex1Clear = false;
const bool colortex2Clear = false;
const bool colortex3Clear = true;
const bool colortex4Clear = false;
const bool colortex5Clear = false;
#ifdef BLOCKLIGHT_HIGHLIGHT
    const bool colortex6Clear = false;
#endif
const bool colortex7Clear = false;
const bool colortex8Clear = false;
const bool colortex9Clear = false;
const bool colortex10Clear = false;
const bool colortex11Clear = false;
const bool colortex12Clear = false;
const bool colortex13Clear = false;
const bool colortex14Clear = false;
const bool colortex15Clear = true;

const bool shadowcolor2Clear = false;

const int noiseTextureResolution = 128;

const bool shadowHardwareFiltering = true;
const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.5;

const float drynessHalflife = 300.0;
const float wetnessHalflife = 300.0;

const float ambientOcclusionLevel = 1.0;
