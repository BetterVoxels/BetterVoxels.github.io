#ifndef INCLUDE_LOD_LAYER
#define INCLUDE_LOD_LAYER

#if defined DISTANT_HORIZONS && !defined VOXY_PATCH
    #define LOD_ACTIVE 1
    #define LOD_DH 1
    #define lodDepthTex0 dhDepthTex
    #define lodDepthTex1 dhDepthTex1
    #define lodProjection dhProjection
    #define lodProjectionInverse dhProjectionInverse
    #define lodRenderDistanceRaw float(dhRenderDistance)
    #define LOD_DISABLE_BORDER_FOG DH_DISABLE_BORDER_FOG
    #define LOD_EDGE_FOG_DISTANCE DH_EDGE_FOG_DISTANCE
    #define LOD_SEASONS DH_SEASONS
    #define lodDepthTexOccluder dhDepthTex
    #define LOD_SEAM_BLEND DH_SEAM_BLEND
    #define LOD_NETHER_TERRAIN DH_NETHER_TERRAIN
    #define LOD_DISTANT_LIGHTS DH_DISTANT_LIGHTS
    #define LOD_DISTANT_SHADOWS DH_DISTANT_SHADOWS
    #define LOD_DISTANT_AO DH_DISTANT_AO
    #define LOD_CLOUD_SHADOWS DH_CLOUD_SHADOWS
#elif defined VOXY || defined VOXY_PATCH
    #define LOD_ACTIVE 1
    #define LOD_VOXY 1
    #define lodDepthTex0 vxDepthTexTrans
    #define lodDepthTex1 vxDepthTexOpaque
    #define lodProjection vxProj
    #define lodProjectionInverse vxProjInv

    #define lodRenderDistanceRaw max(float(vxRenderDistance) * 16.0 - 256.0, far)
    #define LOD_DISABLE_BORDER_FOG VOXY_DISABLE_BORDER_FOG
    #define LOD_EDGE_FOG_DISTANCE VOXY_EDGE_FOG_DISTANCE
    #define LOD_SEASONS VOXY_SEASONS

    #define lodDepthTexOccluder vxDepthTexOpaque

    #define LOD_SEAM_BLEND 0
    #define LOD_NETHER_TERRAIN VOXY_NETHER_TERRAIN
    #define LOD_DISTANT_LIGHTS VOXY_DISTANT_LIGHTS
    #define LOD_DISTANT_SHADOWS VOXY_DISTANT_SHADOWS
    #define LOD_DISTANT_AO VOXY_DISTANT_AO
    #define LOD_CLOUD_SHADOWS VOXY_CLOUD_SHADOWS
#endif

#if defined LOD_ACTIVE && (defined DH_TERRAIN || defined DH_WATER || defined VOXY_PATCH)
    #define LOD_PROGRAM 1
#endif

#endif
