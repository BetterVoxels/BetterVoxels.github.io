#ifndef INCLUDE_BIOME_WATER_COLOR
#define INCLUDE_BIOME_WATER_COLOR

#ifdef BV_BIOME_IDS_ACTIVE

    void bvBwAccum(float w, vec3 col, inout vec3 acc, inout float total) {
        acc += w * col;
        total += w;
    }

    vec3 bvBiomeWaterColor() {
        vec3 acc = vec3(0.0);
        float total = 0.0;

        bvBwAccum(bvBiomeSwamp,           vec3(0.3804, 0.4824, 0.3922), acc, total);
        bvBwAccum(bvBiomeMangrove,        vec3(0.2275, 0.4784, 0.4157), acc, total);
        bvBwAccum(bvBiomeCherry,          vec3(0.3647, 0.7176, 0.9373), acc, total);
        bvBwAccum(bvBiomeMeadow,          vec3(0.0549, 0.3059, 0.8118), acc, total);
        bvBwAccum(bvBiomeWarmocean,       vec3(0.2627, 0.8353, 0.9333), acc, total);
        bvBwAccum(bvBiomeLukeocean,       vec3(0.2706, 0.6784, 0.9490), acc, total);
        bvBwAccum(bvBiomeDeeplukeocean,   vec3(0.2706, 0.6784, 0.9490), acc, total);
        bvBwAccum(bvBiomeColdocean,       vec3(0.2392, 0.3412, 0.8392), acc, total);
        bvBwAccum(bvBiomeDeepcoldocean,   vec3(0.2392, 0.3412, 0.8392), acc, total);
        bvBwAccum(bvBiomeSnowybeach,      vec3(0.2392, 0.3412, 0.8392), acc, total);
        bvBwAccum(bvBiomeSnowtaiga,       vec3(0.2392, 0.3412, 0.8392), acc, total);
        bvBwAccum(bvBiomeFrozenocean,     vec3(0.2235, 0.2196, 0.7882), acc, total);
        bvBwAccum(bvBiomeDeepfrozenocean, vec3(0.2235, 0.2196, 0.7882), acc, total);
        bvBwAccum(bvBiomeFrozenriver,     vec3(0.2235, 0.2196, 0.7882), acc, total);

        return mix(vec3(0.2471, 0.4627, 0.8941), acc / max(total, 0.0001), min(total, 1.0));
    }

    const float bvBiomeWaterSat = 0.70;

    vec3 bvBiomeWaterTint(vec3 base, vec3 tint, float strength) {
        float lo = min(min(tint.r, tint.g), tint.b);
        vec3 vivid = tint - lo * bvBiomeWaterSat;

        float baseMax = max(max(base.r, base.g), base.b);
        float vividMax = max(max(vivid.r, vivid.g), vivid.b);
        vec3 hued = vivid * (baseMax / max(vividMax, 0.0001));

        return mix(base, hued, clamp(strength, 0.0, 1.0));
    }
#endif

#endif
