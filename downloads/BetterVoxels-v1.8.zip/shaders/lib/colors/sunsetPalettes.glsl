#ifndef INCLUDE_SUNSET_PALETTES
#define INCLUDE_SUNSET_PALETTES

#define SUNSET_MODE 6 //[0 1 2 3 4 5 6]

#define SUNSET_STRENGTH 100 //[0 25 50 75 100 125 150 200 300]

#define BV_SUNSET_PEAK 2.2

float bvLum(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float bvSat(vec3 c) {
    float mx = max(c.r, max(c.g, c.b));
    return 1.0 - min(c.r, min(c.g, c.b)) / max(mx, 0.0001);
}

vec3 bvCapSat(vec3 p, float sMax) {
    if (bvSat(p) <= sMax) return p;
    float L = bvLum(p);
    float mx = max(p.r, max(p.g, p.b));
    float mn = min(p.r, min(p.g, p.b));
    float den = (1.0 - sMax) * (mx - L) - (mn - L);
    float k = clamp(sMax * L / max(den, 0.0001), 0.0, 1.0);
    return vec3(L) + (p - vec3(L)) * k;
}

float bvSunsetMargin(int s) {
    return s == 0 ? 0.12 : (s == 1 ? 0.15 : (s == 2 ? 0.10 : 0.05));
}

int bvSunsetMode() {
    #if SUNSET_MODE == 6
        float day = float(worldDay) + (worldTime >= 18000 ? 1.0 : 0.0);
        float h = fract(sin(mod(day, 1000.0) * 12.9898 + 4.1414) * 43758.5453);
        return 1 + int(min(h * 5.0, 4.0));
    #else
        return SUNSET_MODE;
    #endif
}

vec3 bvPick5(int s, vec3 up, vec3 middle, vec3 down, vec3 light, vec3 ambient) {
    return s == 0 ? up : (s == 1 ? middle : (s == 2 ? down : (s == 3 ? light : ambient)));
}

vec3 bvSunsetHue(int m, int s) {
    if (m == 1) return bvPick5(s,
        vec3(0.62, 0.60, 0.72), vec3(1.00, 0.66, 0.42), vec3(1.00, 0.50, 0.16),
        vec3(1.00, 0.58, 0.28), vec3(0.80, 0.68, 0.66));
    if (m == 2) return bvPick5(s,
        vec3(0.55, 0.40, 0.85), vec3(0.95, 0.52, 0.62), vec3(1.00, 0.52, 0.18),
        vec3(1.00, 0.58, 0.30), vec3(0.72, 0.60, 0.82));
    if (m == 3) return bvPick5(s,
        vec3(0.66, 0.50, 0.68), vec3(1.00, 0.42, 0.50), vec3(1.00, 0.24, 0.24),
        vec3(1.00, 0.42, 0.26), vec3(0.82, 0.60, 0.66));
    if (m == 4) return bvPick5(s,
        vec3(0.66, 0.50, 0.64), vec3(1.00, 0.34, 0.32), vec3(1.00, 0.52, 0.16),
        vec3(1.00, 0.50, 0.26), vec3(0.84, 0.62, 0.62));
    return bvPick5(s,
        vec3(0.52, 0.32, 0.82), vec3(0.88, 0.32, 0.58), vec3(1.00, 0.26, 0.28),
        vec3(1.00, 0.42, 0.28), vec3(0.70, 0.56, 0.80));
}

vec3 bvSunsetSlot(int slot, vec3 classic) {
    #if SUNSET_MODE == 0
        return classic;
    #else

        vec3 hue = pow(bvSunsetHue(bvSunsetMode(), slot), vec3(2.2));
        vec3 p = hue * (bvLum(classic) / max(bvLum(hue), 0.0001));

        p = bvCapSat(p, min(bvSat(classic)
                            + bvSunsetMargin(slot) * (SUNSET_STRENGTH * 0.01), 0.95));

        float pk = max(p.r, max(p.g, p.b));
        p *= min(1.0, BV_SUNSET_PEAK / max(pk, 0.0001));

        if (slot == 4) p = mix(classic, p, 0.35);

        return mix(p, classic, rainFactor);
    #endif
}

#endif
