
#ifndef INCLUDE_ATMOSPHERE_LUT
#define INCLUDE_ATMOSPHERE_LUT

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"

#define ATM_TRANS_W 128
#define ATM_TRANS_H 64

#define ATM_RAYLEIGH 100 //[0 25 50 75 100 125 150 200 300 400]
#define ATM_RAYLEIGH_H 80 //[40 50 60 70 80 90 100 120 150]

#define ATM_MIE 100 //[0 25 50 75 100 150 200 300 500 800]
#define ATM_MIE_H 12 //[4 6 8 10 12 15 20 30]

#define ATM_OZONE 100 //[0 50 100 150 200 300]

#define ATM_THICKNESS 100 //[40 60 80 100 120 150 200]

const float atmGroundRadius = 6360000.0;
const float atmTopRadius = atmGroundRadius + float(ATM_THICKNESS) * 1000.0;
const vec3 atmRayleighBeta = vec3(5.802e-6, 13.558e-6, 33.100e-6) * (float(ATM_RAYLEIGH) * 0.01);
const float atmRayleighH = float(ATM_RAYLEIGH_H) * 100.0;
const float atmMieExtinct = 8.396e-6 * (float(ATM_MIE) * 0.01);
const float atmMieH = float(ATM_MIE_H) * 100.0;
const vec3 atmOzoneBeta = vec3(0.650e-6, 1.881e-6, 0.085e-6) * (float(ATM_OZONE) * 0.01);

vec3 atmExtinction(float h) {
    float r = exp(-h / atmRayleighH);
    float m = exp(-h / atmMieH);
    float o = max(0.0, 1.0 - abs(h - 25000.0) / 15000.0);
    return atmRayleighBeta * r + vec3(atmMieExtinct * m) + atmOzoneBeta * o;
}

float atmRayTop(float r, float mu) {
    float disc = r * r * (mu * mu - 1.0) + atmTopRadius * atmTopRadius;
    return max(0.0, -r * mu + sqrt(max(disc, 0.0)));
}

float atmUnitToTex(float u, float n) {
    return 0.5 / n + u * (1.0 - 1.0 / n);
}

float atmTexToUnit(float u, float n) {
    return (u - 0.5 / n) / (1.0 - 1.0 / n);
}

vec2 atmLutUv(float r, float mu) {
    float H = sqrt(max(atmTopRadius * atmTopRadius - atmGroundRadius * atmGroundRadius, 1.0));
    float rho = sqrt(max(r * r - atmGroundRadius * atmGroundRadius, 0.0));
    float d = atmRayTop(r, mu);
    float dMin = atmTopRadius - r;
    float dMax = rho + H;
    float u = (d - dMin) / max(dMax - dMin, 1.0);
    return vec2(atmUnitToTex(clamp(u, 0.0, 1.0), float(ATM_TRANS_W)),
                atmUnitToTex(clamp(rho / H, 0.0, 1.0), float(ATM_TRANS_H)));
}

void atmLutParams(vec2 uv, out float r, out float mu) {
    float H = sqrt(max(atmTopRadius * atmTopRadius - atmGroundRadius * atmGroundRadius, 1.0));
    float rho = atmTexToUnit(uv.y, float(ATM_TRANS_H)) * H;
    r = sqrt(rho * rho + atmGroundRadius * atmGroundRadius);

    float dMin = atmTopRadius - r;
    float dMax = rho + H;
    float d = dMin + atmTexToUnit(uv.x, float(ATM_TRANS_W)) * (dMax - dMin);
    mu = d < 1.0 ? 1.0 : clamp((H * H - rho * rho - d * d) / (2.0 * r * d), -1.0, 1.0);
}

vec3 atmBuildTransmittance(vec2 uv) {
    float r, mu;
    atmLutParams(uv, r, mu);

    float d = atmRayTop(r, mu);
    float seg = d / 40.0;
    vec3 tau = vec3(0.0);

    for (int i = 0; i < 40; i++) {
        float t = seg * (float(i) + 0.5);
        float h = sqrt(max(r * r + t * t + 2.0 * r * t * mu, 0.0)) - atmGroundRadius;
        tau += atmExtinction(max(h, 0.0)) * seg;
    }

    return exp(-tau);
}

#ifndef ATM_LUT_WRITER

    vec3 atmTransmittance(float r, float mu) {
        vec2 uv = atmLutUv(r, mu);

        vec2 px = vec2(uv.x * float(ATM_TRANS_W) + float(VC_CURL_X0),
                       uv.y * float(ATM_TRANS_H) + float(VC_CURL_RES));
        return textureLod(vc_weather_sampler, vcAtlasUV(px), 0.0).rgb;
    }

    void atmSamplePoint(vec3 rel, float camAlt, out float r, out vec3 up) {
        float s = float(VC_WORLD_SCALE);
        float invR = 1.0 / atmGroundRadius;
        vec3 relM = rel * s;
        float camM = camAlt * s;

        float horiz2 = relM.x * relM.x + relM.z * relM.z;
        float alt = camM + relM.y + horiz2 * (0.5 * invR);

        r = atmGroundRadius + alt;
        up = normalize(vec3(relM.x * invR, 1.0 + alt * invR, relM.z * invR));
    }

    vec3 atmSegmentCamEnd(float camAlt, vec3 rd, out bool rising) {
        float rCam;
        vec3 upCam;
        atmSamplePoint(vec3(0.0), camAlt, rCam, upCam);
        float muCam = dot(upCam, rd);
        rising = muCam >= 0.0;
        return max(atmTransmittance(rCam, abs(muCam)), vec3(0.0001));
    }

    vec3 atmSegmentTo(vec3 camEnd, bool rising, float rHit, vec3 upHit, vec3 rd) {
        float muHit = dot(upHit, rd);
        vec3 hitEnd = max(atmTransmittance(rHit, rising ? muHit : -muHit), vec3(0.0001));
        return clamp(rising ? camEnd / hitEnd : hitEnd / camEnd, vec3(0.0), vec3(1.0));
    }

    vec3 atmSegmentTransmittance(vec3 rel, float camAlt, vec3 rd) {
        bool rising;
        vec3 camEnd = atmSegmentCamEnd(camAlt, rd, rising);
        float rHit;
        vec3 upHit;
        atmSamplePoint(rel, camAlt, rHit, upHit);
        return atmSegmentTo(camEnd, rising, rHit, upHit, rd);
    }
#endif

#endif
