
#if defined MOON_ZOOM_ACTIVE || defined REALISTIC_MOON_ACTIVE
#ifndef INCLUDE_MOON_ZOOM
#define INCLUDE_MOON_ZOOM

uniform sampler2D colortex10;

#ifdef REALISTIC_MOON_ACTIVE
    #if SUN_MOON_STYLE == 2
        const float rmTexRadius = 0.0733;
    #else
        const float rmTexRadius = 0.0605;
    #endif
    const float rmBranchCos = 0.9740;

    void RmFrame(vec3 nViewPos, vec3 moonDir, vec3 upVecM, float moonUp, out vec2 local, out float texScale, out float low, out vec3 phaseDir, out vec3 moonTint) {
        low = 1.0 - smoothstep(0.0, 0.42, moonUp);
        float scale = 1.0 + 0.55 * low;
        float squash = 1.0 - 0.08 * low * low;
        vec3 mUp = normalize(upVecM - moonDir * dot(upVecM, moonDir));
        vec3 mRight = cross(moonDir, mUp);
        texScale = sin(rmTexRadius) * scale;
        local = vec2(dot(nViewPos, mRight), dot(nViewPos, mUp) / squash);
        phaseDir = normalize(moonDir * dot(nViewPos, moonDir) + (mRight * local.x + mUp * local.y) / scale);

        float airmass = 1.0 / (max(moonUp, 0.0) + 0.09);
        vec3 ext = exp(-max(airmass - 1.0, 0.0) * vec3(0.06, 0.13, 0.30));
        moonTint = vec3(0.38, 0.4, 0.5) * 3.0 * ext / pow(max(dot(ext, vec3(0.2126, 0.7152, 0.0722)), 0.05), 0.6);
    }

    vec3 GetRealisticMoon(vec3 nViewPos, vec3 moonDir, vec3 upVecM, float moonUp, out float mask, out vec3 phaseDir, out vec3 glow) {
        mask = 0.0;
        vec2 local;
        float texScale, low;
        vec3 moonTint;
        RmFrame(nViewPos, moonDir, upVecM, moonUp, local, texScale, low, phaseDir, moonTint);

        float r = length(local) / texScale;
        glow = moonTint * 0.585 * exp(-max(r - 0.849, 0.0) / 0.3) * (0.06 + 0.22 * low);

        vec2 diskUV = local / texScale * 0.5 + 0.5;
        if (any(lessThan(diskUV, vec2(0.0))) || any(greaterThan(diskUV, vec2(1.0)))) return vec3(0.0);

        float pixelUV = (1.0 + 5.0 * low * low) / (gbufferProjection[1][1] * viewHeight * texScale);
        vec4 hd = texture2D(colortex10, diskUV);
        vec3 sumRgb = hd.rgb * hd.a;
        float sumA = hd.a;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * 0.7853981634;
            vec2 dir = vec2(cos(a), sin(a)) * pixelUV;
            vec4 s1 = texture2D(colortex10, diskUV + dir * 0.5);
            vec4 s2 = texture2D(colortex10, diskUV + dir * 0.25);
            sumRgb += s1.rgb * s1.a + s2.rgb * s2.a;
            sumA += s1.a + s2.a;
        }
        mask = clamp(sumA * 0.058823529, 0.0, 1.0);
        float lum = dot(sumRgb / max(sumA, 0.001), vec3(0.2126, 0.7152, 0.0722));
        return moonTint * lum;
    }
#endif

#ifdef MOON_ZOOM_ACTIVE
float mzPhaseShade(vec3 nViewPosM) {
    #if SUN_MOON_STYLE >= 2
        if (moonPhase < 1) return 1.0;

        #if SUN_MOON_STYLE == 2
            float moonCrescentOffset = 0.0055;
            float moonPhaseFactor1 = 2.45;
            float moonPhaseFactor2 = 750.0;
        #else
            float moonCrescentOffset = 0.0042;
            float moonPhaseFactor1 = 2.2;
            float moonPhaseFactor2 = 1000.0;
        #endif

        float moonPhaseOffset = moonPhase != 4 ? moonCrescentOffset : 0.0;
        if (moonPhase > 4) moonPhaseOffset = -moonPhaseOffset;

        float ang = fract(timeAngle - (0.25 + moonPhaseOffset));
        ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
        vec2 sunRotationData2 = vec2(cos(sunPathRotation * 0.01745329251994),
                                    -sin(sunPathRotation * 0.01745329251994));
        vec3 rawSunVec2 = (gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData2) * 2000.0, 1.0)).xyz;

        float moonPhaseVdosS = dot(nViewPosM, normalize(rawSunVec2));
        return pow2(1.0 - min1(pow(abs(moonPhaseVdosS), moonPhaseFactor2) * moonPhaseFactor1));
    #else
        return 1.0;
    #endif
}

vec3 ApplyMoonZoom(vec3 sky, vec3 nViewPos, vec3 sunVecM, vec3 upVecM, float sunVisibilityM) {
    float phase = MoonZoomPhase();
    if (phase <= 0.001 || sunVisibilityM > 0.5) return sky;

    float darkT = sin(min(phase / 0.40, 1.0) * 1.5707963);

    float blurAmount;
    if (phase < MZ_BLUR_PEAK) {
        blurAmount = sin(phase / MZ_BLUR_PEAK * 1.5707963);
    } else {
        blurAmount = 1.0 - sin((phase - MZ_BLUR_PEAK) / (1.0 - MZ_BLUR_PEAK) * 1.5707963);
    }

    float revealT = sin(clamp((phase - 0.20) / 0.80, 0.0, 1.0) * 1.5707963);

    sky *= mix(vec3(1.0), vec3(0.62, 0.72, 1.0) * MOON_ZOOM_SKY_DARKNESS, darkT);

    vec3 moonDir = -sunVecM;
    float VdotMoon = dot(nViewPos, moonDir);
    #ifdef REALISTIC_MOON_ACTIVE
        vec2 rmLocal;
        float rmTexScale, rmLow;
        vec3 rmPhaseDir, rmTint;
        RmFrame(nViewPos, moonDir, upVecM, dot(moonDir, upVecM), rmLocal, rmTexScale, rmLow, rmPhaseDir, rmTint);
        float diskR     = asin(min(rmTexScale, 1.0));
    #else
        float diskR     = radians(MOON_ZOOM_DISK_SIZE);
    #endif
    float moonCos = cos(diskR);

    float centerAng = acos(clamp(VdotMoon, -1.0, 1.0));
    float bloomOut  = diskR * MOON_ZOOM_BLOOM_SIZE;
    float bt        = clamp((centerAng - diskR) / max(bloomOut - diskR, 1e-4), 0.0, 1.0);
    float glow      = exp(-bt * bt * 3.5) * MOON_ZOOM_BLOOM * revealT;
    sky += vec3(0.68, 0.76, 0.90) * glow;

    float fd       = (phase - MZ_BLUR_PEAK) / 0.28;
    float diskFall = 1.0 - smoothstep(diskR * 0.85, diskR * 1.25, centerAng);
    float flash    = exp(-fd * fd * 3.0) * diskFall * MOON_ZOOM_FLASH;

    vec3 result = sky;

    if (VdotMoon > moonCos) {
        #ifdef REALISTIC_MOON_ACTIVE
            vec2 diskUV = rmLocal / rmTexScale * 0.5 + 0.5;
        #else
            vec3 mUp    = normalize(upVecM - moonDir * dot(upVecM, moonDir));
            vec3 mRight = cross(moonDir, mUp);
            float scale = sqrt(max(1.0 - moonCos * moonCos, 1e-5));
            vec2 diskUV = vec2(dot(nViewPos, mRight), dot(nViewPos, mUp)) / scale * 0.5 + 0.5;
        #endif

        if (!(any(lessThan(diskUV, vec2(0.0))) || any(greaterThan(diskUV, vec2(1.0))))) {
            float blurRad = blurAmount * MOON_ZOOM_FOCUS_BLUR;
            vec4 hd = texture2D(colortex10, diskUV);
            if (blurRad > 0.0005) {
                for (int i = 0; i < 8; i++) {
                    float a = float(i) * 0.7853981634;
                    vec2 dir = vec2(cos(a), sin(a));
                    hd += texture2D(colortex10, diskUV + dir * blurRad);
                    hd += texture2D(colortex10, diskUV + dir * blurRad * 0.55);
                }
                hd *= 0.058823529;
            }

            #ifdef REALISTIC_MOON_ACTIVE
                vec3 hdCol = vec3(dot(hd.rgb, vec3(0.2126, 0.7152, 0.0722))) * rmTint * mzPhaseShade(rmPhaseDir) * (MOON_ZOOM_BRIGHTNESS / 1.2);
            #else
                vec3 hdCol = hd.rgb * mzPhaseShade(nViewPos) * MOON_ZOOM_BRIGHTNESS * vec3(0.82, 0.88, 1.03);
            #endif

            float textureMix = revealT * clamp(hd.a, 0.0, 1.0);
            result = mix(sky, hdCol, textureMix);
        }
    }

    return result * (1.0 + flash);
}
#endif

#endif
#endif
