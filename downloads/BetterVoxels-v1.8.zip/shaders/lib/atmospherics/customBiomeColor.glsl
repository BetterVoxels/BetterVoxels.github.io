#if CUSTOM_BIOME_SUPPORT == 1 && BIOME_ATMOSPHERE == 1

#ifndef INCLUDE_CUSTOM_BIOME_COLOR
#define INCLUDE_CUSTOM_BIOME_COLOR

    #include "/lib/misc/bvStateImage.glsl"

    vec4 bvCustomBiomeRead() {
        return texelFetch(bv_state_sampler, BV_ST_CBIOME_OUT, 0);
    }
#endif

#if defined BV_CUSTOM_BIOME_WRITER && !defined INCLUDE_CUSTOM_BIOME_WRITER
#define INCLUDE_CUSTOM_BIOME_WRITER

    #include "/lib/misc/bvStateImage.glsl"

    const vec2 bvCbR2 = vec2(0.75487766624669276, 0.56984029099805327);

    const int bvCbSamples = 96;
    const float bvCbMinSamples = 24.0;
    const float bvCbNearLimit = 48.0;
    const float bvCbAccentDist = 0.45;
    const float bvCbFloorLo = 0.08;
    const float bvCbFloorHi = 0.22;
    const float bvCbMaxPull = 0.55;
    const float bvCbTau = 2.0;
    const float bvCbMarker = 4321.5;

    void bvCustomBiomeUpdate(sampler2D scene, sampler2D depth) {
        vec4 prevBulk = imageLoad(bvStateImg, BV_ST_CBIOME_BULK);
        vec4 prevOut = imageLoad(bvStateImg, BV_ST_CBIOME_OUT);
        bool warm = prevBulk.a == bvCbMarker;
        vec3 ref = warm ? prevBulk.rgb : vec3(0.0);

        const vec3 lumW = vec3(0.2125, 0.7154, 0.0721);
        vec3 illum = max(fogColor / max(dot(fogColor, lumW), 0.0001), vec3(0.05));

        vec2 jitter = fract(vec2(0.5) + bvCbR2 * float(frameCounter & 255));

        vec3 bulkSum = vec3(0.0);
        vec3 accentSum = vec3(0.0);
        float n = 0.0;
        float na = 0.0;

        for (int i = 0; i < bvCbSamples; i++) {
            vec2 uv = fract(jitter + bvCbR2 * float(i));

            float d = texture2D(depth, uv).r;
            if (d >= 1.0) continue;

            vec4 vp = gbufferProjectionInverse * (vec4(uv, d, 1.0) * 2.0 - 1.0);
            if (length(vp.xyz / vp.w) > bvCbNearLimit) continue;

            vec3 c = texture2D(scene, uv).rgb / illum;
            c /= max(dot(c, lumW), 0.0001);

            bulkSum += c;
            n += 1.0;

            if (warm && distance(c, ref) > bvCbAccentDist) {
                accentSum += c;
                na += 1.0;
            }
        }

        if (n < bvCbMinSamples) return;
        if (any(isnan(bulkSum)) || any(isinf(bulkSum))) return;

        vec3 bulk = bulkSum / n;
        vec3 accent = na > 0.5 ? accentSum / na : bulk;

        float pull = smoothstep(bvCbFloorLo, bvCbFloorHi, na / n) * bvCbMaxPull;
        vec3 target = mix(bulk, accent, pull);

        float rate = warm ? clamp(frameTime / bvCbTau, 0.0, 1.0) : 1.0;

        imageStore(bvStateImg, BV_ST_CBIOME_BULK,
                   vec4(mix(prevBulk.rgb, bulk, rate), bvCbMarker));
        imageStore(bvStateImg, BV_ST_CBIOME_OUT,
                   vec4(mix(prevOut.rgb, target, rate),
                        warm ? min(prevOut.a + rate, 1.0) : rate));
    }
#endif

#endif
