#ifndef INCLUDE_DISTANT_HAZE
#define INCLUDE_DISTANT_HAZE

#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/colorMultipliers.glsl"
#endif
#ifdef MOON_PHASE_INF_ATMOSPHERE
    #include "/lib/colors/moonPhaseInfluence.glsl"
#endif

vec3 FogTint(vec3 fog) {
    vec3 desat = mix(vec3(GetLuminance(fog)), fog, FOG_SATURATION);
    return desat * vec3(FOG_TINT_R, FOG_TINT_G, FOG_TINT_B);
}

#if DISTANT_HAZE > 0 && defined OVERWORLD
    #define DISTANT_HAZE_ACTIVE
    #include "/lib/atmospherics/sky.glsl"

    vec3 ApplyDistantHaze(vec3 color, float dist, float VdotS, float dither) {
        float x = max(dist - float(HAZE_START), 0.0) / max(float(HAZE_DISTANCE - HAZE_START), 64.0);
        if (x <= 0.0) return color;

        const float blue = HAZE_BLUE * 0.01;
        vec3 tau = x * (3.0 * DISTANT_HAZE * 0.01) * (1.0 + 1.5 * rainFactor)
                 * mix(vec3(0.7, 0.85, 1.0), vec3(0.3, 0.55, 1.0), blue);
        vec3 transmit = exp(-tau);

        vec3 airlight = mix(GetSkyTinted(0.0, VdotS, dither, false, false, SKY_BLUE_FOG),
                            GetSkyTinted(0.45, VdotS, dither, false, false, SKY_BLUE_FOG), blue);
        airlight = FogTint(airlight);

        airlight *= 1.0 + 0.3 * pow(max(VdotS, 0.0), 8.0) * sunVisibility2 * invRainFactor;
        #ifdef ATM_COLOR_MULTS
            airlight *= GetAtmColorMult();
        #endif
        #ifdef MOON_PHASE_INF_ATMOSPHERE
            airlight *= moonPhaseInfluence;
        #endif

        return color * transmit + airlight * (1.0 - transmit);
    }

    float GetCloudHazeFade(float dist, float rayUp) {
        float u = max(dist * rayUp, 0.0) * 0.015625;
        float pathLength = u > 0.001 ? dist * (1.0 - exp(-u)) / u : dist;
        float x = max(pathLength - float(HAZE_START), 0.0) * 0.00052083;

        const float blue = HAZE_BLUE * 0.01;
        vec3 tau = x * (0.3 * DISTANT_HAZE * 0.01) * (1.0 + 1.5 * rainFactor)
                 * mix(vec3(0.7, 0.85, 1.0), vec3(0.3, 0.55, 1.0), blue);
        return GetLuminance(exp(-tau));
    }
#endif

#endif
