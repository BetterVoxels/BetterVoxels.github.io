#ifndef INCLUDE_CAVE_FACTOR
    #define INCLUDE_CAVE_FACTOR

    float bvCaveSkyRelease(float camY) {
        float depth = clamp(1.0 - camY / oceanAltitude, 0.0, 1.0);
        float say = mix(1.0, CAVE_FOG_SKY_RELEASE * 0.01, depth);
        return clamp(1.0 - eyeBrightnessM * say, 0.0, 1.0);
    }

    float GetCaveFactor() {
        return clamp(1.0 - cameraPosition.y / oceanAltitude, 0.0, bvCaveSkyRelease(cameraPosition.y));
    }
    float GetCaveFactor(float yPos) {
        return clamp(1.0 - yPos / oceanAltitude, 0.0, bvCaveSkyRelease(cameraPosition.y));
    }
#endif
