#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/colorMultipliers.glsl"
#endif
#ifdef MOON_PHASE_INF_ATMOSPHERE
    #include "/lib/colors/moonPhaseInfluence.glsl"
#endif

#include "/lib/atmospherics/fog/distantHaze.glsl"

#ifdef BORDER_FOG_ACTIVE
    #ifdef OVERWORLD
        #include "/lib/atmospherics/sky.glsl"
    #elif defined NETHER
        #include "/lib/colors/skyColors.glsl"
    #endif

    void DoBorderFog(inout vec3 color, inout float skyFade, float lPos, float VdotU, float VdotS, float dither) {
        #if defined LOD_ACTIVE && LOD_DISABLE_BORDER_FOG == 1
            float borderDist = renderDistance * (LOD_EDGE_FOG_DISTANCE * 0.01);
            #if defined OVERWORLD && defined VL_CLOUDS_ACTIVE
                float aboveDeck = clamp((cameraPosition.y - float(cloudAlt1i)) * 0.015625, 0.0, 1.0);
                borderDist = mix(borderDist, min(borderDist, renderDistance), aboveDeck);
            #endif
        #else
            float borderDist = far;
        #endif
        #ifdef OVERWORLD
            float fog = lPos / borderDist;
            fog = pow2(pow2(fog));
            #if !defined LOD_ACTIVE || LOD_DISABLE_BORDER_FOG != 1
                fog = pow2(pow2(fog));
            #endif
            fog = 1.0 - exp(-3.0 * fog);
        #endif
        #ifdef NETHER
            float farM = min(borderDist, NETHER_VIEW_LIMIT_M);
            float fog = lPos / farM;
            fog = fog * 0.3 + 0.7 * pow(fog, 256.0 / max(farM, 256.0));
        #endif
        #ifdef END
            float fog = lPos / borderDist;
            fog = pow2(pow2(fog));
            fog = 1.0 - exp(-3.0 * fog);
        #endif

        #ifdef DREAM_TWEAKED_BORDERFOG
            fog *= fog * 0.5;
        #endif

        if (fog > 0.0) {
            fog = clamp(fog, 0.0, 1.0);

            #ifdef OVERWORLD
                #if defined LOD_ACTIVE && LOD_DISABLE_BORDER_FOG == 1

                    vec3 fogColorM = FogTint(GetSkyTinted(max(VdotU, 0.0), VdotS, dither, true, false, SKY_BLUE_FOG));
                #else
                    vec3 fogColorM = FogTint(GetSkyTinted(VdotU, VdotS, dither, true, false, SKY_BLUE_FOG));
                #endif
            #elif defined NETHER
                vec3 fogColorM = netherColor;
            #else
                vec3 fogColorM = endSkyColor;
            #endif

            #ifdef ATM_COLOR_MULTS
                fogColorM *= atmColorMult;
                #ifdef BIOME_ATMOSPHERE_ACTIVE
                    {
                        vec3 bvFogTint;
                        float bvFogMult, bvFogWeight;
                        bvBiomeAtmosphere(bvFogTint, bvFogMult, bvFogWeight);
                        fogColorM = bvBiomeTint(fogColorM, bvFogTint, bvFogWeight,
                                                BIOME_TINT_STRENGTH * 0.01);
                    }
                #endif
            #endif
            #ifdef MOON_PHASE_INF_ATMOSPHERE
                fogColorM *= moonPhaseInfluence;
            #endif

            #if defined LOD_ACTIVE && LOD_DISABLE_BORDER_FOG == 1 && defined OVERWORLD && defined VL_CLOUDS_ACTIVE
                if (aboveDeck > 0.0) {
                    vec3 voidColor = GetSky(VdotU, VdotS, dither, true, false);
                    #ifdef ATM_COLOR_MULTS
                        voidColor *= atmColorMult;
                    #endif
                    #ifdef MOON_PHASE_INF_ATMOSPHERE
                        voidColor *= moonPhaseInfluence;
                    #endif
                    fogColorM = mix(fogColorM, voidColor, aboveDeck);
                }
            #endif

            color = mix(color, fogColorM, fog);

            #ifndef GBUFFERS_WATER
                skyFade = fog;
            #else
                skyFade = fog * (1.0 - isEyeInWater);
            #endif
        }
    }
#endif

#ifdef CAVE_FOG
    #include "/lib/atmospherics/fog/caveFactor.glsl"

    void DoCaveFog(inout vec3 color, float lViewPos) {
        float fog = GetCaveFactor() * (0.9 - 0.9 * exp(- lViewPos * 0.015));

        color = mix(color, caveFogColor, fog);
    }
#endif

#ifdef ATMOSPHERIC_FOG
    #include "/lib/atmospherics/fog/atmFogAmount.glsl"

    void DoAtmosphericFog(inout vec3 color, vec3 playerPos, float lViewPos, float VdotS) {
        float fog = GetAtmosphericFogAmount(playerPos, lViewPos);

        if (fog > 0.0) {
            float altitudeFactorRaw = GetAtmFogAltitudeFactor(playerPos.y + cameraPosition.y);

            #ifdef OVERWORLD
                vec3 fogColorM = FogTint(GetAtmFogColor(altitudeFactorRaw, VdotS));
            #else
                vec3 fogColorM = endSkyColor * 1.5;
            #endif

            #ifdef ATM_COLOR_MULTS
                fogColorM *= atmColorMult;
                #ifdef BIOME_ATMOSPHERE_ACTIVE
                    {
                        vec3 bvFogTint;
                        float bvFogMult, bvFogWeight;
                        bvBiomeAtmosphere(bvFogTint, bvFogMult, bvFogWeight);
                        fogColorM = bvBiomeTint(fogColorM, bvFogTint, bvFogWeight,
                                                BIOME_TINT_STRENGTH * 0.01);
                    }
                #endif
            #endif
            #ifdef MOON_PHASE_INF_ATMOSPHERE
                fogColorM *= moonPhaseInfluence;
            #endif

            color = mix(color, fogColorM, fog);
        }
    }
#endif

#include "/lib/atmospherics/fog/waterFog.glsl"

void DoWaterFog(inout vec3 color, float lViewPos) {
    float fog = GetWaterFog(lViewPos);

    color = mix(color, waterFogColor, fog);
}

#ifndef VOXY_PATCH
void DoLavaFog(inout vec3 color, float lViewPos) {
    float fog = (lViewPos * 3.0 - gl_Fog.start) * gl_Fog.scale;

    #ifdef LESS_LAVA_FOG
        fog = sqrt(fog) * 0.4;
    #endif

    fog = 1.0 - exp(-fog);

    fog = clamp(fog, 0.0, 1.0);
    color = mix(color, fogColor * 5.0, fog);
}
#endif

void DoPowderSnowFog(inout vec3 color, float lViewPos) {
    float fog = lViewPos;

    #ifdef LESS_LAVA_FOG
        fog = sqrt(fog) * 0.4;
    #endif

    fog *= fog;
    fog = 1.0 - exp(-fog);

    fog = clamp(fog, 0.0, 1.0);
    color = mix(color, fogColor, fog);
}

void DoBlindnessFog(inout vec3 color, float lViewPos) {
    float fog = lViewPos * 0.3 * blindness;
    fog *= fog;
    fog = 1.0 - exp(-fog);

    fog = clamp(fog, 0.0, 1.0);
    color = mix(color, vec3(0.0), fog);
}

void DoDarknessFog(inout vec3 color, float lViewPos) {
    float fog = lViewPos * 0.075 * darknessFactor;
    fog *= fog;
    fog *= fog;
    color *= exp(-fog);
}

void DoFog(inout vec3 color, inout float skyFade, float lViewPos, vec3 playerPos, float VdotU, float VdotS, float dither) {
    #ifdef CAVE_FOG
        DoCaveFog(color, lViewPos);
    #endif
    float fogPath = lViewPos;
    #ifdef OVERWORLD
        if (cameraPosition.y > float(cloudAlt1i)) {
            float fogPointY = playerPos.y + cameraPosition.y;
            float fogBelow = float(cloudAlt1i) - fogPointY;
            fogPath = fogBelow <= 0.0 ? 0.0
                    : lViewPos * clamp(fogBelow / max(cameraPosition.y - fogPointY, 0.001), 0.0, 1.0);
        }
    #endif
    #ifdef ATMOSPHERIC_FOG
        DoAtmosphericFog(color, playerPos, fogPath, VdotS);
    #endif
    #ifdef DISTANT_HAZE_ACTIVE
        color = ApplyDistantHaze(color, fogPath, VdotS, dither);
    #endif
    #ifdef BORDER_FOG_ACTIVE
        DoBorderFog(color, skyFade, max(length(playerPos.xz), abs(playerPos.y)), VdotU, VdotS, dither);
    #endif

    if (isEyeInWater == 1) DoWaterFog(color, lViewPos);
    #ifndef VOXY_PATCH
    else if (isEyeInWater == 2) DoLavaFog(color, lViewPos);
    #endif
    else if (isEyeInWater == 3) DoPowderSnowFog(color, lViewPos);

    if (blindness > 0.00001) DoBlindnessFog(color, lViewPos);
    if (darknessFactor > 0.00001) DoDarknessFog(color, lViewPos);
}
