#ifndef INCLUDE_VOLUMETRIC_SEA
#define INCLUDE_VOLUMETRIC_SEA

#if defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE

#include "/lib/vx/irradianceCache.glsl"

float bvVolNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    vec2 base = i.xz + f.xz + 0.5;
    vec2 uv0 = (base + vec2(37.0, 17.0) * i.y) / 256.0;
    vec2 uv1 = (base + vec2(37.0, 17.0) * (i.y + 1.0)) / 256.0;

    return mix(texture2D(noisetex, uv0).r, texture2D(noisetex, uv1).r, f.y);
}

vec3 bvVolCoord(vec3 wp) {
    vec3 q = wp * vec3(0.022, 0.055, 0.022);
    q.x += frameTimeCounter * 0.010 * (VOL_FOG_SPEED * 0.01);
    return q;
}

float bvVolFalloff(float y) {
    return exp2(-abs(y - float(VOL_FOG_ALT)) / max(float(VOL_FOG_THICK) * 4.0, 1.0));
}

float bvVolShadow(vec3 wp) {
    #if SHADOW_QUALITY > -1
        vec4 sp = vec4(wp - cameraPosition, 1.0);
        #ifdef SMOOTH_SHADOW_ROTATION
            sp.xyz = stShadowRotation * sp.xyz;
        #endif
        sp = shadowProjection * (shadowModelView * sp);
        sp /= sp.w;

        float distb = sqrt(sp.x * sp.x + sp.y * sp.y);
        float distortFactor = 1.0 - shadowMapBias + distb * shadowMapBias;
        sp.xy *= 1.0 / distortFactor;
        sp.z *= 0.2;
        sp = sp * 0.5 + 0.5;

        if (any(greaterThan(abs(sp.xy - 0.5), vec2(0.5)))) return 1.0;
        return shadow2D(shadowtex1, sp.xyz).z;
    #else
        return 1.0;
    #endif
}

vec3 bvVolBlockLight(vec3 wp) {
    vec3 camFloor = cameraPositionInt.y == -98257195
                  ? floor(cameraPosition) : vec3(cameraPositionInt);
    return readVolumetricBlocklight(wp - camFloor);
}

float bvVolHG(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (12.566370614 * pow(max(1.0 + g2 - 2.0 * g * c, 0.0001), 1.5));
}

#ifdef VOL_FOG_ACTIVE

float bvVolDensity(vec3 wp, out float lift) {
    float falloff = bvVolFalloff(wp.y);
    lift = clamp((wp.y - float(VOL_FOG_ALT)) / max(float(VOL_FOG_THICK), 1.0) * 0.5 + 0.5,
                 0.0, 1.0);

    if (falloff < 0.02) return 0.0;

    vec3 q = bvVolCoord(wp);
    float n = bvVolNoise(q)         * 0.500
            + bvVolNoise(q *  2.1)  * 0.250
            + bvVolNoise(q *  4.3)  * 0.125
            + bvVolNoise(q *  8.7)  * 0.075
            + bvVolNoise(q * 17.1)  * 0.050;

    float macro = smoothstep(0.30, 0.72, bvVolNoise(q * 0.10) * 0.65
                                       + bvVolNoise(q * 0.30) * 0.35);

    float coverage = clamp(VOL_FOG_DENSITY * 0.01, 0.0, 1.0);

    float d = clamp(falloff * n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);
    d *= 0.12 + 1.90 * macro;

    return d * (0.006 + coverage * 0.018);
}

float bvVolDensityCheap(vec3 wp) {
    float falloff = bvVolFalloff(wp.y);
    if (falloff < 0.02) return 0.0;

    vec3 q = bvVolCoord(wp);
    float n = bvVolNoise(q) * 0.65 + bvVolNoise(q * 2.1) * 0.35;

    float coverage = clamp(VOL_FOG_DENSITY * 0.01, 0.0, 1.0);
    float d = clamp(falloff * n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);
    d *= 0.12 + 1.90 * smoothstep(0.30, 0.72, bvVolNoise(q * 0.10) * 0.65
                                            + bvVolNoise(q * 0.30) * 0.35);
    return d * (0.006 + coverage * 0.018);
}

void bvVolumetricSea(inout vec3 color, vec3 worldDir, vec3 sunDirWorld,
                     float sceneDist, float dither) {
    float range = min(sceneDist, float(VOL_FOG_DIST));
    if (range < 1.0) return;

    vec3 lit = skyColor * 0.75 + fogColor * 0.35;

    #ifdef BIOME_ATMOSPHERE_ACTIVE
        vec3 bvSeaTint;
        float bvSeaMult, bvSeaWeight;
        bvBiomeAtmosphere(bvSeaTint, bvSeaMult, bvSeaWeight);
        lit = bvBiomeTint(lit, bvSeaTint, bvSeaWeight,
                          BIOME_TINT_STRENGTH * 0.01) * bvSeaMult;
    #endif

    lit *= VOL_FOG_I * 0.01;

    float c = dot(worldDir, sunDirWorld);
    float phase = (bvVolHG(c, 0.60) + bvVolHG(c, -0.30)) * 4.0;

    float trans = 1.0;
    vec3 acc = vec3(0.0);
    float prevEdge = 0.0;

    for (int i = 0; i < VOL_FOG_STEPS; i++) {
        float f = float(i + 1) / float(VOL_FOG_STEPS);
        float edge = range * f * f;
        float dt = edge - prevEdge;
        float t = prevEdge + dt * dither;
        prevEdge = edge;

        vec3 wp = cameraPosition + worldDir * t;

        float lift;
        float d = bvVolDensity(wp, lift);
        if (d > 0.0) {
            float sunOD = 0.0;
            for (int k = 1; k <= 4; k++) {
                sunOD += bvVolDensityCheap(wp + sunDirWorld * (float(k) * 5.0));
            }
            sunOD *= 5.0;

            float beer = exp(-sunOD * 4.0);
            float powder = 1.0 - exp(-d * dt * 90.0);

            float shade = bvVolShadow(wp);

            vec3 sampleCol = lit * (beer * powder * phase * shade
                                  + 0.20 + 0.25 * lift);

            sampleCol += bvVolBlockLight(wp) * (VOL_FOG_I * 0.01) * 1.2;
            sampleCol *= 1.0 - smoothstep(range * 0.65, range, t);

            float a = 1.0 - exp(-d * dt);
            acc += sampleCol * a * trans;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    color = color * trans + acc;
}
#endif

#ifdef VOLCAVE_ACTIVE

float bvCaveDensity(vec3 wp, out float skyReach) {
    float below = float(VOLCAVE_TOP) - wp.y;
    skyReach = exp2(-max(below, 0.0) / 24.0);
    if (below <= 0.0) return 0.0;

    float depth = 1.0 - exp2(-below / 20.0);

    vec3 q = wp * vec3(0.035, 0.070, 0.035);
    q.y += frameTimeCounter * 0.004;

    float n = bvVolNoise(q) * 0.50
            + bvVolNoise(q * 2.3) * 0.30
            + bvVolNoise(q * 5.1) * 0.20;

    float coverage = clamp(VOLCAVE_DENSITY * 0.01, 0.0, 1.0);
    float d = clamp(n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);

    return d * depth * (0.002 + coverage * 0.007);
}

void bvCaveFog(inout vec3 color, vec3 worldDir, vec3 sunDirWorld,
               float sceneDist, float dither) {
    float range = min(sceneDist, float(VOLCAVE_DIST));
    if (range < 1.0) return;
    if (cameraPosition.y - 8.0 > float(VOLCAVE_TOP) && worldDir.y >= 0.0) return;

    vec3 lit = skyColor * 0.12 + fogColor * 0.45;

    #ifdef BIOME_ATMOSPHERE_ACTIVE
        vec3 bvCaveTint;
        float bvCaveMult, bvCaveWeight;
        bvBiomeAtmosphere(bvCaveTint, bvCaveMult, bvCaveWeight);
        lit = bvBiomeTint(lit, bvCaveTint, bvCaveWeight,
                          BIOME_TINT_STRENGTH * 0.01) * bvCaveMult;
    #endif

    lit *= VOLCAVE_I * 0.01;

    float c = dot(worldDir, sunDirWorld);
    float phase = (bvVolHG(c, 0.60) + bvVolHG(c, -0.30)) * 4.0;

    float trans = 1.0;
    vec3 acc = vec3(0.0);
    float prevEdge = 0.0;

    for (int i = 0; i < VOLCAVE_STEPS; i++) {
        float f = float(i + 1) / float(VOLCAVE_STEPS);
        float edge = range * f * f;
        float dt = edge - prevEdge;
        float t = prevEdge + dt * dither;
        prevEdge = edge;

        vec3 wp = cameraPosition + worldDir * t;

        float skyReach;
        float d = bvCaveDensity(wp, skyReach);
        if (d > 0.0) {
            float shade = bvVolShadow(wp);
            float powder = 1.0 - exp(-d * dt * 90.0);

            vec3 sampleCol = lit * (powder * phase * shade * 2.2
                                  + 0.05 + 0.30 * skyReach);

            sampleCol += bvVolBlockLight(wp) * (VOLCAVE_I * 0.01) * 3.0;
            sampleCol *= 1.0 - smoothstep(range * 0.7, range, t);

            float a = 1.0 - exp(-d * dt);
            acc += sampleCol * a * trans;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    color = color * trans + acc;
}
#endif

#endif

#endif
