#include "/lib/colors/skyColors.glsl"

float GetStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 GetStarCoord(vec3 viewPos, float sphereness) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * cloudSyncedTime;
    return starCoord.xz;
}

float BvStarLayer(vec2 starCoord, float scale, float seed) {
    float starFactor = 1024.0 * scale / (STAR_SIZE * 0.01);

    vec2 sc = starCoord * starFactor;
    vec2 cellId = floor(sc) / starFactor;

    float star = GetStarNoise(cellId + seed)
               * GetStarNoise(cellId + seed + 0.1)
               * GetStarNoise(cellId + seed + 0.23);

    #if NIGHT_STAR_AMOUNT == 2
        star -= 0.7;
    #else
        star -= 0.6;
        star *= 0.65;
    #endif
    star = max0(star);
    star *= star;

    if (star <= 0.0) return 0.0;

    #if STAR_ROUND == 1
        float d = length(fract(sc) - 0.5) * 2.0;
        float soft = 0.06 + STAR_SOFTNESS * 0.01 * 0.9;
        star *= 1.0 - smoothstep(1.0 - soft, 1.0, d);
    #endif

    #if STAR_TWINKLE > 0
        float phase = GetStarNoise(cellId + seed + 0.77) * 6.2831853;
        float tw = sin(frameTimeCounter * (STAR_TWINKLE_SPEED * 0.01) + phase);
        star *= 1.0 - (STAR_TWINKLE * 0.01) * 0.5 * (1.0 + tw);
    #endif

    return star;
}

#if SHOOTING_STARS == 1
float BvShootingStars(vec2 starCoord) {
    float t = frameTimeCounter / max(float(SHOOTING_STARS_RATE), 1.0);
    float total = 0.0;

    for (int i = 0; i < 2; i++) {
        float ts = t + float(i) * 0.5;
        float slot = floor(ts);
        float life = fract(ts);

        vec2 h = vec2(GetStarNoise(vec2(slot, float(i) * 17.3)),
                      GetStarNoise(vec2(slot + 3.7, float(i) * 5.1)));
        if (h.x > 0.55) continue;

        float ang = GetStarNoise(vec2(slot + 9.1, float(i) * 2.7)) * 6.2831853;
        vec2 dir = vec2(cos(ang), sin(ang));
        vec2 origin = (h - 0.5) * 6.0;

        float travel = life * (SHOOTING_STARS_SPEED * 0.01) * 2.0;
        vec2 head = origin + dir * travel;

        vec2 d = starCoord - head;
        float along = dot(d, -dir);
        float across = abs(dot(d, vec2(-dir.y, dir.x)));

        float tail = SHOOTING_STARS_LENGTH * 0.01 * 0.35;
        float body = clamp(1.0 - along / max(tail, 0.001), 0.0, 1.0) * step(0.0, along);
        float thin = 1.0 - smoothstep(0.0, 0.010, across);

        float fade = smoothstep(0.0, 0.15, life) * (1.0 - smoothstep(0.55, 1.0, life));

        total += pow2(body) * thin * fade;
    }
    return total * (SHOOTING_STARS_I * 0.01);
}
#endif

vec3 GetStars(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);

    starCoord *= 0.2;

    float star = BvStarLayer(starCoord, 1.0, 0.0);

    #if STAR_LAYER == 1
        star += BvStarLayer(starCoord, 2.7, 4.31) * 0.55;
    #endif

    star *= min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));

    float dayMask = pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);
    #if STAR_DAYLIGHT > 0
        dayMask = mix(dayMask, 1.0, STAR_DAYLIGHT * 0.01);
    #endif
    star *= invRainFactor * dayMask;

    vec3 starColor = vec3(STAR_COL_R, STAR_COL_G, STAR_COL_B) * 0.01;

    #if STAR_COLOR_VARIATION > 0
        float starFactor = 1024.0 / (STAR_SIZE * 0.01);
        vec2 cellId = floor(starCoord * starFactor) / starFactor;
        float temp = GetStarNoise(cellId + 1.61) * 2.0 - 1.0;
        starColor *= 1.0 + (STAR_COLOR_VARIATION * 0.01) * temp * vec3(0.55, 0.05, -0.45);
        starColor = max(starColor, vec3(0.0));
    #endif

    vec3 result = 40.0 * star * starColor * (STAR_BRIGHTNESS * 0.01);

    #if SHOOTING_STARS == 1
        result += BvShootingStars(starCoord)
                * min1(VdotU * 3.0) * invRainFactor * dayMask
                * starColor * 200.0;
    #endif

    return result;
}
