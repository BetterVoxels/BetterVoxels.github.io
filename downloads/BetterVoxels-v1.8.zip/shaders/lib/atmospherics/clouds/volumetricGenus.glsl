
#ifndef INCLUDE_VOLUMETRIC_GENUS
#define INCLUDE_VOLUMETRIC_GENUS

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

#define VC_H_ALT      2272
#define VC_H_THICK    511.0

#define VC_H_STEP_MUL       2.0
#define VC_H_LIGHT_SAMPLES  2

#define VC_H_SKIP_H         160.0

#define VC_H_EXT_MUL  (VC_H_EXTINCTION * 0.01)

#define VC_H_CC_EDGE   0.30
#define VC_H_CC_FADE   0.12
#define VC_H_CC_ALT    2272.0
#define VC_H_CC_THICK  85.0
#define VC_H_CC_EXT    0.10
#define VC_H_CC_COV    1.0
#define VC_H_CC_FREQ   15.0
#define VC_H_CC_SIZE   (100.0 / float(VC_CC_SIZE))

#define VC_H_CI_ALT    2556.0
#define VC_H_CI_THICK  227.0
#define VC_H_CI_EXT    1.00
#define VC_H_CI_COV    0.45
#define VC_H_CI_ERODE  1.0

#define VC_H_CS_ALT    2272.0
#define VC_H_CS_THICK  355.0
#define VC_H_CS_EXT    0.38
#define VC_H_CS_COV    1.0
#define VC_H_CS_ERODE  0.0

#define VC_H_CI_FREQ   3.0
#define VC_H_CI_SIZE   (100.0 / float(VC_CI_SIZE))

#if VC_GENUS == 8
    #define VC_G_ALL 1
#else
    #define VC_G_ALL 0
#endif

#if VC_GENUS == 8

    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CC       0
    #define VC_G_AC       0
    #define VC_G_ALT      cloudAlt1i
    #define VC_G_ALT_FIXED 0
    #define VC_G_THICK    float(VC_THICKNESS)
    #define VC_G_DETAIL_S 1.0
    #define VC_G_SIZE     1.0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_CC_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_STRATUS  1

    #define VC_G_BLEND    vcG3(0.0,                        0.5,           1.0)
    #define VC_G_DETAIL_0 vcG3(VC_PH_DETAIL_1 * 0.01,      0.265,         0.07)
    #define VC_G_DETAIL_1 vcG3(VC_PH_DETAIL_2 * 0.01,      0.250,         0.10)
    #define VC_G_SHARP_0  vcG3(VC_PH_SHARP_LOW * 0.1,      2.75,          2.0)
    #define VC_G_SHARP_1  vcG3(VC_PH_SHARP_HIGH * 0.1,     10.75,         7.0)
    #define VC_G_EGG      vcG3(VC_PH_EGG * 0.01,           0.45,          0.30)
    #define VC_G_COV_ADD  vcG3(0.0,                        0.075,         0.30)
    #define VC_G_COV_MUL  vcG3(1.0,                        75.0 / 90.0,   50.0 / 90.0)
    #define VC_G_TORN     vcG3(VC_PH_TORN * 0.01, VC_PH_TORN * 0.01 * 0.5, 0.0)
    #define VC_G_EXT_S    vcG3(1.0,                        0.75,          0.5)
    #define VC_G_EXT_MUL  1.0
#elif VC_GENUS == 7

    #define VC_G_CB       1
    #define VC_G_CI       0
    #define VC_G_CC       0
    #define VC_G_AC       0
    #define VC_G_ALT      256
    #define VC_G_ALT_FIXED 1

    #define VC_G_THICK    2272.0

    #define VC_G_EXT_MUL  0.89

    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0
    #define VC_G_DETAIL_0 (VC_PH_DETAIL_1 * 0.01)
    #define VC_G_DETAIL_1 (VC_PH_DETAIL_2 * 0.01)
    #define VC_G_SHARP_0  (VC_PH_SHARP_LOW * 0.1)
    #define VC_G_SHARP_1  (VC_PH_SHARP_HIGH * 0.1)
    #define VC_G_EGG      0.0
    #define VC_G_TORN     (VC_PH_TORN * 0.01)
    #define VC_G_COV_ADD  0.0
    #define VC_G_COV_MUL  1.0

    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_CC_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_SIZE     1.0
#elif VC_GENUS == 6

    #define VC_G_CB       0
    #define VC_G_CI       1
    #define VC_G_CC       0
    #define VC_G_AC       0
    #define VC_G_ALT      2272
    #define VC_G_ALT_FIXED 1
    #define VC_G_THICK    355.0
    #define VC_G_CI_FREQ  3.0
    #define VC_G_SIZE     (100.0 / float(VC_CI_SIZE))

    #define VC_G_COV_MUL  1.0

    #define VC_G_CI_ERODE 0.0

    #define VC_G_EXT_MUL  0.38

    #define VC_G_CC_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0
    #define VC_G_DETAIL_0 0.0
    #define VC_G_DETAIL_1 0.0
    #define VC_G_SHARP_0  1.0
    #define VC_G_SHARP_1  1.0
    #define VC_G_EGG      0.0
    #define VC_G_COV_ADD  0.0
    #define VC_G_TORN     0.0
#elif VC_GENUS == 5

    #define VC_G_CB       0
    #define VC_G_CI       1
    #define VC_G_CC       0
    #define VC_G_AC       0
    #define VC_G_ALT      2556
    #define VC_G_ALT_FIXED 1
    #define VC_G_THICK    227.0

    #define VC_G_CI_ERODE 1.0
    #define VC_G_CI_FREQ  3.0
    #define VC_G_SIZE     (100.0 / float(VC_CI_SIZE))

    #define VC_G_EXT_MUL  1.0

    #define VC_G_CC_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0
    #define VC_G_DETAIL_0 0.0
    #define VC_G_DETAIL_1 0.0
    #define VC_G_SHARP_0  1.0
    #define VC_G_SHARP_1  1.0
    #define VC_G_EGG      0.0
    #define VC_G_COV_ADD  0.0

    #define VC_G_COV_MUL  0.45
    #define VC_G_TORN     0.0
#elif VC_GENUS == 4

    #define VC_G_CC       1
    #define VC_G_AC       0
    #define VC_G_ALT      2272
    #define VC_G_ALT_FIXED 1
    #define VC_G_THICK    85.0

    #define VC_G_CC_FREQ  15.0
    #define VC_G_SIZE     (100.0 / float(VC_CC_SIZE))

    #define VC_G_EXT_MUL  0.10

    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0
    #define VC_G_DETAIL_0 0.0
    #define VC_G_DETAIL_1 0.0
    #define VC_G_SHARP_0  1.0
    #define VC_G_SHARP_1  1.0
    #define VC_G_EGG      0.0
    #define VC_G_COV_ADD  0.0
    #define VC_G_COV_MUL  1.0
    #define VC_G_TORN     0.0
#elif VC_GENUS == 3

    #define VC_G_AC       1
    #define VC_G_ALT      994
    #define VC_G_ALT_FIXED 1
    #define VC_G_THICK    128.0
    #define VC_G_DETAIL_S 1.50

    #define VC_G_EXT_MUL  0.36

    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0

    #define VC_G_DETAIL_0 0.30
    #define VC_G_DETAIL_1 0.0
    #define VC_G_SHARP_0  3.0
    #define VC_G_SHARP_1  14.0
    #define VC_G_EGG      0.60
    #define VC_G_COV_ADD  0.0
    #define VC_G_TORN     0.0

    #define VC_G_COV_MUL  1.0

    #define VC_G_SIZE     (100.0 / float(VC_AC_SIZE))
    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_AC_DET   2.128
    #define VC_G_CC       0
    #define VC_G_CC_FREQ  0.0
#elif VC_GENUS == 2

    #define VC_G_AC       0
    #define VC_G_ALT      cloudAlt1i
    #define VC_G_ALT_FIXED 0
    #define VC_G_THICK    float(VC_THICKNESS)
    #define VC_G_DETAIL_S 1.0
    #define VC_G_SIZE     1.0
    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_CC       0
    #define VC_G_CC_FREQ  0.0
    #define VC_G_STRATUS  1
    #define VC_G_BLEND    0.5
    #define VC_G_DETAIL_0 0.265
    #define VC_G_DETAIL_1 0.250
    #define VC_G_SHARP_0  2.75
    #define VC_G_SHARP_1  10.75
    #define VC_G_EGG      0.45
    #define VC_G_COV_ADD  0.075
    #define VC_G_EXT_MUL  0.75
    #define VC_G_COV_MUL  (75.0 / 90.0)
    #define VC_G_TORN     (VC_PH_TORN * 0.01 * 0.5)
#elif VC_GENUS == 1

    #define VC_G_AC       0
    #define VC_G_ALT      cloudAlt1i
    #define VC_G_ALT_FIXED 0
    #define VC_G_THICK    float(VC_THICKNESS)
    #define VC_G_DETAIL_S 1.0
    #define VC_G_SIZE     1.0
    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_CC       0
    #define VC_G_CC_FREQ  0.0
    #define VC_G_STRATUS  1
    #define VC_G_BLEND    1.0
    #define VC_G_DETAIL_0 0.07
    #define VC_G_DETAIL_1 0.10
    #define VC_G_SHARP_0  2.0
    #define VC_G_SHARP_1  7.0
    #define VC_G_EGG      0.30
    #define VC_G_COV_ADD  0.30
    #define VC_G_EXT_MUL  0.5
    #define VC_G_COV_MUL  (50.0 / 90.0)

    #define VC_G_TORN     0.0
#else

    #define VC_G_AC       0
    #define VC_G_ALT      cloudAlt1i
    #define VC_G_ALT_FIXED 0
    #define VC_G_THICK    float(VC_THICKNESS)
    #define VC_G_DETAIL_S 1.0
    #define VC_G_SIZE     1.0
    #define VC_G_CB       0
    #define VC_G_CI       0
    #define VC_G_CI_ERODE 0.0
    #define VC_G_CI_FREQ  0.0
    #define VC_G_AC_DET   0.0
    #define VC_G_CC       0
    #define VC_G_CC_FREQ  0.0
    #define VC_G_STRATUS  0
    #define VC_G_BLEND    0.0
    #define VC_G_DETAIL_0 (VC_PH_DETAIL_1 * 0.01)
    #define VC_G_DETAIL_1 (VC_PH_DETAIL_2 * 0.01)
    #define VC_G_SHARP_0  (VC_PH_SHARP_LOW * 0.1)
    #define VC_G_SHARP_1  (VC_PH_SHARP_HIGH * 0.1)
    #define VC_G_EGG      (VC_PH_EGG * 0.01)
    #define VC_G_COV_ADD  0.0
    #define VC_G_EXT_MUL  1.0
    #define VC_G_COV_MUL  1.0
    #define VC_G_TORN     (VC_PH_TORN * 0.01)
#endif

#endif
