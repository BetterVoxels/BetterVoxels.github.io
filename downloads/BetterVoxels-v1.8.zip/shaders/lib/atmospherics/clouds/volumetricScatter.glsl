
#ifndef INCLUDE_VOLUMETRIC_SCATTER
#define INCLUDE_VOLUMETRIC_SCATTER

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricDensity.glsl"

const vec3 vcConeKernel[6] = vec3[6](
    vec3( 0.38051305,  0.92453449, -0.02111345),
    vec3(-0.50625799, -0.03590792, -0.86163418),
    vec3(-0.32509218, -0.94557439,  0.01428793),
    vec3( 0.09026238, -0.27376545,  0.95755165),
    vec3( 0.28128598,  0.42443639, -0.86065785),
    vec3(-0.16852403,  0.14748697,  0.97460106)
);

float vcHG(float c, float g) {
    float g2 = g * g;
    float d = 1.0 + g2 - 2.0 * g * c;
    return (1.0 - g2) / max(d * sqrt(d), 0.00001);
}

float vcPhase(float c) {
    float w = VC_PHASE_MIX * 0.01;
    float p = w * vcHG(c, VC_PHASE_G * 0.01)
            + (1.0 - w) * vcHG(c, VC_PHASE_BACK * -0.01);
    return mix(1.0, p, VC_PHASE_STRENGTH * 0.01);
}

#if VC_MS_MODE == 2
    #define VC_MS_COUNT (VC_MS_OCTAVES - 1)
#elif VC_MS_MODE == 1
    #define VC_MS_COUNT VC_MS_OCTAVES
#else
    #define VC_MS_COUNT 1
#endif

float vcMsWp[5];
float vcMsAt[5];
float vcMsNorm;

float vcPhaseE(float c, float e) {
    float w = VC_PHASE_MIX * 0.01;
    float p = w * vcHG(c, (VC_PHASE_G * 0.01) * e)
            + (1.0 - w) * vcHG(c, (VC_PHASE_BACK * -0.01) * e);
    return mix(1.0, p, VC_PHASE_STRENGTH * 0.01);
}

void vcMakeScatter(float cosT, float ext) {
    float a = 1.0;
    float b = 1.0;
    float e = 1.0;
    vcMsNorm = 0.0;

    for (int n = 0; n < 5; n++) {
        vcMsWp[n] = n < VC_MS_COUNT ? b * vcPhaseE(cosT, e) : 0.0;
        vcMsAt[n] = ext * a;
        if (n < VC_MS_COUNT) vcMsNorm += b;
        a *= VC_MS_ATTEN * 0.01;
        b *= VC_MS_CONTRIB * 0.01;
        e *= VC_MS_ECCENT * 0.01;
    }
}

float vcScatterEnergy(float tau) {
#if VC_MS_ATTEN == 50

    float e = exp(-tau * vcMsAt[0]);
    float sum = vcMsWp[0] * e;

    for (int n = 1; n < VC_MS_COUNT; n++) {
        e = sqrt(e);
        sum += vcMsWp[n] * e;
    }
#else
    float sum = 0.0;

    for (int n = 0; n < VC_MS_COUNT; n++) {
        sum += vcMsWp[n] * exp(-tau * vcMsAt[n]);
    }
#endif

    return sum / vcMsNorm;
}

#if VC_MS_MODE == 2
    float vcInnerGlow(float cosT, float tau, float ext, float dist) {
        float far = mix(0.25, 0.05, clamp01(dist / float(VC_GLOW_DISTANCE)));
        float rate = mix(0.25, far, clamp01(cosT * 1.111111));
        return exp(-tau * ext * rate);
    }
#endif

float vcConeLength(float sunUp, float thickness) {
    float s = min(abs(sunUp), 1.0);
    float slant = 0.55 + 2.286 * max(0.0, 0.35 - s);
    return thickness * slant * (VC_CONE_LENGTH * 0.01);
}

float vcLightDepth(vec3 p, vec3 cameraPos, vec3 lightDir, float baseAlt,
                   float thickness, float coneLen, float t,
                   float covMul, float denMul, bool high) {
    int nS = VC_LIGHT_N;
    #if VC_GENUS_HIGH > 0
        if (high) nS = min(VC_H_LIGHT_SAMPLES, VC_LIGHT_N);
    #endif
    if (vcReflG) nS = min(nS, VC_REFL_LIGHT);
    float seg = coneLen / float(nS);
    float tau = 0.0;

    vcConeG = true;

    for (int i = 0; i < VC_LIGHT_N; i++) {
        if (i >= nS) break;
        float d = seg * (float(i) + 0.5);
        vec3 sp = p + lightDir * d + vcConeKernel[i % 6] * ((VC_CONE_SPREAD * 0.01) * d);

        float hs = (vcShellAltitude(sp, cameraPos) - baseAlt) / thickness;
        if (hs < 0.0 || hs > 1.0) continue;

        #if VC_GENUS_HIGH > 0
            if (high) {
                tau += vcHighDensity(sp, hs, covMul, denMul) * seg;
                continue;
            }
        #endif
        tau += vcCloudDensity(sp, hs, t, covMul, denMul,
                              i >= VC_LIGHT_DETAIL_N) * seg;
    }

    vcConeG = false;
    return tau;
}

#endif
