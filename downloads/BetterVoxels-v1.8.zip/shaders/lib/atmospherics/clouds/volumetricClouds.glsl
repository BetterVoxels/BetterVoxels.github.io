#ifndef INCLUDE_VOLUMETRIC_CLOUDS
#define INCLUDE_VOLUMETRIC_CLOUDS

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricGenus.glsl"
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricWeather.glsl"
#include "/lib/atmospherics/clouds/volumetricDensity.glsl"
#include "/lib/atmospherics/clouds/volumetricScatter.glsl"
#include "/lib/atmospherics/atmosphereLut.glsl"
#include "/lib/atmospherics/clouds/cloudLightSources.glsl"
#include "/lib/atmospherics/clouds/cloudObjectShadow.glsl"

bool vcHighBandG = false;

#if VC_DEBUG == 3
    vec4 vcWeatherView() {
        vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);

        vec4 w = textureLod(vc_weather_sampler, uv, 0.0);

        #if VC_DEBUG_CHANNEL == 0
            return vec4(vec3(w.r), 1.0);
        #elif VC_DEBUG_CHANNEL == 1
            return vec4(vec3(w.g), 1.0);
        #elif VC_DEBUG_CHANNEL == 2
            return vec4(vec3(w.b), 1.0);
        #elif VC_DEBUG_CHANNEL == 3
            return vec4(vec3(w.a), 1.0);
        #elif VC_DEBUG_CHANNEL == 5
            vec3 pr = vcPressure(uv * float(VC_DEBUG_TILES), cloudSyncedTime);
            return vec4(vec3(pr.x * 0.5 + 0.5), 1.0);
        #elif VC_DEBUG_CHANNEL == 6
            vec3 pf = vcPressure(uv * float(VC_DEBUG_TILES), cloudSyncedTime);
            return vec4(pf.yz * 2.0 + 0.5, 0.5, 1.0);
        #else
            return vec4(w.rgb, 1.0);
        #endif
    }
#endif

#if VC_DEBUG == 1
    vec4 vcNoiseSlice() {
        vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        vec2 tuv = uv * float(VC_DEBUG_TILES);
        float z = fract(frameTimeCounter * (VC_DEBUG_SLICE_SPEED * 0.01));

        vec4 shape = vcShape(vec3(tuv, z));
        vec4 detail = vcDetail(vec3(tuv, z));
        vec2 curl = vcCurlRead(tuv) * 0.5 + 0.5;

        #if VC_DEBUG_CHANNEL == 0
            return vec4(vec3(shape.r), 1.0);
        #elif VC_DEBUG_CHANNEL == 1
            return vec4(vec3(shape.g), 1.0);
        #elif VC_DEBUG_CHANNEL == 2
            return vec4(vec3(shape.b), 1.0);
        #elif VC_DEBUG_CHANNEL == 3
            return vec4(vec3(shape.a), 1.0);
        #elif VC_DEBUG_CHANNEL == 4
            return vec4(vec3(detail.r), 1.0);
        #elif VC_DEBUG_CHANNEL == 5
            return vec4(vec3(detail.g), 1.0);
        #elif VC_DEBUG_CHANNEL == 6
            return vec4(vec3(detail.b), 1.0);
        #else
            return vec4(curl, 0.5, 1.0);
        #endif
    }
#endif

struct VcLook {
    float thickness;
    float coverage;
    float density;
    float stepSize;
    float extinction;
};

VcLook VcGetLook() {
    VcLook look;
    look.thickness  = VC_G_THICK;
    look.coverage   = VC_COVERAGE * 0.01;
    #if VC_PHYSICS == 1

        look.coverage = vcPhysCoverage();
    #endif
    look.density    = VC_DENSITY * 0.01;
    look.stepSize   = float(VC_STEP_N);

    look.extinction = VC_EXTINCTION * 0.001 * VC_G_EXT_MUL;

    #if VC_GENUS_HIGH > 0
        if (vcHighBandG) {
            look.thickness  = VC_H_THICK;
            look.extinction = VC_EXTINCTION * 0.001 * VC_H_EXT_MUL;
            look.stepSize   = float(VC_STEP_N) * VC_H_STEP_MUL;
        }
    #endif

    if (vcReflG) look.stepSize *= VC_REFL_STEP;

    #if VC_LOOK == 1
        look.coverage *= 1.30;
        look.density *= 1.15;
    #elif VC_LOOK == 2
        look.coverage *= 0.70;
        look.density *= 0.80;
    #endif

    return look;
}

bool vcShellRange(float camAlt, vec3 rd, float baseAlt, float topAlt,
                  out float tNear, out float tFar,
                  out float tSkipA, out float tSkipB) {
    float R = VC_RADIUS;
    float camR = R + camAlt;
    float rIn = R + baseAlt;
    float rOut = R + topAlt;

    float b = camR * rd.y;
    float camR2 = camR * camR;

    tNear = 0.0;
    tFar = 0.0;
    tSkipA = 0.0;
    tSkipB = 0.0;

    float dOut = b * b - (camR2 - rOut * rOut);
    if (dOut <= 0.0) return false;
    float sOut = sqrt(dOut);
    tNear = max(-b - sOut, 0.0);
    tFar = -b + sOut;
    if (tFar <= tNear) return false;

    float dIn = b * b - (camR2 - rIn * rIn);
    if (dIn > 0.0) {
        float sIn = sqrt(dIn);
        float i0 = -b - sIn;
        float i1 = -b + sIn;

        if (i1 > tNear && i0 < tFar) {
            if (i0 <= tNear) {
                tNear = i1;
            } else if (i1 >= tFar) {
                tFar = i0;
            } else {
                tSkipA = i0;
                tSkipB = i1;
            }
        }
        if (tFar <= tNear) return false;
    }

    return true;
}

vec3 vcSkyChroma(vec3 c) {
    float l = dot(c, vec3(0.2125, 0.7154, 0.0721));
    if (l < 0.0001) return vec3(1.0);
    return clamp(c / l, vec3(0.0), vec3(3.0));
}

vec3 vcAmbTop = vec3(0.0);
vec3 vcAmbBot = vec3(0.0);
bool vcAmbReady = false;

void vcPrepAmbient(vec3 lightDir, float dither) {
    if (vcAmbReady) return;
    vcAmbReady = true;

    vcAmbTop = cloudAmbientColor;
    vcAmbBot = cloudAmbientColor;
    #if VC_AMBIENT_TINT > 0
    {
        vec3 sunDirW = lightDir * (sunVisibility > 0.5 ? 1.0 : -1.0);

        float sunHoriz = sqrt(max(1.0 - sunDirW.y * sunDirW.y, 0.0));
        vec3 skyZenith   = GetSky( 1.0, sunDirW.y, dither, false, false);
        vec3 skySunSide  = GetSky(0.08,  sunHoriz, dither, false, false);
        vec3 skyOpposite = GetSky(0.08, -sunHoriz, dither, false, false);

        vec3 upper = skyZenith * 0.6 + (skySunSide + skyOpposite) * 0.2;
        vec3 lower = skySunSide * 0.6 + skyOpposite * 0.4;

        float ambTintAmount = VC_AMBIENT_TINT * 0.01;
        vcAmbTop *= mix(vec3(1.0), vcSkyChroma(upper), ambTintAmount);
        vcAmbBot *= mix(vec3(1.0), vcSkyChroma(lower), ambTintAmount);
    }
    #endif
}

vec4 vcReprojG = vec4(0.0);

vec4 GetVolumetricClouds(int cloudAltitude, float distanceThreshold, inout float cloudLinearDepth,
                         float skyFade, float skyMult0, vec3 cameraPos, vec3 nPlayerPos,
                         float lViewPosM, float VdotS, float VdotU, float dither) {
    vec4 result = vec4(0.0);

    #if VC_DEBUG == 1
        return vcNoiseSlice();
    #elif VC_DEBUG == 3
        return vcWeatherView();
    #endif

    VcLook look = VcGetLook();

    #if VC_G_ALT_FIXED == 1
        float baseAlt = float(VC_G_ALT);
    #else
        float baseAlt = float(cloudAltitude);
    #endif
    #if VC_GENUS_HIGH > 0
        if (vcHighBandG) baseAlt = float(VC_H_ALT);
    #endif
    float topAlt  = baseAlt + look.thickness;

    float tNear, tFar, tSkipA, tSkipB;
    if (!vcShellRange(cameraPos.y, nPlayerPos, baseAlt, topAlt,
                      tNear, tFar, tSkipA, tSkipB))
        return result;

    #if VC_G_CB == 1

        bool cbBound = true;
        #if VC_GENUS_HIGH > 0
            cbBound = !vcHighBandG;
        #endif
        if (cbBound) {
            vcCbPrep(cameraPos, cloudSyncedTime);
            if (!vcCbCylinder(cameraPos, nPlayerPos, tNear, tFar)) return result;

            tSkipA = 0.0;
            tSkipB = 0.0;
        }
    #endif

    float reach = float(VC_REACH_N);
    #ifdef LOD_ACTIVE
        reach = max(reach, renderDistance);
    #endif
    #if VC_GENUS_HIGH > 0

        if (vcHighBandG) {
            float rMap = float(VC_MAP_SPAN) * 0.5;
            float dyTop = max(topAlt - cameraPos.y, 0.0);
            reach = max(reach, sqrt(rMap * rMap + dyTop * dyTop));
        }
    #endif
    tFar = min(tFar, reach);

    if (tSkipB > tFar) tFar = min(tFar, tSkipA);
    if (tFar <= tNear) return result;

    if (skyFade < 0.7 && lViewPosM < tNear) return result;

    float grow = VC_STEP_GROW * 0.00001;
    float cheapMult = VC_CHEAP_MULT * 0.01;

    vec3 lightDir = normalize(mat3(gbufferModelViewInverse) * lightVec);
    float cosT = dot(nPlayerPos, lightDir);
    float phase = vcPhase(cosT);
    vcMakeScatter(cosT, VC_EXTINCTION * 0.001);
    float coneLen = vcConeLength(lightDir.y, look.thickness);
    float shadowMult = VC_SHADOW_STRENGTH * 0.01;
    float ambientTop = VC_AMBIENT_STRENGTH * 0.01;
    float ambientBottom = ambientTop * (VC_AMBIENT_BOTTOM * 0.01);
    vec3 sunColor = cloudLightColor * (VC_SUN_STRENGTH * 0.01);

    sunColor *= smoothstep(0.0, 0.007, min(abs(timeAngle - 0.5325), abs(timeAngle - 0.9675)));
    float sunTintAmount = VC_SUN_TINT * 0.01;
    vec3 sunTintRef = vec3(1.0);
    {
        float rRef;
        vec3 upRef;
        atmSamplePoint(vec3(0.0, baseAlt - cameraPos.y, 0.0), cameraPos.y,
                       rRef, upRef);
        sunTintRef = max(atmTransmittance(rRef, dot(upRef, lightDir)), vec3(0.0001));
    }

    vcPrepAmbient(lightDir, dither);
    vec3 ambTopColor = vcAmbTop;
    vec3 ambBotColor = vcAmbBot;

    bool aerialRising = true;
    vec3 aerialCamEnd = vec3(1.0);
    #if VC_AERIAL > 0
        aerialCamEnd = atmSegmentCamEnd(cameraPos.y, nPlayerPos, aerialRising);
    #endif

    int beamN = 0;
    vec2 beamXZ[BV_BEAM_SLOTS];
    vec3 beamCol[BV_BEAM_SLOTS];

    vec3 beamPrev[BV_BEAM_SLOTS];
    vec2 beamFront[BV_BEAM_SLOTS];
    #if VC_BEAM_LIGHT == 1
    if (texelFetch(bv_state_sampler, BV_BEAM_FLAG, 0).r > 0.5) {
        for (int i = 0; i < BV_BEAM_SLOTS; i++) {
            vec4 bp = texelFetch(bv_state_sampler, ivec2(BV_BEAM_REP_X + 2 * i, 0), 0);
            if (bp.b < 0.5) continue;
            beamXZ[beamN] = bp.rg;
            vec3 bc = texelFetch(bv_state_sampler, ivec2(BV_BEAM_REP_X + 2 * i + 1, 0), 0).rgb;
            float bMul = VC_BEAM_BRIGHTNESS * 0.01;
            beamCol[beamN] = bvBeamGlowColor(bc) * bMul;
            beamPrev[beamN] = beamCol[beamN];
            beamFront[beamN] = vec2(1.0e6);
            #if SMOOTH_BEACON_RAY == 1
                vec4 s0 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * i, 0), 0);
                if (abs(s0.x - bp.a) < 0.5 && s0.z <= 1.0) {
                    vec4 s1 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * i + 1, 0), 0);
                    vec4 s2 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * i + 2, 0), 0);
                    beamFront[beamN] = vec2(bvBeamFront(s0.y, s2.a), bvBeamFront(s1.a, s0.w + 1.0));
                    beamPrev[beamN] = bvBeamGlowColor(s2.rgb) * bMul;

                    if (beamFront[beamN].y > 1.0e5 && distance(bc, s1.rgb) > 0.02)
                        beamCol[beamN] = bvBeamGlowColor(s1.rgb) * bMul;
                } else {
                    beamFront[beamN].x = -1.0e6;
                }
            #endif
            beamN++;
        }
    }
    #endif

    const float beamInvCore2 = 1.0 / (VC_BEAM_RADIUS * 0.2 * VC_BEAM_RADIUS * 0.2);
    const float beamInvHalo = 1.0 / float(VC_BEAM_RADIUS);

    vec4 flashA = vec4(0.0);
    vec4 flashB = vec4(0.0);
    vec4 strike = vec4(0.0);
    #if BETTER_THUNDER == 1
        bool lowBand = true;
        #if VC_GENUS_HIGH > 0
            lowBand = !vcHighBandG;
        #endif
        if (lowBand && thunderStrength > 0.001) {
            float flashAlt = baseAlt + 0.4 * look.thickness;

            #if BT_SHEET_DAY == 1
                float night = 1.0;
            #else
                float night = smoothstep(0.0, 0.25, nightFactor);
            #endif
            #if BT_SHEET == 0
                night = 0.0;
            #endif
            if (night > 0.001) {
                for (int k = 0; k < 2; k++) {
                    float period = 0.9 + 0.45 * float(k);
                    float tt = frameTimeCounter / period + float(k) * 0.37;
                    float slot = floor(tt);
                    float f = tt - slot;
                    vec3 fh = vcHash33(vec3(slot, 17.0 * float(k) + 3.1, 5.7));
                    if (fh.x > min(0.45 * thunderStrength * (BT_SHEET_FREQ * 0.01), 0.95)) continue;
                    if (f > 0.45) continue;
                    float pulse = 0.5 + 0.5 * sin(f * 55.0 + fh.y * 20.0);
                    float amp = (1.0 - f / 0.45) * pulse * pulse * pulse
                              * (0.6 + 0.8 * fh.z) * 4.0 * (BT_SHEET_STRENGTH * 0.01) * night;
                    float ang = fh.y * 6.2831853;
                    float rad = 250.0 + (float(BT_SHEET_RANGE) - 250.0) * fract(fh.z * 7.13);
                    vec4 fl = vec4(cameraPosition.x + cos(ang) * rad, flashAlt,
                                   cameraPosition.z + sin(ang) * rad, amp);
                    if (k == 0) flashA = fl; else flashB = fl;
                }
            }

            if (btFlash > 0.01) {
                float flick = 0.6 + 0.4 * vcHash33(vec3(floor(frameTimeCounter * 15.0), 2.3, 9.1)).x;
                strike = vec4(btBoltX / btFlash + cameraPosition.x,
                              baseAlt + 0.3 * look.thickness,
                              btBoltZ / btFlash + cameraPosition.z,
                              btFlash * flick * 9.0 * (BT_STRIKE_STRENGTH * 0.01));
            }
        }
    #endif

    #if BETTER_THUNDER == 1
        const vec3 flashColor = btFlashTint * 0.43;
    #endif

    float firstLightT = 1.0;

    float firstHighT = 1.0;
    float firstScatter = 0.0;
    float firstEnergy = 0.0;

    float transmittance = 1.0;
    vec3 scattered = vec3(0.0);
    float distSum = 0.0;
    vec3 aerialSum = vec3(0.0);
    float edgeSum = 0.0;
    float firstHit = 0.0;
    float sumDensity = 0.0;
    float cloudTop = 0.0;
    int taken = 0;

    #if VC_Q_FIXED_STEPS > 0
        bool cheap = false;
        float fixedSkip = tSkipB > tSkipA && tSkipB <= tFar ? max(min(tSkipB, tFar) - max(tSkipA, tNear), 0.0) : 0.0;
        float fixedStep = max(tFar - tNear - fixedSkip, 0.01) / float(VC_Q_FIXED_STEPS);
        vcErodeLodG = smoothstep(0.5 * float(VC_DETAIL_SCALE), 2.0 * float(VC_DETAIL_SCALE), fixedStep);
    #else
        bool cheap = true;
    #endif
    int emptyRun = 0;
    float viewOpacity = VC_VIEW_OPACITY * 0.01;
    #if VC_GENUS_HIGH > 0
        if (vcHighBandG) viewOpacity = 1.0;
    #endif
    float tDone = tNear;

    float t = tNear;

    for (int i = 0; i < VC_LOOP_N; i++) {
        if (t >= tSkipA && t < tSkipB) {
            t = tSkipB;
            tDone = max(tDone, tSkipB);
        }
        if (t >= tFar) break;
        taken++;

        #if VC_Q_FIXED_STEPS > 0
            float stepLen = fixedStep;
        #else
            float stepLen = look.stepSize * (1.0 + t * grow);
            if (cheap) stepLen *= cheapMult;
            #if VC_NEAR_REFINE == 1

                else stepLen *= mix(0.25, 1.0, clamp(t / 48.0, 0.0, 1.0));
            #endif
        #endif

        float jitter = fract(dither + float(i) * 0.6180339887);
        vec3 tracePos = cameraPos + nPlayerPos * (t + stepLen * jitter);

        float rangeMult = 1.0;
        if (t > lViewPosM) {
            if (skyFade < 0.7) {
                t += stepLen;
                continue;
            }
            rangeMult = skyMult0;
        }

        float h = (vcShellAltitude(tracePos, cameraPos) - baseAlt) / look.thickness;

        float density = 0.0;
        if (h >= 0.0 && h <= 1.0) {
            #if VC_GENUS_HIGH > 0
                if (vcHighBandG) {
                    density = vcHighDensity(tracePos, h, look.coverage,
                                            look.density);
                } else
            #endif

            density = vcCloudDensity(tracePos, h, cloudSyncedTime,
                                     look.coverage, look.density,
                                     cheap || VC_Q_ERODE == 0);
        }

        if (cheap) {
            if (density > 0.0) {
                t = max(t - stepLen, tDone);
                cheap = false;
                emptyRun = 0;
            } else {
                float adv = stepLen;
                #if VC_GENUS_HIGH > 0

                    if (vcHighBandG && vcHighSkipG != 0.0) {
                        float cap = VC_H_SKIP_H / max(length(nPlayerPos.xz), 0.001);
                        float jump = cap;

                        if (vcHighSkipG * nPlayerPos.y > 0.0)
                            jump = min(0.9 * vcHighSkipG / nPlayerPos.y, cap);
                        adv = max(adv, jump);
                    }
                #endif
                t += adv;
            }
            continue;
        }

        if (density > 0.0) {
            emptyRun = 0;
            if (density > 0.01) cloudTop = max(cloudTop, h);
            sumDensity += density * stepLen;
            tDone = t + stepLen;

            float lightTau = vcLightDepth(tracePos, cameraPos, lightDir,
                                          baseAlt, look.thickness,
                                          coneLen, cloudSyncedTime,
                                          look.coverage, look.density,
                                          vcHighBandG);
            #if VC_GENUS_HIGH > 0 && VC_H_SHADOW_N == 1

                float highT = 1.0;
                if (!vcHighBandG) {
                    float hTau = vcHighShadowTau(tracePos, baseAlt + h * look.thickness,
                                                 lightDir, look.coverage, look.density)
                               * (VC_EXTINCTION * 0.001 * VC_H_EXT_MUL)
                               * (VC_H_SHADOW_STRENGTH * 0.01);
                    lightTau += hTau / look.extinction;
                    highT = exp(-hTau * shadowMult);
                }
            #endif
            float tauM = lightTau * shadowMult;
            float lightT = exp(-tauM * look.extinction);

            float tauE = tauM;
            #if VC_GENUS_HIGH > 0
                if (vcHighBandG) tauE *= 1.0 - VC_H_WHITENESS * 0.01;
            #endif
            float energy = vcScatterEnergy(tauE);
            #if VC_MS_MODE == 2
                energy *= vcInnerGlow(cosT, tauE, look.extinction, t);
            #endif

            if (firstHit < 1.0) {
                firstHit = t;
                firstLightT = lightT;
                #if VC_GENUS_HIGH > 0 && VC_H_SHADOW_N == 1
                    firstHighT = highT;
                #endif
                firstScatter = phase * lightT;
                firstEnergy = energy;
            }

            float rSample;
            vec3 upSample;
            atmSamplePoint(tracePos - cameraPos, cameraPos.y, rSample, upSample);
            vec3 sunTint = atmTransmittance(rSample, dot(upSample, lightDir));
            sunTint = mix(vec3(1.0), sunTint / sunTintRef, sunTintAmount);

            vec3 sunPart = sunColor * (energy * sunTint);

            #if VC_OBJ_SHADOW == 1 && VC_Q_OBJ_SHADOW == 1 && SHADOW_QUALITY > -1

                if (!vcReflG && !vcHighBandG && t < 32.0) {
                    float objSh = 0.0;
                    for (int k = 0; k < 8; k++)
                        objSh += vcObjSunShadow(nPlayerPos * (t + stepLen * (float(k) + jitter) * 0.125));
                    sunPart *= mix(1.0, objSh * 0.125, VC_OBJ_SHADOW_STRENGTH * 0.01
                                                       * (1.0 - smoothstep(8.0, 32.0, t)));
                }
            #endif

            float hAmb = h;
            #if VC_GENUS_HIGH > 0

                if (vcHighBandG) hAmb = mix(vcHighHlG, 1.0, VC_H_WHITENESS * 0.01);
            #endif
            vec3 ambPart = mix(ambBotColor * ambientBottom, ambTopColor * ambientTop, hAmb);

            vec3 aerialT = vec3(1.0);
            #if VC_AERIAL > 0
                aerialT = atmSegmentTo(aerialCamEnd, aerialRising, rSample, upSample, nPlayerPos);
                #if VC_AERIAL != 100
                    aerialT = pow(aerialT, vec3(VC_AERIAL * 0.01));
                #endif
            #endif

            float sampleT = exp(-density * stepLen * look.extinction * rangeMult * viewOpacity);
            float absorbed = (1.0 - sampleT) * transmittance;

            vec3 emitPart = vec3(0.0);
            for (int i = 0; i < BV_BEAM_SLOTS; i++) {
                if (i >= beamN) break;
                float r = length(tracePos.xz - beamXZ[i]);

                float lit = 1.0 - smoothstep(beamFront[i].x - 16.0, beamFront[i].x + 16.0, tracePos.y);
                vec3 bcol = mix(beamCol[i], beamPrev[i],
                                smoothstep(beamFront[i].y - 16.0, beamFront[i].y + 16.0, tracePos.y));

                #if VC_OBJ_SHADOW == 1 && VC_Q_OBJ_SHADOW == 1 && defined VC_VOXEL_OCCLUSION

                    if (!vcReflG && t < 32.0 && r < float(VC_BEAM_RADIUS) * 2.5) {
                        float occ = 0.0;
                        for (int k = 0; k < 4; k++)
                            occ += vcBeamOcclusion(cameraPos + nPlayerPos * (t + stepLen * (float(k) + jitter) * 0.25),
                                                   beamXZ[i]);
                        lit *= mix(1.0, occ * 0.25, VC_OBJ_SHADOW_STRENGTH * 0.01
                                                    * (1.0 - smoothstep(8.0, 32.0, t)));
                    }
                #endif
                emitPart += bcol * lit * (3.0 / (1.0 + r * r * beamInvCore2)
                                          + 0.25 * exp(-r * beamInvHalo));
            }
            #if BETTER_THUNDER == 1
                if (flashA.w > 0.0)
                    emitPart += flashColor * flashA.w * exp(-distance(tracePos, flashA.xyz) * (1.0 / float(BT_SHEET_SIZE)));
                if (flashB.w > 0.0)
                    emitPart += flashColor * flashB.w * exp(-distance(tracePos, flashB.xyz) * (1.0 / float(BT_SHEET_SIZE)));
                if (strike.w > 0.0)
                    emitPart += flashColor * strike.w * exp(-distance(tracePos, strike.xyz) * (1.0 / float(BT_STRIKE_RADIUS)));
            #endif

            scattered += (sunPart + ambPart + emitPart) * absorbed;

            aerialSum += aerialT * absorbed;

            distSum += t * absorbed;
            edgeSum += clamp((reach - t) * (4.0 / reach), 0.0, 1.0) * absorbed;

            transmittance *= sampleT;

            if (transmittance < 0.015) break;
        } else {
            emptyRun++;
            #if VC_Q_FIXED_STEPS == 0
                if (emptyRun >= VC_EMPTY_EXIT) cheap = true;
            #endif
        }

        t += stepLen;
    }

    vcErodeLodG = 0.0;
    float alpha = 1.0 - transmittance;

    float edgeFade = edgeSum / max(alpha, 0.0001);
    vec3 aerial = aerialSum / max(alpha, 0.0001);

    vec3 cloudSkyColor = GetSky(VdotU, VdotS, dither, true, false);
    #ifdef ATM_COLOR_MULTS
        cloudSkyColor *= sqrtAtmColorMult;
    #endif

    vec3 finalColor = scattered / max(alpha, 0.0001);
    finalColor = mix(cloudSkyColor, finalColor, aerial);
    finalColor *= pow2(1.0 - maxBlindnessDarkness);

    result.rgb = finalColor;
    result.a = alpha * edgeFade;

    #if VC_DEBUG > 0 && VC_DEBUG != 10
        vec3 debugColor = vec3(1.0, 0.0, 1.0);
        #if VC_DEBUG == 2
            debugColor = vec3(clamp01(sumDensity * 0.04));
        #elif VC_DEBUG == 4
            debugColor = vec3(cloudTop);
        #elif VC_DEBUG == 5
            float stepLoad = float(taken) / float(VC_LOOP_N);
            debugColor = vec3(clamp01(stepLoad * 2.0 - 1.0),
                              1.0 - abs(stepLoad * 2.0 - 1.0),
                              clamp01(1.0 - stepLoad * 2.0));
        #elif VC_DEBUG == 6
            debugColor = vec3(firstLightT);
        #elif VC_DEBUG == 7
            debugColor = vec3(transmittance);
        #elif VC_DEBUG == 8
            debugColor = vec3(clamp01(firstScatter * 0.5));
        #elif VC_DEBUG == 9
            debugColor = vec3(clamp01(firstEnergy * 0.5));
        #elif VC_DEBUG == 11
            debugColor = vec3(clamp01(result.a));
        #elif VC_DEBUG == 13

            #if VC_GENUS_HIGH > 0
                if (vcHighBandG) return vec4(0.0);
            #endif
            debugColor = vec3(firstHighT);
        #elif VC_DEBUG == 12
            debugColor = result.rgb;
        #elif VC_DEBUG == 14

            #if VC_PHYSICS == 1
                debugColor = vcPhysicsAt((cameraPos + nPlayerPos * tNear).xz).rgb;
            #endif
        #endif
        return vec4(debugColor, 1.0);
    #endif

    if (result.a < 0.002) return vec4(0.0);

    if (result.a > 0.9) cloudLinearDepth = min(sqrt(firstHit / renderDistance), 1.0);

    float vcA = max(alpha, 1e-4);
    vec3 vcV = vcWindVelocity();
    #if VC_GENUS_HIGH > 0
        if (vcHighBandG) vcV = vcHighWindVelocity();
    #endif
    vcReprojG = vec4(distSum / vcA, vcV.x, vcV.z, 1.0) * result.a;

    return result;
}

#endif
