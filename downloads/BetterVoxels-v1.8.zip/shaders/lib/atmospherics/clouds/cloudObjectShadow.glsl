#ifndef INCLUDE_CLOUD_OBJECT_SHADOW
#define INCLUDE_CLOUD_OBJECT_SHADOW

#if __VERSION__ >= 420
    #define VC_VOXEL_OCCLUSION
    #include "/lib/vx/voxelReading.glsl"
#endif

#if VC_OBJ_SHADOW == 1 && SHADOW_QUALITY > -1

    float vcObjSunShadow(vec3 playerPos) {
        vec4 wpos = vec4(playerPos, 1.0);
        #ifdef SMOOTH_SHADOW_ROTATION
            wpos.xyz = stShadowRotation * wpos.xyz;
        #endif
        wpos = shadowProjection * (shadowModelView * wpos);
        wpos /= wpos.w;
        float distb = length(wpos.xy);
        float distortFactor = 1.0 - shadowMapBias + distb * shadowMapBias;
        vec3 sp = vec3(wpos.xy / distortFactor, wpos.z * 0.2) * 0.5 + 0.5;
        if (any(greaterThan(abs(sp.xy * 2.0 - 1.0), vec2(0.999)))) return 1.0;

        #ifdef COMPOSITE
            vec2 res = vec2(textureSize(shadowtex0, 0));
            float d = texelFetch(shadowtex0, ivec2(sp.xy * res), 0).x;
            return clamp((d - sp.z) * 65536.0, 0.0, 1.0);
        #else
            return texture(shadowtex0, vec3(sp.xy, sp.z - 0.0001));
        #endif
    }
#endif

#if VC_OBJ_SHADOW == 1 && defined VC_VOXEL_OCCLUSION
    #if FINE_VOXEL_COLOR > 0

        int vcFineSolid(vec3 q) {
            vec3 fp = q * float(FINE_COL_RES) + float(FINE_COL_SIDE) * 0.5;
            if (any(lessThan(fp, vec3(0.0))) || any(greaterThanEqual(fp, vec3(float(FINE_COL_SIDE)))))
                return -1;
            ivec3 fc = ivec3(fp) * ivec3(1, 2, 1);
            return (imageLoad(fineColImg, fc + ivec3(0, 1, 0)).r >> 23) > 0 ? 1 : 0;
        }
    #endif

    float vcBeamOcclusion(vec3 worldPos, vec2 axisXZ) {
        vec2 to = axisXZ - worldPos.xz;
        float r = length(to);
        if (r < 0.75) return 1.0;
        vec3 dir = vec3(to.x, 0.0, to.y) / r;
        float len = r - 0.5;

        vec3 vx = worldPos - cameraPosition + cameraPositionBestFract;
        float w = 0.25;
        for (int s = 0; s < 32; s++) {
            if (w >= len) return 1.0;
            vec3 p = vx + dir * w;
            if (vxOutOfRange(ivec3(floor(p + 0.5 * vec3(voxelVolumeSize))))) return 1.0;
            float d = getDistanceField(p);
            if (d > 1.0) {
                w += d - 0.5;
                continue;
            }

            #if FINE_VOXEL_COLOR > 0
                if (vcFineSolid(p) >= 0) {
                    for (int f = 0; f < 36; f++) {
                        float df = w + float(f) * (1.0 / 24.0);
                        if (df >= len) return 1.0;
                        if (vcFineSolid(vx + dir * df) == 1) return 0.0;
                    }
                    w += 1.5;
                    continue;
                }
            #endif
            for (int f = 0; f < 3; f++) {
                float df = w + float(f) * 0.5;
                if (df >= len) return 1.0;
                ivec3 c = ivec3(floor(vx + dir * df + 0.5 * vec3(voxelVolumeSize)));
                if (vxOutOfRange(c)) return 1.0;
                if ((imageLoad(occupancyVolume, c).r & 1) != 0) return 0.0;
            }
            w += 1.5;
        }
        return 1.0;
    }
#endif

#endif
