#ifndef INCLUDE_VOLUMETRIC_BIOME_CLIMATE
#define INCLUDE_VOLUMETRIC_BIOME_CLIMATE

#define VC_PH_BIOMES 0 //[0 1]
#define VC_PH_BIOME_RANGE 2000 //[500 1000 1500 2000 3000 4000 6000]

#define VC_BM_FOREST_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_FOREST_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_FOREST_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_FOREST_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_FLOWERFOREST_T 1 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_FLOWERFOREST_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_FLOWERFOREST_S 95 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_FLOWERFOREST_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_BIRCH_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_BIRCH_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_BIRCH_S 95 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_BIRCH_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_OLDBIRCH_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_OLDBIRCH_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_OLDBIRCH_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_OLDBIRCH_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_DARKFOR_T -1 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DARKFOR_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DARKFOR_S 80 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DARKFOR_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_PALE_T -3 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_PALE_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_PALE_S 80 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_PALE_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_WINDFOREST_T -3 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WINDFOREST_H 0 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WINDFOREST_S 100 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WINDFOREST_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_TAIGA_T -6 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_TAIGA_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_TAIGA_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_TAIGA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SNOWTAIGA_T -15 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SNOWTAIGA_H -3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SNOWTAIGA_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SNOWTAIGA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_PINETAIGA_T -5 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_PINETAIGA_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_PINETAIGA_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_PINETAIGA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SPRUCETAIGA_T -5 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SPRUCETAIGA_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SPRUCETAIGA_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SPRUCETAIGA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_GROVE_T -12 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_GROVE_H -3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_GROVE_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_GROVE_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_JUNGLE_T 8 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_JUNGLE_H 12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_JUNGLE_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_JUNGLE_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SPARSEJUNGLE_T 7 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SPARSEJUNGLE_H 8 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SPARSEJUNGLE_S 80 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SPARSEJUNGLE_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_BAMBOO_T 8 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_BAMBOO_H 12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_BAMBOO_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_BAMBOO_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_PLAINS_T 1 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_PLAINS_H 0 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_PLAINS_S 110 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_PLAINS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SUNFLOWER_T 2 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SUNFLOWER_H 0 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SUNFLOWER_S 110 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SUNFLOWER_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_MEADOW_T -3 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_MEADOW_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_MEADOW_S 100 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_MEADOW_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_CHERRY_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_CHERRY_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_CHERRY_S 100 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_CHERRY_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SAVANNA_T 10 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SAVANNA_H -12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SAVANNA_S 140 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SAVANNA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SAVPLATEAU_T 8 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SAVPLATEAU_H -12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SAVPLATEAU_S 140 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SAVPLATEAU_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_WINDSAVANNA_T 8 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WINDSAVANNA_H -12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WINDSAVANNA_S 140 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WINDSAVANNA_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_SWAMP_T 3 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SWAMP_H 12 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SWAMP_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SWAMP_E 8 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_MANGROVE_T 7 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_MANGROVE_H 15 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_MANGROVE_S 65 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_MANGROVE_E 8 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_DESERT_T 15 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DESERT_H -30 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DESERT_S 170 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DESERT_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_BADLANDS_T 14 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_BADLANDS_H -25 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_BADLANDS_S 160 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_BADLANDS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_ERODEDBAD_T 14 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_ERODEDBAD_H -25 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_ERODEDBAD_S 160 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_ERODEDBAD_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_WOODEDBAD_T 12 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WOODEDBAD_H -20 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WOODEDBAD_S 150 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WOODEDBAD_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_SNOWYPLAINS_T -18 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SNOWYPLAINS_H -5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SNOWYPLAINS_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SNOWYPLAINS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_ICESPIKES_T -22 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_ICESPIKES_H -8 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_ICESPIKES_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_ICESPIKES_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SNOWYSLOPES_T -18 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SNOWYSLOPES_H -5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SNOWYSLOPES_S 90 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SNOWYSLOPES_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_FROZENPEAKS_T -25 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_FROZENPEAKS_H -10 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_FROZENPEAKS_S 80 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_FROZENPEAKS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_JAGGEDPEAKS_T -22 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_JAGGEDPEAKS_H -8 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_JAGGEDPEAKS_S 80 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_JAGGEDPEAKS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_SNOWYBEACH_T -15 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_SNOWYBEACH_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_SNOWYBEACH_S 60 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_SNOWYBEACH_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_FROZENRIVER_T -15 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_FROZENRIVER_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_FROZENRIVER_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_FROZENRIVER_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_WINDHILLS_T -6 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WINDHILLS_H 0 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WINDHILLS_S 100 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WINDHILLS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_WINDGRAVEL_T -7 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WINDGRAVEL_H -3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WINDGRAVEL_S 100 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WINDGRAVEL_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_STONYPEAKS_T -10 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_STONYPEAKS_H -5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_STONYPEAKS_S 110 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_STONYPEAKS_E 0 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_STONYSHORE_T -2 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_STONYSHORE_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_STONYSHORE_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_STONYSHORE_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_BEACH_T 2 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_BEACH_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_BEACH_S 70 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_BEACH_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_RIVER_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_RIVER_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_RIVER_S 75 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_RIVER_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]

#define VC_BM_OCEAN_T 1 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_OCEAN_H 8 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_OCEAN_S 35 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_OCEAN_E 8 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_DEEPOCEAN_T 0 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DEEPOCEAN_H 8 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DEEPOCEAN_S 30 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DEEPOCEAN_E 8 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_COLDOCEAN_T -6 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_COLDOCEAN_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_COLDOCEAN_S 35 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_COLDOCEAN_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_DEEPCOLDOCEAN_T -7 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DEEPCOLDOCEAN_H 5 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DEEPCOLDOCEAN_S 30 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DEEPCOLDOCEAN_E 5 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_LUKEOCEAN_T 5 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_LUKEOCEAN_H 10 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_LUKEOCEAN_S 35 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_LUKEOCEAN_E 10 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_DEEPLUKEOCEAN_T 4 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DEEPLUKEOCEAN_H 10 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DEEPLUKEOCEAN_S 30 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DEEPLUKEOCEAN_E 10 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_WARMOCEAN_T 9 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_WARMOCEAN_H 10 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_WARMOCEAN_S 35 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_WARMOCEAN_E 12 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_FROZENOCEAN_T -15 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_FROZENOCEAN_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_FROZENOCEAN_S 40 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_FROZENOCEAN_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_DEEPFROZENOCEAN_T -16 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_DEEPFROZENOCEAN_H 3 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_DEEPFROZENOCEAN_S 35 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_DEEPFROZENOCEAN_E 3 //[0 3 5 8 10 12 15 20 25 30 40 50]
#define VC_BM_MUSHROOM_T 2 //[-30 -25 -22 -20 -18 -16 -15 -14 -12 -10 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 12 14 15 18 20 25]
#define VC_BM_MUSHROOM_H 10 //[-50 -40 -35 -30 -28 -25 -20 -15 -12 -10 -8 -5 -3 0 3 5 8 10 12 15 18 20 22 25 30 35 40 50]
#define VC_BM_MUSHROOM_S 60 //[0 10 20 30 35 40 50 60 65 70 75 80 90 95 100 110 120 140 150 160 170 200]
#define VC_BM_MUSHROOM_E 8 //[0 3 5 8 10 12 15 20 25 30 40 50]

#if VC_PH_BIOMES == 1

    #if !(defined INCLUDE_BIOME_ATMOSPHERE && defined BV_BIOME_IDS_ACTIVE)
        uniform float bvBiomeForest;
        uniform float bvBiomeFlowerforest;
        uniform float bvBiomeBirch;
        uniform float bvBiomeOldbirch;
        uniform float bvBiomeDarkfor;
        uniform float bvBiomePale;
        uniform float bvBiomeWindforest;
        uniform float bvBiomeTaiga;
        uniform float bvBiomeSnowtaiga;
        uniform float bvBiomePinetaiga;
        uniform float bvBiomeSprucetaiga;
        uniform float bvBiomeGrove;
        uniform float bvBiomeJungle;
        uniform float bvBiomeSparsejungle;
        uniform float bvBiomeBamboo;
        uniform float bvBiomePlains;
        uniform float bvBiomeSunflower;
        uniform float bvBiomeMeadow;
        uniform float bvBiomeCherry;
        uniform float bvBiomeSavanna;
        uniform float bvBiomeSavplateau;
        uniform float bvBiomeWindsavanna;
        uniform float bvBiomeSwamp;
        uniform float bvBiomeMangrove;
        uniform float bvBiomeDesert;
        uniform float bvBiomeBadlands;
        uniform float bvBiomeErodedbad;
        uniform float bvBiomeWoodedbad;
        uniform float bvBiomeSnowyplains;
        uniform float bvBiomeIcespikes;
        uniform float bvBiomeSnowyslopes;
        uniform float bvBiomeFrozenpeaks;
        uniform float bvBiomeJaggedpeaks;
        uniform float bvBiomeSnowybeach;
        uniform float bvBiomeFrozenriver;
        uniform float bvBiomeWindhills;
        uniform float bvBiomeWindgravel;
        uniform float bvBiomeStonypeaks;
        uniform float bvBiomeStonyshore;
        uniform float bvBiomeBeach;
        uniform float bvBiomeRiver;
        uniform float bvBiomeOcean;
        uniform float bvBiomeDeepocean;
        uniform float bvBiomeColdocean;
        uniform float bvBiomeDeepcoldocean;
        uniform float bvBiomeLukeocean;
        uniform float bvBiomeDeeplukeocean;
        uniform float bvBiomeWarmocean;
        uniform float bvBiomeFrozenocean;
        uniform float bvBiomeDeepfrozenocean;
        uniform float bvBiomeMushroom;
    #endif

    vec4 vcBiomeClimate() {
        vec4 acc = vec4(0.0);
        float w = 0.0;
        acc += bvBiomeForest * vec4(VC_BM_FOREST_T, VC_BM_FOREST_H, VC_BM_FOREST_S * 0.01, VC_BM_FOREST_E); w += bvBiomeForest;
        acc += bvBiomeFlowerforest * vec4(VC_BM_FLOWERFOREST_T, VC_BM_FLOWERFOREST_H, VC_BM_FLOWERFOREST_S * 0.01, VC_BM_FLOWERFOREST_E); w += bvBiomeFlowerforest;
        acc += bvBiomeBirch * vec4(VC_BM_BIRCH_T, VC_BM_BIRCH_H, VC_BM_BIRCH_S * 0.01, VC_BM_BIRCH_E); w += bvBiomeBirch;
        acc += bvBiomeOldbirch * vec4(VC_BM_OLDBIRCH_T, VC_BM_OLDBIRCH_H, VC_BM_OLDBIRCH_S * 0.01, VC_BM_OLDBIRCH_E); w += bvBiomeOldbirch;
        acc += bvBiomeDarkfor * vec4(VC_BM_DARKFOR_T, VC_BM_DARKFOR_H, VC_BM_DARKFOR_S * 0.01, VC_BM_DARKFOR_E); w += bvBiomeDarkfor;
        acc += bvBiomePale * vec4(VC_BM_PALE_T, VC_BM_PALE_H, VC_BM_PALE_S * 0.01, VC_BM_PALE_E); w += bvBiomePale;
        acc += bvBiomeWindforest * vec4(VC_BM_WINDFOREST_T, VC_BM_WINDFOREST_H, VC_BM_WINDFOREST_S * 0.01, VC_BM_WINDFOREST_E); w += bvBiomeWindforest;
        acc += bvBiomeTaiga * vec4(VC_BM_TAIGA_T, VC_BM_TAIGA_H, VC_BM_TAIGA_S * 0.01, VC_BM_TAIGA_E); w += bvBiomeTaiga;
        acc += bvBiomeSnowtaiga * vec4(VC_BM_SNOWTAIGA_T, VC_BM_SNOWTAIGA_H, VC_BM_SNOWTAIGA_S * 0.01, VC_BM_SNOWTAIGA_E); w += bvBiomeSnowtaiga;
        acc += bvBiomePinetaiga * vec4(VC_BM_PINETAIGA_T, VC_BM_PINETAIGA_H, VC_BM_PINETAIGA_S * 0.01, VC_BM_PINETAIGA_E); w += bvBiomePinetaiga;
        acc += bvBiomeSprucetaiga * vec4(VC_BM_SPRUCETAIGA_T, VC_BM_SPRUCETAIGA_H, VC_BM_SPRUCETAIGA_S * 0.01, VC_BM_SPRUCETAIGA_E); w += bvBiomeSprucetaiga;
        acc += bvBiomeGrove * vec4(VC_BM_GROVE_T, VC_BM_GROVE_H, VC_BM_GROVE_S * 0.01, VC_BM_GROVE_E); w += bvBiomeGrove;
        acc += bvBiomeJungle * vec4(VC_BM_JUNGLE_T, VC_BM_JUNGLE_H, VC_BM_JUNGLE_S * 0.01, VC_BM_JUNGLE_E); w += bvBiomeJungle;
        acc += bvBiomeSparsejungle * vec4(VC_BM_SPARSEJUNGLE_T, VC_BM_SPARSEJUNGLE_H, VC_BM_SPARSEJUNGLE_S * 0.01, VC_BM_SPARSEJUNGLE_E); w += bvBiomeSparsejungle;
        acc += bvBiomeBamboo * vec4(VC_BM_BAMBOO_T, VC_BM_BAMBOO_H, VC_BM_BAMBOO_S * 0.01, VC_BM_BAMBOO_E); w += bvBiomeBamboo;
        acc += bvBiomePlains * vec4(VC_BM_PLAINS_T, VC_BM_PLAINS_H, VC_BM_PLAINS_S * 0.01, VC_BM_PLAINS_E); w += bvBiomePlains;
        acc += bvBiomeSunflower * vec4(VC_BM_SUNFLOWER_T, VC_BM_SUNFLOWER_H, VC_BM_SUNFLOWER_S * 0.01, VC_BM_SUNFLOWER_E); w += bvBiomeSunflower;
        acc += bvBiomeMeadow * vec4(VC_BM_MEADOW_T, VC_BM_MEADOW_H, VC_BM_MEADOW_S * 0.01, VC_BM_MEADOW_E); w += bvBiomeMeadow;
        acc += bvBiomeCherry * vec4(VC_BM_CHERRY_T, VC_BM_CHERRY_H, VC_BM_CHERRY_S * 0.01, VC_BM_CHERRY_E); w += bvBiomeCherry;
        acc += bvBiomeSavanna * vec4(VC_BM_SAVANNA_T, VC_BM_SAVANNA_H, VC_BM_SAVANNA_S * 0.01, VC_BM_SAVANNA_E); w += bvBiomeSavanna;
        acc += bvBiomeSavplateau * vec4(VC_BM_SAVPLATEAU_T, VC_BM_SAVPLATEAU_H, VC_BM_SAVPLATEAU_S * 0.01, VC_BM_SAVPLATEAU_E); w += bvBiomeSavplateau;
        acc += bvBiomeWindsavanna * vec4(VC_BM_WINDSAVANNA_T, VC_BM_WINDSAVANNA_H, VC_BM_WINDSAVANNA_S * 0.01, VC_BM_WINDSAVANNA_E); w += bvBiomeWindsavanna;
        acc += bvBiomeSwamp * vec4(VC_BM_SWAMP_T, VC_BM_SWAMP_H, VC_BM_SWAMP_S * 0.01, VC_BM_SWAMP_E); w += bvBiomeSwamp;
        acc += bvBiomeMangrove * vec4(VC_BM_MANGROVE_T, VC_BM_MANGROVE_H, VC_BM_MANGROVE_S * 0.01, VC_BM_MANGROVE_E); w += bvBiomeMangrove;
        acc += bvBiomeDesert * vec4(VC_BM_DESERT_T, VC_BM_DESERT_H, VC_BM_DESERT_S * 0.01, VC_BM_DESERT_E); w += bvBiomeDesert;
        acc += bvBiomeBadlands * vec4(VC_BM_BADLANDS_T, VC_BM_BADLANDS_H, VC_BM_BADLANDS_S * 0.01, VC_BM_BADLANDS_E); w += bvBiomeBadlands;
        acc += bvBiomeErodedbad * vec4(VC_BM_ERODEDBAD_T, VC_BM_ERODEDBAD_H, VC_BM_ERODEDBAD_S * 0.01, VC_BM_ERODEDBAD_E); w += bvBiomeErodedbad;
        acc += bvBiomeWoodedbad * vec4(VC_BM_WOODEDBAD_T, VC_BM_WOODEDBAD_H, VC_BM_WOODEDBAD_S * 0.01, VC_BM_WOODEDBAD_E); w += bvBiomeWoodedbad;
        acc += bvBiomeSnowyplains * vec4(VC_BM_SNOWYPLAINS_T, VC_BM_SNOWYPLAINS_H, VC_BM_SNOWYPLAINS_S * 0.01, VC_BM_SNOWYPLAINS_E); w += bvBiomeSnowyplains;
        acc += bvBiomeIcespikes * vec4(VC_BM_ICESPIKES_T, VC_BM_ICESPIKES_H, VC_BM_ICESPIKES_S * 0.01, VC_BM_ICESPIKES_E); w += bvBiomeIcespikes;
        acc += bvBiomeSnowyslopes * vec4(VC_BM_SNOWYSLOPES_T, VC_BM_SNOWYSLOPES_H, VC_BM_SNOWYSLOPES_S * 0.01, VC_BM_SNOWYSLOPES_E); w += bvBiomeSnowyslopes;
        acc += bvBiomeFrozenpeaks * vec4(VC_BM_FROZENPEAKS_T, VC_BM_FROZENPEAKS_H, VC_BM_FROZENPEAKS_S * 0.01, VC_BM_FROZENPEAKS_E); w += bvBiomeFrozenpeaks;
        acc += bvBiomeJaggedpeaks * vec4(VC_BM_JAGGEDPEAKS_T, VC_BM_JAGGEDPEAKS_H, VC_BM_JAGGEDPEAKS_S * 0.01, VC_BM_JAGGEDPEAKS_E); w += bvBiomeJaggedpeaks;
        acc += bvBiomeSnowybeach * vec4(VC_BM_SNOWYBEACH_T, VC_BM_SNOWYBEACH_H, VC_BM_SNOWYBEACH_S * 0.01, VC_BM_SNOWYBEACH_E); w += bvBiomeSnowybeach;
        acc += bvBiomeFrozenriver * vec4(VC_BM_FROZENRIVER_T, VC_BM_FROZENRIVER_H, VC_BM_FROZENRIVER_S * 0.01, VC_BM_FROZENRIVER_E); w += bvBiomeFrozenriver;
        acc += bvBiomeWindhills * vec4(VC_BM_WINDHILLS_T, VC_BM_WINDHILLS_H, VC_BM_WINDHILLS_S * 0.01, VC_BM_WINDHILLS_E); w += bvBiomeWindhills;
        acc += bvBiomeWindgravel * vec4(VC_BM_WINDGRAVEL_T, VC_BM_WINDGRAVEL_H, VC_BM_WINDGRAVEL_S * 0.01, VC_BM_WINDGRAVEL_E); w += bvBiomeWindgravel;
        acc += bvBiomeStonypeaks * vec4(VC_BM_STONYPEAKS_T, VC_BM_STONYPEAKS_H, VC_BM_STONYPEAKS_S * 0.01, VC_BM_STONYPEAKS_E); w += bvBiomeStonypeaks;
        acc += bvBiomeStonyshore * vec4(VC_BM_STONYSHORE_T, VC_BM_STONYSHORE_H, VC_BM_STONYSHORE_S * 0.01, VC_BM_STONYSHORE_E); w += bvBiomeStonyshore;
        acc += bvBiomeBeach * vec4(VC_BM_BEACH_T, VC_BM_BEACH_H, VC_BM_BEACH_S * 0.01, VC_BM_BEACH_E); w += bvBiomeBeach;
        acc += bvBiomeRiver * vec4(VC_BM_RIVER_T, VC_BM_RIVER_H, VC_BM_RIVER_S * 0.01, VC_BM_RIVER_E); w += bvBiomeRiver;
        acc += bvBiomeOcean * vec4(VC_BM_OCEAN_T, VC_BM_OCEAN_H, VC_BM_OCEAN_S * 0.01, VC_BM_OCEAN_E); w += bvBiomeOcean;
        acc += bvBiomeDeepocean * vec4(VC_BM_DEEPOCEAN_T, VC_BM_DEEPOCEAN_H, VC_BM_DEEPOCEAN_S * 0.01, VC_BM_DEEPOCEAN_E); w += bvBiomeDeepocean;
        acc += bvBiomeColdocean * vec4(VC_BM_COLDOCEAN_T, VC_BM_COLDOCEAN_H, VC_BM_COLDOCEAN_S * 0.01, VC_BM_COLDOCEAN_E); w += bvBiomeColdocean;
        acc += bvBiomeDeepcoldocean * vec4(VC_BM_DEEPCOLDOCEAN_T, VC_BM_DEEPCOLDOCEAN_H, VC_BM_DEEPCOLDOCEAN_S * 0.01, VC_BM_DEEPCOLDOCEAN_E); w += bvBiomeDeepcoldocean;
        acc += bvBiomeLukeocean * vec4(VC_BM_LUKEOCEAN_T, VC_BM_LUKEOCEAN_H, VC_BM_LUKEOCEAN_S * 0.01, VC_BM_LUKEOCEAN_E); w += bvBiomeLukeocean;
        acc += bvBiomeDeeplukeocean * vec4(VC_BM_DEEPLUKEOCEAN_T, VC_BM_DEEPLUKEOCEAN_H, VC_BM_DEEPLUKEOCEAN_S * 0.01, VC_BM_DEEPLUKEOCEAN_E); w += bvBiomeDeeplukeocean;
        acc += bvBiomeWarmocean * vec4(VC_BM_WARMOCEAN_T, VC_BM_WARMOCEAN_H, VC_BM_WARMOCEAN_S * 0.01, VC_BM_WARMOCEAN_E); w += bvBiomeWarmocean;
        acc += bvBiomeFrozenocean * vec4(VC_BM_FROZENOCEAN_T, VC_BM_FROZENOCEAN_H, VC_BM_FROZENOCEAN_S * 0.01, VC_BM_FROZENOCEAN_E); w += bvBiomeFrozenocean;
        acc += bvBiomeDeepfrozenocean * vec4(VC_BM_DEEPFROZENOCEAN_T, VC_BM_DEEPFROZENOCEAN_H, VC_BM_DEEPFROZENOCEAN_S * 0.01, VC_BM_DEEPFROZENOCEAN_E); w += bvBiomeDeepfrozenocean;
        acc += bvBiomeMushroom * vec4(VC_BM_MUSHROOM_T, VC_BM_MUSHROOM_H, VC_BM_MUSHROOM_S * 0.01, VC_BM_MUSHROOM_E); w += bvBiomeMushroom;
        acc += max(1.0 - w, 0.0) * vec4(0.0, 0.0, 1.0, 0.0);
        return acc / max(w, 1.0);
    }
#endif

#endif
