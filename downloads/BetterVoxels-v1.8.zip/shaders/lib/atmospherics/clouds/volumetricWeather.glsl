
#ifndef INCLUDE_VOLUMETRIC_WEATHER
#define INCLUDE_VOLUMETRIC_WEATHER

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricWind.glsl"
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricGenus.glsl"

// CREDIT: the map projection is ported from Photon by SixthSurge
// (coverage_map.glsl:55), with permission - see volumetricShapePhoton.glsl.

#define VC_MAP_D (VC_MAP_DISTORT * 0.01)

vec2 vcMapProject(vec2 worldXZ, vec2 camXZ) {
    vec2 p = (worldXZ - camXZ) * (2.0 / float(VC_MAP_SPAN));
    p /= VC_MAP_D * length(p) + (1.0 - VC_MAP_D);
    return p * 0.5 + 0.5;
}

vec2 vcMapUnproject(vec2 uv) {
    vec2 p = uv * 2.0 - 1.0;
    float l = min(length(p), 0.999 / max(VC_MAP_D, 0.001));
    p *= (1.0 - VC_MAP_D) / max(1.0 - l * VC_MAP_D, 0.001);
    return p * (0.5 * float(VC_MAP_SPAN));
}

float vcPerlinFbmW(vec3 p, float freq, int octaves) {
    float sum = 0.0;
    float norm = 0.0;
    float amp = 1.0;
    for (int i = 0; i < octaves; i++) {
        sum += vcPerlin(p, freq) * amp;
        norm += amp;
        freq *= 2.0;
        amp *= 0.5;
    }
    return clamp(sum / norm * 1.3 + 0.5, 0.0, 1.0);
}

#define VC_PRESSURE_CENTRES 6

vec4 vcCentreHash(float seed, float i) {
    vec2 p = vec2(seed * 0.1031 + i * 0.7317, seed * 0.0973 + i * 0.3797);
    return fract(sin(vec4(dot(p, vec2(12.9898, 78.233)),
                          dot(p, vec2(16.0898, 76.533)),
                          dot(p, vec2(19.1898, 74.833)),
                          dot(p, vec2(22.2898, 73.133)))) * 43758.5453);
}

float vcWeatherDay() {
    #if VC_SEED == 0
        return mod(float(worldDay), 4096.0) + float(worldTime) / 24000.0;
    #else
        return float(VC_SEED);
    #endif
}

float vcWeatherSeed() {
    return floor(vcWeatherDay());
}

vec2 vcDayBlend() {
    float f = fract(vcWeatherDay()) * 1.5707963;
    return vec2(cos(f), sin(f));
}

float vcStormSeed() {
    #if VC_SEED == 0
        return 0.0;
    #else
        return float(VC_SEED);
    #endif
}

vec3 vcPressureSeed(vec2 uv, float t, float seed) {
    float p = 0.0;
    vec2 g = vec2(0.0);

    for (int i = 0; i < VC_PRESSURE_CENTRES; i++) {
        float fi = float(i);
        vec4 h = vcCentreHash(seed, fi);

        float ang = h.y * 6.28318531;
        float speed = 0.0008 + 0.0012 * h.z;
        vec2 pos = fract(vec2(h.x, fract(h.x * 7.3 + h.y * 3.1))
                       + vec2(cos(ang), sin(ang)) * (speed * t));

        vec2 d0 = uv - pos;
        d0 -= floor(d0 + 0.5);

        float r = 0.20 + 0.20 * h.w;
        float r2 = r * r;
        float amp = (mod(fi, 2.0) < 0.5 ? 1.0 : -1.0) * (0.6 + 0.4 * h.z);

        for (int ox = -1; ox <= 1; ox++) {
            for (int oy = -1; oy <= 1; oy++) {
                vec2 d = d0 + vec2(float(ox), float(oy));
                float e = exp(-dot(d, d) / r2);
                p += amp * e;
                g += (amp * e * (-2.0 / r2)) * d;
            }
        }
    }

    return vec3(p, g * 0.25);
}

vec3 vcPressure(vec2 uv, float t) {
    float s0 = vcWeatherSeed();
    vec2 w = vcDayBlend();
    vec3 a = vcPressureSeed(uv, t, s0);
    if (w.y < 0.0001) return a;
    return a * w.x + vcPressureSeed(uv, t, s0 + 1.0) * w.y;
}

vec4 vcWeatherCirrus(vec2 auv, float ez, float freqBase, float fibre) {
    float cif = floor(freqBase + 0.5);
    float cs = VC_CURL_AMOUNT * 0.01 * fibre;

    vec2 cu = vcCurl(auv, 12.0) * 0.5
            + vcCurl(auv, 24.0) * 0.25
            + vcCurl(auv, 48.0) * 0.125;

    float inv = 1.0 / float(VC_DOMAIN);
    float ciBase =
          0.7 * vcPerlinFbmW(vec3(auv + cu * (82.0 * inv * cs), ez),
                             max(cif, 1.0), 2)
        + 0.3 * vcPerlinFbmW(vec3(auv + cu * (20.0 * inv * cs), ez),
                             max(floor(cif * 5.0 + 0.5), 1.0), 2);

    float ciDet = 0.0;
    float amp = 0.2;
    float fr = max(floor(cif * 12.0 + 0.5), 1.0);
    float disp = 102.0;
    for (int i = 0; i < 4; i++) {
        ciDet += vcPerlinFbmW(vec3(auv + cu * (disp * inv * cs), ez), fr, 2)
               * amp;
        amp *= 0.6;
        fr *= 2.0;
        disp *= 2.0;
    }
    return vec4(ciBase, ciDet, 0.0, 0.0);
}

vec4 vcWeatherCirrocumulus(vec2 auv, float ez, float freqBase) {
    float ccf = floor(freqBase + 0.5);
    float ccCov = vcPerlinFbmW(vec3(auv, ez),
                               max(floor(ccf / 9.6 + 0.5), 1.0), 2);
    float ccShape = 0.0;
    {
        float c = (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), ccf), 0.0, 1.0)))
                + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), ccf * 2.0), 0.0, 1.0))) * 0.8
                + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), ccf * 4.0), 0.0, 1.0))) * 0.64;
        ccShape = 0.535 + (c * (1.0 / 2.44) - 0.474) * (0.086 / 0.108);
    }
    float ccD1 = vcPerlinFbmW(vec3(auv + vec2(7.3, 19.1), ez),
                              max(floor(ccf * 2.0 + 0.5), 1.0), 3);
    float ccD2 = vcPerlinFbmW(vec3(auv + vec2(23.7, 5.9), ez),
                              max(floor(ccf * 8.0 + 0.5), 1.0), 3);
    return vec4(ccCov, ccShape, ccD1, ccD2);
}

float vcRegionSG = 0.0;

vec2 vcPhysWinG = vec2(0.0, 1.0);
#if VC_PHYSICS == 1 && !defined VC_NOISE_WRITER
    vec4 vcPhysicsAt(vec2 worldXZ);
#endif

float vcRegionHG = 0.5;
float vcExtG = 1.0;

bool vcConeG = false;

bool vcReflG = false;

float vcHighHlG = 0.5;

float vcHighSkipG = 0.0;

#define VC_REGION_P30 0.37
#define VC_REGION_P70 0.62

float vcRegionMixAt(vec2 worldXZ, float z) {
    float v = vcPerlinFbmW(vec3(worldXZ / float(VC_DOMAIN), z),
                           float(VC_REGION_FREQ), 1);
    v = clamp(v + (VC_REGION_BIAS * 0.01) * 0.25, 0.0, 1.0);

    return v < VC_REGION_P30
         ? 0.25 * (v / VC_REGION_P30)
         : (v < VC_REGION_P70
            ? 0.25 + 0.50 * ((v - VC_REGION_P30)
                           / (VC_REGION_P70 - VC_REGION_P30))
            : 0.75 + 0.25 * ((v - VC_REGION_P70)
                           / (1.0 - VC_REGION_P70)));
}

#include "/lib/misc/bvStateImage.glsl"

float vcRainAmount() {
    #if VC_RAIN_OVERCAST == 0
        return 0.0;
    #else
        return smoothstep(0.0, 1.0, texelFetch(bv_state_sampler, BV_ST_RAIN, 0).r);
    #endif
}

float vcRainLevel() {
    float s = clamp(VC_RAIN_COVERAGE * 0.01, 0.02, 0.98);
    return 0.517 + 0.055 * log(s / (1.0 - s));
}

#define VC_RAIN_RADIUS 8000.0

float vcRainField(vec2 worldXZ) {
    float r = vcRainAmount();
    if (r <= 0.001) return 0.0;
    float d = length(worldXZ - cameraPosition.xz);
    return r * (1.0 - smoothstep(VC_RAIN_RADIUS * 0.5, VC_RAIN_RADIUS, d));
}

float vcRegionMix(vec2 worldXZ) {
    return mix(vcRegionMixAt(worldXZ, vcWeatherDay() * 0.137 + 0.31), 0.8,
               vcRainField(worldXZ));
}

float vcRegionHigh(vec2 worldXZ) {
    #if VC_PHYSICS == 1 && !defined VC_NOISE_WRITER
        return mix(vcPhysicsAt(worldXZ).a, 1.0, 0.8 * vcRainField(worldXZ));
    #else
        return mix(vcRegionMixAt(worldXZ, vcWeatherDay() * 0.137 + 0.73), 1.0,
                   0.8 * vcRainField(worldXZ));
    #endif
}

float vcValue2(vec2 p, float seed) {
    vec2 i = floor(p);
    vec2 f = p - i;
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = vcHash33(vec3(i, seed)).x;
    float b = vcHash33(vec3(i + vec2(1.0, 0.0), seed)).x;
    float c = vcHash33(vec3(i + vec2(0.0, 1.0), seed)).x;
    float d = vcHash33(vec3(i + vec2(1.0, 1.0), seed)).x;
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float vcExtJitter(vec2 worldXZ) {
    #if VC_EXT_VAR == 0 || (VC_EXT_MIN == 100 && VC_EXT_MAX == 100)
        return 1.0;
    #else

        vec2 ep = worldXZ * (float(VC_EXT_VAR_FREQ) / float(VC_DOMAIN));
        float s0 = vcWeatherSeed();
        vec2 w = vcDayBlend();
        float v = vcValue2(ep, s0 * 0.061 + 0.17);
        if (w.y > 0.0001) {
            float vb = vcValue2(ep, (s0 + 1.0) * 0.061 + 0.17);
            v = 0.5 + (v - 0.5) * w.x + (vb - 0.5) * w.y;
        }
        v = clamp((v - 0.095) / 0.808, 0.0, 1.0);
        return mix(VC_EXT_MIN * 0.01, VC_EXT_MAX * 0.01, v);
    #endif
}

float vcExtCached(vec2 worldXZ) {
    if (!vcConeG) vcExtG = vcExtJitter(worldXZ);
    return vcExtG;
}

float vcG3(float a, float b, float c) {
    return vcRegionSG < 0.5 ? mix(a, b, vcRegionSG * 2.0)
                            : mix(b, c, vcRegionSG * 2.0 - 1.0);
}

#include "/lib/atmospherics/clouds/volumetricPhysics.glsl"

#if VC_PHYSICS == 1 && defined VC_NOISE_WRITER

    vec4 vcPhysMapLoad(int x0, vec2 worldXZ) {
        vec2 uv = vcMapProject(worldXZ, cameraPosition.xz);
        vec2 px = clamp(uv, 0.0, 1.0) * float(VC_PHYS_RES) - 0.5;
        ivec2 i0 = ivec2(floor(px));
        vec2 f = px - vec2(i0);
        ivec2 lo = ivec2(0);
        ivec2 hi = ivec2(VC_PHYS_RES - 1);
        ivec2 b = ivec2(x0, VC_PHYS_Y0);
        vec4 a = imageLoad(vcWeatherImg, b + clamp(i0, lo, hi));
        vec4 c = imageLoad(vcWeatherImg, b + clamp(i0 + ivec2(1, 0), lo, hi));
        vec4 d = imageLoad(vcWeatherImg, b + clamp(i0 + ivec2(0, 1), lo, hi));
        vec4 e = imageLoad(vcWeatherImg, b + clamp(i0 + ivec2(1, 1), lo, hi));
        return mix(mix(a, c, f.x), mix(d, e, f.x), f.y);
    }
#endif

vec4 vcBuildWeather(vec2 worldXZ, float t, int band) {
    vec2 uv = worldXZ / float(VC_DOMAIN);
    vec2 w = vcWindVector();
    ivec2 ax = vcWindAxis();

    vec3 pres = vcPressure(uv, t);

    vec2 scroll = w * (t * (VC_WIND_SPEED * 0.1) / float(VC_DOMAIN));
    vec2 base = uv - scroll + pres.yz * (VC_SYN_FLOW * 0.01) * 0.08;

    float ka = float(VC_ANISO);
    vec2 auv = vec2(float(ax.x) * base.x + float(ax.y) * base.y,
                    ka * (float(-ax.y) * base.x + float(ax.x) * base.y));

    float ez = t * (VC_EVOLVE * 0.01) * 0.002;

    #if VC_GENUS_HIGH > 0

        if (band == 1) {
            vec2 hw = vcHighWindVector();
            vec2 hax = hw * length(vec2(ax));
            vec2 hBase = uv - hw * (t * (VC_WIND_SPEED * 0.1) / float(VC_DOMAIN)) * VC_H_WIND
                       + pres.yz * (VC_SYN_FLOW * 0.01) * 0.08;
            vec2 hAuv = vec2(hax.x * hBase.x + hax.y * hBase.y,
                             ka * (-hax.y * hBase.x + hax.x * hBase.y));

            #if VC_PHYSICS == 1 && defined VC_NOISE_WRITER
                float phHigh = vcPhysMapLoad(VC_PHYS2_X0, worldXZ).g;
                float highR = mix(vcPhysMapLoad(VC_PHYS_X0, worldXZ).a, 1.0,
                                  0.8 * vcRainField(worldXZ));
            #elif VC_PHYSICS == 1

                float phCov, phHigh;
                float highR = vcPhysicsColumn(worldXZ, pres.x, phCov, phHigh).a;
            #else
                float highR = vcRegionHigh(worldXZ);
            #endif
            if (highR < VC_H_CC_EDGE) {
                return vcWeatherCirrocumulus(hAuv, ez,
                                             VC_H_CC_FREQ * VC_H_CC_SIZE);
            }
            vec4 ci = vcWeatherCirrus(hAuv, ez, VC_H_CI_FREQ * VC_H_CI_SIZE,
                                      VC_CI_FIBRE * 0.01);

            float hLowf = vcPerlinFbmW(vec3(hAuv + vec2(3.7, 8.1), ez), 1.0, 2);
            float hSyn = clamp(0.5 - pres.x * (VC_SYNOPTIC * 0.01) * 0.5, 0.0, 1.0);
            float hAmt = clamp(0.5 * hLowf + 0.5 * hSyn + VC_COVERAGE_BIAS * 0.01,
                               0.0, 1.0);
            float hLo = max(VC_PH_COV_LOW * 0.01 - VC_REGION_COVER * 0.01, 0.0);
            ci.b = mix(hLo, VC_PH_COV_HIGH * 0.01, hAmt) / (VC_PH_COV_HIGH * 0.01);
            #if VC_PHYSICS == 1

                ci.b = phHigh;
            #endif
            return ci;
        }
    #endif

    float mf = float(VC_MESO_FREQ);
    vec2 q = vec2(vcPerlinFbmW(vec3(auv, ez), mf, 4),
                  vcPerlinFbmW(vec3(auv + vec2(5.2, 1.3), ez), mf, 4));
    float meso = vcPerlinFbmW(vec3(auv + (VC_WARP * 0.01) * q, ez), mf, 4);

    float syn = clamp(0.5 - pres.x * (VC_SYNOPTIC * 0.01) * 0.5, 0.0, 1.0);

    float gate = 1.0 - syn - VC_COVERAGE_BIAS * 0.01;
    float span = max(0.85 - gate, 0.0001);

    float cov = clamp((meso - gate) / span, 0.0, 1.0);

    float islandWorley = vcWorley(vec3(auv, ez), mf) * 0.625
                       + vcWorley(vec3(auv, ez), mf * 2.0) * 0.25
                       + vcWorley(vec3(auv, ez), mf * 4.0) * 0.125;

    float islandPW = clamp(vcRemap(meso, 0.0, 1.0, islandWorley, 1.0), 0.0, 1.0);
    float island = clamp(vcRemap(islandPW, 0.576, 0.981, 0.054, 0.866), 0.0, 1.0);
    float covI = clamp((island - gate) / span, 0.0, 1.0);

    float type = vcPerlinFbmW(vec3(base, ez), float(VC_TYPE_FREQ), 3);

    float bottomType = vcPerlinFbmW(vec3(base + vec2(19.7, 4.3), ez),
                                    float(VC_TYPE_FREQ), 3);

#if VC_SHAPE_MODEL == 1
    // CREDIT: this coverage form is ported from Photon by SixthSurge
    // (coverage_map.glsl:26-34), with permission - see volumetricShapePhoton.glsl.

    float lowf = vcPerlinFbmW(vec3(auv, ez), 1.0, 2);
    float amt = clamp(0.5 * lowf + 0.5 * syn + VC_COVERAGE_BIAS * 0.01,
                      0.0, 1.0);
    #if VC_G_ALL == 1

        amt = mix(max(VC_PH_COV_LOW * 0.01 - VC_REGION_COVER * 0.01, 0.0),
                  VC_PH_COV_HIGH * 0.01, amt);
    #else
        amt = mix(VC_PH_COV_LOW * 0.01, VC_PH_COV_HIGH * 0.01, amt);
    #endif
    #if VC_PHYSICS == 1

        #ifdef VC_NOISE_WRITER
        {
            float pc = vcPhysMapLoad(VC_PHYS2_X0, worldXZ).r;
            #if VC_G_ALL == 1
                float pLo = max(VC_PH_COV_LOW * 0.01 - VC_REGION_COVER * 0.01, 0.0);
            #else
                float pLo = VC_PH_COV_LOW * 0.01;
            #endif
            amt = mix(pLo, VC_PH_COV_HIGH * 0.01, pc) * smoothstep(0.0, 0.12, pc);
        }
        #endif
    #endif

    amt = mix(amt, 1.0, vcRainField(worldXZ));

    #if VC_PH_SHAPE_NOISE == 1

        float cf = floor(float(VC_PH_CELL_FREQ) * VC_G_SIZE + 0.5);
        float cell = (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf), 0.0, 1.0)))
                   + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf * 2.0), 0.0, 1.0))) * 0.8
                   + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf * 4.0), 0.0, 1.0))) * 0.64;
        float shapeN = 0.535 + (cell * (1.0 / 2.44) - 0.474) * (0.086 / 0.108);
    #else
        float shapeN = meso;
    #endif

    #if VC_G_CB == 1

        float sp = float(VC_CB_SPACING);
        vec2 sw = worldXZ - vcWindVector() * (t * (VC_WIND_SPEED * 0.1));
        vec2 sc = floor(sw / sp);
        float best = 1e9;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                vec2 c = sc + vec2(float(dx), float(dy));
                vec3 hh = vcHash33(vec3(c, vcStormSeed()));
                vec2 pos = (c + 0.25 + 0.5 * hh.xy) * sp;
                best = min(best, length(sw - pos));
            }
        }
        float cbR = clamp(best / float(VC_CB_RADIUS), 0.0, 4.0) * 0.25;

        float cbShape = 0.0;
        {
            float cf = float(VC_PH_CELL_FREQ);
            float c = (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf), 0.0, 1.0)))
                    + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf * 2.0), 0.0, 1.0))) * 0.8
                    + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), cf * 4.0), 0.0, 1.0))) * 0.64;
            cbShape = 0.535 + (c * (1.0 / 2.44) - 0.474) * (0.086 / 0.108);
        }

        float cbRag = vcPerlinFbmW(vec3(auv + vec2(41.3, 8.9), ez), 24.0, 3);

        return vec4(cbR, cbShape, cbRag, 0.0);
    #endif

    #if VC_G_CI == 1
        return vcWeatherCirrus(auv, ez, VC_G_CI_FREQ * VC_G_SIZE,
                               VC_CI_FIBRE * 0.01);
    #endif

    #if VC_G_CC == 1
        return vcWeatherCirrocumulus(auv, ez, VC_G_CC_FREQ * VC_G_SIZE);
    #endif

    #if VC_G_AC == 1

        float cfA = floor(float(VC_PH_CELL_FREQ) * VC_G_SIZE + 0.5);
        float df = floor(cfA * VC_G_AC_DET + 0.5);
        float acDet = (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), df), 0.0, 1.0)))
                    + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), df * 2.0), 0.0, 1.0))) * 0.8
                    + (1.0 - sqrt(clamp(1.0 - vcWorley(vec3(auv, ez), df * 4.0), 0.0, 1.0))) * 0.64;
        acDet = 0.535 + (acDet * (1.0 / 2.44) - 0.474) * (0.086 / 0.108);

        float acLow = vcPerlinFbmW(vec3(auv, ez),
                                   max(floor(cfA / 9.4 + 0.5), 1.0), 2);

        return vec4(acLow, shapeN, acDet, syn);
    #endif

    return vec4(amt, shapeN, type, bottomType);
#endif

    return vec4(cov, covI, type, bottomType);
}

#ifndef VC_NOISE_WRITER

    vec2 vcWeatherBandUV(vec2 uv, int band) {
        vec2 px = vec2(0.0, float(band) * float(VC_WEATHER_RES))
                + 0.5 + uv * (float(VC_WEATHER_RES) - 1.0);
        return vcAtlasUV(px);
    }

    vec4 vcWeatherOf(vec2 worldXZ, int band) {
        return textureLod(vc_weather_sampler,
                          vcWeatherBandUV(vcMapProject(worldXZ, cameraPosition.xz),
                                          band), 0.0);
    }

    vec4 vcWeather(vec2 worldXZ) {
        return vcWeatherOf(worldXZ, 0);
    }

    #if VC_PHYSICS == 1

        vec4 vcPhysicsAt(vec2 worldXZ) {
            vec2 uv = vcMapProject(worldXZ, cameraPosition.xz);
            vec2 px = vec2(float(VC_PHYS_X0), float(VC_PHYS_Y0)) + 0.5
                    + clamp(uv, 0.0, 1.0) * (float(VC_PHYS_RES) - 1.0);
            return textureLod(vc_weather_sampler, vcAtlasUV(px), 0.0);
        }
    #endif

    float vcMapFade(vec2 worldXZ) {
        vec2 uv = vcMapProject(worldXZ, cameraPosition.xz) * 2.0 - 1.0;
        return smoothstep(1.0, 0.9, length(uv));
    }
#endif

#endif
