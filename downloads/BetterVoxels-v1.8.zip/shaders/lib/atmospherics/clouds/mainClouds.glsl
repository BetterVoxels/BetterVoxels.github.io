
#define VC_MAIN_CLOUDS_IN 1
#include "/lib/colors/lightAndAmbientColors.glsl"
#include "/lib/colors/cloudColors.glsl"
#include "/lib/atmospherics/sky.glsl"
#include "/lib/atmospherics/fog/distantHaze.glsl"
#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

float InterleavedGradientNoiseForClouds() {
    float n = 52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y);
    #ifdef TAA
        return fract(n + goldenRatio * mod(float(frameCounter), 3600.0));
    #else
        return fract(n);
    #endif
}

#if SHADOW_QUALITY > -1
    vec3 GetShadowOnCloudPosition(vec3 tracePos, vec3 cameraPos) {
        vec3 wpos = PlayerToShadow(tracePos - cameraPos);
        float distb = sqrt(wpos.x * wpos.x + wpos.y * wpos.y);
        float distortFactor = 1.0 - shadowMapBias + distb * shadowMapBias;
        vec3 shadowPosition = vec3(vec2(wpos.xy / distortFactor), wpos.z * 0.2);
        return shadowPosition * 0.5 + 0.5;
    }

    bool GetShadowOnCloud(vec3 tracePos, vec3 cameraPos, int cloudAltitude, float lowerPlaneAltitude, float higherPlaneAltitude) {
        const float cloudShadowOffset = 0.5;

        vec3 shadowPosition0 = GetShadowOnCloudPosition(tracePos, cameraPos);
        if (length(shadowPosition0.xy * 2.0 - 1.0) < 1.0) {
            float shadowsample0 = shadow2D(shadowtex0, shadowPosition0).z;

            if (shadowsample0 == 0.0) return true;
        }

        return false;
    }
#endif

#ifdef CLOUDS_REIMAGINED
    #include "/lib/atmospherics/clouds/reimaginedClouds.glsl"
#endif
#ifdef CLOUDS_UNBOUND
    #include "/lib/atmospherics/clouds/unboundClouds.glsl"
#endif
#ifdef CLOUDS_UNBOUND_PLUS
    #include "/lib/atmospherics/clouds/unboundPlusClouds.glsl"
#endif
#ifdef CLOUDS_VOLUMETRIC
    #include "/lib/atmospherics/clouds/volumetricClouds.glsl"
#endif

vec4 GetClouds(inout float cloudLinearDepth, float skyFade, vec3 cameraPos, vec3 playerPos,
               float lViewPos, float VdotS, float VdotU, float dither, vec3 auroraBorealis, vec3 nightNebula) {
    vec4 clouds = vec4(0.0);

    vec3 nPlayerPos = normalize(playerPos);
    float lViewPosM = lViewPos < renderDistance * 1.5 ? lViewPos - 1.0 : 1000000000.0;
    float skyMult0 = pow2(skyFade * 3.333333 - 2.333333);

    float thresholdMix = pow2(clamp01(VdotU * 5.0));
    float thresholdF = mix(far, 1000.0, thresholdMix * 0.5 + 0.5);
    #ifdef LOD_ACTIVE
        thresholdF = max(thresholdF, renderDistance);
    #endif

    #ifdef CLOUDS_REIMAGINED
        cloudAmbientColor *= 1.0 - 0.25 * rainFactor;
    #endif

    vec3 cloudColorMult = vec3(1.0);
    #if CLOUD_R != 100 || CLOUD_G != 100 || CLOUD_B != 100
        cloudColorMult *= vec3(CLOUD_R, CLOUD_G, CLOUD_B) * 0.01;
    #endif
    cloudAmbientColor *= cloudColorMult;
    cloudLightColor *= cloudColorMult;

    #if CLOUD_LAYER2 != 1 || defined CLOUDS_UNBOUND_PLUS || defined CLOUDS_VOLUMETRIC
        clouds = GetVolumetricClouds(cloudAlt1i, thresholdF, cloudLinearDepth, skyFade, skyMult0,
                                        cameraPos, nPlayerPos, lViewPosM, VdotS, VdotU, dither);
    #else
        float bvDepth1 = cloudLinearDepth;
        vec4 bvDeck1 = GetVolumetricClouds(cloudAlt1i, thresholdF, bvDepth1, skyFade, skyMult0,
                                           cameraPos, nPlayerPos, lViewPosM, VdotS, VdotU, dither);

        float bvDepth2 = cloudLinearDepth;
        vec4 bvDeck2 = GetVolumetricClouds(cloudAlt2i, thresholdF, bvDepth2, skyFade, skyMult0,
                                           cameraPos, nPlayerPos, lViewPosM, VdotS, VdotU, dither);

        float bvRayY = abs(nPlayerPos.y) < 0.001 ? 0.001 : nPlayerPos.y;
        float bvT1 = (float(cloudAlt1i) - cameraPos.y) / bvRayY;
        float bvT2 = (float(cloudAlt2i) - cameraPos.y) / bvRayY;
        if (bvT1 < 0.0) bvT1 = 1000000000.0;
        if (bvT2 < 0.0) bvT2 = 1000000000.0;

        bool bvOneIsFront = bvT1 <= bvT2;
        vec4 bvFront = bvOneIsFront ? bvDeck1 : bvDeck2;
        vec4 bvBack = bvOneIsFront ? bvDeck2 : bvDeck1;
        float bvFrontDepth = bvOneIsFront ? bvDepth1 : bvDepth2;
        float bvBackDepth = bvOneIsFront ? bvDepth2 : bvDepth1;

        float bvAlpha = bvFront.a + (1.0 - bvFront.a) * bvBack.a;
        if (bvAlpha > 0.002) {
            clouds = vec4((bvFront.rgb * bvFront.a
                        + (1.0 - bvFront.a) * bvBack.rgb * bvBack.a) / bvAlpha, bvAlpha);
        }

        if (bvFront.a > 0.5) cloudLinearDepth = bvFrontDepth;
        else if (bvBack.a > 0.5) cloudLinearDepth = bvBackDepth;
    #endif

    #if defined CLOUDS_VOLUMETRIC && VC_GENUS_HIGH > 0

        {
            vec4 lowRep = vcReprojG;

            float highLinearDepth = 1.0;
            vcHighBandG = true;
            vcReprojG = vec4(0.0);
            vec4 high = GetVolumetricClouds(cloudAlt1i, thresholdF,
                                            highLinearDepth, skyFade, skyMult0,
                                            cameraPos, nPlayerPos, lViewPosM,
                                            VdotS, VdotU, dither);
            vec4 highRep = vcReprojG;
            vcHighBandG = false;

            float dLow  = lowRep.a  > 0.001 ? lowRep.r  / lowRep.a  : 1.0e9;
            float dHigh = highRep.a > 0.001 ? highRep.r / highRep.a : 1.0e9;
            bool lowFirst = dLow <= dHigh;

            vec4 nearC = lowFirst ? clouds : high;
            vec4 farC  = lowFirst ? high : clouds;

            float outA = nearC.a + farC.a * (1.0 - nearC.a);
            vec3 outRGB = (nearC.rgb * nearC.a
                         + farC.rgb * (farC.a * (1.0 - nearC.a)))
                        / max(outA, 1.0e-4);
            clouds = vec4(outRGB, outA);

            vec4 nearRep = lowFirst ? lowRep : highRep;
            vec4 farRep  = lowFirst ? highRep : lowRep;
            vcReprojG = nearRep + farRep * (1.0 - nearC.a);
        }
    #endif

    #ifdef CLOUDS_UNBOUND_PLUS
        clouds = bvuAddUpperDeck(clouds, cloudLinearDepth, thresholdF, skyFade, skyMult0,
                                 cameraPos, nPlayerPos, lViewPosM, VdotS, VdotU, dither);
    #endif

    #if VC_DEBUG == 0 || !defined CLOUDS_VOLUMETRIC
        #ifdef ATM_COLOR_MULTS
            clouds.rgb *= sqrtAtmColorMult;
        #endif
        #ifdef MOON_PHASE_INF_ATMOSPHERE
            clouds.rgb *= moonPhaseInfluence;
        #endif

        #if AURORA_STYLE > 0
            clouds.rgb += auroraBorealis * 0.1;
        #endif
        #ifdef NIGHT_NEBULA
            clouds.rgb += nightNebula * 0.2;
        #endif
    #endif

    #if CLOUD_HAZE == 1 && defined DISTANT_HAZE_ACTIVE
        if (clouds.a > 0.001) {
            float hzRayY = abs(nPlayerPos.y) < 0.001 ? 0.001 : nPlayerPos.y;
            float hzDist = max((float(cloudAlt1i) - cameraPos.y) / hzRayY, 0.0);
            #ifdef CLOUDS_VOLUMETRIC
                if (vcReprojG.a > 0.001) hzDist = vcReprojG.r / vcReprojG.a;
            #endif
            float hzAlpha = clouds.a;
            clouds.a *= GetCloudHazeFade(hzDist, nPlayerPos.y);
            if (hzAlpha >= 0.5 && clouds.a < 0.5) cloudLinearDepth = 1.0;
        }
    #endif

    return clouds;
}
