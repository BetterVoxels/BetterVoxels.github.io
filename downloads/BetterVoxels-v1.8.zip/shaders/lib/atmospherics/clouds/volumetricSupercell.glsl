#ifndef INCLUDE_VOLUMETRIC_SUPERCELL
#define INCLUDE_VOLUMETRIC_SUPERCELL

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricGenus.glsl"
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricWind.glsl"
#include "/lib/atmospherics/clouds/volumetricWeather.glsl"

#define CB_BASE_Y      256.0

#define CB_HEIGHT     2272.0

#define CB_R_BASE       0.52
#define CB_H_PEAK       0.55
#define CB_R_TOP        0.62

#define CB_ANVIL_MUL    2.60
#define CB_ANVIL_H      0.72
#define CB_SKIRT        0.22

#define CB_WARP_CELL   620.0
#define CB_WARP_AMP     0.30

#define CB_SOFT         0.55

#define CB_DS_BODY      0.82
#define CB_DS_ANVIL     0.55
#define CB_DS_SKIRT     0.62

#define CB_FLANK_SPREAD  1.20
#define CB_FLANK_H_LO    0.10
#define CB_FLANK_H_HI    0.70

#define CB_FLANK_D_LO   -0.35
#define CB_FLANK_D_HI    0.55
#define CB_FLANK_ASPECT  1.70

#define CB_CELL_TOP_F   0.60
#define CB_FRINGE_CELL 38.0
#define CB_FRINGE_STR   0.30

#define CB_SHAFT        0

float vcCbDampen(float x) {
    x = clamp(x, 0.0, 1.0);
    return x * (2.0 - x);
}

vec2 vcCbCentreG;

void vcCbPrep(vec3 cameraPos, float t) {
    float sp = float(VC_CB_SPACING);
    vec2 drift = vcWindVector() * (t * (VC_WIND_SPEED * 0.1));
    vec2 cw = cameraPos.xz - drift;
    vec2 sc = floor(cw / sp);

    vec2 best = vec2(0.0);
    float bd = 1e9;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            vec2 c = sc + vec2(float(dx), float(dy));
            vec2 pos = (c + 0.25 + 0.5 * vcHash33(vec3(c, vcStormSeed())).xy) * sp;
            float dd = dot(cw - pos, cw - pos);
            if (dd < bd) { bd = dd; best = pos; }
        }
    }
    vcCbCentreG = best + drift;
}

vec2 vcCbAxis(float h) {
    return vcWindVector() * (VC_CB_TILT * 0.01 * CB_HEIGHT * h * h);
}

float vcCbSmooth(float a, float b, float x) {
    float s = vcLinearStep(a, b, x);
    return s * s * (3.0 - 2.0 * s);
}

float vcCbSilhouette(float h) {
    float body = CB_R_BASE
               + (1.0 - CB_R_BASE) * vcCbSmooth(0.0, CB_H_PEAK, h)
               - (1.0 - CB_R_TOP)  * vcCbSmooth(CB_H_PEAK, 1.0, h);

    float skirt = CB_SKIRT * (1.0 - vcLinearStep(0.0, 0.16, h));

    float anv = vcLinearStep(CB_ANVIL_H, CB_ANVIL_H + 0.12, h)
              * (1.0 - vcLinearStep(0.92, 1.00, h));
    anv *= (VC_CB_ANVIL * 0.01) * (CB_ANVIL_MUL - 1.0);

    return float(VC_CB_RADIUS) * max(body + skirt + anv, 0.0);
}

float vcCbFlanks(vec2 cbD, float cbH, float worldY) {
    float best = 0.0;
#if VC_CB_FLANKS > 0
    vec2 up = -vcWindVector();
    float upAng = atan(up.y, up.x);

    for (int i = 0; i < VC_CB_FLANKS; i++) {
        vec3 fh3 = vcHash33(vec3(float(i) * 7.13 + 0.5, vcStormSeed(), 3.7));

        float fH = mix(CB_FLANK_H_LO, CB_FLANK_H_HI, fh3.x);
        float fA = upAng + (fh3.y - 0.5) * (2.0 * CB_FLANK_SPREAD);

        float fS = fract(fh3.x * 7.0 + fh3.z * 13.0);
        float fR = float(VC_CB_RADIUS) * (VC_CB_FLANK_SIZE * 0.01)
                 * mix(0.55, 1.0, fS);

        float fD = vcCbSilhouette(fH)
                 + fR * mix(CB_FLANK_D_LO, CB_FLANK_D_HI, fh3.z);

        vec2 fC = vec2(cos(fA), sin(fA)) * fD + (vcCbAxis(fH) - vcCbAxis(cbH));
        vec2 fXZ = cbD - fC;
        float fY = (worldY - (CB_BASE_Y + fH * CB_HEIGHT)) / CB_FLANK_ASPECT;

        float fDist = length(vec3(fXZ.x, fY, fXZ.y)) / max(fR, 1.0);
        best = max(best, 1.0 - vcLinearStep(CB_SOFT, 1.0, fDist));
    }

    best *= vcLinearStep(0.0, 0.025, cbH);
#endif
    return best;
}

float vcCbDensityScale(float cbR, float cbH, float nz) {
    float core = (1.0 - vcLinearStep(0.0, 0.72, cbR))
               * vcCbSmooth(0.02, 0.35, cbH) * (1.0 - vcCbSmooth(0.62, 0.95, cbH));

    float ice   = vcLinearStep(CB_ANVIL_H - 0.06, 0.96, cbH);
    float scud  = 1.0 - vcLinearStep(0.015, 0.11, cbH);

    float scale = mix(CB_DS_BODY, 1.0, core);
    scale = mix(scale, CB_DS_ANVIL, ice);
    scale = mix(scale, CB_DS_SKIRT, scud);

    float v = (nz - 0.699) * (VC_CB_VARIANCE * 0.02);
    return clamp(scale + v, 0.05, 1.0);
}

float vcSupercellDensity(vec3 worldPos, float t, bool cheap) {
    float cbH = (worldPos.y - CB_BASE_Y) / CB_HEIGHT;
    if (cbH < 0.0 || cbH > 1.0) return 0.0;

    vec2 cbC = vcCbCentreG;

    vec2 cbD = worldPos.xz - (cbC + vcCbAxis(cbH));

    vec3 cbWq = vec3(worldPos.xz, cbH * CB_HEIGHT * 0.5)
              * (1.0 / (4.0 * CB_WARP_CELL));
    vec4 cbN0 = vcShape(cbWq);
    vec4 cbN1 = vcShape(cbWq + vec3(0.37, 0.61, 0.13));
    cbD += (vec2(cbN0.r, cbN1.r) - 0.5)
         * (2.0 * CB_WARP_AMP * float(VC_CB_RADIUS));

    float cbR = length(cbD) / vcCbSilhouette(cbH);

    float cbFlank = vcCbFlanks(cbD, cbH, worldPos.y);

    if (cbR > 1.02 && cbFlank <= 0.001) return 0.0;

    float cbEnv = 1.0 - vcLinearStep(CB_SOFT, 1.0, cbR);

    float cbProf = vcLinearStep(0.0, 0.025, cbH)
                 * (1.0 - vcLinearStep(0.86, 1.00, cbH));

    float cbScale = vcCbDensityScale(cbR, cbH, (cbN0.g + cbN1.g) * 0.5);

    float cbDen = max(cbEnv * cbProf, cbFlank);
    if (cbDen <= 0.001) return 0.0;

    if (cheap) return cbDen * cbScale;

    float cbAng = (VC_CB_SWIRL * 0.01) * (1.0 - cbH);
    float cbCs = cos(cbAng);
    float cbSn = sin(cbAng);
    vec3 cbQ = vec3(cbD.x * cbCs - cbD.y * cbSn,
                    worldPos.y,
                    cbD.x * cbSn + cbD.y * cbCs);

    float cbCell = mix(float(VC_CB_CELL), float(VC_CB_CELL) * CB_CELL_TOP_F,
                       vcLinearStep(0.30, 0.95, cbH));
    float cbBil = vcShape(cbQ * (1.0 / (16.0 * cbCell))).b;

    cbDen = vcRemap(cbDen,
                    cbBil * (VC_CB_TURRET * 0.01) * vcCbDampen(1.0 - cbDen),
                    1.0, 0.0, 1.0);
    if (cbDen <= 0.001) return 0.0;

    float cbFrg = vcDetail(cbQ * (1.0 / (8.0 * CB_FRINGE_CELL))).b;
    float cbFrgW = CB_FRINGE_STR * vcCbDampen(1.0 - cbDen) * (0.45 + 0.55 * cbH);
    cbDen = vcRemap(cbDen, cbFrg * cbFrgW, 1.0, 0.0, 1.0);

    float cbPs = pow(clamp(cbScale, 0.0, 1.0), 4.0);
    cbDen *= cbPs;
    cbDen = pow(cbDen, mix(0.3, 0.6, max(1e-5, cbPs)));

    return clamp(cbDen, 0.0, 1.0);
}

bool vcCbCylinder(vec3 cameraPos, vec3 rd, inout float tNear, inout float tFar) {
    vec2 cbC = vcCbCentreG;

    float cbAnv = (VC_CB_ANVIL * 0.01) * (CB_ANVIL_MUL - 1.0);
    float cbFl  = 0.0;
    #if VC_CB_FLANKS > 0
        cbFl = 1.0 + (1.0 + CB_FLANK_D_HI) * (VC_CB_FLANK_SIZE * 0.01);
    #endif

    float cbMaxS = max(max(1.0 + cbAnv, CB_R_BASE + CB_SKIRT) * 1.02, cbFl)
                 + 2.0 * CB_WARP_AMP;

    float cbRm = float(VC_CB_RADIUS) * cbMaxS + VC_CB_TILT * 0.01 * CB_HEIGHT;

    vec2 cbOc = cameraPos.xz - cbC;
    float cbA = dot(rd.xz, rd.xz);
    if (cbA < 1e-9) return dot(cbOc, cbOc) <= cbRm * cbRm;

    float cbB = dot(cbOc, rd.xz);
    float cbCc = dot(cbOc, cbOc) - cbRm * cbRm;
    float cbDisc = cbB * cbB - cbA * cbCc;
    if (cbDisc < 0.0) return false;

    float cbSq = sqrt(cbDisc);
    tNear = max(tNear, max((-cbB - cbSq) / cbA, 0.0));
    tFar  = min(tFar,  (-cbB + cbSq) / cbA);
    return tFar > tNear;
}

#endif
