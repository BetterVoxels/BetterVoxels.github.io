
#ifndef INCLUDE_VOLUMETRIC_WIND
#define INCLUDE_VOLUMETRIC_WIND

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

ivec2 vcWindAxis() {
    #if VC_WIND_DIR == 0
        return ivec2(1, 0);
    #elif VC_WIND_DIR == 45
        return ivec2(1, 1);
    #elif VC_WIND_DIR == 90
        return ivec2(0, 1);
    #elif VC_WIND_DIR == 135
        return ivec2(-1, 1);
    #elif VC_WIND_DIR == 180
        return ivec2(-1, 0);
    #elif VC_WIND_DIR == 225
        return ivec2(-1, -1);
    #elif VC_WIND_DIR == 270
        return ivec2(0, -1);
    #else
        return ivec2(1, -1);
    #endif
}

vec2 vcWindVector() {
    return normalize(vec2(vcWindAxis()));
}

vec3 vcWindVelocity() {
    vec2 w = vcWindVector() * (VC_WIND_SPEED * 0.1);
    return vec3(w.x, 0.0, w.y);
}

#define VC_H_WIND 2.5

vec2 vcHighWindVector() {
    float a = radians(float(VC_H_WIND_TURN));
    vec2 w = vcWindVector();
    return vec2(w.x * cos(a) - w.y * sin(a), w.x * sin(a) + w.y * cos(a));
}

vec3 vcHighWindVelocity() {
    vec2 w = vcHighWindVector() * (VC_WIND_SPEED * 0.1 * VC_H_WIND);
    return vec3(w.x, 0.0, w.y);
}

#endif
