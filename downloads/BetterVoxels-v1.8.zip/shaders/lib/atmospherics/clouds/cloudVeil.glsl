#ifndef INCLUDE_CLOUD_VEIL
#define INCLUDE_CLOUD_VEIL

#ifdef CLOUDS_VOLUMETRIC
    #include "/lib/atmospherics/clouds/volumetricGenus.glsl"
#endif

uniform sampler2D colortex15;

vec4 GetCloudVeil(ivec2 px, float surfaceY) {
    #ifdef CLOUDS_VOLUMETRIC
        float veilBase = float(VC_G_ALT);
    #else
        float veilBase = float(min(cloudAlt1i, cloudAlt2i));
    #endif

    if ((cameraPosition.y - veilBase) * (surfaceY - veilBase) >= 0.0) return vec4(0.0);

    vec4 veil = texelFetch(colortex15, px, 0);
    return vec4(max(veil.rgb, vec3(0.0)), clamp(veil.a, 0.0, 1.0));
}

#endif
