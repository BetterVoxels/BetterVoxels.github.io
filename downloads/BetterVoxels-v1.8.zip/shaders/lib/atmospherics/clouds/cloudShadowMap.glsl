#ifndef INCLUDE_CLOUD_SHADOW_MAP
#define INCLUDE_CLOUD_SHADOW_MAP

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricGenus.glsl"

#define VC_CSM_RES    512
#define VC_CSM_TEXEL  4.0

#define VC_CSM_X0     1152
#define VC_CSM_ATLAS_W 1664
#define VC_CSM_STEPS  8

#define VC_FSM_RES    240
#define VC_FSM_TEXEL  32.0
#define VC_FSM_X0     1152
#define VC_FSM_Y0     776

#define VC_CSM_ALT    float(VC_G_ALT)
#define VC_CSM_THICK  VC_G_THICK

vec3 vcCsmLightDir() {
    #ifdef BV_DAILY_SUN
        float vcPathDeg = sunPathRotation + bvDailySunOffset();
    #else
        float vcPathDeg = sunPathRotation;
    #endif
    vec2 rot = vec2(cos(vcPathDeg * 0.01745329251994), -sin(vcPathDeg * 0.01745329251994));
    float ang = fract(timeAngle - 0.25);
    ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
    vec3 s = normalize(vec3(-sin(ang), cos(ang) * rot));

    if (!(timeAngle < 0.5325 || timeAngle > 0.9675)) s = -s;
    if (s.y < 0.1) {
        vec2 hz = normalize(s.xz + vec2(1e-6)) * 0.99499;
        s = vec3(hz.x, 0.1, hz.y);
    }
    return s;
}

vec2 vcCsmOrigin() {
    return floor(cameraPosition.xz / VC_CSM_TEXEL) * VC_CSM_TEXEL;
}

vec2 vcCsmTexel(vec2 worldXZ) {
    return (worldXZ - vcCsmOrigin()) / VC_CSM_TEXEL + 0.5 * float(VC_CSM_RES);
}

vec2 vcCsmWorld(ivec2 id) {
    return vcCsmOrigin() + (vec2(id) + 0.5 - 0.5 * float(VC_CSM_RES)) * VC_CSM_TEXEL;
}

#ifdef VC_FAR_SHADOW_MAP
vec2 vcFsmOrigin() {
    return floor(cameraPosition.xz / VC_FSM_TEXEL) * VC_FSM_TEXEL;
}

vec2 vcFsmTexel(vec2 worldXZ) {
    return (worldXZ - vcFsmOrigin()) / VC_FSM_TEXEL + 0.5 * float(VC_FSM_RES);
}

vec2 vcFsmWorld(ivec2 id) {
    return vcFsmOrigin() + (vec2(id) + 0.5 - 0.5 * float(VC_FSM_RES)) * VC_FSM_TEXEL;
}
#endif

float vcCsmBaseY(vec2 worldXZ) {
    vec2 d = worldXZ - cameraPosition.xz;
    return VC_CSM_ALT - dot(d, d) * (0.5 / VC_RADIUS);
}

#ifndef VC_NOISE_WRITER
    #ifndef VC_WEATHER_SAMPLER_DECL
        #define VC_WEATHER_SAMPLER_DECL
        #ifndef VOXY_PATCH
            uniform sampler2D vc_weather_sampler;
        #endif
    #endif

    float vcCloudShadowAt(vec3 worldPos) {
        vec3 L = vcCsmLightDir();

        float dy = max(VC_CSM_ALT - worldPos.y, 0.0);
        vec2 q = worldPos.xz + L.xz * (dy / L.y);
        dy = max(vcCsmBaseY(q) - worldPos.y, 0.0);
        q = worldPos.xz + L.xz * (dy / L.y);

        vec2 tc = vcCsmTexel(q);
        vec2 atlas = vec2(float(VC_CSM_ATLAS_W), float(VC_WEATHER_RES * VC_WEATHER_BANDS));

        float pr = clamp(dy * 0.05, 2.0, 16.0) / VC_CSM_TEXEL;
        vec2 lo = vec2(0.5);
        vec2 hi = vec2(float(VC_CSM_RES) - 0.5);
        vec2 base = vec2(float(VC_CSM_X0), 0.0);
        vec4 s = textureLod(vc_weather_sampler, (base + clamp(tc, lo, hi)) / atlas, 0.0);
        float sh = s.r * 2.0;
        sh += textureLod(vc_weather_sampler, (base + clamp(tc + vec2( pr, 0.0), lo, hi)) / atlas, 0.0).r;
        sh += textureLod(vc_weather_sampler, (base + clamp(tc + vec2(-pr, 0.0), lo, hi)) / atlas, 0.0).r;
        sh += textureLod(vc_weather_sampler, (base + clamp(tc + vec2(0.0,  pr), lo, hi)) / atlas, 0.0).r;
        sh += textureLod(vc_weather_sampler, (base + clamp(tc + vec2(0.0, -pr), lo, hi)) / atlas, 0.0).r;
        sh *= 1.0 / 6.0;

        vec2 e = abs(tc * (2.0 / float(VC_CSM_RES)) - 1.0);
        float inMap = smoothstep(1.0, 0.86, max(e.x, e.y)) * s.a;
        #ifdef VC_FAR_SHADOW_MAP

            if (inMap < 0.999) {
                vec2 ftc = vcFsmTexel(q);
                vec2 fhi = vec2(float(VC_FSM_RES) - 0.5);
                vec4 fs = textureLod(vc_weather_sampler,
                                     (vec2(float(VC_FSM_X0), float(VC_FSM_Y0)) + clamp(ftc, lo, fhi)) / atlas, 0.0);
                vec2 fe = abs(ftc * (2.0 / float(VC_FSM_RES)) - 1.0);
                float farIn = smoothstep(1.0, 0.9, max(fe.x, fe.y)) * fs.a;
                return mix(mix(1.0, fs.r, farIn), sh, inMap);
            }
        #endif
        return mix(1.0, sh, inMap);
    }

    float vcCloudCoverAt(vec2 worldXZ) {
        vec2 tc = vcCsmTexel(worldXZ);
        vec2 c = clamp(tc, vec2(0.5), vec2(float(VC_CSM_RES) - 0.5));
        vec2 atlas = vec2(float(VC_CSM_ATLAS_W), float(VC_WEATHER_RES * VC_WEATHER_BANDS));
        vec4 s = textureLod(vc_weather_sampler, (vec2(float(VC_CSM_X0), 0.0) + c) / atlas, 0.0);
        return (1.0 - s.r) * s.a;
    }

    float vcSkyCover() {
        vec4 s = texelFetch(vc_weather_sampler, ivec2(VC_CSM_X0, VC_CSM_RES), 0);
        return s.r * s.a;
    }
#endif

#endif
