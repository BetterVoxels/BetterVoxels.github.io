
#ifndef INCLUDE_VOLUMETRIC_NOISE
#define INCLUDE_VOLUMETRIC_NOISE

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

#define VC_SHAPE_RES 128
#define VC_DETAIL_RES 32
#define VC_CURL_RES 128

#define VC_CURL_IMG_H 192

#define VC_CURL_X0    VC_WEATHER_RES

#define VC_ATLAS_W    (VC_WEATHER_RES + VC_CURL_RES + 512)
#define VC_ATLAS_H    (VC_WEATHER_RES * VC_WEATHER_BANDS)
#define VC_DETAIL_X0  VC_SHAPE_RES
#define VC_VOL_W      (VC_SHAPE_RES + VC_DETAIL_RES)

#if VC_WEATHER_RES + VC_CURL_RES != 1152
    #error "the weather atlas moved - VC_CSM_X0 and VC_CSM_ATLAS_W in cloudShadowMap.glsl are spelled out and no longer match"
#endif

#if VC_WEATHER_RES * VC_WEATHER_BANDS < VC_CURL_IMG_H
    #error "the weather atlas is shorter than the curl strip it carries"
#endif

float vcRemap(float v, float oMin, float oMax, float nMin, float nMax) {
    return nMin + (((v - oMin) / (oMax - oMin)) * (nMax - nMin));
}

float vcLinearStep(float e0, float e1, float x) {
    return clamp((x - e0) / (e1 - e0), 0.0, 1.0);
}

vec3 vcHash33(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

float vcWorley(vec3 p, float cells) {
    vec3 pc = p * cells;
    vec3 ic = floor(pc);
    vec3 fc = pc - ic;

    float best = 1.0e9;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
                vec3 o = vec3(float(x), float(y), float(z));
                vec3 cell = mod(ic + o, vec3(cells));
                vec3 d = o + vcHash33(cell) - fc;
                best = min(best, dot(d, d));
            }
        }
    }

    return clamp(1.0 - best, 0.0, 1.0);
}

float vcGradDot(vec3 cell, float period, vec3 d) {
    vec3 g = vcHash33(mod(cell, vec3(period))) * 2.0 - 1.0;
    return dot(g, d);
}

float vcPerlin(vec3 p, float freq) {
    vec3 pp = p * freq;
    vec3 i = floor(pp);
    vec3 f = pp - i;
    vec3 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

    float n000 = vcGradDot(i + vec3(0.0, 0.0, 0.0), freq, f - vec3(0.0, 0.0, 0.0));
    float n100 = vcGradDot(i + vec3(1.0, 0.0, 0.0), freq, f - vec3(1.0, 0.0, 0.0));
    float n010 = vcGradDot(i + vec3(0.0, 1.0, 0.0), freq, f - vec3(0.0, 1.0, 0.0));
    float n110 = vcGradDot(i + vec3(1.0, 1.0, 0.0), freq, f - vec3(1.0, 1.0, 0.0));
    float n001 = vcGradDot(i + vec3(0.0, 0.0, 1.0), freq, f - vec3(0.0, 0.0, 1.0));
    float n101 = vcGradDot(i + vec3(1.0, 0.0, 1.0), freq, f - vec3(1.0, 0.0, 1.0));
    float n011 = vcGradDot(i + vec3(0.0, 1.0, 1.0), freq, f - vec3(0.0, 1.0, 1.0));
    float n111 = vcGradDot(i + vec3(1.0, 1.0, 1.0), freq, f - vec3(1.0, 1.0, 1.0));

    float x00 = mix(n000, n100, u.x);
    float x10 = mix(n010, n110, u.x);
    float x01 = mix(n001, n101, u.x);
    float x11 = mix(n011, n111, u.x);
    float y0 = mix(x00, x10, u.y);
    float y1 = mix(x01, x11, u.y);
    return mix(y0, y1, u.z);
}

float vcPerlinFbm(vec3 p, float freq, int octaves) {
    float sum = 0.0;
    float norm = 0.0;
    float amp = 1.0;
    for (int i = 0; i < octaves; i++) {
        sum += vcPerlin(p, freq) * amp;
        norm += amp;
        freq *= 2.0;
        amp *= 0.5;
    }

    return clamp(sum / norm * 3.4 * 0.5 + 0.5, 0.0, 1.0);
}

float vcPerlinFbmH(vec3 p, float freq, int octaves) {
    float sum = 0.0;
    float weightSum = 0.0;
    float weight = 0.5;
    for (int i = 0; i < octaves; i++) {
        sum += vcPerlin(p, freq) * weight;
        weightSum += weight;
        weight *= weight;
        freq *= 2.0;
    }

    return clamp(sum / weightSum * 1.954 * 0.5 + 0.5, 0.0, 1.0);
}

float vcPerlinWorleyH(vec3 p, float cellCount) {
    float perlin = vcPerlinFbmH(p, 8.0, 3);
    float worley = vcWorley(p, cellCount * 2.0) * 0.625
                 + vcWorley(p, cellCount * 8.0) * 0.25
                 + vcWorley(p, cellCount * 14.0) * 0.125;
    return clamp(vcRemap(perlin, 0.0, 1.0, worley, 1.0), 0.0, 1.0);
}

#define VC_CURL_GAIN 7.29

vec2 vcCurl(vec2 p, float freq) {
    float e = 1.0 / float(VC_CURL_RES);
    float ny1 = vcPerlinFbm(vec3(p + vec2(0.0, e), 0.5), freq, 3);
    float ny0 = vcPerlinFbm(vec3(p - vec2(0.0, e), 0.5), freq, 3);
    float nx1 = vcPerlinFbm(vec3(p + vec2(e, 0.0), 0.5), freq, 3);
    float nx0 = vcPerlinFbm(vec3(p - vec2(e, 0.0), 0.5), freq, 3);
    vec2 c = vec2(ny1 - ny0, -(nx1 - nx0));

    return clamp(c * VC_CURL_GAIN, vec2(-1.0), vec2(1.0));
}

float vcFold(float n, float power) {
    return pow(abs(abs(n * 2.0 - 1.0) * 2.0 - 1.0), power);
}

vec3 vcGenCoord(ivec3 id, float res) {
    return vec3(id) / (res - 1.0);
}

vec3 vcWrap3(vec3 p, float res) {
    return (fract(p) * (res - 1.0) + 0.5) / res;
}

vec2 vcWrap2(vec2 p, float res) {
    return (fract(p) * (res - 1.0) + 0.5) / res;
}

#ifndef VC_NOISE_WRITER
    uniform sampler3D vc_shape_sampler;

    #ifndef VC_WEATHER_SAMPLER_DECL
        #define VC_WEATHER_SAMPLER_DECL
        #ifndef VOXY_PATCH
            uniform sampler2D vc_weather_sampler;
        #endif
    #endif

    vec3 vcVolCoord(vec3 p, float res, float x0) {
        return (vec3(x0, 0.0, 0.0) + fract(p) * (res - 1.0) + 0.5)
             / vec3(float(VC_VOL_W), float(VC_SHAPE_RES), float(VC_SHAPE_RES));
    }

    vec4 vcShape(vec3 p) {
        return textureLod(vc_shape_sampler,
                          vcVolCoord(p, float(VC_SHAPE_RES), 0.0), 0.0);
    }

    vec4 vcDetail(vec3 p) {
        return textureLod(vc_shape_sampler,
                          vcVolCoord(p, float(VC_DETAIL_RES), float(VC_DETAIL_X0)), 0.0);
    }

    vec2 vcAtlasUV(vec2 px) {
        return px / vec2(float(VC_ATLAS_W), float(VC_ATLAS_H));
    }

    float vcProfile(float type, float h) {
        vec2 c = clamp(vec2(type, h), 0.0, 1.0) * 31.0 + 0.5;
        return textureLod(vc_weather_sampler,
                          vcAtlasUV(c + vec2(float(VC_CURL_X0), 0.0)), 0.0).b;
    }

    float vcProfileBottom(float type, float h) {
        vec2 c = clamp(vec2(type, h), 0.0, 1.0) * 31.0 + 0.5;
        return textureLod(vc_weather_sampler,
                          vcAtlasUV(c + vec2(float(VC_CURL_X0), 0.0)), 0.0).a;
    }

    vec2 vcCurlRead(vec2 p) {
        vec2 px = vec2(float(VC_CURL_X0), 0.0)
                + fract(p) * (float(VC_CURL_RES) - 1.0) + 0.5;
        return textureLod(vc_weather_sampler, vcAtlasUV(px), 0.0).rg * 2.0 - 1.0;
    }
#endif

#endif
