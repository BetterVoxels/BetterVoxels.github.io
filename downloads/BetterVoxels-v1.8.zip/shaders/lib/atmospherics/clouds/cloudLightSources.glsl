#ifndef INCLUDE_CLOUD_LIGHT_SOURCES
#define INCLUDE_CLOUD_LIGHT_SOURCES

#include "/lib/misc/bvStateImage.glsl"

#define BV_BEAM_SLOTS     8
#define BV_BEAM_REP_X     8
#define BV_BEAM_FLAG      ivec2(24, 0)
#define BV_BEAM_STATE_X   32
#define BV_BEAM_SEG_X     8
#define BV_BEAM_SEG_N     384
#define BV_BEAM_REPA_ROW  1
#define BV_BEAM_REPB_ROW  9
#define BV_BEAM_STA_ROW   17
#define BV_BEAM_STB_ROW   25

int bvBeamHash(ivec2 cell) {
    return (cell.x * 73856093) ^ (cell.y * 19349663);
}
int bvBeamSlot(ivec2 cell) {
    return bvBeamHash(cell) & 7;
}
float bvBeamKey(ivec2 cell) {
    return float(((bvBeamHash(cell) >> 3) & 2047) + 1);
}

#include "/lib/misc/easeCurves.glsl"

#ifdef VC_BEAM_TINT
    vec3 bvBeamGlowColor(vec3 bc) {
        float lum = max(bc.r, max(bc.g, bc.b));
        vec3 c = mix(vec3(lum), bc, VC_BEAM_TINT * 0.01) * vec3(0.90, 0.96, 1.0);

        return c * smoothstep(0.15, 0.30, lum);
    }
#endif

float bvBeamDuration() {
    return max(BSR_TIME_IN + BSR_TIME_OUT, 0.05);
}
float bvBeamEase(float age) {
    float tIn = max(BSR_TIME_IN, 0.0);
    float tOut = max(BSR_TIME_OUT, 0.0);
    float p = age < tIn ? (tIn > 0.0001 ? 0.5 * age / tIn : 0.5)
                        : (tOut > 0.0001 ? 0.5 + 0.5 * (age - tIn) / tOut : 1.0);
    return bvEaseCurve(clamp(p, 0.0, 1.0), BSR_CURVE);
}

float bvBeamFront(float age, float yBase) {
    if (age >= bvBeamDuration()) return 1.0e6;
    return yBase + bvBeamEase(age) * float(BSR_REACH);
}

#if SMOOTH_BEACON_RAY == 1

    void BvBeamFragment(vec3 wp, inout vec3 col, inout float alpha, inout float boost) {
        ivec2 cell = ivec2(floor(wp.xz));
        int s = bvBeamSlot(cell);
        vec4 st0 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * s, 0), 0);
        if (abs(st0.x - bvBeamKey(cell)) > 0.5) {
            if (st0.x < 0.5 || st0.z > 0.1) alpha = 0.0;
            return;
        }

        if (st0.z > 1.0) {
            alpha = 0.0;
            return;
        }
        vec4 st1 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * s + 1, 0), 0);
        vec4 st2 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * s + 2, 0), 0);
        vec4 st3 = texelFetch(bv_state_sampler, ivec2(BV_BEAM_STATE_X + 4 * s + 3, 0), 0);
        float g = float(BSR_GRADIENT);

        {
            int ix = int(floor(wp.y)) + 64;
            if (ix >= 0 && ix < BV_BEAM_SEG_N) {
                vec4 a = texelFetch(bv_state_sampler, ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_STA_ROW + s), 0);
                vec4 b = texelFetch(bv_state_sampler, ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_STB_ROW + s), 0);
                if (a.a > 0.5 && b.a > 0.5) {
                    vec3 up = st3.x > 0.5 ? b.rgb : a.rgb;
                    vec3 dn = st3.x > 0.5 ? a.rgb : b.rgb;
                    col = mix(dn, up, smoothstep(0.0, 1.0, fract(wp.y)));
                }
            }
        }

        float h = st0.w + 1.0;
        float sweep = bvBeamFront(st1.a, h);

        if (sweep > 1.0e5 && wp.y > st0.w + 1.0 && distance(col, st1.rgb) > 0.02) col = st1.rgb;
        if (sweep < 1.0e5) {
            float band = max(g, 1.0);
            col = mix(col, st2.rgb, smoothstep(sweep - 0.5 * band, sweep + 0.5 * band, wp.y));
        }

        float front = bvBeamFront(st0.y, st2.a);
        if (front < 1.0e5) {
            alpha *= 1.0 - smoothstep(front - 4.0, front, wp.y);
            boost *= 1.0 + 2.0 * exp(-max(front - wp.y, 0.0) * 0.25);
        }

        #if BSR_BLOOM == 1

            boost *= 1.0 + (BSR_BLOOM_STRENGTH * 0.01) * exp(-st0.y / BSR_BLOOM_DECAY);
        #endif
    }
#endif

#endif
