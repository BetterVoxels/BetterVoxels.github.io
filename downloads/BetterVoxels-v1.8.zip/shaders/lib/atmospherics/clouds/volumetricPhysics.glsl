#ifndef INCLUDE_VOLUMETRIC_PHYSICS
#define INCLUDE_VOLUMETRIC_PHYSICS

#include "/lib/atmospherics/clouds/volumetricBiomeClimate.glsl"

#define VC_PHYS_X0  1152
#define VC_PHYS_Y0  520
#define VC_PHYS_RES 256

#define VC_PHYS2_X0 1408

float vcPhField(vec2 worldXZ, float k) {
    vec2 p = worldXZ * (float(VC_PH_FIELD_FREQ) / float(VC_DOMAIN));
    float s0 = vcWeatherSeed();
    vec2 w = vcDayBlend();
    float v = vcValue2(p, s0 * 0.061 + k);
    if (w.y > 0.0001) {
        float vb = vcValue2(p, (s0 + 1.0) * 0.061 + k);
        v = 0.5 + (v - 0.5) * w.x + (vb - 0.5) * w.y;
    }
    return clamp((v - 0.095) / 0.808, 0.0, 1.0);
}

float vcPhDayHash(float d, float k) {
    return fract(sin(mod(d, 997.0) * 12.9898 + k * 78.233) * 43758.5453);
}
float vcPhDayValue(float k) {
    float dayF = (float(worldDay) * 24000.0 + float(worldTime) + 6000.0) / 24000.0;
    float d = floor(dayF);
    return mix(vcPhDayHash(d - 1.0, k), vcPhDayHash(d, k), smoothstep(0.0, 0.2, dayF - d));
}

float vcPhysCoverage() {
    float u = 1.0 - pow(1.0 - vcPhDayValue(3.7), 1.6);
    return mix(float(VC_PH_DAY_COV_MIN), float(VC_PH_DAY_COV_MAX), u) * 0.01;
}

vec4 vcPhysicsColumn(vec2 worldXZ, float presX, out float cov, out float highAmt) {
    #if SMOOTH_TIME_ACTIVE >= 2
        float hour = mod(SmoothTimeVisualSunAngle() * 24.0 + 6.0, 24.0);
    #else
        float hour = mod(float(worldTime) * 0.001 + 6.0, 24.0);
    #endif
    float dayCurve = cos(6.2831853 * (hour - float(VC_PH_PEAK_HOUR)) / 24.0);
    float solar = max(cos(6.2831853 * (hour - 12.0) / 24.0), 0.0);

    float fT = vcPhField(worldXZ, 0.11);
    float fH = vcPhField(worldXZ, 0.47);
    float fL = vcPhField(worldXZ, 0.83);
    float fU = vcPhField(worldXZ, 0.29);
    float hiP = clamp(0.5 + presX, 0.0, 1.0);

    #if VC_PH_BIOMES == 1
        vec4 bmC = vcBiomeClimate();
        float bmW = 1.0 - smoothstep(float(VC_PH_BIOME_RANGE), 3.0 * float(VC_PH_BIOME_RANGE),
                                     length(worldXZ - cameraPosition.xz));
    #else
        const vec4 bmC = vec4(0.0, 0.0, 1.0, 0.0);
        const float bmW = 0.0;
    #endif

    float tMean = float(VC_PH_T_MEAN) + (fT - 0.5) * 2.0 * float(VC_PH_T_VAR) + bmC.x * bmW;

    float rhMean = clamp(float(VC_PH_HUMIDITY) + (fH - 0.5) * 2.0 * float(VC_PH_HUM_VAR)
                         - presX * float(VC_PH_SYNOPTIC_HUM)
                         + (vcPhDayValue(8.1) - 0.5) * 2.0 * float(VC_PH_DAY_HUM)
                         + bmC.y * bmW

                         + bmC.w * bmW * clamp(tMean / 25.0, 0.0, 1.5)
                           * (hour < 7.0 ? 0.5 - 0.5 * smoothstep(0.0, 7.0, hour)
                                         : smoothstep(7.0, 15.0, hour) * (1.0 - 0.5 * smoothstep(18.0, 24.0, hour))),
                         5.0, 100.0);
    float td = tMean - (100.0 - rhMean) * 0.2;
    float temp = tMean + float(VC_PH_T_DAY) * mix(1.0, bmC.z, bmW) * dayCurve;
    float spread = max(temp - td, 0.0);
    float rhNow = clamp(100.0 - 5.0 * spread, 0.0, 100.0);
    float lcl = 0.125 * spread;

    float lapse = (float(VC_PH_LAPSE) + (fL - 0.5) * 2.0 * float(VC_PH_LAPSE_VAR)) * 0.1
                - presX * 0.6;
    float zi = float(VC_PH_INV_HEIGHT) * 0.001;
    float invK = float(VC_PH_INVERSION) * 0.01 * 6.0 * mix(0.25, 1.0, hiP);

    float mixedBL = smoothstep(7.5, 10.5, hour) * (1.0 - smoothstep(17.0, 19.0, hour));
    float thermal = float(VC_PH_THERMAL) * 0.1 * solar;
    float lapseBL = mix(lapse, 9.8, 0.95 * mixedBL);

    float lift = smoothstep(0.05, 0.4, -presX) * float(VC_PH_LIFT) * 0.01;
    float excess = thermal + 2.5 * lift - (9.8 - lapseBL) * lcl;
    float trig = smoothstep(0.0, 0.8, excess);

    float b = lapse - 6.0 - float(VC_PH_ENTRAIN) * 0.1;
    float maxDepth = float(VC_PH_MAX_DEPTH) * 0.1;

    float topFree = lcl + min(max(excess, 0.0) / max(0.4 - b, 0.05), maxDepth);

    float eAtInv = excess + b * (zi - lcl);
    float capW = smoothstep(invK + 0.5, invK - 0.5, eAtInv) * smoothstep(0.05, 0.3, invK)
               * smoothstep(-0.05, 0.25, zi - lcl);
    float topCu = mix(min(topFree, lcl + maxDepth), max(zi, lcl + 0.2), capW);
    topCu = max(topCu, lcl + 0.25);

    float covCu = trig * smoothstep(30.0, 70.0, rhMean) * 0.85;

    float covSc = smoothstep(-0.2, 0.2, zi - lcl) * smoothstep(0.1, 0.6, invK)
                * smoothstep(60.0, 88.0, rhMean);
    covSc = max(covSc, capW * covCu * 0.7);
    covSc = max(covSc, lift * smoothstep(55.0, 80.0, rhMean) * 0.6);
    #if VC_PH_FOG == 1
        float covSt = smoothstep(0.5, 0.1, lcl) * (1.0 - trig) * smoothstep(78.0, 96.0, rhNow);

        covSt = max(covSt, lift * smoothstep(72.0, 92.0, rhMean) * (1.0 - 0.6 * trig));
    #else
        float covSt = 0.0;
    #endif
    float topSc = max(zi, lcl + 0.3);
    float topSt = lcl + 0.45;

    float wsum = covCu + covSc + covSt + 0.0001;

    float region = (0.5 * covSc + 1.0 * covSt) / max(wsum, 0.3);

    float top = mix(topCu, (topCu * covCu + topSc * covSc + topSt * covSt) / wsum,
                    smoothstep(0.02, 0.1, wsum));
    cov = clamp(max(covCu, max(covSc, covSt)) * float(VC_PH_COVER_GAIN) * 0.01, 0.0, 1.0);

    float kb = float(VC_PH_KM_BASE) * 0.1;
    float kt = float(VC_PH_KM_TOP) * 0.1;
    float hb = clamp((lcl - kb) / (kt - kb), 0.0, 0.9);
    float ht = clamp((top - kb) / (kt - kb), hb + 0.1, 1.0);

    float rhUp = clamp(float(VC_PH_UPPER_HUM) + (fU - 0.5) * 2.0 * float(VC_PH_UPPER_VAR)
                       - presX * 20.0, 0.0, 100.0);
    float depth = top - lcl;
    float anvil = smoothstep(4.0, 7.0, depth) * trig;
    highAmt = max(smoothstep(20.0, 70.0, rhUp), anvil);
    float high = mix(0.45, 1.0, smoothstep(55.0, 95.0, rhUp));

    float ccW = smoothstep(0.55, 0.8, fL) * smoothstep(25.0, 40.0, rhUp)
              * (1.0 - smoothstep(55.0, 70.0, rhUp)) * (1.0 - anvil);
    high = mix(high, 0.12, ccW);

    return vec4(region, hb, ht, high);
}

#endif
