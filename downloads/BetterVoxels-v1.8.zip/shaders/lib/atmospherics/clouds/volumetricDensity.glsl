
#ifndef INCLUDE_VOLUMETRIC_DENSITY
#define INCLUDE_VOLUMETRIC_DENSITY

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricWeather.glsl"
#include "/lib/atmospherics/clouds/volumetricShapePhoton.glsl"
#include "/lib/atmospherics/clouds/volumetricGenus.glsl"
#include "/lib/atmospherics/clouds/volumetricSupercell.glsl"

float vcErodeLodG = 0.0;

float vcShellAltitude(vec3 worldPos, vec3 cameraPos) {
    vec2 d = worldPos.xz - cameraPos.xz;
    return worldPos.y + dot(d, d) * (0.5 / VC_RADIUS);
}

vec3 vcCloudCoord(vec3 worldPos, float h, float t) {
    vec2 w = vcWindVector();
    vec3 p = worldPos;

    p.xz -= w * (t * (VC_WIND_SPEED * 0.1));
    p.xz += h * w * (VC_G_THICK * (VC_SKEW * 0.01));
    return p;
}

float vcErosionMod(vec3 cp, float h) {
    vec3 dp = cp / float(VC_DETAIL_SCALE);
    vec2 curl = vcCurlRead(cp.xy / float(VC_CURL_SCALE));
    dp.xy += curl * (VC_CURL_AMOUNT * 0.01) * (1.0 - h);

    vec4 dn = vcDetail(dp);
    float highFreqFbm = dn.r * 0.625 + dn.g * 0.25 + dn.b * 0.125;

    return clamp(mix(highFreqFbm, 1.0 - highFreqFbm,
                     clamp(h * 2.0, 0.0, 1.0)), 0.0, 1.0);
}

#if VC_GENUS_HIGH > 0

float vcHighCcField(vec4 wm, float covMul, float denMul, float ccW, float mapFade) {
    float ccCov = 5.0 * vcLinearStep(0.25, 0.9,
                      clamp(covMul * VC_H_CC_COV * wm.r * mapFade * ccW,
                            0.0, 1.0));
    if (ccCov <= 0.001) return 0.0;
    float ccD = vcLinearStep(1.0 - ccCov, 1.0, vcDampen(wm.g));
    float ccE1 = wm.b;
    float ccE2 = wm.a;
    ccD -= ccE1 * ccE1 * (VC_CC_DETAIL * 0.01);
    ccD -= ccE2 * ccE2 * (VC_CC_DETAIL * 0.01 * 0.5);
    ccD = max(ccD, 0.0);
    ccD = ccD * ccD * ccD;
    return ccD * denMul * VC_H_CC_EXT * ccW * mapFade;
}

float vcHighCiField(vec4 wm, float u, float covMul, float denMul, float ciW,
                    float mapFade) {
    float ciAmt = clamp(covMul * mix(VC_H_CI_COV, VC_H_CS_COV, u)
                      * mapFade * ciW * wm.b, 0.0, 1.0);
    float ciD = vcLinearStep(0.7 - ciAmt, 1.0, wm.r);
    ciD -= wm.g * mix(VC_H_CI_ERODE, VC_H_CS_ERODE, u);
    ciD = max(ciD, 0.0);
    ciD = ciD * ciD * ciD;

    return ciD * denMul * mix(VC_H_CI_EXT, VC_H_CS_EXT, u) * ciW * mapFade;
}

float vcHighDensityBase(vec3 worldPos, float h, float covMul, float denMul) {
    if (!vcConeG) vcHighSkipG = 0.0;
    float mapFade = vcMapFade(worldPos.xz);
    if (mapFade <= 0.001) return 0.0;

    float alt = float(VC_H_ALT) + h * VC_H_THICK;

    if (!vcConeG) vcRegionHG = vcRegionHigh(worldPos.xz);
    float t = vcRegionHG;

    if (t < VC_H_CC_EDGE) {
        float ccW = vcLinearStep(VC_H_CC_EDGE, VC_H_CC_EDGE - VC_H_CC_FADE, t);
        if (ccW <= 0.001) return 0.0;

        float hl = (alt - VC_H_CC_ALT) / VC_H_CC_THICK;
        if (hl < 0.0 || hl > 1.0) {
            if (!vcConeG) vcHighSkipG = hl < 0.0 ? VC_H_CC_ALT - alt
                                                 : (VC_H_CC_ALT + VC_H_CC_THICK) - alt;
            return 0.0;
        }
        if (!vcConeG) vcHighHlG = hl;
        vec4 wm = vcWeatherOf(worldPos.xz, 1);

        float ccT = 1.0 - abs(1.0 - 2.0 * hl);
        return vcHighCcField(wm, covMul, denMul, ccW, mapFade) * ccT * ccT;
    }

    float ciW = vcLinearStep(VC_H_CC_EDGE, VC_H_CC_EDGE + VC_H_CC_FADE, t);
    if (ciW <= 0.001) return 0.0;

    float u = clamp((t - VC_H_CC_EDGE) / (1.0 - VC_H_CC_EDGE), 0.0, 1.0);

    float ciAltM = mix(VC_H_CI_ALT, VC_H_CS_ALT, u);
    float ciThkM = mix(VC_H_CI_THICK, VC_H_CS_THICK, u);
    float hl = (alt - ciAltM) / ciThkM;
    if (hl < 0.0 || hl > 1.0) {
        if (!vcConeG) vcHighSkipG = hl < 0.0 ? ciAltM - alt : (ciAltM + ciThkM) - alt;
        return 0.0;
    }
    if (!vcConeG) vcHighHlG = hl;
    vec4 wm = vcWeatherOf(worldPos.xz, 1);

    float ciT = 1.0 - abs(1.0 - 2.0 * hl);
    return vcHighCiField(wm, u, covMul, denMul, ciW, mapFade) * ciT * ciT;
}

float vcHighDensity(vec3 worldPos, float h, float covMul, float denMul) {
    float d = vcHighDensityBase(worldPos, h, covMul, denMul);
    return d > 0.0 ? d * vcExtCached(worldPos.xz) : 0.0;
}

float vcHighShadowTau(vec3 p, float altP, vec3 lightDir, float covMul, float denMul) {
    if (lightDir.y < 0.02) return 0.0;

    float midAlt = float(VC_H_ALT) + 0.5 * VC_H_THICK;
    vec2 q = p.xz + lightDir.xz * (max(midAlt - altP, 0.0) / lightDir.y);

    float mapFade = vcMapFade(q);
    if (mapFade <= 0.001) return 0.0;

    float t = vcRegionHigh(q);
    float col;
    if (t < VC_H_CC_EDGE) {
        float ccW = vcLinearStep(VC_H_CC_EDGE, VC_H_CC_EDGE - VC_H_CC_FADE, t);
        if (ccW <= 0.001) return 0.0;
        col = vcHighCcField(vcWeatherOf(q, 1), covMul, denMul, ccW, mapFade)
            * (VC_H_CC_THICK / 3.0);
    } else {
        float ciW = vcLinearStep(VC_H_CC_EDGE, VC_H_CC_EDGE + VC_H_CC_FADE, t);
        if (ciW <= 0.001) return 0.0;
        float u = clamp((t - VC_H_CC_EDGE) / (1.0 - VC_H_CC_EDGE), 0.0, 1.0);
        col = vcHighCiField(vcWeatherOf(q, 1), u, covMul, denMul, ciW, mapFade)
            * (mix(VC_H_CI_THICK, VC_H_CS_THICK, u) / 3.0);
    }

    return col * VC_EXT_MEAN / max(lightDir.y, 0.1);
}
#endif

float vcCloudDensityBase(vec3 worldPos, float h, float t, float covMul,
                         float denMul, bool cheap) {
#if VC_G_CB == 1

    return vcSupercellDensity(worldPos, t, cheap);
#endif

    float covFair = covMul;
    float rainAmt = vcRainField(worldPos.xz);
    float rainLvl = vcRainLevel();
    covMul = mix(covMul, rainLvl, rainAmt);

    #if VC_PHYSICS == 1

        if (!vcConeG) {
            vec4 ph = vcPhysicsAt(worldPos.xz);
            float rf = vcRainField(worldPos.xz);
            vcPhysWinG = mix(ph.gb, vec2(0.0, 0.7), rf);
            #if VC_G_ALL == 1
                vcRegionSG = mix(ph.r, 0.8, rf);
            #endif
        }
    #elif VC_G_ALL == 1

        if (!vcConeG) vcRegionSG = vcRegionMix(worldPos.xz);
    #endif

    vec4 wm = vcWeather(worldPos.xz);

#if VC_SHAPE_MODEL == 1

    {
        float mapFade = vcMapFade(worldPos.xz);
        if (mapFade <= 0.001) return 0.0;

    #if VC_G_CI == 1

        float ciAmt = clamp(covMul * VC_G_COV_MUL * mapFade, 0.0, 1.0);
        float ciD = vcLinearStep(0.7 - ciAmt, 1.0, wm.r);

        ciD -= wm.g * VC_G_CI_ERODE;
        ciD = max(ciD, 0.0);
        ciD = ciD * ciD * ciD;

        float ciT = 1.0 - abs(1.0 - 2.0 * h);
        return ciD * ciT * ciT * denMul;
    #endif

    #if VC_G_CC == 1

        float ccCov = 5.0 * vcLinearStep(0.25, 0.9,
                          clamp(covMul * VC_G_COV_MUL * wm.r * mapFade,
                                0.0, 1.0));
        if (ccCov <= 0.001) return 0.0;

        float ccD = vcLinearStep(1.0 - ccCov, 1.0, vcDampen(wm.g));

        float ccE1 = wm.b;
        float ccE2 = wm.a;
        ccD -= ccE1 * ccE1 * (VC_CC_DETAIL * 0.01);
        ccD -= ccE2 * ccE2 * (VC_CC_DETAIL * 0.01 * 0.5);
        ccD = max(ccD, 0.0);

        ccD = ccD * ccD * ccD;

        float ccT = 1.0 - abs(1.0 - 2.0 * h);
        return ccD * ccT * ccT * denMul;
    #endif

    #if VC_G_AC == 1

        float n = wm.r;

    #if VC_AC_PATCH >= 100

        const float gate = 1.0;
    #else

        float gt = 0.75 - 0.5 * (VC_AC_PATCH * 0.01);
        float gate = vcLinearStep(gt - 0.15, gt, wm.a);
        if (gate <= 0.001) return 0.0;
    #endif

        float lvl = clamp(covMul * VC_G_COV_MUL * gate * mapFade, 0.0, 1.0);
        float amt = clamp(mix(0.5, 1.5, vcDampen(n)) * lvl, 0.0, 1.0);
        if (amt <= 0.001) return 0.0;

        float thr = 1.0 - amt;
        float cov2d = vcLinearStep(thr * thr, 1.0, wm.g);

        float g = 1.0 - wm.b;
        cov2d -= 1.9 * g * g * vcDampen(clamp(1.0 - cov2d, 0.0, 1.0));
        if (cov2d <= 0.001) return 0.0;
    #else

        float amt = wm.r * covFair * VC_G_COV_MUL + VC_G_COV_ADD;

        amt = clamp(mix(amt, rainLvl, rainAmt) * mapFade, 0.0, 1.0);
        if (amt <= 0.001) return 0.0;

        float cov2d = vcLinearStep(1.0 - amt, 1.0, wm.g);
        if (cov2d <= 0.001) return 0.0;
    #endif

        #if VC_G_AC == 1
            float dyn = mix(0.5, 1.0, smoothstep(0.4, 0.6,
                            clamp(1.5 * VC_COVERAGE * 0.01 * VC_G_COV_MUL,
                                  0.0, 1.0)));
        #else
            float dyn = mix(0.5, 1.0,
                            smoothstep(0.4, 0.6, VC_COVERAGE * 0.01 * VC_G_COV_MUL));
        #endif
        float hp = h * ((VC_PH_ALT_SCALE * 0.01) / dyn);

        float hTop = h;
        #if VC_PHYSICS == 1
            float hW = (h - vcPhysWinG.x) / max(vcPhysWinG.y - vcPhysWinG.x, 0.02);
            if (hW < 0.0 || hW > 1.0) return 0.0;
            hp = hW * ((VC_PH_ALT_SCALE * 0.01) / dyn);
            hTop = hW;
        #endif
        float phd = vcPhDensity(vcCloudCoord(worldPos, h, t), cov2d, hp, cheap);
        #if VC_PH_TOP > 0
            phd *= smoothstep(1.0, 1.0 - VC_PH_TOP * 0.01, hTop);
        #endif
        #if VC_G_ALL == 1

            return phd * denMul * VC_G_EXT_S;
        #else
            return phd * denMul;
        #endif
    }
#endif

    float cov = mix(wm.r, wm.g, VC_ISLANDS * 0.01) * covMul * vcMapFade(worldPos.xz);
    cov = clamp(cov, 0.0, 1.0);
    if (cov <= 0.001) return 0.0;

    #if VC_ANVIL > 0

        cov = pow(cov, vcRemap(clamp(h, 0.7, 0.8), 0.7, 0.8,
                               1.0, mix(1.0, 0.5, VC_ANVIL * 0.01)));
    #endif

    float grad = min(vcProfile(wm.b, h) * vcProfileBottom(wm.a, h), 1.0);
    if (grad <= 0.001) return 0.0;

    vec3 cp = vcCloudCoord(worldPos, h, t);

    vec4 sn = vcShape(cp / float(VC_SHAPE_SCALE));

    float lowFreqFbm = clamp(sn.g * 0.625 + sn.b * 0.25 + sn.a * 0.125, 0.0, 1.0);
    #if VC_Q_FIXED_STEPS > 0
        lowFreqFbm = mix(lowFreqFbm, 0.700, vcErodeLodG);
    #endif
    float base = clamp(vcRemap(sn.r, lowFreqFbm - 0.9, 1.0, 0.0, 1.0), 0.0, 1.0);

    float dimensional = grad * cov;

    #if VC_EROSION_MODE == 2
        #if VC_Q_FIXED_STEPS > 0
            {
                float emMean = mix(0.695, 0.305, clamp(h * 2.0, 0.0, 1.0));
                float em = (cheap || vcErodeLodG > 0.999) ? emMean
                         : mix(vcErosionMod(cp, h), emMean, vcErodeLodG);
                base = clamp(vcRemap(base, (VC_EROSION * 0.01) * em, 1.0, 0.0, 1.0), 0.0, 1.0);
            }
        #else
            if (!cheap) {
                base = clamp(vcRemap(base, (VC_EROSION * 0.01) * vcErosionMod(cp, h),
                                     1.0, 0.0, 1.0), 0.0, 1.0);
            }
        #endif
    #endif

    float d = clamp(base - (1.0 - dimensional), 0.0, 1.0);
    if (d <= 0.001) return 0.0;
    #if VC_Q_FIXED_STEPS > 0
        #if VC_EROSION_MODE == 1
            float emMean = mix(0.695, 0.305, clamp(h * 2.0, 0.0, 1.0));
            float em = (cheap || vcErodeLodG > 0.999) ? emMean
                     : mix(vcErosionMod(cp, h), emMean, vcErodeLodG);
            d = clamp(vcRemap(d, (VC_EROSION * 0.01) * em, 1.0, 0.0, 1.0), 0.0, 1.0);
        #endif
    #else
        if (cheap) return d * denMul;

        #if VC_EROSION_MODE == 1

            d = clamp(vcRemap(d, (VC_EROSION * 0.01) * vcErosionMod(cp, h),
                              1.0, 0.0, 1.0), 0.0, 1.0);
        #endif
    #endif

    return d * denMul;
}

float vcCloudDensity(vec3 worldPos, float h, float t, float covMul, float denMul,
                     bool cheap) {
    float d = vcCloudDensityBase(worldPos, h, t, covMul, denMul, cheap);

    return d > 0.0 ? d * vcExtCached(worldPos.xz)
                       * (1.0 + 1.5 * vcRainField(worldPos.xz)) : 0.0;
}

#endif
