
#ifndef INCLUDE_VOLUMETRIC_SHAPE_PHOTON
#define INCLUDE_VOLUMETRIC_SHAPE_PHOTON

// CREDIT: the cumulus shape model is inspired by and ported from the Photon
// shaderpack by SixthSurge, with the author's written permission (2026-07-23):
// "Sure, go for it. As long as you acknowledge that it's inspired by my cloud
// implementation that's fine."
// Source: photon_v1.3b, include/sky/clouds/cumulus.glsl and coverage_map.glsl.

float vcDampen(float x) {
    x = clamp(x, 0.0, 1.0);
    return x * (2.0 - x);
}

float vcLift(float x, float amount) {
    return (x + x * amount) / (1.0 + x * amount);
}

float vcPhAltitudeShaping(float density, float h) {
    #if VC_G_STRATUS == 1

        density = mix(density,
                      clamp(density * vcDampen(clamp(2.0 * h, 0.0, 1.0)
                                             * vcLinearStep(0.0, 0.1, h)
                                             * vcLinearStep(0.0, 0.6, 1.0 - h)),
                            0.0, 1.0),
                      VC_G_BLEND);
    #endif

    density -= smoothstep(0.2, 1.0, h) * VC_G_EGG;

    density *= smoothstep(0.0, 0.2, h);

    return density;
}

float vcPhDensity(vec3 cp, float cov2d, float h, bool cheap) {
    float density = vcPhAltitudeShaping(cov2d, h);
    if (density < 0.0001) return 0.0;

    if (cheap) return clamp(density, 0.0, 1.0);

    float worley0 = 1.0 - vcShape(cp / float(VC_SHAPE_SCALE)).g;
    float worley1 = 1.0 - vcDetail(cp / float(VC_DETAIL_SCALE)).r;

    float detailFade = 0.20 * smoothstep(0.85, 1.0, 1.0 - h)
                     - 0.35 * smoothstep(0.05, 0.5, h) + 0.6;

    float torn = 1.0 + 0.5 * VC_G_TORN;
    float w0 = VC_G_DETAIL_0 * torn;
    float w1 = VC_G_DETAIL_1 * torn;
    density -= w0 * worley0 * vcDampen(clamp(1.0 - density, 0.0, 1.0));
    density -= w1 * worley1 * vcDampen(clamp(1.0 - density, 0.0, 1.0))
                  * detailFade;

    density = max(density, 0.0);
    density = vcLift(density, mix(VC_G_SHARP_0, VC_G_SHARP_1, h));
    density *= 0.1 + 0.9 * smoothstep(0.2, 0.7, h);

    return density;
}

#endif
