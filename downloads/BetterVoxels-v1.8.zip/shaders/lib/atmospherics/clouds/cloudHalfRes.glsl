#ifndef INCLUDE_CLOUD_HALF_RES
#define INCLUDE_CLOUD_HALF_RES

ivec2 VcHalfSize() {
    return (ivec2(viewWidth, viewHeight) + (VC_HALF_BLOCK - 1)) / VC_HALF_BLOCK;
}

ivec2 VcHalfPhase2(int k) {
    k &= 3;
    if (k == 0) return ivec2(0, 0);
    if (k == 1) return ivec2(1, 1);
    if (k == 2) return ivec2(1, 0);
    return ivec2(0, 1);
}

ivec2 VcHalfPhase(int k) {
    #if VC_HALF_BLOCK == 4
        k &= 15;
        return VcHalfPhase2(k >> 2) + 2 * VcHalfPhase2(k & 3);
    #else
        return VcHalfPhase2(k);
    #endif
}

#ifndef VC_HALF_WRITER
    uniform sampler2D vc_cloud_sampler;

    bool VcHalfResolve(ivec2 px, inout vec4 clouds, inout float cloudLinearDepth,
                       inout vec4 reproj) {
        ivec2 halfS = VcHalfSize();
        ivec2 b0 = px / VC_HALF_BLOCK;
        vec2 pc = vec2(px) + 0.5;

        vec4 accC = vec4(0.0);
        vec4 accR = vec4(0.0);
        float accW = 0.0;
        float bestD = 1e9;
        float bestLD = 1.0;

        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                ivec2 b = b0 + ivec2(x, y);
                if (b.x < 0 || b.y < 0 || b.x >= halfS.x || b.y >= halfS.y) continue;

                vec4 info = texelFetch(vc_cloud_sampler, b + ivec2(0, halfS.y), 0);
                if (info.a < 0.5) continue;

                float d = length(pc - (vec2(VC_HALF_BLOCK * b) + info.gb + 0.5));
                #if VC_Q_FIXED_STEPS > 0
                    float w = exp(-d * d / (0.9 * float(VC_HALF_BLOCK * VC_HALF_BLOCK)));
                #else
                    float w = max(0.9 * float(VC_HALF_BLOCK) - d, 0.0);
                    if (w <= 0.0) continue;
                    w *= w;
                #endif

                vec4 c = texelFetch(vc_cloud_sampler, b, 0);
                accC += vec4(c.rgb * c.a, c.a) * w;
                accR += texelFetch(vc_cloud_sampler, b + ivec2(halfS.x, 0), 0) * w;
                accW += w;

                if (d < bestD) {
                    bestD = d;
                    bestLD = info.r;
                }
            }
        }

        if (accW <= 0.0) return false;

        clouds = vec4(accC.rgb / max(accC.a, 1e-5), accC.a / accW);
        reproj = accR / accW;
        cloudLinearDepth = bestLD;
        return true;
    }
#endif

#endif
