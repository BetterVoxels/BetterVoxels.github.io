#ifndef INCLUDE_SKY
    #define INCLUDE_SKY

    #include "/lib/colors/lightAndAmbientColors.glsl"
    #include "/lib/colors/skyColors.glsl"

    #ifdef CAVE_FOG
        #include "/lib/atmospherics/fog/caveFactor.glsl"
    #endif

    vec3 GetGradientSky(float VdotU, float VdotS) {
        float nightFactorSqrt2 = sqrt2(nightFactor);
        float nightFactorM = sqrt2(nightFactorSqrt2) * 0.4;
        float VdotSM1 = pow2(max(VdotS, 0.0));
        float VdotSM2 = pow2(VdotSM1);
        float VdotSM3 = pow2(pow2(max(-VdotS, 0.0)));

        float VdotUmax0 = max(VdotU, 0.0);

        vec3 upColor = mix(nightUpSkyColor * (1.5 - 0.5 * nightFactorSqrt2 + nightFactorM * VdotSM3 * 1.5), dayUpSkyColor, sunFactor);
        vec3 middleColor = mix(nightMiddleSkyColor * (3.0 - 2.0 * nightFactorSqrt2), dayMiddleSkyColor * (1.0 + VdotSM2 * 0.3), sunFactor);
        vec3 downColor = mix(nightDownSkyColor, dayDownSkyColor, (sunFactor + sunVisibility) * 0.5);

            float VdotUM1 = pow2(1.0 - VdotUmax0);
                  VdotUM1 = pow(VdotUM1, 1.0 - VdotSM2 * 0.4);
                  VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.15);
            vec3 finalSky = mix(upColor, middleColor, VdotUM1);

            float VdotUM2 = pow2(1.0 - abs(VdotU));
                  VdotUM2 = VdotUM2 * VdotUM2 * (3.0 - 2.0 * VdotUM2);
                  VdotUM2 *= (0.7 - nightFactorM + VdotSM1 * (0.3 + nightFactorM)) * invNoonFactor * sunFactor;
            finalSky = mix(finalSky, sunsetDownSkyColorP * (1.0 + VdotSM1 * 0.3), VdotUM2 * invRainFactor);

            float VdotUM3 = min(max0(-VdotU + 0.08) / 0.35, 1.0);
                  VdotUM3 = smoothstep1(VdotUM3);
            vec3 scatteredGroundMixer = vec3(VdotUM3 * VdotUM3, sqrt1(VdotUM3), sqrt3(VdotUM3));
                 scatteredGroundMixer = mix(vec3(VdotUM3), scatteredGroundMixer, 0.75 - 0.5 * rainFactor);
            finalSky = mix(finalSky, downColor, scatteredGroundMixer);

        return finalSky;
    }

    vec3 ApplySkySaturation(vec3 sky) {
        float sat = SKY_SATURATION * (1.0 / SKY_SATURATION_V13_NEUTRAL);
        if (sat == 1.0) return sky;

        return max(mix(vec3(GetLuminance(sky)), sky, sat), vec3(0.0));
    }

    vec3 ApplySkyBlue(vec3 sky, float blueAmt) {
        float amt = (blueAmt - 1.0) * invRainFactor;
        if (amt == 0.0) return sky;

        vec3 tinted = sky * vec3(1.0 - 0.65 * amt, 1.0 - 0.30 * amt, 1.0 + 0.50 * amt);

        float lum  = GetLuminance(sky);
        float lumT = GetLuminance(tinted);
        float keep = 1.0 / (1.0 + 0.6 * max(amt, 0.0));
        return tinted * mix(1.0, lum / max(lumT, 1e-5), keep);
    }

    vec3 GetSkyBase(float VdotU, float VdotS, float blueAmt) {
        return ApplySkyBlue(ApplySkySaturation(GetGradientSky(VdotU, VdotS)), blueAmt);
    }

    vec3 GetSkyTinted(float VdotU, float VdotS, float dither, bool doGlare, bool doGround, float blueAmt) {
        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);
        float VdotSML = sunVisibility > 0.5 ? VdotS : -VdotS;

        vec3 finalSky = GetSkyBase(VdotU, VdotS, blueAmt);

        if (doGround)
            finalSky *= smoothstep1(pow2(1.0 + min(VdotU, 0.0)));

        if (isEyeInWater == 1)
            finalSky = mix(finalSky * 3.0, waterFogColor, VdotUmax0M);

        if (doGlare) {
            if (0.0 < VdotSML) {
                float glareScatter = (4.0 * 100.0 / float(SKY_GLARE_SIZE)) * (2.0 - clamp01(VdotS * 1000.0));
                float VdotSM4 = pow(abs(VdotS), glareScatter);

                float visfactor = 0.075;
                float glare = visfactor / (1.0 - (1.0 - visfactor) * VdotSM4) - visfactor;

                glare *= 0.5 + pow2(noonFactor) * 1.2;
                glare *= 1.0 - rainFactor * 0.5;

                float glareWaterFactor = isEyeInWater * sunVisibility;
                vec3 glareColor = mix(vec3(0.38, 0.4, 0.5) * 0.7, vec3(0.5), sunVisibility);
                     glareColor = glareColor + glareWaterFactor * vec3(7.0);

                glare *= mix(SKY_GLARE, 1.0, rainFactor);

                finalSky += glare * shadowTime * glareColor;
            }
        }

        #ifdef CAVE_FOG

            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        finalSky += (dither - 0.5) / 128.0;

        return finalSky;
    }

    vec3 GetSky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {
        vec3 sky = GetSkyTinted(VdotU, VdotS, dither, doGlare, doGround,
                                 1.0 + (SKY_BLUE - 1.50));

        #ifdef BIOME_ATMOSPHERE_ACTIVE
        #if BIOME_SKY_TINT == 1
            {
                vec3 bvSkyTint;
                float bvSkyMult, bvSkyWeight;
                bvBiomeAtmosphere(bvSkyTint, bvSkyMult, bvSkyWeight);
                sky = bvBiomeTint(sky, bvSkyTint, bvSkyWeight,
                                  BIOME_SKY_STRENGTH * 0.01);
            }
        #endif
        #endif

        return sky;
    }

    vec3 GetLowQualitySky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {
        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);

            vec3 upColor = mix(nightUpSkyColor, dayUpSkyColor, sunFactor);
            vec3 middleColor = mix(nightMiddleSkyColor, dayMiddleSkyColor, sunFactor);

                float VdotUM1 = pow2(1.0 - VdotUmax0);
                      VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.2);
                vec3 finalSky = mix(upColor, middleColor, VdotUM1);

                float VdotUM2 = pow2(1.0 - abs(VdotU));
                      VdotUM2 *= invNoonFactor * sunFactor * (0.8 + 0.2 * VdotS);
                finalSky = mix(finalSky, sunsetDownSkyColorP * (shadowTime * 0.6 + 0.2), VdotUM2 * invRainFactor);

            finalSky *= pow2(pow2(1.0 + min(VdotU, 0.0)));

            if (isEyeInWater == 1)
                finalSky = mix(finalSky, waterFogColor, VdotUmax0M);

            finalSky *= 1.0 + mix(nightFactor, 0.5 + 0.7 * noonFactor, VdotS * 0.5 + 0.5) * pow2(pow2(pow2(VdotS)));

            finalSky = ApplySkyBlue(ApplySkySaturation(finalSky),
                                  1.0 + (SKY_BLUE - 1.50));

        #ifdef CAVE_FOG

            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        return finalSky;
    }

#endif
