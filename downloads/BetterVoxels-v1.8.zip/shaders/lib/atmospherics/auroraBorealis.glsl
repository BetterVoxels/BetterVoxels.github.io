vec3 GetAuroraBorealis(vec3 viewPos, float VdotU, float dither) {
    float visibility = sqrt1(clamp01(VdotU * 1.5 - 0.225)) - sunVisibility - rainFactor - maxBlindnessDarkness;
    visibility *= 1.0 - VdotU * 0.9;

    #if AURORA_CONDITION == 1 || AURORA_CONDITION == 3
        visibility -= moonPhase;
    #endif
    #if AURORA_CONDITION == 2 || AURORA_CONDITION == 3
        visibility *= inSnowy;
    #endif
    #if AURORA_CONDITION == 4
        visibility = max(visibility * inSnowy, visibility - moonPhase);
    #endif

    if (visibility > 0.0) {
        vec3 aurora = vec3(0.0);

        vec3 wpos = mat3(gbufferModelViewInverse) * viewPos;
             wpos.xz /= wpos.y;
        vec2 cameraPositionM = cameraPosition.xz * 0.0075;
             cameraPositionM.x += cloudSyncedTime * 0.04;

        #ifdef DEFERRED1
            int sampleCount = 25;
            int sampleCountP = sampleCount + 5;
        #else
            int sampleCount = 10;
            int sampleCountP = sampleCount + 10;
        #endif

        float ditherM = dither + 5.0;
        float auroraAnimate = frameTimeCounter * 0.001;
        for (int i = 0; i < sampleCount; i++) {
            float current = pow2((i + ditherM) / sampleCountP);

            vec2 planePos = wpos.xz * (0.8 + current) * 11.0 + cameraPositionM;
            #if AURORA_STYLE == 1
                planePos = floor(planePos) * 0.0007;

                float noise = texture2D(noisetex, planePos).b;
                noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

                noise *= pow1_5(texture2D(noisetex, planePos * 100.0 + auroraAnimate).b);
            #else
                planePos *= 0.0007;

                float noise = texture2D(noisetex, planePos).r;
                noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

                noise *= texture2D(noisetex, planePos * 3.0 + auroraAnimate).b;
                noise *= texture2D(noisetex, planePos * 5.0 - auroraAnimate).b;
            #endif

            float currentM = 1.0 - current;
            #if AURORA_COLOR == 1
                vec3 auroraLow = vec3(1.5, 14.0, 6.0);
                vec3 auroraHigh = vec3(9.0, 3.0, 10.0);
            #elif AURORA_COLOR == 2
                vec3 auroraLow = vec3(0.8, 6.0, 15.0);
                vec3 auroraHigh = vec3(3.0, 13.0, 14.0);
            #elif AURORA_COLOR == 3
                vec3 auroraLow = vec3(14.0, 4.0, 2.0);
                vec3 auroraHigh = vec3(15.0, 11.0, 2.5);
            #elif AURORA_COLOR == 4
                vec3 auroraLow = vec3(13.0, 2.0, 9.0);
                vec3 auroraHigh = vec3(4.0, 5.0, 15.0);
            #elif AURORA_COLOR == 5
                vec3 auroraLow = vec3(2.0, 13.0, 10.0);
                vec3 auroraHigh = vec3(11.0, 13.0, 3.0);
            #elif AURORA_COLOR == 6
                float auroraPhase = planePos.x * 0.35 + auroraAnimate.x * 2.0;
                vec3 auroraLow = 8.0 + 7.0 * cos(auroraPhase + vec3(0.0, 2.094, 4.188));
                vec3 auroraHigh = 8.0 + 7.0 * cos(auroraPhase * 1.3 + 2.0
                                + vec3(0.0, 2.094, 4.188));
            #else
                vec3 auroraLow = vec3(7.0, 2.2, 12.0);
                vec3 auroraHigh = vec3(6.0, 16.0, 12.0);
            #endif

            aurora += noise * currentM * mix(auroraLow, auroraHigh, pow2(pow2(currentM)));
        }

        #if AURORA_STYLE == 1
            aurora *= 1.3;
        #else
            aurora *= 1.8;
        #endif

        #ifdef ATM_COLOR_MULTS
            aurora *= sqrtAtmColorMult;
        #endif

        return aurora * visibility / sampleCount;
    }

    return vec3(0.0);
}
