#ifndef INCLUDE_FOLIAGE_SHADOW_WARP
#define INCLUDE_FOLIAGE_SHADOW_WARP

#if defined CLOUDS_VOLUMETRIC && defined LEAVES_PHYSICS_WEATHER
    #include "/lib/atmospherics/clouds/volumetricWind.glsl"
#endif

vec3 bvFoliageShadowOffset(vec3 relativePos) {
    vec3 offset = vec3(0.0);

    #ifdef LEAVES_PHYSICS_WEATHER
        #ifdef CLOUDS_VOLUMETRIC
            vec2 windDirection = vcWindVector();
        #else
            const vec2 windDirection = vec2(1.0, 0.0);
        #endif

        vec3 worldPos = relativePos + cameraPosition;
        float weatherAmount = max(rainFactor + thunderStrength * 0.75, LEAVES_PHYSICS_CLEAR_WIND * 0.01);

        float t = frameTimeCounter * WAVING_SPEED;
        float phase = worldPos.x * 0.4 + worldPos.z * 0.4;
        float sway = sin(t * 1.1 + phase) + 0.5 * sin(t * 2.3 - phase * 1.7) + 0.25 * sin(t * 4.1 + phase * 0.6);
        sway *= 0.57;

        float gust = sin(t * 0.7 + worldPos.x * 0.13 - worldPos.z * 0.17) * 0.5 + 0.5;
        gust *= gust;

        offset.xz += windDirection * weatherAmount * 0.22
                   + windDirection * (sway * 0.10 + gust * 0.12) * weatherAmount
                   + vec2(-windDirection.y, windDirection.x) * sway * weatherAmount * 0.05;
    #endif

    return offset * LEAVES_PHYSICS_STRENGTH;
}

#endif
