uint posToHash(uvec3 pos) {
    pos *= uvec3(1597334673U, 3812015801U, 2798796415U);
    uint hash = (pos.x ^ pos.y ^ pos.z) * 1597334673U;
    return hash;
}

uint posToHash(vec3 pos) {
    return posToHash(uvec3(pos + 1000));
}

uint posToHash(ivec3 pos) {
    return posToHash(uvec3(pos + 1000));
}
