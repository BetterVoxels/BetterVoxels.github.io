#ifndef INCLUDE_VX_DEBUG
#define INCLUDE_VX_DEBUG

#include "/lib/vx/voxelReading.glsl"

vec3 bvDebugRamp(float t) {
    t = clamp(t, 0.0, 1.0);
    return clamp(vec3(t * 3.0 - 1.5, 1.5 - abs(t * 3.0 - 1.5), 1.5 - t * 3.0), 0.0, 1.0);
}

vec3 bvDebugTrace(vec3 start, vec3 dir, float dither, out int steps, out bool hit) {
    float dirLen = infnorm(dir);
    dir /= dirLen;
    float w = 0.001 + dither * getDistanceField(start + 0.001 * dir);
    steps = 0;
    hit = false;
    for (int k = 0; k < RT_STEPS; k++) {
        steps = k + 1;
        vec3 p = start + w * dir;

        #if EOPT_RAY_SKY_EARLY_OUT == 1
            if (infnorm(p / voxelVolumeSize) > 0.5) break;
        #endif
        float thisdist = getDistanceField(p);
        if (abs(thisdist) < 0.0001) {
            hit = true;
            break;
        }
        w += thisdist;
        if (w > dirLen) break;
    }
    return start + min(w, dirLen) * dir;
}

vec3 BvVoxelDebug(vec3 vxPos, vec3 worldNormal, float dither) {
    if (any(lessThanEqual(vxPos, -0.5 * vec3(voxelVolumeSize)))
     || any(greaterThanEqual(vxPos, 0.5 * vec3(voxelVolumeSize)))) return vec3(0.0);

    #if VX_DEBUG == 1
        return getColorFine(vxPos, worldNormal).rgb;

    #elif VX_DEBUG == 2
        float df = getDistanceField(vxPos + 0.5 * worldNormal);
        vec3 base = bvDebugRamp(df / 8.0);
        float band = abs(fract(df) - 0.5) * 2.0;
        return base * (0.45 + 0.55 * band);

    #elif VX_DEBUG == 3
        int res = getVoxelResolution(vxPos);
        return bvDebugRamp(float(res) / float(max(VOXEL_DETAIL_AMOUNT - 1, 1)));

    #elif VX_DEBUG == 4
        ivec3 coords = ivec3(vxPos + 0.5 * worldNormal + 0.5 * voxelVolumeSize);
        if (vxOutOfRange(coords)) return vec3(0.0);
        int code = imageLoad(occupancyVolume, coords).r >> 28 & 3;
        return vec3(float(ivec4(0, 1, 3, 2)[code]) / 3.0);

    #else
        int steps;
        bool hit;
        vec3 origin = vxPos + 0.5 * worldNormal;
        vec3 traceVec = (LIGHT_TRACE_LENGTH * EOPT_GI_RANGE_MULT) * worldNormal;
        vec3 hitPos = bvDebugTrace(origin, traceVec, dither, steps, hit);

        #if VX_DEBUG == 5
            if (!hit) return vec3(0.02, 0.04, 0.12);
            vec3 hitNormal = vec3(0.0);
            for (int k = 0; k < 3; k++) {
                hitNormal[k] = getDistanceField(hitPos + mat3(0.5)[k])
                             - getDistanceField(hitPos - mat3(0.5)[k]);
            }
            hitNormal = normalize(hitNormal);
            if (any(isnan(hitNormal))) hitNormal = vec3(0.0);
            return getColorFine(hitPos, hitNormal).rgb;

        #elif VX_DEBUG == 6
            if (!hit) return vec3(0.0);
            return bvDebugRamp(length(hitPos - origin)
                             / max(LIGHT_TRACE_LENGTH * EOPT_GI_RANGE_MULT, 0.001));

        #else
            return bvDebugRamp(float(steps) / float(RT_STEPS));
        #endif
    #endif
}

#endif
