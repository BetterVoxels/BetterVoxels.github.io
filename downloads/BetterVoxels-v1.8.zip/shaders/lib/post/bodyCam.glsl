
#ifndef INCLUDE_BODYCAM_MODE
#define INCLUDE_BODYCAM_MODE

#define PP_BODYCAM 0 //[0 1]
#define PP_BC_FORCE_4_3 0 //[0 1]
#define PP_BC_ZOOM 0.80 //[0.75 0.80 0.825 0.85 0.90 0.95 1.00]
#define PP_BC_DISTORTION 1.25 //[-1.00 -0.85 -0.75 -0.65 -0.50 -0.45 -0.35 -0.25 -0.15 0.00 0.15 0.25 0.35 0.45 0.50 0.65 0.75 0.85 1.00 1.15 1.25 1.35 1.50]
#define PP_BC_SHAKE 0.00 //[0.00 0.001 0.0025 0.005 0.01]
#define PP_BC_ABERRATION 0.0025 //[0.00 0.0025 0.005 0.0075 0.01]
#define PP_BC_SHARPNESS 0.25 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_DYNAMIC_RANGE 1.8 //[1.0 1.2 1.4 1.6 1.8 2.0 2.2]
#define PP_BC_SATURATION 0.80 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25]
#define PP_BC_BRIGHTNESS -0.25 //[-1.00 -0.95 -0.90 -0.85 -0.80 -0.75 -0.70 -0.65 -0.60 -0.55 -0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_CONTRAST 0.95 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.025 1.05 1.075 1.10]
#define PP_BC_GRAIN 1 //[0 1]
#define PP_BC_GRAIN_STRENGTH 0.075 //[0.01 0.025 0.05 0.075 0.1 0.125 0.15]
#define PP_BC_SCANLINE 0 //[0 1]
#define PP_BC_SCANLINE_STRENGTH 0.025 //[0.01 0.025 0.05 0.075 0.1]
#define PP_BC_SCANLINE_WIDTH 750 //[100 250 500 750 1000]
#define PP_BC_COLOR_DIST 1 //[0 1]
#define PP_BC_COLOR_DIST_STRENGTH 0.01 //[0.01 0.02 0.03 0.04 0.05]

#ifdef PPP_BODYCAM
    #define PPX_BODYCAM PPP_BODYCAM
#else
    #define PPX_BODYCAM PP_BODYCAM
#endif
#ifdef PPP_BC_BRIGHTNESS
    #define PPX_BC_BRIGHTNESS PPP_BC_BRIGHTNESS
#else
    #define PPX_BC_BRIGHTNESS PP_BC_BRIGHTNESS
#endif
#ifdef PPP_BC_DISTORTION
    #define PPX_BC_DISTORTION PPP_BC_DISTORTION
#else
    #define PPX_BC_DISTORTION PP_BC_DISTORTION
#endif
#define PP_BC_VIGNETTE 1 //[0 1]
#define PP_BC_VIGNETTE_RADIUS 0.45 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_VIGNETTE_STRENGTH 0.20 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_BLACK_STRIPES 0 //[0 1]
#define PP_BC_STRIPES_WIDTH 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55]
#define PP_BC_STRIPES_SOFT 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_NVG 0 //[0 1]
#define PP_BC_NVG_SNEAK 0 //[0 1]
#define PP_BC_NVG_R 0.29 //[0.0 0.05 0.10 0.15 0.20 0.25 0.29 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_NVG_G 0.75 //[0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_NVG_B 0.39 //[0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.39 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_BC_NVG_GAIN 3 //[1 2 3 4 5 6 7 8 9 10]

#define PP_BC_NVG_AUTO 0 //[0 1]
#define PP_BC_NVG_ON_DELAY 40 //[0 5 10 20 30 40 60 80 100 140 200 300 400 600 1200]
#define PP_BC_NVG_OFF_DELAY 60 //[0 5 10 20 30 40 60 80 100 140 200 300 400 600 1200]
#define PP_BC_NVG_TRANSITION 2 //[0 1 2 3]
#define PP_BC_NVG_TRANS_CURVE 8 //[0 1 2 3 4 5 6 7 8]
#define PP_BC_NVG_TRANS_IN 0.35 //[0.05 0.10 0.15 0.20 0.25 0.35 0.50 0.75 1.00 1.50 2.00 3.00 4.00 6.00]
#define PP_BC_NVG_TRANS_OUT 0.60 //[0.05 0.10 0.15 0.20 0.25 0.35 0.50 0.75 1.00 1.50 2.00 3.00 4.00 6.00]
#define PP_BC_NVG_FLASH_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00]

#if PP_BC_NVG_AUTO == 1
    #include "/lib/misc/easeCurves.glsl"
    uniform float fxNvgNight;
    uniform float fxNvgNightRaw;
#endif

#if PPX_BODYCAM == 1

uniform float isSneaking;

float ppBcRand(vec2 n) {
    return fract(sin(dot(n, vec2(12.9898, 78.233))) * 43758.5453);
}

float ppBcNoise(vec2 x) {
    vec2 i = floor(x);
    vec2 f = fract(x);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = ppBcRand(i + vec2(0.0, 0.0));
    float b = ppBcRand(i + vec2(1.0, 0.0));
    float c = ppBcRand(i + vec2(0.0, 1.0));
    float d = ppBcRand(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

vec2 ppBcCameraShake(float t, float intensity, float freq) {
    float nx = ppBcNoise(vec2(0.0, t * freq));
    float ny = ppBcNoise(vec2(1.0, t * freq));
    return (vec2(nx, ny) * 2.0 - 1.0) * intensity;
}

vec3 ppBcTonemap(vec3 color) {
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    vec3 desaturated = mix(vec3(luminance), color, PP_BC_SATURATION);
    desaturated = pow(desaturated, vec3(0.9));
    float newLum = dot(desaturated, vec3(0.299, 0.587, 0.114));
    if (newLum > 0.0) desaturated *= luminance / newLum;
    return desaturated;
}

vec3 ApplyBodyCam(sampler2D src, vec2 uvRaw) {
    vec3 bcColor;

    vec2 effectUV = uvRaw;
    float currentAR = viewWidth / viewHeight;
    float targetAR = 4.0 / 3.0;
    float visibleWidth = 1.0;
    float margin = 0.0;
    #if PP_BC_FORCE_4_3 == 1
        if (currentAR > targetAR) {
            visibleWidth = targetAR / currentAR;
            margin = (1.0 - visibleWidth) / 2.0;
            effectUV.x = (uvRaw.x - margin) / visibleWidth;
        }
    #endif

    vec2 centeredCoord = (effectUV - 0.5) * PP_BC_ZOOM + 0.5;
    float bcDistance = length(centeredCoord - 0.5);
    vec2 shake = ppBcCameraShake(frameTimeCounter, PP_BC_SHAKE, 3.0);
    vec2 fisheyeUV = (centeredCoord + shake - 0.5) * (1.0 + PPX_BC_DISTORTION * bcDistance * bcDistance) + 0.5;
    vec2 redUV  = fisheyeUV + vec2(PP_BC_ABERRATION) * bcDistance;
    vec2 blueUV = fisheyeUV - vec2(PP_BC_ABERRATION) * bcDistance;

    vec2 sampleFisheyeUV = fisheyeUV;
    vec2 sampleRedUV = redUV;
    vec2 sampleBlueUV = blueUV;
    #if PP_BC_FORCE_4_3 == 1
        if (currentAR > targetAR) {
            sampleFisheyeUV.x = fisheyeUV.x * visibleWidth + margin;
            sampleRedUV.x = redUV.x * visibleWidth + margin;
            sampleBlueUV.x = blueUV.x * visibleWidth + margin;
        }
    #endif

    #if LOW_HEALTH == 1
        sampleFisheyeUV = bvLowHealthWarpUV(sampleFisheyeUV);
        sampleRedUV = bvLowHealthWarpUV(sampleRedUV);
        sampleBlueUV = bvLowHealthWarpUV(sampleBlueUV);

        float bcSplit = bvLowHealthSplit();
        sampleRedUV.x = clamp(sampleRedUV.x + bcSplit, 0.001, 0.999);
        sampleBlueUV.x = clamp(sampleBlueUV.x - bcSplit, 0.001, 0.999);
    #endif

    bcColor.r = texture2D(src, sampleRedUV).r;
    bcColor.g = texture2D(src, sampleFisheyeUV).g;
    bcColor.b = texture2D(src, sampleBlueUV).b;

    vec2 bcTexel = 1.0 / vec2(viewWidth, viewHeight);
    vec3 sharpened = vec3(0.0);
    sharpened += texture2D(src, sampleFisheyeUV + bcTexel * vec2(-1.0,  0.0)).rgb * -1.0;
    sharpened += texture2D(src, sampleFisheyeUV + bcTexel * vec2( 1.0,  0.0)).rgb * -1.0;
    sharpened += texture2D(src, sampleFisheyeUV + bcTexel * vec2( 0.0, -1.0)).rgb * -1.0;
    sharpened += texture2D(src, sampleFisheyeUV + bcTexel * vec2( 0.0,  1.0)).rgb * -1.0;
    sharpened += texture2D(src, sampleFisheyeUV).rgb * 5.0;
    bcColor = mix(bcColor, sharpened, PP_BC_SHARPNESS);
    bcColor = clamp(bcColor, 0.0, 1.0);

    bcColor = pow(bcColor, vec3(1.0 / PP_BC_DYNAMIC_RANGE));
    bcColor = ppBcTonemap(bcColor);
    bcColor.r *= 0.975;
    bcColor.g *= 1.025;
    bcColor.b *= 1.05;

    #if PP_BC_SCANLINE == 1
        float bcScanline = sin(fisheyeUV.y * float(PP_BC_SCANLINE_WIDTH) * 1.5) * PP_BC_SCANLINE_STRENGTH;
        bcColor += bcScanline;
    #endif

    #if PP_BC_GRAIN == 1
        float bcNoiseVal = (fract(sin(dot(fisheyeUV, vec2(12.9898, 78.233 * frameTimeCounter))) * 43758.5453) - 0.5) * PP_BC_GRAIN_STRENGTH;
        bcColor += vec3(bcNoiseVal);
    #endif

    #if PP_BC_COLOR_DIST == 1
        float bcColorDistort = PP_BC_COLOR_DIST_STRENGTH * sin(frameTimeCounter * 2.0);
        bcColor *= vec3(1.0 + bcColorDistort, 1.0 - bcColorDistort, 1.0 + bcColorDistort);
    #endif

    {
        float bcNvgOn = 0.0;
        #if PP_BC_NVG_SNEAK == 1
            if (isSneaking > 0.5) bcNvgOn = 1.0;
        #elif PP_BC_NVG == 1
            bcNvgOn = 1.0;
        #endif

        float bcNvgBlend = bcNvgOn;
        float bcNvgFlash = 0.0;

        #if PP_BC_NVG_AUTO == 1

            float bcNvgDelay = max((fxNvgNightRaw > 0.5
                ? float(PP_BC_NVG_ON_DELAY) : float(PP_BC_NVG_OFF_DELAY)) / 20.0, 0.05);

            float bcNvgTau = bcNvgDelay * 1.4426950409;
            float bcNvgRatio = 4.0 / bcNvgTau;
            float bcNvgPhase = fxNvgNightRaw > 0.5
                ? 1.0 - pow(max(1.0 - fxNvgNight, 0.0), bcNvgRatio)
                : pow(max(fxNvgNight, 0.0), bcNvgRatio);

            float bcNvgWin = clamp((fxNvgNightRaw > 0.5 ? PP_BC_NVG_TRANS_IN
                                                        : PP_BC_NVG_TRANS_OUT)
                                   / (4.0 * bcNvgTau), 0.0005, 0.5);
            float bcNvgAuto = bvEaseCurve(
                clamp((bcNvgPhase - 0.5 + bcNvgWin) / (2.0 * bcNvgWin), 0.0, 1.0),
                PP_BC_NVG_TRANS_CURVE);
            bcNvgFlash = bvEaseCurve(
                1.0 - min(abs(bcNvgPhase - 0.5) / bcNvgWin, 1.0),
                PP_BC_NVG_TRANS_CURVE);

            #if PP_BC_NVG_TRANSITION == 1 || PP_BC_NVG_TRANSITION == 2
                bcNvgBlend = max(bcNvgBlend, bcNvgAuto);
            #else
                bcNvgBlend = max(bcNvgBlend, step(0.5, bcNvgPhase));
            #endif
            #if PP_BC_NVG_TRANSITION == 0
                bcNvgFlash = 0.0;
            #endif
        #endif

        if (bcNvgBlend > 0.0) {
            float bcGray = dot(bcColor, vec3(0.299, 0.587, 0.114));
            vec3 bcNvgCol = vec3(bcGray) *
                (vec3(PP_BC_NVG_R, PP_BC_NVG_G, PP_BC_NVG_B) * float(PP_BC_NVG_GAIN));
            bcColor = mix(bcColor, bcNvgCol, bcNvgBlend);
        }

        #if PP_BC_NVG_AUTO == 1

            #if PP_BC_NVG_TRANSITION == 2
                bcColor = mix(bcColor, vec3(1.0), min(bcNvgFlash * PP_BC_NVG_FLASH_I, 1.0));
            #elif PP_BC_NVG_TRANSITION == 3
                bcColor *= 1.0 - min(bcNvgFlash * PP_BC_NVG_FLASH_I, 1.0);
            #endif
        #endif
    }

    bcColor += PPX_BC_BRIGHTNESS;
    bcColor = (bcColor - 0.5) * PP_BC_CONTRAST + 0.5;

    #if PP_BC_VIGNETTE == 1
        float bcVignette = smoothstep(PP_BC_VIGNETTE_RADIUS, PP_BC_VIGNETTE_RADIUS + PP_BC_VIGNETTE_STRENGTH, bcDistance);
        bcColor = mix(bcColor, vec3(0.0), bcVignette);

        float bcLeftV = smoothstep(0.1, 0.1 - 0.3, fisheyeUV.x);
        float bcRightV = smoothstep(1.0 - 0.1, 1.0 - (0.1 - 0.3), fisheyeUV.x);
        bcColor = mix(bcColor, vec3(0.0), max(bcLeftV, bcRightV));
    #endif

    #if PP_BC_BLACK_STRIPES == 1
        float bcLeft = smoothstep(PP_BC_STRIPES_WIDTH, PP_BC_STRIPES_WIDTH - PP_BC_STRIPES_SOFT, effectUV.x);
        float bcRight = smoothstep(1.0 - PP_BC_STRIPES_WIDTH, 1.0 - (PP_BC_STRIPES_WIDTH - PP_BC_STRIPES_SOFT), effectUV.x);
        bcColor = mix(bcColor, vec3(0.0), max(bcLeft, bcRight));
    #endif

    #if PP_BC_FORCE_4_3 == 1
        if (currentAR > targetAR) {
            if (uvRaw.x < margin || uvRaw.x > 1.0 - margin) bcColor = vec3(0.0);
        }
    #endif

    return bcColor;
}

#endif

#endif
