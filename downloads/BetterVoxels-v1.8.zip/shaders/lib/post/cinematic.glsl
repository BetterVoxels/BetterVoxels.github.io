#ifndef INCLUDE_CINEMATIC
#define INCLUDE_CINEMATIC

#define CINEMA_LETTERBOX 0 //[0 1]
#define CINEMA_LETTERBOX_RATIO 239 //[166 178 185 200 220 235 239 255 276 300]

#define CINEMA_GRAIN 0 //[0 1]
#define CINEMA_GRAIN_I 30 //[5 10 15 20 25 30 40 50 65 80 100 130]
#define CINEMA_GRAIN_SIZE 1 //[1 2 3]

#if POST_PROFILE == 7
    #undef CINEMA_LETTERBOX
    #define CINEMA_LETTERBOX 1
#endif

#if CINEMA_GRAIN == 1
    float bvCinemaHash(vec2 p) {
        p = fract(p * vec2(443.8975, 397.2973));
        p += dot(p, p.yx + 19.19);
        return fract((p.x + p.y) * p.x);
    }
#endif

void ApplyCinematic(inout vec3 color) {
    #if CINEMA_GRAIN == 1
        vec2 grainCoord = floor(gl_FragCoord.xy / float(CINEMA_GRAIN_SIZE));
        float grain = bvCinemaHash(grainCoord + fract(float(frameCounter) * 0.618034) * 71.0) - 0.5;

        float lum = clamp(GetLuminance(color), 0.0, 1.0);
        color += grain * (CINEMA_GRAIN_I * 0.001) * (4.0 * lum * (1.0 - lum));
        color = max(color, vec3(0.0));
    #endif

    #if CINEMA_LETTERBOX == 1
        float target = float(CINEMA_LETTERBOX_RATIO) * 0.01;
        float bar = 0.5 * max(0.0, 1.0 - (viewWidth / max(viewHeight, 1.0)) / target);
        float y = gl_FragCoord.y / max(viewHeight, 1.0);
        if (y < bar || y > 1.0 - bar) color = vec3(0.0);
    #endif
}

#endif
