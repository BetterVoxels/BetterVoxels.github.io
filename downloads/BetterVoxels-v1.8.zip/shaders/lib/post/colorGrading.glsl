#ifndef INCLUDE_COLOR_GRADING
#define INCLUDE_COLOR_GRADING

#if CG_WHITE_BALANCE != 6500 || CG_PURKINJE > 0
    #define BV_GRADE_SCENE 1
#endif
#if CG_SATURATION != 0 || CG_CROSSTALK != 0
    #define BV_GRADE_SATURATION 1
#endif
#if CG_SHADOWS != 0 || CG_HIGHLIGHTS != 0
    #define BV_GRADE_CURVE 1
#endif
#if CG_SH_R != 100 || CG_SH_G != 100 || CG_SH_B != 100 || CG_SH_I != 100 || CG_MID_R != 100 || CG_MID_G != 100 || CG_MID_B != 100 || CG_MID_I != 100 || CG_HI_R != 100 || CG_HI_G != 100 || CG_HI_B != 100 || CG_HI_I != 100
    #define BV_GRADE_THREE_WAY 1
#endif
#if defined BV_GRADE_SATURATION || defined BV_GRADE_CURVE || defined BV_GRADE_THREE_WAY
    #define BV_GRADE_DISPLAY 1
#endif

#if defined BV_GRADE_SCENE || defined BV_GRADE_DISPLAY
    const vec3 bvCgLum = vec3(0.2126390059, 0.7151686788, 0.0721923154);
#endif

#ifdef BV_GRADE_SCENE

    const mat3 bvCgToXYZ = mat3(0.4123907993, 0.3575843394, 0.1804807884, 0.2126390059, 0.7151686788, 0.0721923154, 0.0193308187, 0.1191947798, 0.9505321522);
    const mat3 bvCgFromXYZ = mat3(3.2409699419, -1.5373831776, -0.4986107603, -0.9692436363, 1.8759675015, 0.0415550574, 0.0556300797, -0.2039769589, 1.0569715142);

    #if CG_WHITE_BALANCE != 6500
        const mat3 bvCgBradford = mat3(0.8951, 0.2664, -0.1614, -0.7502, 1.7135, 0.0367, 0.0389, -0.0685, 1.0296);
        const mat3 bvCgBradfordInv = mat3(0.9869929055, -0.1470542564, 0.1599626517, 0.4323052697, 0.5183602715, 0.0492912282, -0.0085286646, 0.0400428217, 0.9684866958);

        const vec3 bvCgRef6500 = vec3(0.9524406490, 1.0280115620, 1.1234156244);

        vec2 bvCgPlanckXY(float t) {
            float t2 = t * t;
            float t3 = t2 * t;
            float x = t <= 4000.0
                ? -0.2661239e9 / t3 - 0.2343589e6 / t2 + 0.8776956e3 / t + 0.179910
                : -3.0258469e9 / t3 + 2.1070379e6 / t2 + 0.2226347e3 / t + 0.240390;
            float x2 = x * x;
            float x3 = x2 * x;
            float y = t <= 2222.0 ? -1.1063814 * x3 - 1.34811020 * x2 + 2.18555832 * x - 0.20219683
                    : t <= 4000.0 ? -0.9549476 * x3 - 1.37418593 * x2 + 2.09137015 * x - 0.16748867
                    :                3.0817580 * x3 - 5.87338670 * x2 + 3.75112997 * x - 0.37001483;
            return vec2(x, y);
        }

        void bvWhiteBalance(inout vec3 color) {
            vec2 xy = bvCgPlanckXY(float(CG_WHITE_BALANCE));
            vec3 target = vec3(xy.x / xy.y, 1.0, (1.0 - xy.x - xy.y) / xy.y) * bvCgBradford;
            vec3 cone = (color * bvCgToXYZ) * bvCgBradford;
            cone *= target / bvCgRef6500;
            color = max((cone * bvCgBradfordInv) * bvCgFromXYZ, vec3(0.0));
        }
    #endif

    #if CG_PURKINJE > 0
        void bvNightVision(inout vec3 color, float exposure) {
            vec3 xyz = color * bvCgToXYZ;
            float scotopic = xyz.y * (1.33 * (1.0 + (xyz.y + xyz.z) / max(xyz.x, 1e-6)) - 1.68);
            scotopic = max(scotopic, 0.0) * (1.0 / 2.5732779);

            float stops = log2(max(xyz.y * exposure, 1e-7) / 0.25) - float(CG_PURKINJE_SENS);
            float rods = 1.0 - smoothstep(-8.0, -3.0, stops);

            vec3 tint = vec3(CG_PURKINJE_R, CG_PURKINJE_G, CG_PURKINJE_B) * 0.01;
            float tintL = dot(tint, bvCgLum);
            tint = tintL > 1e-4 ? tint / tintL : vec3(1.0);

            color = mix(color, scotopic * tint, rods * (CG_PURKINJE * 0.01));
        }
    #endif

    void bvGradeScene(inout vec3 color) {
        #if CG_WHITE_BALANCE != 6500
            bvWhiteBalance(color);
        #endif
        #if CG_PURKINJE > 0
            #if AUTO_EXPOSURE == 1
                bvNightVision(color, TM_EXPOSURE * bvAutoExposure());
            #else
                bvNightVision(color, TM_EXPOSURE);
            #endif
        #endif
    }
#endif

#ifdef BV_GRADE_DISPLAY

    #ifdef BV_GRADE_SATURATION
        void bvSaturation(inout vec3 color) {
            float l = dot(color, bvCgLum);
            float s = 1.0 + CG_SATURATION * 0.01;
            s *= 1.0 + CG_CROSSTALK * 0.01 * smoothstep(0.35, 1.0, l);
            color = max(vec3(l) + (color - l) * s, vec3(0.0));
        }
    #endif

    #ifdef BV_GRADE_CURVE
        void bvToneCurve(inout vec3 color) {
            float l = dot(color, bvCgLum);
            float lc = clamp(l, 0.0, 1.0);
            float u = 1.0 - lc;
            float shadowBump = 6.75 * lc * u * u;
            float highBump = 6.75 * lc * lc * u;
            float lNew = lc + 0.12 * (CG_SHADOWS * 0.01 * shadowBump + CG_HIGHLIGHTS * 0.01 * highBump);
            color *= lNew / max(l, 1e-4);
        }
    #endif

    #ifdef BV_GRADE_THREE_WAY
        vec3 bvZoneGain(vec3 tint, float intensity) {
            tint *= 0.01;
            float l = dot(tint, bvCgLum);
            return (l > 1e-4 ? tint / l : vec3(1.0)) * (intensity * 0.01);
        }

        void bvThreeWay(inout vec3 color) {
            float l = clamp(dot(color, bvCgLum), 0.0, 1.0);
            float ws = (1.0 - l) * (1.0 - l);
            float wh = l * l;
            float wm = 1.0 - ws - wh;
            vec3 gain = ws * bvZoneGain(vec3(CG_SH_R, CG_SH_G, CG_SH_B), float(CG_SH_I))
                      + wm * bvZoneGain(vec3(CG_MID_R, CG_MID_G, CG_MID_B), float(CG_MID_I))
                      + wh * bvZoneGain(vec3(CG_HI_R, CG_HI_G, CG_HI_B), float(CG_HI_I));
            color *= gain;
        }
    #endif

    void bvGradeDisplay(inout vec3 color) {
        #ifdef BV_GRADE_SATURATION
            bvSaturation(color);
        #endif
        #ifdef BV_GRADE_CURVE
            bvToneCurve(color);
        #endif
        #ifdef BV_GRADE_THREE_WAY
            bvThreeWay(color);
        #endif
        color = clamp(color, 0.0, 1.0);
    }
#endif

#endif
