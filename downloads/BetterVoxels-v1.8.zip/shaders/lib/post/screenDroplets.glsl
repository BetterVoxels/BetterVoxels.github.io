
#ifndef INCLUDE_SCREEN_DROPLETS
#define INCLUDE_SCREEN_DROPLETS

#define WATER_DROPLETS
#define WD_SCALE 2.00 //[0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00]
#define WD_DISTORTION 2.00 //[0.10 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50 3.00 4.00 5.00]
#define WD_COVERAGE 1.00 //[0.40 0.60 0.80 1.00 1.20 1.40 1.60 2.00]
#define WD_DURATION 5.0 //[1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0 15.0 20.0]

#ifdef WATER_DROPLETS

uniform float exitWater;

float bvWdHash(vec2 c) {
    return fract(sin(dot(c, vec2(97.31, 41.87))) * 3571.19);
}

float bvWdValue(vec2 p) {
    vec2 i = floor(p);
    vec2 f = p - i;
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = bvWdHash(i);
    float b = bvWdHash(i + vec2(1.0, 0.0));
    float c = bvWdHash(i + vec2(0.0, 1.0));
    float d = bvWdHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float bvWdFilm(vec2 q) {
    return bvWdValue(q) * 0.66 + bvWdValue(q * 2.31 + 13.7) * 0.34;
}

float bvWdThick(vec2 q, float drain, float life) {
    float v = max(bvWdFilm(q) - drain, 0.0);
    return v * v * life;
}

vec3 ApplyWaterDroplets(vec3 color, sampler2D src, vec2 uv) {
    if (isEyeInWater == 1) return color;

    float life = fxRetimeDecay(clamp(exitWater, 0.0, 1.0), 5.0, WD_DURATION);
    if (life < 0.01) return color;

    float aspect = viewWidth / viewHeight;

    vec2 freq = vec2(12.0 * aspect, 3.6 + life * 2.0) / WD_SCALE;

    float slide = (1.0 - life) * 0.85;
    vec2 q = vec2(uv.x, uv.y + slide) * freq;

    float drain = (1.0 - sqrt(life)) * (0.78 / WD_COVERAGE);

    float here = bvWdThick(q, drain, life);
    if (here < 1e-5) return color;

    const float e = 0.1;
    vec2 slope = vec2(bvWdThick(q + vec2(e, 0.0), drain, life),
                      bvWdThick(q + vec2(0.0, e), drain, life)) - here;
    slope /= e;

    vec2 wet = uv + slope * vec2(0.022 / aspect, 0.022) * WD_DISTORTION;

    #if LOW_HEALTH == 1
        wet = bvLowHealthWarpUV(wet);
    #endif

    float opacity = clamp(here * 6.0, 0.0, 1.0) * smoothstep(0.0, 0.20, life);
    return mix(color, texture2D(src, clamp(wet, 0.0015, 0.9985)).rgb, opacity);
}

#endif

#endif
