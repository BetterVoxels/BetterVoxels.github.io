#ifndef INCLUDE_TONEMAPPERS
#define INCLUDE_TONEMAPPERS

// CREDIT: ACES Fitted is Stephen Hill's fit of the ACES RRT + sRGB ODT, as
// published in MJP's BakingLab under the MIT License, Copyright (c) 2016 MJP.
// The AgX sigmoid is as fitted in Benjamin Wrensch's "Minimal AgX
// Implementation", MIT License, Copyright (c) 2024 Missing Deadlines
// (Benjamin Wrensch); AgX by Troy Sobotka.
// Khronos PBR Neutral: Khronos Group 3D Commerce, Apache License 2.0.

#if TONEMAPPER > 0

#include "/lib/post/colorSpaces.glsl"

const vec3 bvTmLum = vec3(0.2126390059, 0.7151686788, 0.0721923154);

vec3 bvTmEncode(vec3 c) {
    return mix(1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, 12.92 * c, lessThan(c, vec3(0.0031308)));
}

#if TONEMAPPER == 1
    #define BV_TM_CAL 1.0
    vec3 bvTmOperator(vec3 x) { return x; }

#elif TONEMAPPER == 2
    #define BV_TM_CAL 1.333333
    vec3 bvTmOperator(vec3 x) { return x / (1.0 + x); }

#elif TONEMAPPER == 3
    #define BV_TM_CAL 1.298221
    vec3 bvTmOperator(vec3 x) {
        const float w = 4.0 * TONE_WHITE * 0.01;
        return x * (1.0 + x / (w * w)) / (1.0 + x);
    }

#elif TONEMAPPER == 4
    #define BV_TM_CAL 1.298221
    #define BV_TM_HUE_PRESERVING 1
    vec3 bvTmOperator(vec3 x) {
        const float w = 4.0 * TONE_WHITE * 0.01;
        float l = dot(x, bvTmLum);
        float lo = l * (1.0 + l / (w * w)) / (1.0 + l);
        return x * (lo / max(l, 1e-6));
    }

#elif TONEMAPPER == 5
    #define BV_TM_CAL 1.333333
    vec3 bvTmOperator(vec3 x) {
        float l = dot(x, bvTmLum);
        vec3 tc = x / (1.0 + x);
        return mix(x / (1.0 + l), tc, tc);
    }

#elif TONEMAPPER == 6
    #define BV_TM_CAL 1.150728
    vec3 bvTmOperator(vec3 x) { return 1.0 - exp(-x); }

#elif TONEMAPPER == 7
    #define BV_TM_CAL 0.816218
    #define BV_TM_ENCODED 1
    vec3 bvTmOperator(vec3 c) {
        vec3 x = max(vec3(0.0), c - 0.004);
        return (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);
    }

#elif TONEMAPPER == 8
    #define BV_TM_CAL 3.117837
    vec3 bvTmHable(vec3 x) {
        const float A = TONE_HABLE_A * 0.01;
        const float B = TONE_HABLE_B * 0.01;
        const float C = TONE_HABLE_C * 0.01;
        const float D = TONE_HABLE_D * 0.01;
        const float E = TONE_HABLE_E * 0.01;
        const float F = TONE_HABLE_F * 0.01;
        return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
    }
    vec3 bvTmOperator(vec3 x) {
        const float w = 11.2 * TONE_WHITE * 0.01;
        return bvTmHable(x) / bvTmHable(vec3(w));
    }

#elif TONEMAPPER == 9
    #define BV_TM_CAL 0.714074
    vec3 bvTmOperator(vec3 x) {
        const float w = 4.0 * TONE_WHITE * 0.01;
        vec4 vh = vec4(x, w);
        vec4 va = 1.425 * vh + 0.05;
        vec4 vf = (vh * va + 0.004) / (vh * (va + 0.55) + 0.0491) - 0.0821;
        return vf.rgb / vf.w;
    }

#elif TONEMAPPER == 10
    #define BV_TM_CAL 0.679945
    vec3 bvTmOperator(vec3 x) {
        return (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14);
    }

#elif TONEMAPPER == 11
    #define BV_TM_CAL 1.368217
    #define BV_TM_OWN_SPACE 1

    const mat3 bvTmAcesIn = mat3(0.59719, 0.35458, 0.04823,
                                 0.07600, 0.90834, 0.01566,
                                 0.02840, 0.13383, 0.83777);
    const mat3 bvTmAcesOut = mat3( 1.60475, -0.53108, -0.07367,
                                  -0.10208,  1.10813, -0.00605,
                                  -0.00327, -0.07276,  1.07602);
    vec3 bvTmOperator(vec3 x) {
        vec3 v = x * bvTmAcesIn;
        vec3 a = v * (v + 0.0245786) - 0.000090537;
        vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
        return (a / b) * bvTmAcesOut;
    }

#elif TONEMAPPER == 12
    #define BV_TM_CAL 0.679549
    vec3 bvTmOperator(vec3 x) {
        const float a = TONE_LOTTES_CONTRAST * 0.01;
        const float d = TONE_LOTTES_SHOULDER * 0.001;
        const float hdrMax = float(TONE_LOTTES_HDRMAX);
        const float midIn = 0.18;
        const float midOut = 0.267;
        float hA = pow(hdrMax, a);
        float hAD = pow(hdrMax, a * d);
        float mA = pow(midIn, a);
        float mAD = pow(midIn, a * d);
        float b = (-mA + hA * midOut) / ((hAD - mAD) * midOut);
        float c = (hAD * mA - hA * mAD * midOut) / ((hAD - mAD) * midOut);
        return pow(x, vec3(a)) / (pow(x, vec3(a * d)) * b + c);
    }

#elif TONEMAPPER == 13
    #define BV_TM_CAL 1.0
    vec3 bvTmOperator(vec3 x) {
        const float P = TONE_GT_MAX * 0.01;
        const float a = TONE_GT_CONTRAST * 0.01;
        const float m = TONE_GT_LINEAR_START * 0.01;
        const float l = TONE_GT_LINEAR_LENGTH * 0.01;
        const float c = TONE_GT_BLACK * 0.01;
        const float b = TONE_GT_PEDESTAL * 0.01;
        float l0 = ((P - m) * l) / a;
        float S0 = m + l0;
        float S1 = m + a * l0;
        float C2 = (a * P) / (P - S1);
        float CP = -C2 / P;
        vec3 w0 = 1.0 - smoothstep(0.0, m, x);
        vec3 w2 = step(vec3(m + l0), x);
        vec3 w1 = 1.0 - w0 - w2;
        vec3 T = m * pow(x / m, vec3(c)) + b;
        vec3 S = P - (P - S1) * exp(CP * (x - S0));
        vec3 L = m + a * (x - m);
        return T * w0 + L * w1 + S * w2;
    }

#elif TONEMAPPER == 14
    #define BV_TM_ENCODED 1
    #define BV_TM_OWN_SPACE 1
    #if AGX_LOOK == 1
        #define BV_TM_CAL 1.819165
    #elif AGX_LOOK == 2
        #define BV_TM_CAL 0.737885
    #else
        #define BV_TM_CAL 0.900604
    #endif

    const mat3 bvAgxIn = mat3(0.842479062253094, 0.0423282422610123, 0.0423756549057051,
                              0.0784335999999992, 0.878468636469772, 0.0784336,
                              0.0792237451477643, 0.0791661274605434, 0.879142973793104);
    const mat3 bvAgxOut = mat3(1.19687900512017, -0.0528968517574562, -0.0529716355144438,
                               -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
                               -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
    const float bvAgxMinEv = -12.47393;
    const float bvAgxMaxEv = 4.026069;

    vec3 bvAgxCurve(vec3 x) {
        vec3 x2 = x * x;
        vec3 x4 = x2 * x2;
        return 15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4
             - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232;
    }

    vec3 bvTmOperator(vec3 x) {
        vec3 v = bvAgxIn * x;
        v = clamp(log2(max(v, vec3(1e-10))), bvAgxMinEv, bvAgxMaxEv);
        v = (v - bvAgxMinEv) / (bvAgxMaxEv - bvAgxMinEv);
        v = bvAgxCurve(v);

        #if AGX_LOOK == 1
            const vec3 slope = vec3(1.0);
            const float power = 1.35;
            const float sat = 1.4;
        #elif AGX_LOOK == 2
            const vec3 slope = vec3(1.0, 0.9, 0.5);
            const float power = 0.8;
            const float sat = 0.8;
        #elif AGX_LOOK == 3
            const vec3 slope = vec3(AGX_SLOPE_R, AGX_SLOPE_G, AGX_SLOPE_B) * 0.01;
            const float power = AGX_POWER * 0.01;
            const float sat = AGX_SAT * 0.01;
        #else
            const vec3 slope = vec3(1.0);
            const float power = 1.0;
            const float sat = 1.0;
        #endif
        #if AGX_LOOK > 0
            float luma = dot(v, bvTmLum);
            v = pow(max(v * slope, vec3(0.0)), vec3(power));
            v = luma + sat * (v - luma);
        #endif

        return bvAgxOut * v;
    }

#elif TONEMAPPER == 15
    #define BV_TM_CAL 1.16
    #define BV_TM_HUE_PRESERVING 1
    vec3 bvTmOperator(vec3 color) {
        const float startCompression = 0.8 - 0.04;
        const float desaturation = 0.15;
        float x = min(color.r, min(color.g, color.b));
        float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
        color -= offset;
        float peak = max(color.r, max(color.g, color.b));
        if (peak < startCompression) return color;
        const float d = 1.0 - startCompression;
        float newPeak = 1.0 - d * d / (peak + d - startCompression);
        color *= newPeak / peak;
        float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
        return mix(color, vec3(newPeak), g);
    }
#endif

void bvTonemap(inout vec3 color) {
    #if AUTO_EXPOSURE == 1
        color = TM_EXPOSURE * bvAutoExposure() * color;
    #else
        color = TM_EXPOSURE * color;
    #endif
    color = max(color * BV_TM_CAL, vec3(0.0));

    #if TONE_SPACE > 0 && !defined BV_TM_OWN_SPACE && !defined BV_TM_HUE_PRESERVING && !defined BV_TM_ENCODED && TONEMAPPER != 1
        color = max(color * bvCsToWork, vec3(0.0));
        color = bvTmOperator(color);
        color = color * bvCsFromWork;
    #else
        color = bvTmOperator(color);
    #endif

    color = clamp(color, 0.0, 1.0);
    #ifndef BV_TM_ENCODED
        color = bvTmEncode(color);
    #endif
}

#endif

#endif
