
#ifndef INCLUDE_ASCII_MODE
#define INCLUDE_ASCII_MODE

#define PP_ASCII_MODE 0 //[0 1]
#define PP_ASCII_SCALE 8 //[4 6 8 10 12 16 24 32]
#define PP_ASCII_BRIGHTNESS 100 //[50 60 70 80 90 100 110 120 130 140 150 175 200]
#define PP_ASCII_CONTRAST 100 //[50 60 70 80 90 100 110 120 130 140 150 175 200]
#define PP_ASCII_COLOR_MODE 0 //[0 1 2 3]
#define PP_ASCII_EDGE_GLYPHS 1 //[0 1]
#define PP_ASCII_BACKGROUND 5 //[0 5 10 15 20 25 30]

#if PP_ASCII_MODE == 1

void ppAsciiPattern(float luminance, out ivec4 rowsLo, out ivec4 rowsHi) {
    if (luminance > 0.9)      { rowsLo = ivec4(0xF8, 0xF8, 0xF8, 0xF8); rowsHi = ivec4(0xF8, 0x00, 0x00, 0x00); }
    else if (luminance > 0.8) { rowsLo = ivec4(0x70, 0x90, 0x60, 0xB8); rowsHi = ivec4(0x88, 0x70, 0x00, 0x00); }
    else if (luminance > 0.7) { rowsLo = ivec4(0x20, 0x00, 0x38, 0x08); rowsHi = ivec4(0x70, 0x00, 0x00, 0x00); }
    else if (luminance > 0.6) { rowsLo = ivec4(0xF0, 0x90, 0x90, 0x90); rowsHi = ivec4(0xF0, 0x00, 0x00, 0x00); }
    else if (luminance > 0.5) { rowsLo = ivec4(0x80, 0x80, 0xF0, 0x90); rowsHi = ivec4(0xF0, 0x00, 0x00, 0x00); }
    else if (luminance > 0.4) { rowsLo = ivec4(0x70, 0x50, 0x70, 0x00); rowsHi = ivec4(0x00, 0x00, 0x00, 0x00); }
    else if (luminance > 0.3) { rowsLo = ivec4(0x70, 0x40, 0x70, 0x00); rowsHi = ivec4(0x00, 0x00, 0x00, 0x00); }
    else if (luminance > 0.2) { rowsLo = ivec4(0x20, 0x20, 0x00, 0x20); rowsHi = ivec4(0x00, 0x00, 0x00, 0x00); }
    else if (luminance > 0.1) { rowsLo = ivec4(0x20, 0x00, 0x00, 0x00); rowsHi = ivec4(0x00, 0x00, 0x00, 0x00); }
    else                      { rowsLo = ivec4(0x00, 0x00, 0x00, 0x00); rowsHi = ivec4(0x00, 0x00, 0x00, 0x00); }
}

#if PP_ASCII_EDGE_GLYPHS == 1

    void ppAsciiPatternAngle(float angle, out ivec4 rowsLo, out ivec4 rowsHi) {
        float a = mod(angle, 6.2831853);
        rowsHi = ivec4(0x00, 0x00, 0x00, 0x00);
        if (a < 0.3927 || a > 5.8905)        { rowsLo = ivec4(0x20, 0x20, 0x20, 0x20); rowsHi.x = 0x20; }
        else if (a < 1.1781)                 { rowsLo = ivec4(0x80, 0x40, 0x20, 0x10); rowsHi.x = 0x08; }
        else if (a < 1.9635)                 { rowsLo = ivec4(0x00, 0x00, 0xF8, 0x00); }
        else if (a < 2.7489)                 { rowsLo = ivec4(0x08, 0x10, 0x20, 0x40); rowsHi.x = 0x80; }
        else if (a < 3.5343)                 { rowsLo = ivec4(0x20, 0x20, 0x20, 0x20); rowsHi.x = 0x20; }
        else if (a < 4.3197)                 { rowsLo = ivec4(0x80, 0x40, 0x20, 0x10); rowsHi.x = 0x08; }
        else if (a < 5.1051)                 { rowsLo = ivec4(0x00, 0x00, 0xF8, 0x00); }
        else                                 { rowsLo = ivec4(0x08, 0x10, 0x20, 0x40); rowsHi.x = 0x80; }
    }
#endif

float ppAsciiLuma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float ppAsciiCellLuma(sampler2D src, vec2 cellOrigin, vec2 cellSize) {
    float sum = 0.0;
    for (int x = 0; x < 4; x++) {
        for (int y = 0; y < 4; y++) {
            vec2 offset = (vec2(x, y) + 0.5) * cellSize * 0.25;
            sum += ppAsciiLuma(texture2D(src, cellOrigin + offset).rgb);
        }
    }
    return sum * 0.0625;
}

vec3 ApplyAsciiMode(sampler2D src, vec2 uv) {
    vec2 res = vec2(viewWidth, viewHeight);
    vec2 cellSize = float(PP_ASCII_SCALE) / res;
    vec2 cellOrigin = floor(uv / cellSize) * cellSize;

    float cellLuma = ppAsciiCellLuma(src, cellOrigin, cellSize);
    cellLuma = clamp((cellLuma - 0.5) * (PP_ASCII_CONTRAST * 0.01) + 0.5, 0.0, 1.0);

    ivec4 rowsLo = ivec4(0);
    ivec4 rowsHi = ivec4(0);
    #if PP_ASCII_EDGE_GLYPHS == 1

        float gradX = 0.0;
        float gradY = 0.0;
        for (int gy = -1; gy <= 1; gy++) {
            for (int gx = -1; gx <= 1; gx++) {
                float ppL = ppAsciiLuma(texture2D(src, cellOrigin + (vec2(gx, gy) + 0.5) * cellSize).rgb);
                gradX += ppL * float(gx) * (gy == 0 ? 2.0 : 1.0);
                gradY += ppL * float(gy) * (gx == 0 ? 2.0 : 1.0);
            }
        }
        float magnitude = length(vec2(gradX, gradY));
        if (magnitude < 0.4) ppAsciiPattern(cellLuma, rowsLo, rowsHi);
        else ppAsciiPatternAngle(clamp(atan(gradY, gradX), 0.0, 6.2831853), rowsLo, rowsHi);
    #else
        ppAsciiPattern(cellLuma, rowsLo, rowsHi);
    #endif

    vec2 cellPos = mod(uv / cellSize, vec2(1.0));
    ivec2 px = ivec2(floor(cellPos * 8.0));
    int rowBits = px.y < 4 ? rowsLo[px.y] : rowsHi[px.y - 4];
    bool litUp = (rowBits & (1 << (7 - px.x))) != 0;
    if (cellLuma < 0.1) litUp = false;

    if (litUp) {
        #if PP_ASCII_COLOR_MODE == 1
            vec3 glyphColor = texture2D(src, cellOrigin + cellSize * 0.5).rgb;
        #elif PP_ASCII_COLOR_MODE == 2
            vec3 glyphColor = vec3(0.25, 1.0, 0.30) * cellLuma;
        #elif PP_ASCII_COLOR_MODE == 3
            vec3 glyphColor = vec3(1.0, 0.72, 0.20) * cellLuma;
        #else
            vec3 glyphColor = vec3(1.0) * cellLuma;
        #endif
        return glyphColor * (PP_ASCII_BRIGHTNESS * 0.01);
    }
    return vec3(PP_ASCII_BACKGROUND * 0.01);
}

#endif

#endif
