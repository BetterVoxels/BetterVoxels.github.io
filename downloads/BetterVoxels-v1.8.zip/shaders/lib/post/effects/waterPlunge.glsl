#ifndef INCLUDE_FX_WATER_PLUNGE
#define INCLUDE_FX_WATER_PLUNGE

#include "/lib/misc/easeCurves.glsl"

uniform float fxWaterSink;

vec3 ApplyWaterPlunge(vec3 color, sampler2D src, vec2 uv) {
    if (isEyeInWater != 1) return color;

    float progress = fxRetimeApproach(clamp(fxWaterSink, 0.0, 1.0), 2.0,
                                      max(WATER_PLUNGE_TIME, 0.05));
    float amt = 1.0 - clamp(bvEaseCurve(clamp(progress, 0.0, 1.0), WATER_PLUNGE_CURVE),
                            0.0, 1.0);
    if (amt < 0.004) return color;

    vec2 centred = (uv - 0.5) * fxAspect();
    float r = length(centred);
    vec2 dir = centred / max(r, 0.0001);

    vec2 sampleUv = uv;

    #if WATER_PLUNGE_DISTORT > 0
        float chop = fxNoise(uv * 7.0 + frameTimeCounter * 2.6) - 0.5;
        sampleUv -= dir * (amt * r * WATER_PLUNGE_DISTORT * 0.0009);
        sampleUv += dir * chop * amt * WATER_PLUNGE_DISTORT * 0.00035;
        sampleUv = clamp(sampleUv, vec2(0.0015), vec2(0.9985));
    #endif

    color = texture2D(src, sampleUv).rgb;

    #if WATER_PLUNGE_VEIL > 0
        float veil = smoothstep(0.12, 0.78, r) * amt * (WATER_PLUNGE_VEIL * 0.01);
        vec3 veilCol = vec3(0.09, 0.27, 0.38) * (0.35 + 0.65 * fxLuma(color));
        color = mix(color, veilCol, clamp(veil, 0.0, 0.94));
    #endif

    #if WATER_PLUNGE_BUBBLES > 0
        vec2 grid = uv * vec2(fxAspect().x, 1.0) * 9.0;
        grid.y += frameTimeCounter * 1.7 + amt * 3.5;

        vec2 cell = floor(grid);
        if (fxHash12(cell) > 0.855) {
            vec2 local = fract(grid) - 0.5 - (fxHash22(cell) - 0.5) * 0.55;
            float bubble = smoothstep(0.24, 0.05, length(local));
            color += vec3(0.42, 0.66, 0.78) * bubble * amt * (WATER_PLUNGE_BUBBLES * 0.006);
        }
    #endif

    return color;
}

#endif
