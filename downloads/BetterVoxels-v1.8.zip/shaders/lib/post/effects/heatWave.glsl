
#ifndef INCLUDE_FX_HEAT_WAVE
#define INCLUDE_FX_HEAT_WAVE

#define HEAT_DISTORTION 1 //[0 1]
#define HEAT_WAVE_SPEED 1.0 //[0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 3.5 4.0]
#define HEAT_WAVE_INTENSITY 1 //[0 1 2]
#define HEAT_BLOCK_SOURCES 0 //[0 1 2]
#define HEAT_BIOME_HAZE 0 //[0 1 2 3]
#define HEAT_RISE_HEIGHT 3 //[1 2 3 4 5]

#if HEAT_DISTORTION == 1

#if HEAT_WAVE_INTENSITY == 0
    #define FX_HEAT_AMPLITUDE 0.0016
#elif HEAT_WAVE_INTENSITY == 1
    #define FX_HEAT_AMPLITUDE 0.0035
#else
    #define FX_HEAT_AMPLITUDE 0.0075
#endif

#if HEAT_BIOME_HAZE > 0 && !defined NETHER

    uniform float fxInDesert;
    uniform float fxInBadlands;
#endif

float fxHeatSourceMask(vec3 c) {
    float l = fxLuma(c);

    float warmth = clamp((c.r - c.b) / max(c.r + c.b, 0.001), 0.0, 1.0);

    #if HEAT_BLOCK_SOURCES == 0

        return clamp((l - 0.45) * 2.2, 0.0, 1.0) * clamp((warmth - 0.20) * 3.0, 0.0, 1.0);
    #elif HEAT_BLOCK_SOURCES == 1

        return clamp((l - 0.65) * 2.8, 0.0, 1.0) * clamp((warmth - 0.42) * 4.0, 0.0, 1.0);
    #else

        return clamp((l - 0.28) * 1.8, 0.0, 1.0) * clamp((warmth - 0.10) * 2.2, 0.0, 1.0);
    #endif
}

float fxHeatBiomeHaze() {
    #if HEAT_BIOME_HAZE == 0
        return 0.0;
    #else
        #ifdef NETHER
            #if HEAT_BIOME_HAZE == 2 || HEAT_BIOME_HAZE == 3
                return 1.0;
            #else
                return 0.0;
            #endif
        #else
            #if HEAT_BIOME_HAZE == 1 || HEAT_BIOME_HAZE == 3
                return clamp(fxInDesert + fxInBadlands, 0.0, 1.0);
            #else
                return 0.0;
            #endif
        #endif
    #endif
}

vec2 HeatWaveUV(vec2 uv) {
    if (isEyeInWater != 0) return uv;

    float depth = fxLinearDepth(texture2D(depthtex0, uv).r);
    float riseUv = float(HEAT_RISE_HEIGHT) * 0.045 / max(depth * 0.25, 1.0);

    float srcMask = 0.0;
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 0.33), vec2(0.0), vec2(1.0))).rgb) * 1.00);
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 0.66), vec2(0.0), vec2(1.0))).rgb) * 0.66);
    srcMask = max(srcMask, fxHeatSourceMask(texture2D(colortex3, clamp(uv - vec2(0.0, riseUv * 1.00), vec2(0.0), vec2(1.0))).rgb) * 0.33);

    float haze = fxHeatBiomeHaze();

    haze *= clamp(depth / 48.0, 0.0, 1.0);

    float heat = max(srcMask, haze * 0.55);
    if (heat <= 0.002) return uv;

    float t = frameTimeCounter * HEAT_WAVE_SPEED;
    vec2 p = uv * fxAspect() * 26.0;
    float nx = fxFbm2(p + vec2(0.0, -t * 1.15));
    float ny = fxFbm2(p * 1.31 + vec2(11.3, -t * 1.55));

    vec2 offset = (vec2(nx, ny) - 0.5) * 2.0 * FX_HEAT_AMPLITUDE * heat;

    offset.y = offset.y * 1.6 + FX_HEAT_AMPLITUDE * heat * 0.35;

    return clamp(uv + offset, vec2(0.0), vec2(1.0));
}

#endif

#endif
