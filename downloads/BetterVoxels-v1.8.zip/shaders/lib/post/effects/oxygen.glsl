#ifndef INCLUDE_FX_LOW_OXYGEN
#define INCLUDE_FX_LOW_OXYGEN

#if LOW_OXYGEN == 1

float bvOxygenAir() {
    if (currentPlayerAir < -0.5) return 1.0;
    return clamp(currentPlayerAir, 0.0, 1.0);
}

float bvOxygenVeil() {
    float start = max(LOW_OXYGEN_START * 0.01, 0.001);
    return clamp((start - bvOxygenAir()) / start, 0.0, 1.0);
}

float bvOxygenStress() {
    float start = max(LOW_OXYGEN_BLUR_START * 0.01, 0.001);
    return clamp((start - bvOxygenAir()) / start, 0.0, 1.0);
}

float bvOxygenDrown() {
    return 1.0 - smoothstep(0.0, 0.03, bvOxygenAir());
}

vec3 bvOxygenColour(vec3 color, vec2 uv) {
    float veil = bvOxygenVeil();
    if (veil < 0.001) return color;

    float radius = length(uv * 2.0 - 1.0);
    float reach = pow(veil * clamp(LOW_OXYGEN_VIGNETTE * 0.01, 0.0, 1.0), 0.55);
    float edge = mix(1.45, -0.60, reach);
    float vig = clamp((radius - edge) / 0.55, 0.0, 1.0);

    vec3 grey = vec3(dot(color, vec3(0.2125, 0.7154, 0.0721)));
    color = mix(color, grey, vig * clamp(LOW_OXYGEN_DESAT * 0.01, 0.0, 1.0));
    color *= 1.0 - 0.45 * vig * veil;

    return color;
}

#endif

#endif
