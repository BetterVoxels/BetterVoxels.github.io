#ifndef INCLUDE_FILTERS
#define INCLUDE_FILTERS

#define PP_FILTERS 0 //[0 1]
#define PP_FILTER_LOOK 1 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25]
#define PP_FILTER_I 100 //[5 10 15 20 25 30 40 50 60 70 80 90 100]

#if POST_PROFILE == 7
    #undef PP_FILTERS
    #define PP_FILTERS 1
    #undef PP_FILTER_LOOK
    #define PP_FILTER_LOOK 25
#endif

#if PP_FILTERS == 1

vec3 bvFxSat(vec3 c, float s) {
    return max(mix(vec3(GetLuminance(c)), c, s), vec3(0.0));
}

vec3 bvFxCon(vec3 c, float k) {
    return max((c - 0.5) * k + 0.5, vec3(0.0));
}

vec3 bvFxSplit(vec3 c, vec3 shadowTint, vec3 highTint) {
    return c * mix(shadowTint, highTint, clamp(GetLuminance(c), 0.0, 1.0));
}

vec3 bvFxLift(vec3 c, float l) {
    return c * (1.0 - l) + l;
}

vec3 bvFxMono(vec3 c, vec3 w) {
    return vec3(dot(c, w / max(w.r + w.g + w.b, 0.0001)));
}

void ApplyFilters(inout vec3 color) {
    vec3 src = color;
    vec3 c = color;

    #if PP_FILTER_LOOK == 1
        c = bvFxSat(c, 1.30);
        c = bvFxSplit(c, vec3(0.90, 0.98, 1.12), vec3(1.10, 1.02, 0.90));
        c = bvFxCon(c, 1.12);

    #elif PP_FILTER_LOOK == 2
        c = bvFxSat(c, 1.55);
        c = bvFxCon(c, 1.28);
        c *= vec3(1.03, 1.01, 0.98);

    #elif PP_FILTER_LOOK == 3
        c = bvFxSat(c, 0.95);
        c = bvFxCon(c, 0.90);
        c = bvFxLift(c, 0.030);
        c = bvFxSplit(c, vec3(1.02, 0.99, 0.98), vec3(1.05, 1.01, 0.95));

    #elif PP_FILTER_LOOK == 4
        c = bvFxSplit(c, vec3(0.95, 1.04, 0.97), vec3(1.08, 1.02, 0.92));
        c = bvFxSat(c, 1.08);
        c = bvFxLift(c, 0.018);

    #elif PP_FILTER_LOOK == 5
        c = bvFxSplit(c, vec3(0.82, 0.94, 1.25), vec3(1.12, 1.00, 0.88));
        c = bvFxSat(c, 1.12);
        c = bvFxCon(c, 1.08);

    #elif PP_FILTER_LOOK == 6
        c = bvFxSat(c, 0.32);
        c = bvFxCon(c, 1.45);
        c *= vec3(0.99, 1.00, 1.03);

    #elif PP_FILTER_LOOK == 7
        c = bvFxSplit(c, vec3(0.78, 1.02, 1.20), vec3(1.18, 1.10, 0.72));
        c = bvFxSat(c, 1.35);
        c = bvFxCon(c, 1.30);

    #elif PP_FILTER_LOOK == 8
        c = vec3(dot(c, vec3( 1.35, -0.22, -0.13)),
                 dot(c, vec3(-0.18,  1.32, -0.14)),
                 dot(c, vec3(-0.12, -0.20,  1.32)));
        c = max(c, vec3(0.0));
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 9
        c = bvFxSat(c, 0.55);
        c *= vec3(0.55, 0.68, 1.00);
        c = bvFxCon(c, 0.88);
        c *= 0.72;

    #elif PP_FILTER_LOOK == 10
        c = bvFxMono(c, vec3(0.2126, 0.7152, 0.0722));

    #elif PP_FILTER_LOOK == 11
        c = bvFxMono(c, vec3(0.05, 0.60, 0.75));
        c = bvFxCon(c, 1.08);

    #elif PP_FILTER_LOOK == 12
        c = bvFxMono(c, vec3(1.55, 0.45, 0.02));
        c = bvFxCon(c, 1.22);

    #elif PP_FILTER_LOOK == 13
        float ir = dot(c, vec3(0.10, 1.45, -0.30));
        c = vec3(clamp(ir, 0.0, 1.6));
        c = bvFxCon(c, 1.18);

    #elif PP_FILTER_LOOK == 14
        c = bvFxMono(c, vec3(0.30, 0.59, 0.11));
        c *= vec3(1.20, 1.00, 0.74);
        c = bvFxLift(c, 0.030);

    #elif PP_FILTER_LOOK == 15
        c = bvFxMono(c, vec3(0.30, 0.59, 0.11));
        c = mix(vec3(0.06, 0.16, 0.34), vec3(0.86, 0.93, 1.00), c);

    #elif PP_FILTER_LOOK == 16
        c = bvFxMono(c, vec3(0.2126, 0.7152, 0.0722));
        c = bvFxSplit(c, vec3(0.94, 0.92, 1.10), vec3(1.02, 1.00, 1.00));
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 17
        c = bvFxSat(c, 0.72);
        c = bvFxCon(c, 0.84);
        c = bvFxLift(c, 0.085);
        c *= vec3(1.02, 1.00, 0.98);

    #elif PP_FILTER_LOOK == 18
        c = bvFxSplit(c, vec3(0.80, 1.00, 1.18), vec3(1.16, 1.02, 0.84));
        c = bvFxSat(c, 1.18);
        c = bvFxCon(c, 1.12);

    #elif PP_FILTER_LOOK == 19
        c = bvFxSplit(c, vec3(1.04, 0.98, 0.92), vec3(1.16, 1.04, 0.82));
        c = bvFxSat(c, 1.10);
        c = bvFxLift(c, 0.020);

    #elif PP_FILTER_LOOK == 20
        c = bvFxSat(c, 0.85);
        c = bvFxSplit(c, vec3(0.92, 1.00, 1.10), vec3(0.98, 1.00, 1.06));
        c = bvFxCon(c, 0.92);

    #elif PP_FILTER_LOOK == 21
        c = bvFxSplit(c, vec3(0.78, 0.86, 1.20), vec3(1.22, 0.92, 0.94));
        c = bvFxSat(c, 1.22);
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 22
        c = bvFxMono(c, vec3(0.28, 0.62, 0.10));
        c = bvFxCon(c, 1.65);

    #elif PP_FILTER_LOOK == 23
        c = bvFxSplit(c, vec3(1.06, 0.94, 1.04), vec3(1.04, 0.96, 1.10));
        c = bvFxSat(c, 0.88);
        c = bvFxLift(c, 0.065);
        c = bvFxCon(c, 0.90);

    #elif PP_FILTER_LOOK == 25

        c = pow(clamp(c * vec3(1.1209, 0.9584, 0.8288) + vec3(-0.0921, 0.0266, 0.0798), 0.0, 1.0),
                vec3(0.9037, 1.0225, 1.0022));

    #else
        c = bvFxSplit(c, vec3(0.90, 0.98, 1.10), vec3(1.12, 1.04, 0.94));
        c = bvFxSat(c, 1.05);
        c = bvFxLift(c, 0.055);
        c = bvFxCon(c, 0.88);
    #endif

    color = mix(src, c, PP_FILTER_I * 0.01);
}

#endif

#endif
