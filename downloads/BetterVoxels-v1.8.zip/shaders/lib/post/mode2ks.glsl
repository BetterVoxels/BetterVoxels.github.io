
#ifndef INCLUDE_MODE_2KS
#define INCLUDE_MODE_2KS

#define PP_2KS 0 //[0 1]

#define PP_2KS_ZOOM 1.10 //[1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define PP_2KS_FISHEYE 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]

#define PP_2KS_SHAKE 1 //[0 1]
#define PP_2KS_SHAKE_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_FLOW_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_FLOW_SPEED 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_MICRO_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_MICRO_SPEED 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_DROP_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_DROP_FREQ 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

#define PP_2KS_TILT 1 //[0 1]
#define PP_2KS_TILT_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_TILT_FLOW_I 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_TILT_FLOW_SPEED 1.00 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

#define PP_2KS_ABERRATION 1.00 //[0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 3.50 4.00 4.50 5.00]
#define PP_2KS_SOFTNESS 2 //[0 1 2 3 4]
#define PP_2KS_SHARPNESS 1.00 //[0.00 0.20 0.40 0.60 0.80 1.00 1.20 1.40 1.60 1.80 2.00]
#define PP_2KS_DISTANCE_BLUR 1 //[0 1]
#define PP_2KS_WATER_BLUR 3 //[0 1 2 3 4 5]

#define PP_2KS_GAMMA 2.20 //[1.00 1.20 1.40 1.60 1.80 2.00 2.20 2.40 2.60 2.80 3.00]
#define PP_2KS_CRUSH 0.30 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]
#define PP_2KS_EXPOSURE 0.90 //[0.50 0.70 0.90 1.10 1.30 1.40 1.50 1.70 1.90 2.10 2.30]
#define PP_2KS_BRIGHTNESS 0.00 //[-0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50]
#define PP_2KS_R 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_G 0.85 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_B 0.80 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.60 1.70 1.80 1.90 2.00]
#define PP_2KS_DAY_LEVEL 1.00 //[0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_2KS_HIGHLIGHT 0.55 //[0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define PP_2KS_CONTRAST 0.50 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define PP_2KS_GRAIN 1 //[0 1]
#define PP_2KS_GRAIN_I 0.20 //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define PP_2KS_DISTORTIONS 1 //[0 1]
#define PP_2KS_DISTORTION_I 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define PP_2KS_FLICKER 1 //[0 1]
#define PP_2KS_FLICKER_I 1.00 //[0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 1.75 2.00]
#define PP_2KS_GRADIENTS 1 //[0 1]
#define PP_2KS_STREAK 1 //[0 1]
#define PP_2KS_STREAK_I 1.00 //[0.10 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 3.50 4.00 4.50 5.00]

#define PP_2KS_VIGNETTE 1 //[0 1]
#define PP_2KS_VIGNETTE_I 1.00 //[0.10 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00]
#define PP_2KS_BORDER 1 //[0 1]

#if PP_2KS == 1

float bv2ksRand(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

mat2 bv2ksRotate(float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return mat2(c, -s, s, c);
}

float bv2ksMotion() {
    return (1.0 - 1.0 / exp(distance(cameraPosition, previousCameraPosition) * 2.3)) * 0.5;
}

float bv2ksDaylight() {
    float elevation = sin(sunAngle * 6.2831853);
    float sky = clamp(float(eyeBrightness.y) / 240.0, 0.0, 1.0);
    return smoothstep(0.0, 0.25, elevation) * sky * sky;
}

vec2 bv2ksCameraUV(vec2 uv) {
    float aspect = viewWidth / viewHeight;
    float power = bv2ksMotion();

    vec2 p = (uv * 2.0 - 1.0) / PP_2KS_ZOOM;
    float centerDistance = length(p);
    p *= centerDistance * PP_2KS_FISHEYE + (1.0 - PP_2KS_FISHEYE);
    p.x *= aspect;

    #if PP_2KS_SHAKE == 1
        float ft = frameTimeCounter;
        float amp = PP_2KS_SHAKE_I;

        p.x += sin(ft * 0.3 * PP_2KS_FLOW_SPEED) * 0.04 * PP_2KS_FLOW_I * amp;
        p.y += sin(ft * 0.32 * PP_2KS_FLOW_SPEED + 12.291) * 0.04 * (1.0 + power) * PP_2KS_FLOW_I * amp;

        p.x += clamp(sin(ft * 23.0 * PP_2KS_MICRO_SPEED) * sin(ft * 9.0 * PP_2KS_MICRO_SPEED)
                   * max(sin(ft * 0.21 * PP_2KS_MICRO_SPEED) * sin(ft * 12.0 * PP_2KS_MICRO_SPEED)
                       * sin(ft * 0.1 * PP_2KS_MICRO_SPEED) * 20.0, 0.0) * 1.3 - 0.3, -1.0, 1.0)
                   * 0.001 * PP_2KS_MICRO_I * amp;
        p.y += clamp(sin(ft * 21.3 * PP_2KS_MICRO_SPEED - 0.324) * sin(ft * 7.6 * PP_2KS_MICRO_SPEED - 2.242)
                   * max(sin(ft * 0.2834 * PP_2KS_MICRO_SPEED + 0.23) * sin(ft * 11.23 * PP_2KS_MICRO_SPEED + 3.42)
                       * sin(ft * 0.132 * PP_2KS_MICRO_SPEED - 0.324) * 20.0, 0.0) * 1.3 - 0.3, -1.0, 1.0)
                   * 0.001 * PP_2KS_MICRO_I * amp;

        p.x += pow(sin(ft * 7.0 * PP_2KS_MICRO_SPEED) * cos(ft * 2.0 * PP_2KS_MICRO_SPEED)
                 * sin(ft * 0.9 * PP_2KS_MICRO_SPEED + 0.32), 2.0)
                 * 0.005 * (1.0 + power * 2.0) * PP_2KS_MICRO_I * amp;

        p.x += clamp(sin(ft * 5.21 + 58.93) * cos(ft * 7.6843 - 12.6344)
                   + cos(ft * 0.312 * PP_2KS_DROP_FREQ + 0.324) * 4.0, -1.0, 1.0)
                   * 0.01 * (1.0 + power * 3.5) * PP_2KS_DROP_I * amp;
        p.y += clamp(pow(sin(ft * 4.3 + 32.24) * cos(ft * 8.392 - 0.324) + cos(ft * 2.392 - 31.324), 3.0), -1.0, 1.0)
                   * 0.01 * (1.0 + power * 3.5) * PP_2KS_DROP_I * amp;

        p += vec2(sin(ft * 78.0 * (1.1 - power)), cos(ft * 86.0 * (1.1 - power)))
           * 0.01 * power * power * amp;

        #if PP_2KS_TILT == 1
            float tiltAngle = floor(sin(ft * 0.5 * PP_2KS_TILT_FLOW_SPEED) * 10.0) / 10.0
                            * 0.2 * amp * PP_2KS_TILT_I * PP_2KS_TILT_FLOW_I + power;
            tiltAngle += sin(ft * 0.32 * PP_2KS_TILT_FLOW_SPEED + 3.14)
                       * 0.2 * amp * PP_2KS_TILT_FLOW_I * PP_2KS_TILT_I;
            p *= bv2ksRotate(tiltAngle * 0.1);
        #endif
    #endif

    p.x /= aspect;
    return p * 0.5 + 0.5;
}

vec3 ApplyTwoKS(sampler2D src, vec2 uvRaw) {
    vec2 res = vec2(viewWidth, viewHeight);
    vec2 uv = bv2ksCameraUV(uvRaw);

    #if LOW_HEALTH == 1
        uv = bvLowHealthWarpUV(uv);
    #endif

    float softness = float(PP_2KS_SOFTNESS);
    #if PP_2KS_DISTANCE_BLUR == 1
        softness = mix(softness, softness + 1.0, pow(texture2D(depthtex0, uv).r, 128.0));
    #endif
    if (isEyeInWater > 0) softness += float(PP_2KS_WATER_BLUR);
    vec2 step2 = pow(2.0, softness) / res;

    vec3 blurred = vec3(0.0);
    blurred += texture2D(src, uv + vec2(-1.0, -1.0) * step2).rgb * 0.0625;
    blurred += texture2D(src, uv + vec2( 1.0, -1.0) * step2).rgb * 0.0625;
    blurred += texture2D(src, uv + vec2(-1.0,  1.0) * step2).rgb * 0.0625;
    blurred += texture2D(src, uv + vec2( 1.0,  1.0) * step2).rgb * 0.0625;
    blurred += texture2D(src, uv + vec2( 0.0, -1.0) * step2).rgb * 0.125;
    blurred += texture2D(src, uv + vec2( 0.0,  1.0) * step2).rgb * 0.125;
    blurred += texture2D(src, uv + vec2(-1.0,  0.0) * step2).rgb * 0.125;
    blurred += texture2D(src, uv + vec2( 1.0,  0.0) * step2).rgb * 0.125;

    float ab = PP_2KS_ABERRATION / viewWidth * max(softness, 1.0);
    vec3 source;
    source.r = texture2D(src, uv + vec2(ab, 0.0)).r;
    source.g = texture2D(src, uv).g;
    source.b = texture2D(src, uv - vec2(ab, 0.0)).b;

    vec3 color = source * 0.25 + blurred;

    vec3 detail = source - blurred;
    color += detail * detail * 64.0 * PP_2KS_SHARPNESS * (1.0 - min(float(isEyeInWater), 1.0));

    #if PP_2KS_STREAK == 1
        float streak = 0.0;
        for (int i = 0; i < 8; i++) {
            vec2 sampleUV = vec2(uv.x, (float(i) + bv2ksRand(uv + sin(frameTimeCounter))) * 0.125);
            streak += max(dot(texture2D(src, sampleUV).rgb - 0.3, vec3(0.333)), 0.0);
        }
        color += vec3(0.4, 0.1, 0.9) * min(streak, 0.2) * PP_2KS_STREAK_I;
    #endif

    #if PP_2KS_GRAIN == 1
        vec2 grainUV = fract(uv * res / max(softness, 1.0) / 75.0) * 75.0;
        color *= mix(bv2ksRand(grainUV + sin(frameTimeCounter) * 10.0) * 0.5 + 0.5, 1.0, 1.0 - PP_2KS_GRAIN_I);
    #endif

    color = pow(max(color, vec3(0.0)), vec3(1.0 / PP_2KS_GAMMA));
    color -= PP_2KS_CRUSH;

    #if PP_2KS_DISTORTIONS == 1
        vec2 warp = vec2(uv.x + sin(uv.x * 124.4) * cos(uv.y * 84.234) * 0.001,
                         uv.y + sin(uv.y * 124.4) * cos(uv.x * 84.234) * 0.001);
        vec3 posterised = floor(max(texture2D(src, warp).rgb, vec3(0.0)) * 16.0) / 16.0;
        color = mix(color, posterised * posterised * 4.0, PP_2KS_DISTORTION_I);
    #endif

    color = pow(max(color, vec3(0.0)), vec3(PP_2KS_EXPOSURE));

    #if PP_2KS_FLICKER == 1
        float pulse = max(sin(frameTimeCounter * 2.6), 0.0)
                    * pow(sin(frameTimeCounter * 46.4 + 0.3) + cos(frameTimeCounter * 32.3 - 0.4), 2.0)
                    * 0.05 + 0.2;
        color = mix(color, vec3(dot(clamp(color, 0.0, 1.0), vec3(0.3333))), pulse * PP_2KS_FLICKER_I);
        color = mix(clamp(color, 0.0, 1.0), clamp(color.brg, 0.0, 1.0),
                    ((sin(frameTimeCounter * 1.4) * 0.5 + 0.5) * 0.1 + 0.1) * PP_2KS_FLICKER_I);
    #endif

    #if PP_2KS_GRADIENTS == 1
        color *= vec3(0.8 + uv.x * uv.x * 0.1,
                      0.9 + uv.y * uv.y * 0.3,
                      0.9 + uv.y * uv.y * 0.5);
    #endif

    color *= vec3(PP_2KS_R, PP_2KS_G, PP_2KS_B);

    float day2ks = bv2ksDaylight();
    color *= mix(1.0, PP_2KS_DAY_LEVEL, day2ks);

    float knee2ks = mix(1.0, PP_2KS_HIGHLIGHT, day2ks);
    float head2ks = max(1.0 - knee2ks, 0.0001);
    vec3 over2ks = max(color - knee2ks, vec3(0.0));
    color = min(color, vec3(knee2ks)) + head2ks * (vec3(1.0) - exp(-over2ks / head2ks));

    vec3 c2ks = clamp(color, 0.0, 1.0);
    color = mix(c2ks, c2ks * c2ks * (3.0 - 2.0 * c2ks), PP_2KS_CONTRAST);

    #if PP_2KS_BORDER == 1
        float aspect = viewWidth / viewHeight;
        float edge = pow(max(bv2ksRand(uvRaw + sin(frameTimeCounter) * 10.0), 0.0), 64.0) * 0.2;
        if (abs((uvRaw.x * 2.0 - 1.0) * aspect) + edge >= 4.0 / 3.0) color = vec3(0.0);
    #endif

    color = min(color, vec3(1.0));

    #if PP_2KS_VIGNETTE == 1
        color *= pow(max(min(1.5 / PP_2KS_VIGNETTE_I - length(uvRaw * 2.0 - 1.0), 1.0), 0.0), 0.5);
    #endif

    color += PP_2KS_BRIGHTNESS;

    return color;
}

#endif

#endif
