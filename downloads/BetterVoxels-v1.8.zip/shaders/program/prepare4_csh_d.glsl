
#include "/lib/common.glsl"

#ifdef CSH

#if CLOUD_STYLE == 4

layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
const ivec3 workGroups = ivec3(16, 8, 1);

#define VC_NOISE_WRITER
#define ATM_LUT_WRITER
#include "/lib/atmospherics/atmosphereLut.glsl"

layout(rgba16f) uniform image2D vcWeatherImg;

void main() {
    ivec2 id = ivec2(gl_GlobalInvocationID.xy);
    if (id.x >= ATM_TRANS_W || id.y >= ATM_TRANS_H) return;

    if (frameCounter > 1) return;

    vec2 uv = (vec2(id) + 0.5) / vec2(float(ATM_TRANS_W), float(ATM_TRANS_H));
    imageStore(vcWeatherImg, id + ivec2(VC_CURL_X0, VC_CURL_RES),
               vec4(atmBuildTransmittance(uv), 1.0));
}

#else

layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}

#endif

#endif
