
#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER

in vec2 texCoord;

flat in vec3 upVec, sunVec;

in vec4 glColor;

float SdotU = dot(sunVec, upVec);
float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;

#include "/lib/util/spaceConversion.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/atmospherics/fog/mainFog.glsl"

#ifdef TAA
    #include "/lib/antialiasing/jitter.glsl"
#endif

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/misc/colorCodedPrograms.glsl"
#endif

#ifdef OVERWORLD
    #include "/lib/atmospherics/clouds/cloudLightSources.glsl"
#endif

#if defined CLOUDS_VOLUMETRIC
    #include "/lib/atmospherics/clouds/volumetricSettings.glsl"
    #if VC_BEAM_LIGHT == 1
        #define BV_BEAM_DISSOLVE
        #include "/lib/atmospherics/clouds/volumetricGenus.glsl"
        #define VC_CSM_ALT_B   float(VC_G_ALT)
        #define VC_CSM_THICK_B VC_G_THICK
        #ifdef CLOUD_SHADOWS
            #include "/lib/atmospherics/clouds/cloudShadowMap.glsl"
        #endif
    #endif
#endif

void main() {
    vec4 color = texture2D(tex, texCoord);
    vec3 colorP = color.rgb;
    color *= glColor;

    vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
    #ifdef TAA
        vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
    #else
        vec3 viewPos = ScreenToView(screenPos);
    #endif
    float lViewPos = length(viewPos);
    vec3 nViewPos = normalize(viewPos);
    vec3 playerPos = ViewToPlayer(viewPos);
    vec3 bvBeamWorld = playerPos + cameraPosition;
    float VdotU = dot(nViewPos, upVec);

    float bvBeamBoost = 1.0;
    #if defined OVERWORLD && SMOOTH_BEACON_RAY == 1
        {
            vec3 segCol = glColor.rgb;
            float beamAlpha = 1.0;
            BvBeamFragment(bvBeamWorld, segCol, beamAlpha, bvBeamBoost);
            if (beamAlpha <= 0.002) discard;
            color = vec4(colorP * segCol, color.a * beamAlpha);
        }
    #endif
    float VdotS = dot(nViewPos, sunVec);

    float dither = Bayer64(gl_FragCoord.xy);
    #ifdef TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #ifdef ATM_COLOR_MULTS
        atmColorMult = GetAtmColorMult();
    #endif

    #ifdef IPBR
        float emission = dot(colorP, colorP);

        if (0.5 > color.a && color.a > 0.01) {
            color.a = 0.101;
            emission = pow2(pow2(emission)) * 0.1;
        }

        color.rgb *= color.rgb * emission * 1.75;
        color.rgb += emission * 0.05;
    #else
        color.rgb *= color.rgb * 4.0;
    #endif

    color.rgb *= bvBeamBoost;

    #ifndef BV_BEAM_DISSOLVE
        color.rgb *= 0.5 + 0.5 * exp(-lViewPos * 0.04);
    #endif

    #ifdef COLOR_CODED_PROGRAMS
        ColorCodeProgram(color, -1);
    #endif

    float sky = 0.0;
    #ifdef BV_BEAM_DISSOLVE

        {
            vec3 fogPos = vec3(playerPos.x, 0.0, playerPos.z);
            DoFog(color.rgb, sky, length(fogPos), fogPos, VdotU, VdotS, dither);
            float cover = 0.0;
            #ifdef CLOUD_SHADOWS
                cover = vcCloudCoverAt(bvBeamWorld.xz);
            #endif
            float deckIn = smoothstep(VC_CSM_ALT_B, VC_CSM_ALT_B + 0.7 * VC_CSM_THICK_B, bvBeamWorld.y);
            color.a *= 1.0 - cover * deckIn;

            color.a *= 1.0 - smoothstep(600.0, 1000.0, bvBeamWorld.y);
        }
    #else
        if (playerPos.y > 0.0) {
            playerPos.y = pow(playerPos.y / renderDistance, 0.15) * renderDistance;
        }
        DoFog(color.rgb, sky, lViewPos, playerPos, VdotU, VdotS, dither);
    #endif
    color.a *= 1.0 - sky;

/* DRAWBUFFERS:06 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
}

#endif

#ifdef VERTEX_SHADER

out vec2 texCoord;

flat out vec3 upVec, sunVec;

out vec4 glColor;

#ifdef TAA
    #include "/lib/antialiasing/jitter.glsl"
#endif

#ifdef OVERWORLD

    #include "/lib/atmospherics/clouds/cloudLightSources.glsl"
    #ifndef INCLUDE_BV_STATE_IMAGE
        #define INCLUDE_BV_STATE_IMAGE
        layout(rgba32f) uniform image2D bvStateImg;
    #endif
#endif

void main() {
    #ifdef WORLD_CURVATURE_ACTIVE
        gl_Position = bvCurveFTransform();
    #else
        gl_Position = ftransform();
    #endif
    #ifdef TAA
        gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
    #endif

    upVec = normalize(gbufferModelView[1].xyz);
    sunVec = GetSunVector();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    glColor = gl_Color;

    #ifdef OVERWORLD
        vec3 bvBeamPlayer = mat3(gbufferModelViewInverse) * (gl_ModelViewMatrix * gl_Vertex).xyz
                          + gbufferModelViewInverse[3].xyz;
        vec3 bvBeamWorld = bvBeamPlayer + cameraPosition;

        ivec2 cell = ivec2(floor(bvBeamWorld.xz));
        int slot = bvBeamSlot(cell);
        if (bvBeamWorld.y > 330.0) {
            imageStore(bvStateImg, ivec2(BV_BEAM_REP_X + 2 * slot, 0),
                       vec4(vec2(cell) + 0.5, 1.0, bvBeamKey(cell)));
            imageStore(bvStateImg, ivec2(BV_BEAM_REP_X + 2 * slot + 1, 0), vec4(gl_Color.rgb, 1.0));
            imageStore(bvStateImg, BV_BEAM_FLAG, vec4(1.0));
        } else {
            int ix = int(floor(bvBeamWorld.y + 0.5)) + 64;
            if (ix >= 0 && ix < BV_BEAM_SEG_N) {
                int vid = gl_VertexID & 3;
                int row = (vid == 0 || vid == 3) ? BV_BEAM_REPB_ROW : BV_BEAM_REPA_ROW;
                imageStore(bvStateImg, ivec2(BV_BEAM_SEG_X + ix, row + slot), vec4(gl_Color.rgb, 1.0));
            }
        }
    #endif
}

#endif
