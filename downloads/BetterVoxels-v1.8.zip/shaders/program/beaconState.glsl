#include "/lib/common.glsl"

#ifdef CSH

#include "/lib/misc/bvStateImage.glsl"
#include "/lib/atmospherics/clouds/cloudLightSources.glsl"
#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

#ifdef BEAM_STATE_UPDATE

layout(local_size_x = 8, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {
    int s = int(gl_LocalInvocationID.x);

    if (s == 0) {
        vec4 rs = imageLoad(bvStateImg, BV_ST_RAIN);
        float wt = float(worldTime);
        float d = wt - rs.y;
        if (d < -12000.0) d += 24000.0;
        if (d < 0.0 || d > 1200.0) d = 0.0;

        float target = clamp(max(rainStrength, thunderStrength), 0.0, 1.0);
        float r = rs.x;
        if (rs.z < 0.5) r = target;
        else if (target > r) r = min(r + d / float(VC_RAIN_TICKS_IN), target);
        else r = max(r - d / float(VC_RAIN_TICKS_OUT), target);

        imageStore(bvStateImg, BV_ST_RAIN, vec4(r, wt, 1.0, d));
    }

    vec4 rep0 = imageLoad(bvStateImg, ivec2(BV_BEAM_REP_X + 2 * s, 0));
    vec4 rep1 = imageLoad(bvStateImg, ivec2(BV_BEAM_REP_X + 2 * s + 1, 0));
    ivec2 sx = ivec2(BV_BEAM_STATE_X + 4 * s, 0);
    vec4 st0 = imageLoad(bvStateImg, sx);
    vec4 st1 = imageLoad(bvStateImg, sx + ivec2(1, 0));
    vec4 st2 = imageLoad(bvStateImg, sx + ivec2(2, 0));
    vec4 st3 = imageLoad(bvStateImg, sx + ivec2(3, 0));
    float dt = clamp(frameTime, 0.0, 0.25);

    if (rep0.b > 0.5) {
        float h = -1000.0;
        float yBase = 1000.0;
        float baseInA = 0.0;
        for (int ix = 0; ix < BV_BEAM_SEG_N; ix++) {
            float a = imageLoad(bvStateImg, ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_REPA_ROW + s)).a;
            float b = imageLoad(bvStateImg, ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_REPB_ROW + s)).a;
            if (a > 0.5 || b > 0.5) {
                float y = float(ix - 64);
                h = max(h, y);
                if (y < yBase) {
                    yBase = y;
                    baseInA = a > 0.5 ? 1.0 : 0.0;
                }
            }
        }
        if (h < -999.0) h = st0.w;
        if (yBase > 999.0) yBase = h;

        float swapped = baseInA > 0.5 ? 0.0 : 1.0;

        bool isNew = abs(st0.x - rep0.a) > 0.5 || st0.z > 1.0;
        if (isNew) {
            st0 = vec4(rep0.a, 0.0, 0.0, h);
            st1 = vec4(rep1.rgb, 99.0);
            st2 = vec4(rep1.rgb, yBase);
        } else {
            st0 = vec4(st0.x, min(st0.y + dt, 99.0), 0.0, h);
            if (distance(rep1.rgb, st1.rgb) > 0.02) {
                st2.rgb = st1.rgb;
                st1 = vec4(rep1.rgb, 0.0);
            } else {
                st1.a = min(st1.a + dt, 99.0);
            }
            st2.a = yBase;
        }
        st3 = vec4(swapped, 0.0, 0.0, 1.0);
    } else {
        st0.z = min(st0.z + dt, 99.0);
    }

    imageStore(bvStateImg, sx, st0);
    imageStore(bvStateImg, sx + ivec2(1, 0), st1);
    imageStore(bvStateImg, sx + ivec2(2, 0), st2);
    imageStore(bvStateImg, sx + ivec2(3, 0), st3);
}

#else

layout(local_size_x = 64, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(6, 17, 1);

void main() {
    int ix = int(gl_GlobalInvocationID.x);
    int r = int(gl_GlobalInvocationID.y);
    if (r == 16) {
        if (ix <= 16) imageStore(bvStateImg, ivec2(BV_BEAM_REP_X + ix, 0), vec4(0.0));
        return;
    }
    if (ix >= BV_BEAM_SEG_N) return;
    ivec2 src = ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_REPA_ROW + r);
    imageStore(bvStateImg, ivec2(BV_BEAM_SEG_X + ix, BV_BEAM_STA_ROW + r), imageLoad(bvStateImg, src));
    imageStore(bvStateImg, src, vec4(0.0));
}

#endif

#endif
