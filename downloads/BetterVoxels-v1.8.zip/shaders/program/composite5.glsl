
#include "/lib/common.glsl"

#if LOW_HEALTH == 1 && LOW_HEALTH_GLARE > 0
    #include "/lib/post/effects/effectsCommon.glsl"
    #include "/lib/post/effects/lowHealth.glsl"
#endif

#ifdef FRAGMENT_SHADER

noperspective in vec2 texCoord;

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    flat in vec3 upVec, sunVec;
#endif

float pw = 1.0 / viewWidth;
float ph = 1.0 / viewHeight;

vec2 view = vec2(viewWidth, viewHeight);

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    float SdotU = dot(sunVec, upVec);
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
#endif

#define BV_AUTO_EXPOSURE_WRITER
#include "/lib/misc/autoExposure.glsl"
#define BV_CUSTOM_BIOME_WRITER
#include "/lib/atmospherics/customBiomeColor.glsl"
#include "/lib/atmospherics/fog/volumetricSea.glsl"
#include "/lib/post/colorSpaces.glsl"

void LinearToRGB(inout vec3 color) {
    const vec3 k = vec3(0.055);
    color = mix((vec3(1.0) + k) * pow(color, vec3(1.0 / 2.4)) - k, 12.92 * color, lessThan(color, vec3(0.0031308)));
}

void DoCompTonemap(inout vec3 color) {
    #if AUTO_EXPOSURE == 1
        color = TM_EXPOSURE * bvAutoExposure() * color;
    #else
        color = TM_EXPOSURE * color;
    #endif

    float colorMax = max(color.r, max(color.g, color.b));
    float initialLuminance = GetLuminance(color);

    vec3 a      = vec3(TM_CONTRAST);
    vec3 d      = vec3(1.0);
    vec3 hdrMax = vec3(8.0);
    vec3 midIn  = vec3(0.25);
    vec3 midOut = vec3(0.25);

    vec3 a_d = a * d;
    vec3 hdrMaxA = pow(hdrMax, a);
    vec3 hdrMaxAD = pow(hdrMax, a_d);
    vec3 midInA = pow(midIn, a);
    vec3 midInAD = pow(midIn, a_d);
    vec3 HM1 = hdrMaxA * midOut;
    vec3 HM2 = hdrMaxAD - midInAD;

    vec3 b = (-midInA + HM1) / (HM2 * midOut);
    vec3 c = (hdrMaxAD * midInA - HM1 * midInAD) / (HM2 * midOut);

    #if TONE_SPACE > 0

        vec3 colorW = max(color * bvCsToWork, vec3(0.0));
        vec3 colorOut = max((pow(colorW, a) / (pow(colorW, a_d) * b + c)) * bvCsFromWork, vec3(0.0));
    #else
        vec3 colorOut = pow(color, a) / (pow(color, a_d) * b + c);
    #endif

    LinearToRGB(colorOut);

    const float darkLiftStart = 0.1;
    const float darkLiftMix = 0.75;
    float darkLift = smoothstep(darkLiftStart, 0.0, initialLuminance);
    vec3 smoothColor = pow(color, vec3(1.0 / 2.2));
    colorOut = mix(colorOut, smoothColor, darkLift * darkLiftMix * max0(0.55 - abs(1.05 - TM_CONTRAST)) / 0.55);

    const float wpInputCurveStart = 0.0;
    const float wpInputCurveMax = 16.0;
    float modifiedLuminance = pow(initialLuminance / wpInputCurveMax, 2.0 - TM_WHITE_PATH) * wpInputCurveMax;
    float whitePath = smoothstep(wpInputCurveStart, wpInputCurveMax, modifiedLuminance);
    colorOut = mix(colorOut, vec3(1.0), whitePath);

    const float dpInputCurveStart = 0.1;
    const float dpInputCurveMax = 0.0;
    float desaturatePath = smoothstep(dpInputCurveStart, dpInputCurveMax, initialLuminance);
    colorOut = mix(colorOut, vec3(GetLuminance(colorOut)), desaturatePath * TM_DARK_DESATURATION);

    color = clamp01(colorOut);
}

void DoBSLColorSaturation(inout vec3 color) {
    float saturationFactor = T_SATURATION + 0.07;

    float grayVibrance = (color.r + color.g + color.b) / 3.0;
    float graySaturation = grayVibrance;
    if (saturationFactor < 1.00) graySaturation = dot(color, vec3(0.299, 0.587, 0.114));

    float mn = min(color.r, min(color.g, color.b));
    float mx = max(color.r, max(color.g, color.b));
    float sat = (1.0 - (mx - mn)) * (1.0 - mx) * grayVibrance * 5.0;
    vec3 lightness = vec3((mn + mx) * 0.5);

    color = mix(color, mix(color, lightness, 1.0 - T_VIBRANCE), sat);
    color = mix(color, lightness, (1.0 - lightness) * (2.0 - T_VIBRANCE) / 2.0 * abs(T_VIBRANCE - 1.0));
    color = color * saturationFactor - graySaturation * (saturationFactor - 1.0);
}

#include "/lib/post/tonemappers.glsl"
#include "/lib/post/colorGrading.glsl"

#ifdef BLOOM
    vec2 rescale = max(vec2(viewWidth, viewHeight) / vec2(1920.0, 1080.0), vec2(1.0));
    vec3 GetBloomTile(float lod, vec2 coord, vec2 offset) {
        float scale = exp2(lod);
        vec2 bloomCoord = coord / scale + offset;
        bloomCoord = clamp(bloomCoord, offset, 1.0 / scale + offset);

        vec3 bloom = texture2D(colortex3, bloomCoord / rescale).rgb;
        bloom *= bloom;
        bloom *= bloom;
        return bloom * 128.0;
    }

    void DoBloom(inout vec3 color, vec2 coord, float dither, float lViewPos) {
        vec3 blur1 = GetBloomTile(2.0, coord, vec2(0.0      , 0.0   ));
        vec3 blur2 = GetBloomTile(3.0, coord, vec2(0.0      , 0.26  ));
        vec3 blur3 = GetBloomTile(4.0, coord, vec2(0.135    , 0.26  ));
        vec3 blur4 = GetBloomTile(5.0, coord, vec2(0.2075   , 0.26  ));
        vec3 blur5 = GetBloomTile(6.0, coord, vec2(0.135    , 0.3325));
        vec3 blur6 = GetBloomTile(7.0, coord, vec2(0.160625 , 0.3325));
        vec3 blur7 = GetBloomTile(8.0, coord, vec2(0.1784375, 0.3325));

        vec3 blur = (blur1 + blur2 + blur3 + blur4 + blur5 + blur6 + blur7) * 0.14;

        float bloomStrength = BLOOM_STRENGTH + 0.2 * darknessFactor;

        #if LOW_HEALTH == 1 && LOW_HEALTH_GLARE > 0
            bloomStrength *= mix(1.0, LOW_HEALTH_GLARE * 0.01, bvLowHealthDanger());
        #endif

        #if defined BLOOM_FOG && defined NETHER && defined BORDER_FOG_ACTIVE
            float farM = min(renderDistance, NETHER_VIEW_LIMIT_M);
            float netherBloom = lViewPos / clamp(farM, 96.0, NETHER_FOG_CAP);
            netherBloom *= netherBloom;
            netherBloom *= netherBloom;
            netherBloom = 1.0 - exp(-8.0 * netherBloom);
            netherBloom *= 1.0 - maxBlindnessDarkness;
            bloomStrength = mix(bloomStrength * 0.7, bloomStrength * 1.8, netherBloom);
        #endif

        color = mix(color, blur, bloomStrength);

    }
#endif

#ifdef BLOOM_FOG
    #include "/lib/atmospherics/fog/bloomFog.glsl"
#endif

#ifdef BLOOM
    #include "/lib/util/dither.glsl"
#endif

#if LENSFLARE_MODE > 0 && defined OVERWORLD
    #include "/lib/misc/lensFlare.glsl"
#endif

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;

    #if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
        float z0 = texture2D(depthtex0, texCoord).r;

        vec4 screenPos = vec4(texCoord, z0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
        viewPos /= viewPos.w;
        float lViewPos = length(viewPos.xyz);

        #if defined LOD_ACTIVE && defined NETHER
            float z0DH = texelFetch(lodDepthTex0, texelCoord, 0).r;
            vec4 screenPosDH = vec4(texCoord, z0DH, 1.0);
            vec4 viewPosDH = lodProjectionInverse * (screenPosDH * 2.0 - 1.0);
            viewPosDH /= viewPosDH.w;
            lViewPos = min(lViewPos, length(viewPosDH.xyz));
        #endif
    #else
        float lViewPos = 0.0;
    #endif

    float dither = texture2D(noisetex, texCoord * view / 128.0).b;
    #ifdef TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #if (defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE) && defined OVERWORLD
        if (isEyeInWater == 0) {
            float seaZ = texture2D(depthtex0, texCoord).r;
            vec4 seaHit = gbufferProjectionInverse * (vec4(texCoord, seaZ, 1.0) * 2.0 - 1.0);
            vec4 seaFar = gbufferProjectionInverse * (vec4(texCoord, 1.0, 1.0) * 2.0 - 1.0);
            vec3 seaDir = normalize(mat3(gbufferModelViewInverse) * (seaFar.xyz / seaFar.w));
            vec3 seaSun = normalize(mat3(gbufferModelViewInverse) * sunVec);
            float seaDist = seaZ >= 1.0 ? 65536.0 : length(seaHit.xyz / seaHit.w);
            #ifdef VOL_FOG_ACTIVE
                bvVolumetricSea(color, seaDir, seaSun, seaDist, dither);
            #endif
            #ifdef VOLCAVE_ACTIVE
                bvCaveFog(color, seaDir, seaSun, seaDist, dither);
            #endif
        }
    #endif

    #ifdef BLOOM_FOG
        color /= GetBloomFog(lViewPos);
    #endif

    #ifdef BLOOM
        DoBloom(color, texCoord, dither, lViewPos);
    #endif

    #ifdef COLORGRADING
        color =
            pow(color.r, GR_RC) * vec3(GR_RR, GR_RG, GR_RB) +
            pow(color.g, GR_GC) * vec3(GR_GR, GR_GG, GR_GB) +
            pow(color.b, GR_BC) * vec3(GR_BR, GR_BG, GR_BB);
        color *= 0.01;
    #endif

    #if AUTO_EXPOSURE == 1
        if (texelCoord == ivec2(0, 0)) bvAutoExposureUpdate(colortex0, depthtex0);
    #endif

    #if CUSTOM_BIOME_SUPPORT == 1 && BIOME_ATMOSPHERE == 1
        if (texelCoord == ivec2(0, 0)) bvCustomBiomeUpdate(colortex0, depthtex0);
    #endif

    #ifdef BV_GRADE_SCENE
        bvGradeScene(color);
    #endif

    #if TONEMAPPER == 0
        DoCompTonemap(color);
    #else
        bvTonemap(color);
    #endif

    #if defined GREEN_SCREEN_LIME || SELECT_OUTLINE >= 0
        int materialMaskInt = int(texelFetch(colortex6, texelCoord, 0).g * 255.1);
    #endif

    #ifdef GREEN_SCREEN_LIME
        if (materialMaskInt == 240) {
            color = vec3(0.0, 1.0, 0.0);
        }
    #endif

    #if SELECT_OUTLINE == 4
        if (materialMaskInt == 252) {
            float colorMF = 1.0 - dot(color, vec3(0.25, 0.45, 0.1));
            colorMF = smoothstep1(smoothstep1(smoothstep1(smoothstep1(smoothstep1(colorMF)))));
            color = mix(color, 3.0 * (color + 0.2) * vec3(colorMF * SELECT_OUTLINE_I), 0.3);
        }
    #endif

    #if LENSFLARE_MODE > 0 && defined OVERWORLD
        DoLensFlare(color, viewPos.xyz, dither);
    #endif

    #if TONEMAPPER == 0
        DoBSLColorSaturation(color);
    #endif

    #ifdef BV_GRADE_DISPLAY
        bvGradeDisplay(color);
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(color, 1.0);
}

#endif

#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    flat out vec3 upVec, sunVec;
#endif

void main() {
    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    #if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
        upVec = normalize(gbufferModelView[1].xyz);
        sunVec = GetSunVector();
    #endif
}

#endif
