#include "/lib/common.glsl"

#ifdef CSH

#if CLOUD_STYLE == 4

#include "/lib/atmospherics/clouds/volumetricSettings.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;

#if VC_WEATHER_BANDS == 3
    const ivec3 workGroups = ivec3(128, 384, 1);
#elif VC_WEATHER_BANDS == 2
    const ivec3 workGroups = ivec3(128, 256, 1);
#else
    const ivec3 workGroups = ivec3(128, 128, 1);
#endif

#define VC_NOISE_WRITER

layout(rgba16f) uniform image2D vcWeatherImg;
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricWeather.glsl"

#if VC_WEATHER_RES != 1024
    #error "VC_WEATHER_RES changed - the workGroups literals at the top of this file are VC_WEATHER_RES / 8 written out by hand and no longer match."
#endif

void main() {
    ivec2 id = ivec2(gl_GlobalInvocationID.xy);
    if (id.x >= VC_WEATHER_RES
     || id.y >= VC_WEATHER_RES * VC_WEATHER_BANDS) return;

    int band = id.y / VC_WEATHER_RES;
    ivec2 local = ivec2(id.x, id.y - band * VC_WEATHER_RES);

    bool vcWrite = true;
    #if VC_Q_SPLIT > 1
        bool vcFull = distance(cameraPosition, previousCameraPosition) > 16.0;
        vcWrite = vcFull || ((local.x + local.y + frameCounter) & 1) == 0;
    #endif

    vec2 uv = (vec2(local) + 0.5) / float(VC_WEATHER_RES);
    vec2 worldXZ = cameraPosition.xz + vcMapUnproject(uv);
    if (vcWrite) imageStore(vcWeatherImg, id, vcBuildWeather(worldXZ, cloudSyncedTime, band));

    #if VC_PHYSICS == 1

        #if VC_Q_SPLIT > 1
            const int vcPhN = 4;
        #else
            const int vcPhN = 1;
        #endif
        bool vcPhTurn = true;
        #if VC_Q_SPLIT > 1
            vcPhTurn = vcFull || (((local.x >> 2) + 2 * (local.y >> 2) + frameCounter) & 3) == 0;
        #endif
        if (band == 0 && (local.x & 3) == 0 && (local.y & 3) == 0 && vcPhTurn) {
            ivec2 pid = local / 4;
            vec2 puv = (vec2(pid) + 0.5) / float(VC_PHYS_RES);
            vec2 pxz = cameraPosition.xz + vcMapUnproject(puv);
            float pc, ph;
            vec4 col = vcPhysicsColumn(pxz, vcPressure(pxz / float(VC_DOMAIN), cloudSyncedTime).x,
                                       pc, ph);

            ivec2 p1 = ivec2(VC_PHYS_X0, VC_PHYS_Y0) + pid;
            ivec2 p2 = ivec2(VC_PHYS2_X0, VC_PHYS_Y0) + pid;
            vec4 old1 = imageLoad(vcWeatherImg, p1);
            vec4 old2 = imageLoad(vcWeatherImg, p2);

            float ticks = max(texelFetch(bv_state_sampler, BV_ST_RAIN, 0).a, frameTime * 20.0)
                        * float(vcPhN);
            float k = old2.a < 0.5 ? 1.0 : 1.0 - exp(-ticks / (float(VC_PH_SMOOTH) * 20.0));
            imageStore(vcWeatherImg, p1, mix(old1, col, k));
            imageStore(vcWeatherImg, p2, vec4(mix(old2.rg, vec2(pc, ph), k), 0.0, 1.0));
        }
    #endif
}

#else

layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}

#endif

#endif
