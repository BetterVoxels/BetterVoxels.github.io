
#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER

flat in vec2 lmCoord;
in vec2 texCoord;

flat in vec3 upVec, sunVec;

flat in vec4 glColor;

float SdotU = dot(sunVec, upVec);
float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;

#include "/lib/colors/lightAndAmbientColors.glsl"

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/misc/colorCodedPrograms.glsl"
#endif

void main() {
    #if PERSONAL_WEATHER == 1
        discard;
    #endif

    #if NO_RAIN_ABOVE_CLOUDS == 1

        float rainAbove = 1.0 - bvRainBelow;
        if (rainAbove >= 1.0) discard;
    #endif

    vec4 color = texture2D(tex, texCoord);
    color *= glColor;

    #if NO_RAIN_ABOVE_CLOUDS == 1
        color.a *= 1.0 - rainAbove;
    #endif

    if (color.a < 0.1 || isEyeInWater == 3) discard;

    bool bvIsRainDrop = color.r + color.g < 1.5;
    if (bvIsRainDrop) color.a *= rainTexOpacity;
    else color.a *= snowTexOpacity;

    color.rgb = sqrt3(color.rgb) * (blocklightCol * 2.0 * lmCoord.x + (ambientColor + 0.2 * lightColor) * lmCoord.y * (0.6 + 0.3 * sunFactor));

    #if BIOME_RAIN_COLOR == 1
        if (bvIsRainDrop) {
            color.rgb = bvBiomeWaterTint(color.rgb, bvBiomeWaterColor(), 0.85);
        }
    #endif

    #ifdef COLOR_CODED_PROGRAMS
        ColorCodeProgram(color, -1);
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}

#endif

#ifdef VERTEX_SHADER

flat out vec2 lmCoord;
out vec2 texCoord;

flat out vec3 upVec, sunVec;

flat out vec4 glColor;

void main() {
    vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    glColor = gl_Color;

    #ifdef WAVING_RAIN
        float rainWavingFactor = eyeBrightnessM2;
        position.xz += rainWavingFactor * (0.4 * position.y + 0.2) * vec2(sin(frameTimeCounter * 0.3) + 0.5, sin(frameTimeCounter * 0.5) * 0.5);
        position.xz *= 1.0 - 0.08 * position.y * rainWavingFactor;
    #endif

    #ifdef WORLD_CURVATURE_ACTIVE
        position.xyz = bvCurveWorld(position.xyz);
    #endif

    gl_Position = gl_ProjectionMatrix * gbufferModelView * position;

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = GetLightMapCoordinates();

    upVec = normalize(gbufferModelView[1].xyz);
    sunVec = GetSunVector();
}

#endif
