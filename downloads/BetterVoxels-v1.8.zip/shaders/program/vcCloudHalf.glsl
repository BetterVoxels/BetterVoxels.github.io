
ivec2 vcHalfPix = ivec2(0);
#define gl_FragCoord vec4(vec2(vcHalfPix) + 0.5, 0.99, 1.0)

#include "/lib/common.glsl"

#ifdef CLOUDS_VOLUMETRIC
    #include "/lib/atmospherics/clouds/volumetricSettings.glsl"
#endif

#if defined CLOUDS_VOLUMETRIC && VC_HALF_BLOCK == 4
    const vec2 workGroupsRender = vec2(0.25, 0.25);
#else
    const vec2 workGroupsRender = vec2(0.5, 0.5);
#endif

layout(local_size_x = 8, local_size_y = 8) in;

#if defined CLOUDS_VOLUMETRIC && VC_HALF_RES == 1

#ifdef BV_DAILY_SUN
    float vcHalfPathDeg = sunPathRotation + bvDailySunOffset();
    vec2 sunRotationData = vec2(cos(vcHalfPathDeg * 0.01745329251994), -sin(vcHalfPathDeg * 0.01745329251994));
#else
    const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
#endif
float vcHalfAng0 = fract(timeAngle - 0.25);
float vcHalfAng = (vcHalfAng0 + (cos(vcHalfAng0 * 3.14159265358979) * -0.5 + 0.5 - vcHalfAng0) / 3.0) * 6.28318530717959;
vec3 sunVec = normalize((gbufferModelView * vec4(vec3(-sin(vcHalfAng), cos(vcHalfAng) * sunRotationData) * 2000.0, 1.0)).xyz);
vec3 upVec = normalize(gbufferModelView[1].xyz);

float SdotU = dot(sunVec, upVec);
float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;
float farMinusNear = far - near;

vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);

float vlFactor = 0.0;

#include "/lib/util/spaceConversion.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/atmospherics/fog/mainFog.glsl"
#include "/lib/colors/skyColors.glsl"
#include "/lib/atmospherics/clouds/mainClouds.glsl"

#define VC_HALF_WRITER
#include "/lib/atmospherics/clouds/cloudHalfRes.glsl"

#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/colorMultipliers.glsl"
#endif
#ifdef MOON_PHASE_INF_ATMOSPHERE
    #include "/lib/colors/moonPhaseInfluence.glsl"
#endif

layout(rgba16f) uniform image2D vcCloudImg;

void main() {
    ivec2 full = ivec2(viewWidth, viewHeight);
    ivec2 halfS = VcHalfSize();
    ivec2 b = ivec2(gl_GlobalInvocationID.xy);
    if (b.x >= halfS.x || b.y >= halfS.y) return;

    int ph = frameCounter & (VC_HALF_BLOCK * VC_HALF_BLOCK - 1);
    ivec2 o = ivec2(-1);
    for (int k = 0; k < VC_HALF_BLOCK * VC_HALF_BLOCK; k++) {
        ivec2 c = VcHalfPhase(ph + k);
        ivec2 p = VC_HALF_BLOCK * b + c;
        if (p.x < full.x && p.y < full.y && texelFetch(depthtex0, p, 0).r == 1.0
            #ifdef LOD_ACTIVE
                && texelFetch(lodDepthTex0, p, 0).r == 1.0
            #endif
        ) {
            o = c;
            break;
        }
    }
    if (o.x < 0) {
        imageStore(vcCloudImg, b + ivec2(0, halfS.y), vec4(1.0, 0.0, 0.0, 0.0));
        return;
    }
    vcHalfPix = VC_HALF_BLOCK * b + o;

    vec2 texCoordH = (vec2(vcHalfPix) + 0.5) / vec2(full);
    vec4 viewPos = gbufferProjectionInverse * (vec4(texCoordH, 1.0, 1.0) * 2.0 - 1.0);
    viewPos /= viewPos.w;
    float lViewPos = length(viewPos);
    vec3 nViewPos = normalize(viewPos.xyz);
    vec3 playerPos = ViewToPlayer(viewPos.xyz);

    float dither = texelFetch(noisetex, vcHalfPix % 128, 0).b;
    #if defined TAA || defined TEMPORAL_FILTER
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #ifdef ATM_COLOR_MULTS
        atmColorMult = GetAtmColorMult();
        sqrtAtmColorMult = sqrt(atmColorMult);
    #endif

    float VdotU = dot(nViewPos, upVec);
    float VdotS = dot(nViewPos, sunVec);
    float skyFade = 1.0;

    float aboveCloudFactor = clamp((cameraPosition.y - (float(CLOUD_ABOVE_ALT) + 100.0)) / 20.0, 0.0, 1.0);

    float cloudLinearDepth = 1.0;
    vcReprojG = vec4(0.0);
    vec4 clouds = GetClouds(cloudLinearDepth, skyFade, cameraPosition, playerPos,
                            lViewPos, VdotS, VdotU, dither, vec3(0.0), vec3(0.0));
    vec4 vcReprojOut = vcReprojG;

    float dh = cameraPosition.y - (float(CLOUD_ABOVE_ALT) + 50.0);
    float insideLayer = 1.0 - clamp(dh * dh / 3600.0, 0.0, 1.0);
    float grazeFade   = smoothstep(0.02, 0.20, abs(VdotU));
    clouds.a *= mix(1.0, grazeFade, insideLayer);

    float horizonFade = smoothstep(0.0, 0.20, VdotU) * 0.6 + 0.4;
    clouds.a *= mix(1.0, horizonFade, rainFactor * (1.0 - aboveCloudFactor));

    if (clouds.a < 0.9) cloudLinearDepth = 1.0;
    vcReprojOut *= clouds.a / max(vcReprojOut.a, 1e-4);

    imageStore(vcCloudImg, b, clouds);
    imageStore(vcCloudImg, b + ivec2(halfS.x, 0), vcReprojOut);
    imageStore(vcCloudImg, b + ivec2(0, halfS.y), vec4(cloudLinearDepth, vec2(o), 1.0));
}

#else

void main() {}

#endif
