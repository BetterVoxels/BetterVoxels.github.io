
#include "/lib/common.glsl"

#ifdef CSH

#ifdef VC_FAR_SHADOW_MAP

layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
const ivec3 workGroups = ivec3(30, 30, 1);

#include "/lib/atmospherics/clouds/volumetricDensity.glsl"
#include "/lib/atmospherics/clouds/cloudShadowMap.glsl"

layout(rgba16f) uniform image2D vcWeatherImg;

#if VC_FSM_RES != 240
    #error "VC_FSM_RES changed - workGroups above is VC_FSM_RES / 8 written out by hand."
#endif

void main() {
    ivec2 id = ivec2(gl_GlobalInvocationID.xy);
    if (id.x >= VC_FSM_RES || id.y >= VC_FSM_RES) return;

    #if VC_Q_SPLIT > 1
        vec2 vcPrevOrigin = floor(previousCameraPosition.xz / VC_FSM_TEXEL) * VC_FSM_TEXEL;
        bool vcFull = any(notEqual(vcPrevOrigin, vcFsmOrigin()));
        if (!vcFull && ((id.x + id.y + frameCounter) & 1) != 0) return;
    #endif

    vec3 L = vcCsmLightDir();
    vec2 xz = vcFsmWorld(id);

    float cov = VC_COVERAGE * 0.01;
    #if VC_PHYSICS == 1
        cov = vcPhysCoverage();
    #endif
    float den = VC_DENSITY * 0.01;
    #if VC_LOOK == 1
        cov *= 1.30;
        den *= 1.15;
    #elif VC_LOOK == 2
        cov *= 0.70;
        den *= 0.80;
    #endif

    float len = min(VC_CSM_THICK / L.y, VC_CSM_THICK * 10.0);
    float seg = len / float(VC_CSM_STEPS);
    vec3 p0 = vec3(xz.x, vcCsmBaseY(xz), xz.y);

    vcConeG = false;

    float tau = 0.0;
    for (int i = 0; i < VC_CSM_STEPS; i++) {
        vec3 p = p0 + L * (seg * (float(i) + 0.5));
        float h = (vcShellAltitude(p, cameraPosition) - VC_CSM_ALT) / VC_CSM_THICK;
        if (h < 0.0 || h > 1.0) continue;

        tau += vcCloudDensity(p, h, cloudSyncedTime, cov, den, false) * seg;
    }
    tau *= VC_EXTINCTION * 0.001 * VC_G_EXT_MUL;

    #if VC_GENUS_HIGH > 0 && VC_H_SHADOW == 1

        vec3 pTop = p0 + L * len;
        tau += vcHighShadowTau(pTop, VC_CSM_ALT + VC_CSM_THICK, L, cov, den)
             * (VC_EXTINCTION * 0.001 * VC_H_EXT_MUL)
             * (VC_H_SHADOW_STRENGTH * 0.01);
    #endif

    float T = exp(-tau * (VC_GROUND_SHADOW * 0.01));
    imageStore(vcWeatherImg, ivec2(VC_FSM_X0, VC_FSM_Y0) + id, vec4(T, 0.0, 0.0, 1.0));
}

#else

layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}

#endif

#endif
