#include "/lib/common.glsl"

#ifdef CSH

#if CLOUD_STYLE == 4

layout(local_size_x = 4, local_size_y = 4, local_size_z = 4) in;
const ivec3 workGroups = ivec3(32, 32, 32);

#define VC_NOISE_WRITER
#include "/lib/atmospherics/clouds/volumetricNoise.glsl"
#include "/lib/atmospherics/clouds/volumetricProfileData.glsl"

layout(rgba16f) uniform image3D vcShapeImg;
layout(rgba16f) uniform image2D vcWeatherImg;

void main() {
    if (frameCounter > 1) return;

    ivec3 id = ivec3(gl_GlobalInvocationID);

    vec3 sp = vcGenCoord(id, float(VC_SHAPE_RES));
    float sw0 = vcWorley(sp, 4.0);
    float sw1 = vcWorley(sp, 8.0);
    float sw2 = vcWorley(sp, 16.0);
    float sw3 = vcWorley(sp, 32.0);
    float sw4 = vcWorley(sp, 64.0);

    vec4 shape;
    shape.r = vcPerlinWorleyH(sp, 4.0);
    shape.g = sw1 * 0.625 + sw2 * 0.25  + sw3 * 0.125;
    shape.b = sw2 * 0.625 + sw3 * 0.25  + sw4 * 0.125;
    shape.a = sw3 * 0.75  + sw4 * 0.25;
    imageStore(vcShapeImg, id, shape);

    if (id.x < VC_DETAIL_RES && id.y < VC_DETAIL_RES && id.z < VC_DETAIL_RES) {
        vec3 dp = vcGenCoord(id, float(VC_DETAIL_RES));
        float dw0 = vcWorley(dp, 2.0);
        float dw1 = vcWorley(dp, 4.0);
        float dw2 = vcWorley(dp, 8.0);
        float dw3 = vcWorley(dp, 16.0);

        vec4 detail;
        detail.r = dw0 * 0.625 + dw1 * 0.25  + dw2 * 0.125;
        detail.g = dw1 * 0.625 + dw2 * 0.25  + dw3 * 0.125;
        detail.b = dw2 * 0.75  + dw3 * 0.25;
        detail.a = 1.0;
        imageStore(vcShapeImg, id + ivec3(VC_DETAIL_X0, 0, 0), detail);
    }

    if (id.z == 0 && id.x < VC_CURL_RES && id.y < VC_CURL_RES) {
        vec2 cp = vec2(id.xy) / (float(VC_CURL_RES) - 1.0);
        vec2 curl = vcCurl(cp, 4.0) * 0.5 + 0.5;

        float pv = 0.0;
        float pb = 1.0;
        if (id.x < VC_PROFILE_RES && id.y < VC_PROFILE_RES) {
            vec2 c = vec2(id.xy) / float(VC_PROFILE_RES - 1);
            pv = vcProfileEval(c.x, c.y);
            pb = vcProfileBottomEval(c.x, c.y);
        }
        imageStore(vcWeatherImg, id.xy + ivec2(VC_CURL_X0, 0), vec4(curl, pv, pb));
    }
}

#else

layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}

#endif

#endif
