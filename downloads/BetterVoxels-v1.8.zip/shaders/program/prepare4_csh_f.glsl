#include "/lib/common.glsl"

#ifdef CSH

#if CLOUD_STYLE == 4 && defined CLOUD_SHADOWS

layout(local_size_x = 16, local_size_y = 16, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

#include "/lib/atmospherics/clouds/cloudShadowMap.glsl"

layout(rgba16f) uniform image2D vcWeatherImg;

shared float vcCoverSum[256];

void main() {
    ivec2 l = ivec2(gl_LocalInvocationID.xy);
    int idx = l.y * 16 + l.x;

    float s = 0.0;
    for (int a = 0; a < 4; a++) {
        for (int b = 0; b < 4; b++) {
            ivec2 t = ivec2(128) + l * 16 + ivec2(a, b) * 4;
            vec4 m = imageLoad(vcWeatherImg, ivec2(VC_CSM_X0, 0) + t);

            s += mix(1.0, m.r, m.a);
        }
    }
    vcCoverSum[idx] = s * (1.0 / 16.0);
    barrier();

    for (int n = 128; n > 0; n /= 2) {
        if (idx < n) vcCoverSum[idx] += vcCoverSum[idx + n];
        barrier();
    }

    if (idx == 0) {
        float cover = clamp(1.0 - vcCoverSum[0] * (1.0 / 256.0), 0.0, 1.0);
        ivec2 at = ivec2(VC_CSM_X0, VC_CSM_RES);
        vec4 prev = imageLoad(vcWeatherImg, at);

        float k = prev.a < 0.5 ? 1.0 : 1.0 - exp(-frameTime / 3.0);
        imageStore(vcWeatherImg, at, vec4(mix(prev.r, cover, k), 0.0, 0.0, 1.0));
    }
}

#else

layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}

#endif

#endif
