#include "/lib/common.glsl"

#ifdef CSH

const ivec3 workGroups = ivec3(4, 4, 1);
layout(local_size_x = 32, local_size_y = 32) in;

layout(rgba16f) uniform image2D rippleCellImg;

#include "/lib/vx/voxelReading.glsl"
#ifdef WATER_RIPPLES
    #include "/lib/water/waterRipples.glsl"
#endif

const float rwNoWater = -9999.0;

void main() {
    #ifdef WATER_RIPPLES
        ivec2 cell = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(cell, ivec2(rwRippleCells)))) return;

        ivec3 camInt = rwRippleCamInt();
        ivec3 camOffset = camInt - (cameraPositionInt.y == -98257195
                        ? ivec3(floor(previousCameraPosition) + 0.5 * sign(previousCameraPosition))
                        : previousCameraPositionInt);

        ivec2 oldCell = cell + camOffset.xz;
        vec4 was = vec4(rwNoWater, 0.0, 0.0, 0.0);
        if (all(greaterThanEqual(oldCell, ivec2(0))) && all(lessThan(oldCell, ivec2(rwRippleCells)))) {
            was = imageLoad(rippleCellImg, oldCell);
        }
        float wasEntity = was.y;

        if (!rwRippleUpdateFrame()) {
            imageStore(rippleCellImg, cell, was);
            return;
        }

        ivec2 rel = cell - rwRippleCells / 2;
        ivec2 vxXZ = rel + voxelVolumeSize.xz / 2;

        float waterY = rwNoWater;
        float entity = 0.0;

        if (all(greaterThanEqual(vxXZ, ivec2(0))) && all(lessThan(vxXZ, voxelVolumeSize.xz))) {
            int surfaceY = -1;
            for (int k = voxelVolumeSize.y - 1; k >= 0; k--) {
                ivec3 coords = ivec3(vxXZ.x, k, vxXZ.y);
                if ((imageLoad(voxelCols, coords * ivec3(1, 2, 1)).r >> 26 & 1) == 1) {
                    surfaceY = k;
                    break;
                }
            }

            if (surfaceY >= 0) {
                waterY = float(surfaceY - voxelVolumeSize.y / 2);

                for (int i = -1; i <= 1; i++) {
                    int k = surfaceY + i;
                    if (k < 0 || k >= voxelVolumeSize.y) continue;
                    ivec3 coords = ivec3(vxXZ.x, k, vxXZ.y);
                    if ((imageLoad(voxelCols, coords * ivec3(1, 2, 1)).r >> 26 & 2) != 0) {
                        entity = 1.0;
                        break;
                    }
                }
            }
        }

        imageStore(rippleCellImg, cell, vec4(waterY, entity, wasEntity, 0.0));
    #endif
}

#endif
