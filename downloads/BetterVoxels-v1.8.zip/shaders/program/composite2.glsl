
#include "/lib/common.glsl"

#if LOW_HEALTH == 1 && LOW_HEALTH_MOTION > 0
    #define BV_MOTION_PASS
#endif
#ifdef MOTION_BLURRING_ACTIVE
    #define BV_MOTION_PASS
#endif

#ifdef FRAGMENT_SHADER

#if LOW_HEALTH == 1 && LOW_HEALTH_MOTION > 0
    #include "/lib/post/effects/effectsCommon.glsl"
    #include "/lib/post/effects/lowHealth.glsl"
#endif

#ifdef BV_MOTION_PASS
    noperspective in vec2 texCoord;

    #ifdef BLOOM_FOG_COMPOSITE2
        flat in vec3 upVec, sunVec;
    #endif
#endif

#if defined MOTION_BLURRING_ACTIVE && defined BLOOM_FOG_COMPOSITE2
    float SdotU = dot(sunVec, upVec);
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
#endif

#ifdef BV_MOTION_PASS
    vec3 MotionBlur(vec3 color, float z, float dither) {
        if (z > 0.56) {
            float mbwg = 0.0;
            vec2 doublePixel = 2.0 / vec2(viewWidth, viewHeight);
            vec3 mblur = vec3(0.0);

            vec4 currentPosition = vec4(texCoord, z, 1.0) * 2.0 - 1.0;

            #ifdef LOD_ACTIVE
                float zDH = texture2D(lodDepthTex1, texCoord).x;
                vec4 viewPos = (z >= 1.0 && zDH < 1.0)
                    ? lodProjectionInverse * (vec4(texCoord, zDH, 1.0) * 2.0 - 1.0)
                    : gbufferProjectionInverse * currentPosition;
            #else
                vec4 viewPos = gbufferProjectionInverse * currentPosition;
            #endif

            viewPos = gbufferModelViewInverse * viewPos;
            viewPos /= viewPos.w;

            vec3 cameraOffset = cameraPosition - previousCameraPosition;

            vec4 previousPosition = viewPos + vec4(cameraOffset, 0.0);
            previousPosition = gbufferPreviousModelView * previousPosition;
            previousPosition = gbufferPreviousProjection * previousPosition;
            previousPosition /= previousPosition.w;

            vec2 velocity = (currentPosition - previousPosition).xy;

            #ifdef MOTION_BLURRING_ACTIVE
                float mbStrength = MOTION_BLURRING_STRENGTH;
            #else
                float mbStrength = 0.0;
            #endif
            #if LOW_HEALTH == 1 && LOW_HEALTH_MOTION > 0
                mbStrength = max(mbStrength,
                                 mix(mbStrength, LOW_HEALTH_MOTION * 0.01, bvLowHealthDanger()));
            #endif
            #if LOW_OXYGEN == 1 && LOW_OXYGEN_MOTION > 0
                mbStrength = max(mbStrength,
                                 mix(mbStrength, LOW_OXYGEN_MOTION * 0.01, bvOxygenStress()));
            #endif
            if (mbStrength < 0.001) return color;

            velocity = velocity / (1.0 + length(velocity)) * mbStrength * 0.02;

            vec2 coord = texCoord - velocity * (3.5 + dither);
            for (int i = 0; i < 9; i++, coord += velocity) {
                vec2 coordb = clamp(coord, doublePixel, 1.0 - doublePixel);
                mblur += texture2DLod(colortex0, coordb, 0).rgb;
                mbwg += 1.0;
            }
            mblur /= mbwg;

            return mblur;
        } else return color;
    }
#endif

#ifdef BV_MOTION_PASS
    #include "/lib/util/dither.glsl"

    #ifdef BLOOM_FOG_COMPOSITE2
        #include "/lib/atmospherics/fog/bloomFog.glsl"
    #endif
#endif

void main() {
    vec3 color = texelFetch(colortex0, texelCoord, 0).rgb;

    #ifdef BV_MOTION_PASS
        float z = texture2D(depthtex1, texCoord).x;
        float dither = Bayer64(gl_FragCoord.xy);

        color = MotionBlur(color, z, dither);

        #ifdef BLOOM_FOG_COMPOSITE2
            float z0 = texelFetch(depthtex0, texelCoord, 0).r;
            vec4 screenPos = vec4(texCoord, z0, 1.0);
            vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
            viewPos /= viewPos.w;
            float lViewPos = length(viewPos.xyz);

            #if defined LOD_ACTIVE && defined NETHER
                float z0DH = texelFetch(lodDepthTex0, texelCoord, 0).r;
                vec4 screenPosDH = vec4(texCoord, z0DH, 1.0);
                vec4 viewPosDH = lodProjectionInverse * (screenPosDH * 2.0 - 1.0);
                viewPosDH /= viewPosDH.w;
                lViewPos = min(lViewPos, length(viewPosDH.xyz));
            #endif

            color *= GetBloomFog(lViewPos);
        #endif
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

#endif

#ifdef VERTEX_SHADER

#ifdef BV_MOTION_PASS
    noperspective out vec2 texCoord;

    #ifdef BLOOM_FOG_COMPOSITE2
        flat out vec3 upVec, sunVec;
    #endif
#endif

void main() {
    gl_Position = ftransform();

    #ifdef BV_MOTION_PASS
        texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

        #ifdef BLOOM_FOG_COMPOSITE2
            upVec = normalize(gbufferModelView[1].xyz);
            sunVec = GetSunVector();
        #endif
    #endif
}

#endif
