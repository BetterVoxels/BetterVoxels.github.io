#version 430

#define CSH
#define OVERWORLD
#define BEAM_STATE_UPDATE
#include "/program/beaconState.glsl"
