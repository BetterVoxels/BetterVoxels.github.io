#version 430
#define PREPARE4
#define CSH
#define OVERWORLD
#include "/program/prepare4_csh_f.glsl"
