#version 130
#extension GL_ARB_shader_image_load_store : enable

#define FRAGMENT_SHADER
#define NETHER
#define COMPOSITE5

#include "/program/composite5.glsl"
