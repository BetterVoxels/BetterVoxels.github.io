#ifndef INCLUDE_FX_LOW_HEALTH
#define INCLUDE_FX_LOW_HEALTH

#include "/lib/misc/easeCurves.glsl"

uniform float currentPlayerHealth;
uniform float maxPlayerHealth;

uniform float fxHealth;
uniform float fxHurt;
uniform float fxHurtAmount;
uniform float fxDeath;

float fxHeartbeat(float t) {
    float phase = fract(t);
    float lub = phase - 0.06;
    float dub = phase - 0.30;
    return exp2(-260.0 * lub * lub) + exp2(-190.0 * dub * dub) * 0.62;
}

vec3 fxBloodRamp(float luma) {
    float l = max(luma, 0.0);
    l /= 1.0 + l * 0.9;
    return vec3(l * 1.30 + 0.06, l * l * 0.55, l * l * 0.47);
}

void bvLowHealthDangerDeath(out float danger, out float death) {
    danger = 0.0;
    death = 0.0;
    if (currentPlayerHealth < 0.0) return;

    bool dead = currentPlayerHealth * maxPlayerHealth <= 0.0;

    float ramp = 1.0 - clamp(fxHealth / max(float(LOW_HEALTH_START), 1.0), 0.0, 1.0);
    danger = bvEaseCurve(ramp, LOW_HEALTH_CURVE);

    death = clamp(fxDeath, 0.0, 1.0);
    if (!dead) death = fxRetimeDecay(death, 3.0, max(LOW_HEALTH_REVIVE_TIME, 0.05));

    danger = max(danger, death);
}

float bvLowHealthDanger() {
    float danger, death;
    bvLowHealthDangerDeath(danger, death);
    return danger;
}

void bvLowHealthState(vec2 uv, out float danger, out float death, out float hurt,
                      out float beat, out float vig, out float radius) {
    hurt = 0.0;
    beat = 0.0;
    vig = 0.0;
    radius = length(uv * 2.0 - 1.0);

    bvLowHealthDangerDeath(danger, death);
    if (currentPlayerHealth < 0.0) return;

    hurt = clamp(fxHurt, 0.0, 1.0)
         * clamp(0.3 + fxHurtAmount / 7.0, 0.0, 1.0)
         * (LOW_HEALTH_HURT * 0.01);

    beat = fxHeartbeat(frameTimeCounter * LOW_HEALTH_PULSE_RATE * (0.75 + 0.7 * danger));

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);
    float reach = max(LOW_HEALTH_VIGNETTE * 0.01, 0.001)
                * (0.55 + 0.45 * danger)
                * (1.0 + (beat - 0.2) * 0.30 * pulseK);
    vig = clamp((radius - (1.0 - reach)) / max(reach, 0.001), 0.0, 1.0);
    vig *= vig;
}

vec2 bvLowHealthWarpUV(vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && death < 0.002) return uv;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);
    float edge = vig * danger * mix(1.0, 0.5 + 0.85 * beat, pulseK);

    vec2 outward = uv - 0.5;

    #if LOW_HEALTH_DIZZY > 0
        float dizzy = danger * (LOW_HEALTH_DIZZY * 0.01);
        if (dizzy > 0.002) {
            float t = frameTimeCounter * LOW_HEALTH_DIZZY_RATE;
            float aspect = fxAspect().x;
            vec2 c = outward * vec2(aspect, 1.0);

            float swirl = sin(t * 6.2831853) * dizzy * 0.10 * (0.30 + length(c));
            float sn = sin(swirl);
            float cs = cos(swirl);
            c = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
            c *= (1.0 - dizzy * 0.05) * (1.0 + sin(t * 4.1 + 1.7) * dizzy * 0.045);

            outward = c / vec2(aspect, 1.0);
        }
    #endif

    #if LOW_HEALTH_ZOOM > 0
        outward *= 1.0 - edge * (LOW_HEALTH_ZOOM * 0.01) * 0.035;
    #endif

    vec2 warped = 0.5 + outward;

    #if LOW_HEALTH_DEATH_GLITCH > 0
        float glitch = death * (LOW_HEALTH_DEATH_GLITCH * 0.01);
        if (glitch > 0.004) {
            float tick = floor(frameTimeCounter * 11.0);
            float band = floor(uv.y * 38.0);
            if (fxHash12(vec2(band, tick)) > 1.0 - 0.35 * glitch) {
                warped.x += (fxHash12(vec2(band, tick + 31.0)) - 0.5) * 0.12 * glitch;
            }
            if (fxHash12(vec2(tick, 7.0)) > 1.0 - 0.20 * glitch) {
                warped.y += (fxHash12(vec2(tick, 19.0)) - 0.5) * 0.05 * glitch;
            }
        }
    #endif

    return clamp(warped, vec2(0.001), vec2(0.999));
}

float bvLowHealthSplit() {
    #if LOW_HEALTH_DEATH_GLITCH > 0
        float danger, death, hurt, beat, vig, radius;
        bvLowHealthState(vec2(0.5), danger, death, hurt, beat, vig, radius);
        float glitch = death * (LOW_HEALTH_DEATH_GLITCH * 0.01);
        if (glitch <= 0.004) return 0.0;
        float tick = floor(frameTimeCounter * 11.0);
        return 0.005 * glitch * (0.4 + fxHash12(vec2(tick, 3.0)));
    #else
        return 0.0;
    #endif
}

vec3 ApplyLowHealthWarp(vec3 color, sampler2D src, vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && death < 0.002) return color;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);

    float edge = vig * danger * mix(1.0, 0.5 + 0.85 * beat, pulseK);

    vec2 warped = bvLowHealthWarpUV(uv);
    float split = bvLowHealthSplit();

    float smear = 0.0;
    #if LOW_HEALTH_BLUR > 0
        smear = edge * (LOW_HEALTH_BLUR * 0.01) * 0.055;
    #endif

    bool moved = warped != uv || split > 0.0;
    if (!moved && smear <= 0.0005) return color;

    vec3 acc;
    if (split > 0.0) {
        acc = vec3(texture2D(src, clamp(warped + vec2(split, 0.0), vec2(0.001), vec2(0.999))).r,
                   texture2D(src, warped).g,
                   texture2D(src, clamp(warped - vec2(split, 0.0), vec2(0.001), vec2(0.999))).b);
    } else {
        acc = texture2D(src, warped).rgb;
    }
    float weight = 1.0;

    #if LOW_HEALTH_BLUR > 0
        if (smear > 0.0005) {
            vec2 outward = warped - 0.5;
            for (int i = 1; i <= 3; i++) {
                vec2 pulled = warped - outward * (smear * float(i) * 0.33333);
                acc += texture2D(src, clamp(pulled, vec2(0.001), vec2(0.999))).rgb;
                weight += 1.0;
            }
        }
    #endif

    return acc / weight;
}

vec3 ApplyLowHealthColour(vec3 color, vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && hurt < 0.004 && death < 0.002) return color;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);

    float edgeTint = vig * danger * mix(1.0, 0.78 + 0.34 * beat, pulseK);

    #if LOW_HEALTH_DARKEN > 0
        float dark = danger * (LOW_HEALTH_DARKEN * 0.01);
        if (dark > 0.002) {
            float keep = sqrt(clamp(fxLuma(color), 0.0, 1.0));
            color *= mix(1.0 - 0.85 * dark, 1.0, keep);
        }
    #endif

    float grey = fxLuma(color);

    vec3 drained = mix(color, vec3(grey), clamp(danger * LOW_HEALTH_DESAT * 0.01, 0.0, 1.0));
    vec3 blood = fxBloodRamp(grey);

    color = mix(drained, blood, clamp(edgeTint * (LOW_HEALTH_TINT * 0.01), 0.0, 1.0));

    color *= 1.0 - vig * danger * beat * 0.20 * pulseK;

    if (hurt > 0.004) {
        float spread = mix(vig, 1.0, clamp(fxHurtAmount / 12.0, 0.0, 0.85));
        color = mix(color, blood, clamp(hurt * spread, 0.0, 0.95));
    }

    if (death > 0.002) {
        float inner = mix(0.60, 0.05, clamp(LOW_HEALTH_DEATH_CLOSE * 0.01, 0.0, 1.0))
                    * (1.0 - 0.45 * death);
        float shut = clamp((radius - inner) / max(1.0 - inner, 0.001), 0.0, 1.0);
        shut = shut * shut * (3.0 - 2.0 * shut);

        vec3 gone = vec3(grey) * vec3(0.42, 0.03, 0.025) + vec3(0.04, 0.0, 0.0);
        float wash = clamp(death * (LOW_HEALTH_DEATH * 0.01), 0.0, 1.0);
        color = mix(color, gone, clamp(shut * wash + 0.25 * wash, 0.0, 1.0));
        color *= 1.0 - 0.45 * wash;

        #if LOW_HEALTH_DEATH_BLACK > 0
            float blackAmt = clamp(LOW_HEALTH_DEATH_BLACK * 0.01, 0.0, 1.0);
            float blackInner = mix(0.95, 0.55, blackAmt) * (1.0 - 0.35 * death);
            float dark = clamp((radius - blackInner) / max(1.0 - blackInner, 0.001), 0.0, 1.0);
            color = mix(color, vec3(0.0), clamp(dark * dark * death * blackAmt * 0.9, 0.0, 1.0));
        #endif
    }

    return color;
}

#endif
