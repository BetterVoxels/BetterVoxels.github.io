#ifndef INCLUDE_CAMERA_SHAKE
#define INCLUDE_CAMERA_SHAKE

#define CAMERA_MOTION 0 //[0 1]
#define SHAKE_MAX_INTENSITY 0.50 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SHAKE_MAX_FREQUENCY 8.0 //[2.0 4.0 6.0 8.0 10.0 12.0 15.0 18.0 22.0 26.0 30.0 40.0 50.0]
#define SHAKE_THUNDER_TRAUMA 0.65 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SHAKE_THUNDER_RANGE 128.0 //[16.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0]
#define SHAKE_EXPLOSION_TRAUMA 0.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define SHAKE_FALL_TRAUMA 0.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CAM_STRAFE_ROLL 0.40 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CAM_TURN_ROLL 0.30 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CAM_VERTICAL_PITCH 0.30 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CAM_SWAY_INTENSITY 0.20 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CAM_SWAY_FREQUENCY 4.0 //[2.0 4.0 6.0 8.0 10.0 12.0 15.0 18.0 22.0 26.0 30.0 40.0 50.0]

#define SHAKE_ENABLE_IMPACTS 1 //[0 1]
#define CAM_ENABLE_STRAFE 0 //[0 1]
#define CAM_ENABLE_TURN 0 //[0 1]
#define CAM_ENABLE_VERTICAL 0 //[0 1]
#define CAM_ENABLE_SWAY 0 //[0 1]
#define SHAKE_AUTO_OVERSCAN 1 //[0 1]
#define SHAKE_OVERSCAN 1.00 //[1.00 1.02 1.05 1.08 1.10 1.15 1.20 1.25 1.30 1.40 1.50]

#if CAMERA_MOTION == 1

uniform float fxShkBolt;
uniform float fxShkBoltD;
uniform float fxShkBlast;

float shakeWave(float t, float seed) {
    return sin(t * (1.0 + seed * 0.6180339887)) * 0.6
         + sin(t * (2.7182818285 + seed)) * 0.3
         + sin(t * (4.6692016091 - seed * 0.5)) * 0.1;
}

vec2 CameraShakeUV(vec2 uv) {

    #if SHAKE_ENABLE_IMPACTS == 0 && CAM_ENABLE_STRAFE == 0 && CAM_ENABLE_TURN == 0         && CAM_ENABLE_VERTICAL == 0 && CAM_ENABLE_SWAY == 0
        return uv;
    #endif

    float aspect = viewWidth / viewHeight;
    float dt = max(frameTime, 0.0005);

    vec3 vel = (cameraPosition - previousCameraPosition) / dt;
    vec3 velCam = mat3(gbufferModelView) * vel;
    float strafe = clamp(velCam.x * 0.12, -1.0, 1.0);
    float rise = clamp(velCam.y * 0.12, -1.0, 1.0);

    vec3 fwdNow = -vec3(gbufferModelView[0].z, gbufferModelView[1].z, gbufferModelView[2].z);
    vec3 fwdOld = -vec3(gbufferPreviousModelView[0].z,
                        gbufferPreviousModelView[1].z,
                        gbufferPreviousModelView[2].z);
    float yawRate = clamp((fwdNow.z * fwdOld.x - fwdNow.x * fwdOld.z) / dt * 0.5, -1.0, 1.0);

    float trauma = 0.0;
  #if SHAKE_ENABLE_IMPACTS == 1

    if (fxShkBolt > 0.0001) {
        float distSq = fxShkBoltD / fxShkBolt;
        float atten = 1.0 - clamp(sqrt(distSq) / SHAKE_THUNDER_RANGE, 0.0, 1.0);
        trauma += fxShkBolt * SHAKE_THUNDER_TRAUMA * atten * atten;
    }

    trauma += fxShkBlast * SHAKE_EXPLOSION_TRAUMA;

    float falling = clamp(-rise - 0.35, 0.0, 1.0) / 0.65;
    trauma += falling * falling * SHAKE_FALL_TRAUMA;

  #endif
    trauma = clamp(trauma, 0.0, 1.0);

    float amp = trauma * trauma * SHAKE_MAX_INTENSITY;
    float t = frameTimeCounter * SHAKE_MAX_FREQUENCY;

    vec2 offset = vec2(shakeWave(t, 0.0), shakeWave(t, 1.7)) * amp * 0.04;
    float roll = shakeWave(t, 3.1) * amp * 0.12;

    #if CAM_ENABLE_STRAFE == 1
        roll += -strafe * CAM_STRAFE_ROLL * 0.10;
    #endif
    #if CAM_ENABLE_TURN == 1
        roll += -yawRate * CAM_TURN_ROLL * 0.10;
    #endif
    #if CAM_ENABLE_VERTICAL == 1
        offset.y += rise * CAM_VERTICAL_PITCH * 0.02;
    #endif

    #if CAM_ENABLE_SWAY == 1
        float stillness = 1.0 - clamp(length(vel) * 2.0 + abs(yawRate) * 2.0, 0.0, 1.0);
        float sway = stillness * CAM_SWAY_INTENSITY * 0.01;
        float st = frameTimeCounter * CAM_SWAY_FREQUENCY;
        offset += vec2(sin(st * 0.7), sin(st * 0.53 + 1.3)) * sway;
        roll += sin(st * 0.41 + 2.2) * sway * 2.0;
    #endif

    float over = SHAKE_OVERSCAN;
    #if SHAKE_AUTO_OVERSCAN == 1

        float k = max(aspect, 1.0 / aspect);
        float offMax = max(abs(offset.x), abs(offset.y));
        over = max(over, (abs(cos(roll)) + abs(sin(roll)) * k)
                        / max(1.0 - 2.0 * offMax, 0.05));
    #endif

    vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
    p /= max(over, 0.0001);
    float cs = cos(roll), sn = sin(roll);
    p = vec2(p.x * cs - p.y * sn, p.x * sn + p.y * cs);
    p += offset * vec2(aspect, 1.0);

    return p / vec2(aspect, 1.0) + 0.5;
}

#endif

#endif
