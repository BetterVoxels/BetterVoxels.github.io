
#ifndef INCLUDE_FUN_EFFECTS
#define INCLUDE_FUN_EFFECTS

#if FUN_UPSIDE == 1 || FUN_POTATO == 1
    vec2 bvFunUV(vec2 uv) {
        #if FUN_UPSIDE == 1
            uv.y = 1.0 - uv.y;
        #endif
        #if FUN_POTATO == 1
            vec2 res = vec2(viewWidth, viewHeight) / 6.0;
            uv = (floor(uv * res) + 0.5) / res;
        #endif
        return uv;
    }
#endif

#if FUN_RAINBOW == 1 || FUN_ROULETTE == 1
    vec3 bvFunHue(vec3 c, float a) {
        const vec3 k = vec3(0.57735);
        float ca = cos(a);
        return c * ca + cross(k, c) * sin(a) + k * dot(k, c) * (1.0 - ca);
    }
#endif

void ApplyFunColour(inout vec3 color, vec2 uv) {

    #if FUN_BIZARRO == 1
        color = 1.0 - clamp(color, 0.0, 1.0);
    #endif

    #if FUN_PREDATOR == 1
        float heat = clamp(dot(color, vec3(0.2125, 0.7154, 0.0721)) * 1.6, 0.0, 1.0);
        color = clamp(vec3(smoothstep(0.5, 1.0, heat),
                           1.0 - abs(heat - 0.5) * 2.0,
                           smoothstep(0.5, 0.0, heat)), 0.0, 1.0);
        color *= 0.35 + 0.65 * heat;
    #endif

    #if FUN_RAINBOW == 1
        color = bvFunHue(color, frameTimeCounter);
    #endif

    #if FUN_ROULETTE == 1
        float tick = floor(frameTimeCounter);
        float roll = fract(sin(tick * 12.9898) * 43758.5453);
        if (roll > 0.66)      color = color.gbr;
        else if (roll > 0.33) color = color.brg;
        if (fract(roll * 7.0) > 0.5) color = color.rbg;
    #endif

    #if FUN_FRIED == 1
        float l = dot(color, vec3(0.2125, 0.7154, 0.0721));
        color = l + (color - l) * 4.0;
        color = (color - 0.45) * 3.5 + 0.45;
        color = clamp(color, 0.0, 1.0);
        color = pow(color, vec3(1.0 / 1.35));
    #endif

    #if FUN_POTATO == 1
        float steps = 3.0;
        color = floor(clamp(color, 0.0, 1.0) * steps + 0.5) / steps;
    #endif

    #if FUN_TUNNEL == 1
        vec2 p = uv - 0.5;
        p.x *= viewWidth / viewHeight;
        float r = length(p) * 3.5;
        color *= 1.0 - smoothstep(0.28, 0.52, r);
    #endif
}

#endif
