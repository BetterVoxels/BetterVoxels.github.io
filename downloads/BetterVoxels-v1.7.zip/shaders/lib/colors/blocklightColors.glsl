vec3 blocklightCol = vec3(0.1775, 0.108, 0.0775) * vec3(XLIGHT_R, XLIGHT_G, XLIGHT_B) * ccBlocklight;

void AddSpecialLightDetail(inout vec3 light, vec3 albedo, float emission) {
	vec3 lightM = max(light, vec3(0.0));
	lightM /= (0.2 + 0.8 * GetLuminance(lightM));
	lightM *= (1.0 / (1.0 + emission)) * 0.22;
	light *= 0.9;
	light += pow2(lightM / (albedo + 0.1));
}

vec3 fireSpecialLightColor = vec3(2.05, 0.83, 0.27) * 3.8;
vec3 lavaSpecialLightColor = vec3(3.0, 0.9, 0.2) * 4.0;
vec3 netherPortalSpecialLightColor = vec3(1.8, 0.4, 2.2) * 0.8;
vec3 redstoneSpecialLightColor = vec3(4.0, 0.1, 0.1);
vec4 soulFireSpecialColor = vec4(vec3(0.3, 2.0, 2.2) * 1.0, 0.3);
float candleColorMult = 2.0;
float candleExtraLight = 0.004;
vec4 GetSpecialBlocklightColor(int mat) {

	if (mat < 50) {
		if (mat < 26) {
			if (mat < 14) {
				if (mat < 8) {
					if (mat == 2) return vec4(fireSpecialLightColor, 0.0);
					#ifndef END
						if (mat == 3) return vec4(vec3(1.0, 1.0, 1.0) * 4.0, 0.0);
					#else
						if (mat == 3) return vec4(vec3(1.25, 0.5, 1.25) * 4.0, 0.0);
					#endif
					if (mat == 4) return vec4(vec3(0.7, 1.5, 2.0) * 3.0, 0.0);
					if (mat == 5) return vec4(fireSpecialLightColor, 0.0);
					if (mat == 6) return vec4(vec3(0.7, 1.5, 1.5) * 1.7, 0.0);
					if (mat == 7) return vec4(vec3(1.1, 0.85, 0.35) * 5.0, 0.0);
				} else {
					if (mat == 8) return vec4(vec3(0.6, 1.3, 0.6) * 4.5, 0.0);
					if (mat == 9) return vec4(vec3(1.1, 0.5, 0.9) * 4.5, 0.0);
					if (mat == 10) return vec4(vec3(1.7, 0.9, 0.4) * 4.0, 0.0);
					if (mat == 11) return vec4(fireSpecialLightColor, 0.0);
					if (mat == 12) return vec4(fireSpecialLightColor, 0.0);
					if (mat == 13) return vec4(lavaSpecialLightColor, 0.8);
				}
			} else {
				if (mat < 20) {
					if (mat == 14) return vec4(lavaSpecialLightColor, 0.0);
					if (mat == 15) return vec4(fireSpecialLightColor, 0.0);
					if (mat == 16) return vec4(vec3(1.7, 0.9, 0.4) * 4.0, 0.0);
					if (mat == 17) return vec4(vec3(1.7, 0.9, 0.4) * 2.0, 0.0);
					if (mat == 18) return vec4(vec3(1.0, 1.25, 1.5) * 3.4, 0.0);
					if (mat == 19) return vec4(vec3(3.0, 0.9, 0.2) * 3.0, 0.0);
				} else {
					if (mat == 20) return vec4(vec3(2.3, 0.9, 0.2) * 3.4, 0.0);
					if (mat == 21) return vec4(fireSpecialLightColor * 0.7, 0.0);
					if (mat == 22) return vec4(fireSpecialLightColor * 0.7, 0.0);
					if (mat == 23) return vec4(fireSpecialLightColor * 0.7, 0.0);
					if (mat == 24) return vec4(fireSpecialLightColor * 0.25 * candleColorMult, candleExtraLight);
					if (mat == 25) return vec4(netherPortalSpecialLightColor * 2.0, 0.4);
				}
			}
		} else {
			if (mat < 38) {
				if (mat < 32) {
					if (mat == 26) return vec4(netherPortalSpecialLightColor, 0.0);
					if (mat == 27) return soulFireSpecialColor;
					if (mat == 28) return soulFireSpecialColor;
					if (mat == 29) return soulFireSpecialColor;
					if (mat == 30) return soulFireSpecialColor;
					if (mat == 31) return vec4(redstoneSpecialLightColor * 0.5, 0.1);
				} else {
					if (mat == 32) return vec4(redstoneSpecialLightColor * 0.3, 0.1);
					if (mat == 33) return vec4(vec3(1.4, 1.1, 0.5), 0.0);
                    #if GLOWING_LICHEN > 0
						if (mat == 34) return vec4(vec3(0.8, 1.1, 1.1), 0.05);
					#else
						if (mat == 34) return vec4(vec3(0.4, 0.55, 0.55), 0.0);
					#endif
					if (mat == 35) return vec4(redstoneSpecialLightColor * 0.25, 0.0);
					if (mat == 36) return vec4(vec3(0.325, 0.15, 0.425) * 2.0, 0.05);
					if (mat == 37) return vec4(lavaSpecialLightColor * 0.1, 0.1);
				}
			} else {
				if (mat < 44) {
					if (mat == 38) return vec4(vec3(2.0, 0.5, 1.5) * 0.3, 0.1);
					if (mat == 39) return vec4(vec3(2.0, 1.0, 1.5) * 0.25, 0.1);
					if (mat == 40) return vec4(vec3(2.5, 1.2, 0.4) * 0.1, 0.1);
					if (mat == 41) return vec4(redstoneSpecialLightColor * 0.4, 0.15);
					if (mat == 42) return vec4(vec3(0.75, 0.75, 3.0) * 0.277, 0.15);
					if (mat == 43) return vec4(vec3(1.7, 0.9, 0.4) * 0.45, 0.05);
				} else {
					if (mat == 44) return vec4(vec3(1.7, 1.1, 0.2) * 0.45, 0.1);
					if (mat == 45) return vec4(vec3(1.7, 0.8, 0.4) * 0.45, 0.05);
					if (mat == 46) return vec4(vec3(0.75, 0.75, 3.0) * 0.2, 0.1);
					if (mat == 47) return vec4(vec3(0.5, 3.5, 0.5) * 0.3, 0.1);
					if (mat == 48) return vec4(vec3(0.5, 2.0, 2.0) * 0.4, 0.15);
					if (mat == 49) return vec4(vec3(1.5, 1.5, 1.5) * 0.3, 0.05);
				}
			}
		}
	} else {
		if (mat < 74) {
			if (mat < 62) {
				if (mat < 56) {
					if (mat == 50) return vec4(vec3(1.7, 1.1, 0.2) * 0.45, 0.05);
					if (mat == 51) return vec4(vec3(1.7, 1.1, 0.2) * 0.45, 0.05);
					if (mat == 52) return vec4(vec3(1.8, 0.8, 0.4) * 0.6, 0.15);
					if (mat == 53) return vec4(vec3(1.4, 0.2, 1.4) * 0.3, 0.05);
					if (mat == 54) return vec4(vec3(3.1, 1.1, 0.3) * 1.0, 0.1);
					if (mat == 55) return vec4(vec3(1.7, 0.9, 0.4) * 4.0, 0.0);
				} else {
					if (mat == 56) return vec4(vec3(1.7, 0.9, 0.4) * 2.0, 0.0);
					if (mat == 57) return vec4(vec3(0.1, 0.3, 0.4) * 0.5, 0.0005);
					if (mat == 58) return vec4(vec3(0.0, 1.4, 1.4) * 4.0, 0.15);
					if (mat == 59) return vec4(0.0);
					if (mat == 60) return vec4(vec3(3.1, 1.1, 0.3) * 0.125, 0.0125);
					if (mat == 61) return vec4(vec3(3.0, 0.9, 0.2) * 0.125, 0.0125);
				}
			} else {
				if (mat < 68) {
					if (mat == 62) return vec4(vec3(3.5, 0.6, 0.4) * 0.3, 0.05);
					if (mat == 63) return vec4(vec3(0.3, 1.9, 1.5) * 0.3, 0.05);
					if (mat == 64) return vec4(vec3(1.0, 1.0, 1.0) * 0.45, 0.1);
					if (mat == 65) return vec4(vec3(3.0, 0.9, 0.2) * 0.125, 0.0125);
					if (mat == 66) return vec4(redstoneSpecialLightColor * 0.05, 0.002);
					if (mat == 67) return vec4(redstoneSpecialLightColor * 0.125, 0.0125);
				} else {
					if (mat == 68) return vec4(vec3(0.75), 0.0);
					if (mat == 69) return vec4(vec3(1.3, 1.6, 1.6) * 1.0, 0.1);
					if (mat == 70) return vec4(vec3(1.0, 0.1, 0.1) * candleColorMult, candleExtraLight);
					if (mat == 71) return vec4(vec3(1.0, 0.4, 0.1) * candleColorMult, candleExtraLight);
					if (mat == 72) return vec4(vec3(1.0, 1.0, 0.1) * candleColorMult, candleExtraLight);
					if (mat == 73) return vec4(vec3(0.1, 1.0, 0.1) * candleColorMult, candleExtraLight);
				}
			}
		} else {
			if (mat < 86) {
				if (mat < 80) {
					if (mat == 74) return vec4(vec3(0.3, 1.0, 0.3) * candleColorMult, candleExtraLight);
					if (mat == 75) return vec4(vec3(0.3, 0.8, 1.0) * candleColorMult, candleExtraLight);
					if (mat == 76) return vec4(vec3(0.5, 0.65, 1.0) * candleColorMult, candleExtraLight);
					if (mat == 77) return vec4(vec3(0.1, 0.15, 1.0) * candleColorMult, candleExtraLight);
					if (mat == 78) return vec4(vec3(0.7, 0.3, 1.0) * candleColorMult, candleExtraLight);
					if (mat == 79) return vec4(vec3(1.0, 0.1, 1.0) * candleColorMult, candleExtraLight);
				} else {
					if (mat == 80) return vec4(vec3(1.0, 0.4, 1.0) * candleColorMult, candleExtraLight);
					if (mat == 81) return vec4(vec3(2.8, 1.1, 0.2) * 0.125, 0.0125);
					if (mat == 82) return vec4(vec3(2.8, 1.1, 0.2) * 0.3, 0.05);
					if (mat == 83) return vec4(vec3(1.6, 1.6, 0.7) * 0.3, 0.05);
					if (mat == 84) return vec4(0.0);
					if (mat == 85) return vec4(0.0);
				}
			} else {
				if (mat < 92) {
					if (mat == 86) return vec4(0.0);
					if (mat == 87) return vec4(0.0);
					if (mat == 88) return vec4(0.0);
					if (mat == 89) return vec4(0.0);
					if (mat == 90) return vec4(0.0);
					if (mat == 91) return vec4(0.0);
				} else {
					if (mat == 92) return vec4(0.0);
					if (mat == 93) return vec4(0.0);
					if (mat == 94) return vec4(0.0);
					if (mat == 95) return vec4(0.0);
					if (mat == 96) return vec4(0.0);
					if (mat == 97) return vec4(0.0);
				}
			}
		}
	}

	return vec4(blocklightCol * 20.0, 0.0);
}

vec3[] specialTintColor = vec3[](

	vec3(1.0),

	vec3(1.0, 0.3, 0.1),

	vec3(1.0, 0.1, 1.0),

	vec3(0.5, 0.65, 1.0),

	vec3(1.0, 1.0, 0.1),

	vec3(0.1, 1.0, 0.1),

	vec3(1.0, 0.4, 1.0),

	vec3(1.0),

	vec3(1.0),

	vec3(0.3, 0.8, 1.0),

	vec3(0.7, 0.3, 1.0),

	vec3(0.1, 0.15, 1.0),

	vec3(1.0, 0.75, 0.5),

	vec3(0.3, 1.0, 0.3),

	vec3(1.0, 0.1, 0.1),

	vec3(1.0),

	vec3(0.5, 0.65, 1.0),

	vec3(1.0),

	vec3(1.0),

	vec3(0.0)
);
