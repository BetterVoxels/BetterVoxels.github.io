vec3 cloudRainColor = mix(nightMiddleSkyColor, dayMiddleSkyColor, sunFactor);
#if BETTER_THUNDER == 1
    float btStorm = thunderStrength * (BETTER_THUNDER_DARKEN * 0.01);
    float btLit = btFlash * thunderStrength * (BETTER_THUNDER_FLASH * 0.01);

    vec3 cloudAmbientColor = mix(ambientColor * (sunVisibility2 * (0.55 + 0.1 * noonFactor) + 0.35), cloudRainColor * 0.5, rainFactor)
                           * (1.0 - 0.72 * btStorm) + cloudRainColor * (btLit * 2.6);
    vec3 cloudLightColor   = mix(lightColor * (0.9 + 0.2 * noonFactor), cloudRainColor * 0.25, noonFactor * rainFactor)
                           * (1.0 - 0.58 * btStorm) + cloudRainColor * (btLit * 1.6);
#else
    vec3 cloudAmbientColor = mix(ambientColor * (sunVisibility2 * (0.55 + 0.1 * noonFactor) + 0.35), cloudRainColor * 0.5, rainFactor);
    vec3 cloudLightColor   = mix(lightColor * (0.9 + 0.2 * noonFactor), cloudRainColor * 0.25, noonFactor * rainFactor);
#endif
