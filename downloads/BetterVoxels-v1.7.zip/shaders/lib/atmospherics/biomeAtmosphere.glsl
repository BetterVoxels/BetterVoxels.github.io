#ifndef INCLUDE_BIOME_ATMOSPHERE
#define INCLUDE_BIOME_ATMOSPHERE

#ifdef BIOME_ATMOSPHERE_ACTIVE

    uniform float bvBiomeForest;
    uniform float bvBiomeFlowerforest;
    uniform float bvBiomeBirch;
    uniform float bvBiomeOldbirch;
    uniform float bvBiomeDarkfor;
    uniform float bvBiomePale;
    uniform float bvBiomeWindforest;
    uniform float bvBiomeTaiga;
    uniform float bvBiomeSnowtaiga;
    uniform float bvBiomePinetaiga;
    uniform float bvBiomeSprucetaiga;
    uniform float bvBiomeGrove;
    uniform float bvBiomeJungle;
    uniform float bvBiomeSparsejungle;
    uniform float bvBiomeBamboo;
    uniform float bvBiomePlains;
    uniform float bvBiomeSunflower;
    uniform float bvBiomeMeadow;
    uniform float bvBiomeCherry;
    uniform float bvBiomeSavanna;
    uniform float bvBiomeSavplateau;
    uniform float bvBiomeWindsavanna;
    uniform float bvBiomeSwamp;
    uniform float bvBiomeMangrove;
    uniform float bvBiomeDesert;
    uniform float bvBiomeBadlands;
    uniform float bvBiomeErodedbad;
    uniform float bvBiomeWoodedbad;
    uniform float bvBiomeSnowyplains;
    uniform float bvBiomeIcespikes;
    uniform float bvBiomeSnowyslopes;
    uniform float bvBiomeFrozenpeaks;
    uniform float bvBiomeJaggedpeaks;
    uniform float bvBiomeSnowybeach;
    uniform float bvBiomeFrozenriver;
    uniform float bvBiomeWindhills;
    uniform float bvBiomeWindgravel;
    uniform float bvBiomeStonypeaks;
    uniform float bvBiomeStonyshore;
    uniform float bvBiomeBeach;
    uniform float bvBiomeRiver;
    uniform float bvBiomeOcean;
    uniform float bvBiomeDeepocean;
    uniform float bvBiomeColdocean;
    uniform float bvBiomeDeepcoldocean;
    uniform float bvBiomeLukeocean;
    uniform float bvBiomeDeeplukeocean;
    uniform float bvBiomeWarmocean;
    uniform float bvBiomeFrozenocean;
    uniform float bvBiomeDeepfrozenocean;
    uniform float bvBiomeDripstone;
    uniform float bvBiomeLushcaves;
    uniform float bvBiomeDeepdark;
    uniform float bvBiomeMushroom;
    uniform float bvBiomeTheend;
    uniform float bvBiomeEndhigh;
    uniform float bvBiomeEndmid;
    uniform float bvBiomeSmallend;
    uniform float bvBiomeEndbarrens;

    void bvBiomeAccum(float w, vec3 col, float mult,
                      inout vec3 acc, inout float accMult, inout float total) {
        acc += w * col * 0.01;
        accMult += w * mult * 0.01;
        total += w;
    }

    vec3 bvBiomeTint(vec3 base, vec3 tint, float weight, float strength) {
        const vec3 lumW = vec3(0.2125, 0.7154, 0.0721);
        float tintLum = dot(tint, lumW);
        float w = clamp(weight, 0.0, 1.0);
        vec3 hued = tint * (dot(base, lumW) / max(tintLum, 0.0001));
        return mix(base, hued, w * clamp(strength, 0.0, 1.0)) * mix(1.0, tintLum, w);
    }

    void bvBiomeAtmosphere(out vec3 tint, out float shaftMult, out float weight) {
        vec3 acc = vec3(0.0);
        float accMult = 0.0;
        float total = 0.0;

        bvBiomeAccum(bvBiomeForest, vec3(BIOME_FOREST_R, BIOME_FOREST_G, BIOME_FOREST_B),
                     BIOME_FOREST_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeFlowerforest, vec3(BIOME_FLOWERFOREST_R, BIOME_FLOWERFOREST_G, BIOME_FLOWERFOREST_B),
                     BIOME_FLOWERFOREST_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeBirch, vec3(BIOME_BIRCH_R, BIOME_BIRCH_G, BIOME_BIRCH_B),
                     BIOME_BIRCH_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeOldbirch, vec3(BIOME_OLDBIRCH_R, BIOME_OLDBIRCH_G, BIOME_OLDBIRCH_B),
                     BIOME_OLDBIRCH_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDarkfor, vec3(BIOME_DARKFOR_R, BIOME_DARKFOR_G, BIOME_DARKFOR_B),
                     BIOME_DARKFOR_I, acc, accMult, total);
        bvBiomeAccum(bvBiomePale, vec3(BIOME_PALE_R, BIOME_PALE_G, BIOME_PALE_B),
                     BIOME_PALE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWindforest, vec3(BIOME_WINDFOREST_R, BIOME_WINDFOREST_G, BIOME_WINDFOREST_B),
                     BIOME_WINDFOREST_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeTaiga, vec3(BIOME_TAIGA_R, BIOME_TAIGA_G, BIOME_TAIGA_B),
                     BIOME_TAIGA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSnowtaiga, vec3(BIOME_SNOWTAIGA_R, BIOME_SNOWTAIGA_G, BIOME_SNOWTAIGA_B),
                     BIOME_SNOWTAIGA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomePinetaiga, vec3(BIOME_PINETAIGA_R, BIOME_PINETAIGA_G, BIOME_PINETAIGA_B),
                     BIOME_PINETAIGA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSprucetaiga, vec3(BIOME_SPRUCETAIGA_R, BIOME_SPRUCETAIGA_G, BIOME_SPRUCETAIGA_B),
                     BIOME_SPRUCETAIGA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeGrove, vec3(BIOME_GROVE_R, BIOME_GROVE_G, BIOME_GROVE_B),
                     BIOME_GROVE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeJungle, vec3(BIOME_JUNGLE_R, BIOME_JUNGLE_G, BIOME_JUNGLE_B),
                     BIOME_JUNGLE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSparsejungle, vec3(BIOME_SPARSEJUNGLE_R, BIOME_SPARSEJUNGLE_G, BIOME_SPARSEJUNGLE_B),
                     BIOME_SPARSEJUNGLE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeBamboo, vec3(BIOME_BAMBOO_R, BIOME_BAMBOO_G, BIOME_BAMBOO_B),
                     BIOME_BAMBOO_I, acc, accMult, total);
        bvBiomeAccum(bvBiomePlains, vec3(BIOME_PLAINS_R, BIOME_PLAINS_G, BIOME_PLAINS_B),
                     BIOME_PLAINS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSunflower, vec3(BIOME_SUNFLOWER_R, BIOME_SUNFLOWER_G, BIOME_SUNFLOWER_B),
                     BIOME_SUNFLOWER_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeMeadow, vec3(BIOME_MEADOW_R, BIOME_MEADOW_G, BIOME_MEADOW_B),
                     BIOME_MEADOW_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeCherry, vec3(BIOME_CHERRY_R, BIOME_CHERRY_G, BIOME_CHERRY_B),
                     BIOME_CHERRY_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSavanna, vec3(BIOME_SAVANNA_R, BIOME_SAVANNA_G, BIOME_SAVANNA_B),
                     BIOME_SAVANNA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSavplateau, vec3(BIOME_SAVPLATEAU_R, BIOME_SAVPLATEAU_G, BIOME_SAVPLATEAU_B),
                     BIOME_SAVPLATEAU_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWindsavanna, vec3(BIOME_WINDSAVANNA_R, BIOME_WINDSAVANNA_G, BIOME_WINDSAVANNA_B),
                     BIOME_WINDSAVANNA_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSwamp, vec3(BIOME_SWAMP_R, BIOME_SWAMP_G, BIOME_SWAMP_B),
                     BIOME_SWAMP_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeMangrove, vec3(BIOME_MANGROVE_R, BIOME_MANGROVE_G, BIOME_MANGROVE_B),
                     BIOME_MANGROVE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDesert, vec3(BIOME_DESERT_R, BIOME_DESERT_G, BIOME_DESERT_B),
                     BIOME_DESERT_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeBadlands, vec3(BIOME_BADLANDS_R, BIOME_BADLANDS_G, BIOME_BADLANDS_B),
                     BIOME_BADLANDS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeErodedbad, vec3(BIOME_ERODEDBAD_R, BIOME_ERODEDBAD_G, BIOME_ERODEDBAD_B),
                     BIOME_ERODEDBAD_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWoodedbad, vec3(BIOME_WOODEDBAD_R, BIOME_WOODEDBAD_G, BIOME_WOODEDBAD_B),
                     BIOME_WOODEDBAD_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSnowyplains, vec3(BIOME_SNOWYPLAINS_R, BIOME_SNOWYPLAINS_G, BIOME_SNOWYPLAINS_B),
                     BIOME_SNOWYPLAINS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeIcespikes, vec3(BIOME_ICESPIKES_R, BIOME_ICESPIKES_G, BIOME_ICESPIKES_B),
                     BIOME_ICESPIKES_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSnowyslopes, vec3(BIOME_SNOWYSLOPES_R, BIOME_SNOWYSLOPES_G, BIOME_SNOWYSLOPES_B),
                     BIOME_SNOWYSLOPES_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeFrozenpeaks, vec3(BIOME_FROZENPEAKS_R, BIOME_FROZENPEAKS_G, BIOME_FROZENPEAKS_B),
                     BIOME_FROZENPEAKS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeJaggedpeaks, vec3(BIOME_JAGGEDPEAKS_R, BIOME_JAGGEDPEAKS_G, BIOME_JAGGEDPEAKS_B),
                     BIOME_JAGGEDPEAKS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSnowybeach, vec3(BIOME_SNOWYBEACH_R, BIOME_SNOWYBEACH_G, BIOME_SNOWYBEACH_B),
                     BIOME_SNOWYBEACH_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeFrozenriver, vec3(BIOME_FROZENRIVER_R, BIOME_FROZENRIVER_G, BIOME_FROZENRIVER_B),
                     BIOME_FROZENRIVER_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWindhills, vec3(BIOME_WINDHILLS_R, BIOME_WINDHILLS_G, BIOME_WINDHILLS_B),
                     BIOME_WINDHILLS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWindgravel, vec3(BIOME_WINDGRAVEL_R, BIOME_WINDGRAVEL_G, BIOME_WINDGRAVEL_B),
                     BIOME_WINDGRAVEL_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeStonypeaks, vec3(BIOME_STONYPEAKS_R, BIOME_STONYPEAKS_G, BIOME_STONYPEAKS_B),
                     BIOME_STONYPEAKS_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeStonyshore, vec3(BIOME_STONYSHORE_R, BIOME_STONYSHORE_G, BIOME_STONYSHORE_B),
                     BIOME_STONYSHORE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeBeach, vec3(BIOME_BEACH_R, BIOME_BEACH_G, BIOME_BEACH_B),
                     BIOME_BEACH_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeRiver, vec3(BIOME_RIVER_R, BIOME_RIVER_G, BIOME_RIVER_B),
                     BIOME_RIVER_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeOcean, vec3(BIOME_OCEAN_R, BIOME_OCEAN_G, BIOME_OCEAN_B),
                     BIOME_OCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDeepocean, vec3(BIOME_DEEPOCEAN_R, BIOME_DEEPOCEAN_G, BIOME_DEEPOCEAN_B),
                     BIOME_DEEPOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeColdocean, vec3(BIOME_COLDOCEAN_R, BIOME_COLDOCEAN_G, BIOME_COLDOCEAN_B),
                     BIOME_COLDOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDeepcoldocean, vec3(BIOME_DEEPCOLDOCEAN_R, BIOME_DEEPCOLDOCEAN_G, BIOME_DEEPCOLDOCEAN_B),
                     BIOME_DEEPCOLDOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeLukeocean, vec3(BIOME_LUKEOCEAN_R, BIOME_LUKEOCEAN_G, BIOME_LUKEOCEAN_B),
                     BIOME_LUKEOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDeeplukeocean, vec3(BIOME_DEEPLUKEOCEAN_R, BIOME_DEEPLUKEOCEAN_G, BIOME_DEEPLUKEOCEAN_B),
                     BIOME_DEEPLUKEOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWarmocean, vec3(BIOME_WARMOCEAN_R, BIOME_WARMOCEAN_G, BIOME_WARMOCEAN_B),
                     BIOME_WARMOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeFrozenocean, vec3(BIOME_FROZENOCEAN_R, BIOME_FROZENOCEAN_G, BIOME_FROZENOCEAN_B),
                     BIOME_FROZENOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDeepfrozenocean, vec3(BIOME_DEEPFROZENOCEAN_R, BIOME_DEEPFROZENOCEAN_G, BIOME_DEEPFROZENOCEAN_B),
                     BIOME_DEEPFROZENOCEAN_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDripstone, vec3(BIOME_DRIPSTONE_R, BIOME_DRIPSTONE_G, BIOME_DRIPSTONE_B),
                     BIOME_DRIPSTONE_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeLushcaves, vec3(BIOME_LUSHCAVES_R, BIOME_LUSHCAVES_G, BIOME_LUSHCAVES_B),
                     BIOME_LUSHCAVES_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeDeepdark, vec3(BIOME_DEEPDARK_R, BIOME_DEEPDARK_G, BIOME_DEEPDARK_B),
                     BIOME_DEEPDARK_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeMushroom, vec3(BIOME_MUSHROOM_R, BIOME_MUSHROOM_G, BIOME_MUSHROOM_B),
                     BIOME_MUSHROOM_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeNetherwastes, vec3(BIOME_NETHERWASTES_R, BIOME_NETHERWASTES_G, BIOME_NETHERWASTES_B),
                     BIOME_NETHERWASTES_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeCrimson, vec3(BIOME_CRIMSON_R, BIOME_CRIMSON_G, BIOME_CRIMSON_B),
                     BIOME_CRIMSON_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeWarped, vec3(BIOME_WARPED_R, BIOME_WARPED_G, BIOME_WARPED_B),
                     BIOME_WARPED_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeBasalt, vec3(BIOME_BASALT_R, BIOME_BASALT_G, BIOME_BASALT_B),
                     BIOME_BASALT_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSoulvalley, vec3(BIOME_SOULVALLEY_R, BIOME_SOULVALLEY_G, BIOME_SOULVALLEY_B),
                     BIOME_SOULVALLEY_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeTheend, vec3(BIOME_THEEND_R, BIOME_THEEND_G, BIOME_THEEND_B),
                     BIOME_THEEND_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeEndhigh, vec3(BIOME_ENDHIGH_R, BIOME_ENDHIGH_G, BIOME_ENDHIGH_B),
                     BIOME_ENDHIGH_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeEndmid, vec3(BIOME_ENDMID_R, BIOME_ENDMID_G, BIOME_ENDMID_B),
                     BIOME_ENDMID_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeSmallend, vec3(BIOME_SMALLEND_R, BIOME_SMALLEND_G, BIOME_SMALLEND_B),
                     BIOME_SMALLEND_I, acc, accMult, total);
        bvBiomeAccum(bvBiomeEndbarrens, vec3(BIOME_ENDBARRENS_R, BIOME_ENDBARRENS_G, BIOME_ENDBARRENS_B),
                     BIOME_ENDBARRENS_I, acc, accMult, total);

        float present = min(total, 1.0);
        float norm = max(total, 0.0001);
        vec3 col = acc / norm;
        float mult = accMult / norm;

        #if BV_BIOME_CHROMA_MULT != 100
            float chromaGrey = dot(col, vec3(1.0 / 3.0));
            col = max(chromaGrey + (col - chromaGrey) * (BV_BIOME_CHROMA_MULT * 0.01), vec3(0.0));
        #endif
        #if BV_BIOME_SHAFT_MULT != 100
            mult *= BV_BIOME_SHAFT_MULT * 0.01;
        #endif

        tint = col;
        shaftMult = mix(1.0, mult, present);
        weight = present;
    }
#endif

#endif
