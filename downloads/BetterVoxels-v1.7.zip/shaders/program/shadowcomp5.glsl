#include "/lib/common.glsl"

#ifdef CSH

#if RIPPLE_RES == 2
    const ivec3 workGroups = ivec3(8, 8, 1);
#elif RIPPLE_RES == 8
    const ivec3 workGroups = ivec3(32, 32, 1);
#else
    const ivec3 workGroups = ivec3(16, 16, 1);
#endif
layout(local_size_x = 32, local_size_y = 32) in;

layout(rgba16f) uniform image2D rippleImg;
layout(rgba16f) uniform image2D rippleCellImg;

#include "/lib/water/waterRipples.glsl"

const float rwNoWater = -9999.0;

#ifdef WATER_RIPPLES
    vec4 rwLoadCell(ivec2 cell) {
        if (any(lessThan(cell, ivec2(0))) || any(greaterThanEqual(cell, ivec2(rwRippleCells)))) {
            return vec4(rwNoWater, 0.0, 0.0, 0.0);
        }
        return imageLoad(rippleCellImg, cell);
    }
#endif

void main() {
    #ifdef WATER_RIPPLES
        ivec2 texel = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(texel, ivec2(rwRippleRes)))) return;

        ivec3 camInt = rwRippleCamInt();
        ivec3 camOffset = camInt - (cameraPositionInt.y == -98257195
                        ? ivec3(floor(previousCameraPosition) + 0.5 * sign(previousCameraPosition))
                        : previousCameraPositionInt);

        ivec2 old = texel + camOffset.xz * RIPPLE_RES;

        vec4 cell = rwLoadCell(texel / RIPPLE_RES);
        if (cell.x <= rwNoWater + 1.0) {

            imageStore(rippleImg, texel, vec4(0.0, 0.0, rwNoWater, 0.0));
            return;
        }

        vec2 state = vec2(0.0);
        if (all(greaterThanEqual(old, ivec2(0))) && all(lessThan(old, ivec2(rwRippleRes)))) {
            state = imageLoad(rippleImg, old).xy;
        }

        if (any(isnan(state)) || any(isinf(state))) state = vec2(0.0);

        if (!rwRippleUpdateFrame()) {
            imageStore(rippleImg, texel, vec4(state, cell.x, 0.0));
            return;
        }

        float lap = 0.0;
        for (int i = 0; i < 4; i++) {
            ivec2 off = ivec2[4](ivec2(1, 0), ivec2(-1, 0), ivec2(0, 1), ivec2(0, -1))[i];

            vec4 nCell = rwLoadCell((texel + off) / RIPPLE_RES);
            ivec2 nOld = old + off;

            bool ok = nCell.x > rwNoWater + 1.0
                   && abs(nCell.x - cell.x) < 1.5
                   && all(greaterThanEqual(nOld, ivec2(0)))
                   && all(lessThan(nOld, ivec2(rwRippleRes)));

            float nh = ok ? imageLoad(rippleImg, nOld).x : state.x;
            if (isnan(nh) || isinf(nh)) nh = state.x;

            lap += nh - state.x;
        }

        float c = RIPPLE_SPEED * rwRippleSub;
        float dt = min(frameTime * float(RIPPLE_UPDATE_INTERVAL + 1), 0.65 / max(c, 0.01));

        state.y += (c * c * lap - RIPPLE_STIFFNESS * state.x) * dt;

        float moved = cell.y - cell.z;
        state.y += moved * (RIPPLE_ENTITY_I * 0.5);

        if (cell.y > 0.5 && RIPPLE_IDLE > 0.001) {
            float t = frameTimeCounter;
            float bob = sin(t * 4.0) + 0.5 * sin(t * 12.0);
            state.y = mix(state.y, bob * (RIPPLE_ENTITY_I * RIPPLE_IDLE), 0.05);
        }

        if (RIPPLE_PLAYER_I > 0.001 && abs(cell.x - (cameraPosition.y - float(camInt.y))) < 2.0) {
            vec2 rel = (vec2(texel) + 0.5) / rwRippleSub - float(rwRippleCells) * 0.5
                     - (cameraPosition - vec3(camInt)).xz;
            float d2 = dot(rel, rel);
            if (d2 < 1.5) {
                vec2 camVel = (cameraPosition - previousCameraPosition).xz;
                float dip = dot(rel * inversesqrt(max(d2, 1e-4)), camVel) / max(frameTime, 0.001);
                state.y = mix(state.y, clamp(dip, -8.0, 8.0) * RIPPLE_PLAYER_I, 0.02);
            }
        }

        state.x += state.y * dt;
        state *= exp(-RIPPLE_DAMPING * dt);

        state = clamp(state, vec2(-64.0), vec2(64.0));

        imageStore(rippleImg, texel, vec4(state, cell.x, 0.0));
    #endif
}

#endif
