
#include "/lib/common.glsl"

#if LOW_HEALTH == 1 && LOW_HEALTH_GLARE > 0
    #include "/lib/post/effects/effectsCommon.glsl"
    #include "/lib/post/effects/lowHealth.glsl"
#endif

#ifdef FRAGMENT_SHADER

noperspective in vec2 texCoord;

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    flat in vec3 upVec, sunVec;
#endif

float pw = 1.0 / viewWidth;
float ph = 1.0 / viewHeight;

vec2 view = vec2(viewWidth, viewHeight);

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    float SdotU = dot(sunVec, upVec);
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
#endif

#define BV_AUTO_EXPOSURE_WRITER
#include "/lib/misc/autoExposure.glsl"
#include "/lib/post/colorCorrection.glsl"
#include "/lib/atmospherics/fog/volumetricSea.glsl"

#ifdef BLOOM
    vec2 rescale = max(vec2(viewWidth, viewHeight) / vec2(1920.0, 1080.0), vec2(1.0));
    vec3 GetBloomTile(float lod, vec2 coord, vec2 offset) {
        float scale = exp2(lod);
        vec2 bloomCoord = coord / scale + offset;
        bloomCoord = clamp(bloomCoord, offset, 1.0 / scale + offset);

        vec3 bloom = texture2D(colortex3, bloomCoord / rescale).rgb;
        bloom *= bloom;
        bloom *= bloom;
        return bloom * 128.0;
    }

    void DoBloom(inout vec3 color, vec2 coord, float dither, float lViewPos) {
        vec3 blur1 = GetBloomTile(2.0, coord, vec2(0.0      , 0.0   ));
        vec3 blur2 = GetBloomTile(3.0, coord, vec2(0.0      , 0.26  ));
        vec3 blur3 = GetBloomTile(4.0, coord, vec2(0.135    , 0.26  ));
        vec3 blur4 = GetBloomTile(5.0, coord, vec2(0.2075   , 0.26  ));
        vec3 blur5 = GetBloomTile(6.0, coord, vec2(0.135    , 0.3325));
        vec3 blur6 = GetBloomTile(7.0, coord, vec2(0.160625 , 0.3325));
        vec3 blur7 = GetBloomTile(8.0, coord, vec2(0.1784375, 0.3325));

        vec3 blur = (blur1 + blur2 + blur3 + blur4 + blur5 + blur6 + blur7) * 0.14;

        float bloomStrength = BLOOM_STRENGTH + 0.2 * darknessFactor;

        #if LOW_HEALTH == 1 && LOW_HEALTH_GLARE > 0
            bloomStrength *= mix(1.0, LOW_HEALTH_GLARE * 0.01, bvLowHealthDanger());
        #endif

        #if defined BLOOM_FOG && defined NETHER && defined BORDER_FOG
            float farM = min(renderDistance, NETHER_VIEW_LIMIT);
            float netherBloom = lViewPos / clamp(farM, 96.0, 256.0);
            netherBloom *= netherBloom;
            netherBloom *= netherBloom;
            netherBloom = 1.0 - exp(-8.0 * netherBloom);
            netherBloom *= 1.0 - maxBlindnessDarkness;
            bloomStrength = mix(bloomStrength * 0.7, bloomStrength * 1.8, netherBloom);
        #endif

        color = mix(color, blur, bloomStrength);

    }
#endif

#ifdef BLOOM_FOG
    #include "/lib/atmospherics/fog/bloomFog.glsl"
#endif

#ifdef BLOOM
    #include "/lib/util/dither.glsl"
#endif

#if LENSFLARE_MODE > 0 && defined OVERWORLD
    #include "/lib/misc/lensFlare.glsl"
#endif

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;

    #if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
        float z0 = texture2D(depthtex0, texCoord).r;

        vec4 screenPos = vec4(texCoord, z0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
        viewPos /= viewPos.w;
        float lViewPos = length(viewPos.xyz);

        #if defined DISTANT_HORIZONS && defined NETHER
            float z0DH = texelFetch(dhDepthTex, texelCoord, 0).r;
            vec4 screenPosDH = vec4(texCoord, z0DH, 1.0);
            vec4 viewPosDH = dhProjectionInverse * (screenPosDH * 2.0 - 1.0);
            viewPosDH /= viewPosDH.w;
            lViewPos = min(lViewPos, length(viewPosDH.xyz));
        #endif
    #else
        float lViewPos = 0.0;
    #endif

    float dither = texture2D(noisetex, texCoord * view / 128.0).b;
    #ifdef TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #if (defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE) && defined OVERWORLD
        if (isEyeInWater == 0) {
            float seaZ = texture2D(depthtex0, texCoord).r;
            vec4 seaHit = gbufferProjectionInverse * (vec4(texCoord, seaZ, 1.0) * 2.0 - 1.0);
            vec4 seaFar = gbufferProjectionInverse * (vec4(texCoord, 1.0, 1.0) * 2.0 - 1.0);
            vec3 seaDir = normalize(mat3(gbufferModelViewInverse) * (seaFar.xyz / seaFar.w));
            vec3 seaSun = normalize(mat3(gbufferModelViewInverse) * sunVec);
            float seaDist = seaZ >= 1.0 ? 65536.0 : length(seaHit.xyz / seaHit.w);
            #ifdef VOL_FOG_ACTIVE
                bvVolumetricSea(color, seaDir, seaSun, seaDist, dither);
            #endif
            #ifdef VOLCAVE_ACTIVE
                bvCaveFog(color, seaDir, seaSun, seaDist, dither);
            #endif
        }
    #endif

    #ifdef BLOOM_FOG
        color /= GetBloomFog(lViewPos);
    #endif

    #ifdef BLOOM
        DoBloom(color, texCoord, dither, lViewPos);
    #endif

    #ifdef COLORGRADING
        color =
            pow(color.r, GR_RC) * vec3(GR_RR, GR_RG, GR_RB) +
            pow(color.g, GR_GC) * vec3(GR_GR, GR_GG, GR_GB) +
            pow(color.b, GR_BC) * vec3(GR_BR, GR_BG, GR_BB);
        color *= 0.01;
    #endif

    #if (CC_MODE == 2 || CC_MODE == 3) && CC_SKY_CHROMA > 0

        float skyDepth = texture2D(depthtex0, texCoord).r;
        vec3 preTonemapColor = color;
    #endif

    #if AUTO_EXPOSURE == 1
        if (texelCoord == ivec2(0, 0)) bvAutoExposureUpdate(colortex0);
    #endif

    DoTonemap(color);

    #if (CC_MODE == 2 || CC_MODE == 3) && CC_SKY_CHROMA > 0
        if (skyDepth >= 1.0) {

            vec4 skyView = gbufferProjectionInverse * (vec4(texCoord, 1.0, 1.0) * 2.0 - 1.0);
            vec3 skyPlayerDir = normalize(mat3(gbufferModelViewInverse) * (skyView.xyz / skyView.w));
            ccRestoreSkyChroma(color, preTonemapColor, max(skyPlayerDir.y, 0.0));
        }
    #endif

    #if defined GREEN_SCREEN_LIME || SELECT_OUTLINE >= 0
        int materialMaskInt = int(texelFetch(colortex6, texelCoord, 0).g * 255.1);
    #endif

    #ifdef GREEN_SCREEN_LIME
        if (materialMaskInt == 240) {
            color = vec3(0.0, 1.0, 0.0);
        }
    #endif

    #if SELECT_OUTLINE == 4
        if (materialMaskInt == 252) {
            float colorMF = 1.0 - dot(color, vec3(0.25, 0.45, 0.1));
            colorMF = smoothstep1(smoothstep1(smoothstep1(smoothstep1(smoothstep1(colorMF)))));
            color = mix(color, 3.0 * (color + 0.2) * vec3(colorMF * SELECT_OUTLINE_I), 0.3);
        }
    #endif

    #if LENSFLARE_MODE > 0 && defined OVERWORLD
        DoLensFlare(color, viewPos.xyz, dither);
    #endif

    DoColorGrade(color);

    float filmGrain = dither;
    color += vec3((filmGrain - 0.25) / 128.0);

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(color, 1.0);
}

#endif

#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

#if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
    flat out vec3 upVec, sunVec;
#endif

void main() {
    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    #if defined BLOOM_FOG || defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE || LENSFLARE_MODE > 0 && defined OVERWORLD
        upVec = normalize(gbufferModelView[1].xyz);
        sunVec = GetSunVector();
    #endif
}

#endif
