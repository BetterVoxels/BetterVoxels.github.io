
#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER

noperspective in vec2 texCoord;

float GetLinearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

#if FXAA_DEFINE == 1
    #include "/lib/antialiasing/fxaa.glsl"
#endif

#include "/lib/vx/voxelReading.glsl"
#include "/lib/vx/irradianceCache.glsl"

#include "/lib/post/effects/effectsCommon.glsl"
#include "/lib/post/effects/exposureSpike.glsl"
#include "/lib/post/effects/screenRainDirt.glsl"
#include "/lib/post/effects/lensFogging.glsl"
#include "/lib/post/effects/lightHalos.glsl"
#include "/lib/post/effects/heatWave.glsl"
#include "/lib/post/effects/cameraShake.glsl"
#include "/lib/post/effects/waterPlunge.glsl"

vec3 fractCamPos = cameraPositionInt.y == -98257195 ? fract(cameraPosition) : cameraPositionFract;

void main() {

    vec2 texCoordL = texCoord;

    #if CAMERA_MOTION == 1
        texCoordL = CameraShakeUV(texCoordL);
    #endif

    #if HEAT_DISTORTION == 1
        vec2 texCoordM = HeatWaveUV(texCoordL);
        vec3 color = texture2D(colortex3, texCoordM).rgb;
    #elif CAMERA_MOTION == 1
        vec2 texCoordM = texCoordL;
        vec3 color = texture2D(colortex3, texCoordM).rgb;
    #else
        vec2 texCoordM = texCoord;
        vec3 color = texelFetch(colortex3, texelCoord, 0).rgb;
    #endif

    #if FXAA_DEFINE == 1
        FXAA311(color);
    #endif

    #if LIGHT_HALOS == 1
        color = ApplyLightHalos(color, colortex3, texCoordM);
    #endif
    #if SCREEN_DROPLETS == 1

        float aboveCloudFactor = clamp((cameraPosition.y - (float(CloudLayer0_height) + 100.0)) / 20.0, 0.0, 1.0);
        vec3 rainedColor = ApplyScreenRainDirt(color, colortex3, texCoordM);
        color = mix(rainedColor, color, aboveCloudFactor);
    #endif
    #if LENS_FOGGING == 1
        color = ApplyLensFogging(color, colortex3, texCoordM);
    #endif
    #if WATER_PLUNGE == 1
        color = ApplyWaterPlunge(color, colortex3, texCoordM);
    #endif
    #if EXPOSURE_SPIKE == 1
        color = ApplyExposureSpike(color);
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(color, 1.0);

}

#endif

#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

void main() {
    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
