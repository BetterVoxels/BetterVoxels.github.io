#include "/lib/misc/voxelization.glsl"

vec3 GetRawWave(in vec3 pos, float wind) {
    float magnitude = sin(wind * 0.0027 + pos.z + pos.y) * 0.04 + 0.04;
    float d0 = sin(wind * 0.0127);
    float d1 = sin(wind * 0.0089);
    float d2 = sin(wind * 0.0114);
    vec3 wave;
    wave.x = sin(wind*0.0063 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
    wave.z = sin(wind*0.0224 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
    wave.y = sin(wind*0.0015 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;

    return wave;
}

vec3 GetWave(in vec3 pos, float waveSpeed) {
    float wind = frameTimeCounter * waveSpeed * WAVING_SPEED;
    vec3 wave = GetRawWave(pos, wind);

    #define WAVING_I_RAIN_MULT_M WAVING_I_RAIN_MULT * 0.01

    #if WAVING_I_RAIN_MULT > 100
        float windRain = frameTimeCounter * waveSpeed * WAVING_I_RAIN_MULT_M * WAVING_SPEED;
        vec3 waveRain = GetRawWave(pos, windRain);
        wave = mix(wave, waveRain, rainFactor);
    #endif

    #ifdef NO_WAVING_INDOORS
        wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
    #else
        wave *= 0.1;
    #endif

    float wavingIntensity = WAVING_I * mix(1.0, WAVING_I_RAIN_MULT_M, rainFactor);

    return wave * wavingIntensity;
}

void DoWave_Foliage(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos.y *= 0.5;

    vec3 wave = GetWave(worldPos, 170.0);
    wave.x = wave.x * 8.0 + wave.y * 4.0;
    wave.y = 0.0;
    wave.z = wave.z * 3.0;

    playerPos.xyz += wave * waveMult;
}

void DoWave_Leaves(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos *= vec3(0.75, 0.375, 0.75);

    vec3 wave = GetWave(worldPos, 170.0);
    wave *= vec3(8.0, 3.0, 4.0);

    wave *= 1.0 - inSnowy; // Leaves with snow on top look wrong

    playerPos.xyz += wave * waveMult;
}

// Leaves Physics: extra grass/leaves motion layered on top of the wind sway
// above. LEAVES_PHYSICS_ENTITIES bends foliage away from nearby moving
// entities (using the camera/player, which is the only entity position the
// standard gbuffers pipeline actually exposes) -- gated per call site by
// allowEntityPush, since leaves shouldn't react to the player at all, only
// grass/flowers/low foliage should. LEAVES_PHYSICS_WEATHER adds a steady
// lean plus a gentle sway during rain and thunderstorms, biased in the same
// direction the clouds scroll (see ModifyTracePos() in
// lib/atmospherics/clouds/cloudCoord.glsl). Both are gated by
// LEAVES_PHYSICS_MODE and scaled by LEAVES_PHYSICS_STRENGTH at the call
// sites in DoWave() below. heightMask (0 at the base, 1 higher up the
// model) keeps the root pinned in place so the block bends instead of
// sliding as a whole -- see physicsHeightMask in DoWave().
//
// LEAVES_PHYSICS_ACTIVE (not just LEAVES_PHYSICS) additionally requires
// GBUFFERS_TERRAIN: DoWave() also runs while rendering the shadow map, and
// that pass writes its position straight into the shadow depth output (see
// shadow.glsl, gl_Position = ... * position after DoWave). A moving,
// previously sometimes-jittery displacement there reads as noise in the
// shadow itself -- grid-like artifacts and extra darkening on the ground
// underneath, worse wherever normal mapping/IPBR makes that noise more
// visible. The regular wind sway (DoWave_Foliage/DoWave_Leaves) is
// unaffected and still shadows normally; only this extra layer is held back
// from the shadow pass. This does NOT touch voxelization (UpdateVoxelMap in
// voxelization.glsl) -- that reads straight from the undisplaced gl_Vertex
// and was never affected by this either way.
#if defined LEAVES_PHYSICS && defined GBUFFERS_TERRAIN
    #define LEAVES_PHYSICS_ACTIVE
#endif

#ifdef LEAVES_PHYSICS_ACTIVE
vec3 GetLeavesPhysicsOffset(vec3 worldPos, vec3 relativePos, float heightMask, bool allowEntityPush) {
    vec3 offset = vec3(0.0);

    #ifdef LEAVES_PHYSICS_ENTITIES
        if (allowEntityPush) {
            // Pure position-based push -- no per-frame velocity estimate. That
            // was the main source of jitter: a value derived from differencing
            // camera position frame-to-frame is inherently noisy, and smoothing
            // the falloff curve around it can't fully hide that. A push that
            // only depends on distance is smooth by construction, every frame.
            vec2 toBlade = relativePos.xz; // camera/player -> vertex, already precise
            float distXZ = length(toBlade);

            // distance * exp2(-k*distance): zero exactly at the player's feet
            // (there's no direction to push in there anyway), rises over
            // roughly the first half-block, then decays smoothly with no hard
            // edge and no branching or division.
            vec2 pushVector = toBlade * exp2(-1.8 * distXZ);

            offset.xz += pushVector * 0.9;
        }
    #endif

    #ifdef LEAVES_PHYSICS_WEATHER
        const vec2 windDirection = vec2(1.0, 0.0); // same horizontal bias as the cloud scroll direction

        // Wind shouldn't act on plants indoors/underground -- reuse the same
        // skylight signal and threshold the base wave system already uses
        // (see NO_WAVING_INDOORS in GetWave() above) so the two agree.
        #ifdef NO_WAVING_INDOORS
            float skylightFactor = clamp(lmCoord.y - 0.87, 0.0, 0.1) * 10.0;
        #else
            float skylightFactor = 1.0;
        #endif

        float weatherAmount = (rainFactor + thunderStrength * 0.75) * skylightFactor;

        // Multiple sine octaves instead of one -- richer, less obviously
        // mechanical motion (same idea as summing noise octaves for terrain).
        float t     = frameTimeCounter * WAVING_SPEED;
        float phase = worldPos.x * 0.4 + worldPos.z * 0.4;
        float sway  = sin(t * 1.1 + phase) + 0.5 * sin(t * 2.3 - phase * 1.7) + 0.25 * sin(t * 4.1 + phase * 0.6);
        sway *= 0.57; // renormalize back to roughly [-1, 1]

        // Occasional stronger gusts layered on top; squaring makes it
        // "peaky" -- mostly calm with occasional stronger pushes, instead
        // of one smooth even pulse.
        float gustPhase = t * 0.7 + worldPos.x * 0.13 - worldPos.z * 0.17;
        float gust = sin(gustPhase) * 0.5 + 0.5;
        gust *= gust;

        // Steady lean toward the wind (grows with rain/thunder) plus the
        // sway and gusts layered around it -- plants tilt one way and keep
        // moving around that tilt, instead of pumping in and out from zero.
        vec2 lean   = windDirection * weatherAmount * 0.22;
        vec2 motion = windDirection * (sway * 0.10 + gust * 0.12) * weatherAmount
                    + vec2(-windDirection.y, windDirection.x) * sway * weatherAmount * 0.05;

        offset.xz += lean + motion;
    #endif

    return offset * heightMask;
}
#endif

void DoWave_Water(inout vec3 playerPos, vec3 worldPos) {
    #ifdef INTERACTIVE_WATER
        #include "/lib/materials/specificMaterials/translucents/interactiveWaterConsts.glsl"

        vec2 interactiveWaterPos = (playerPos.xz + cameraPositionFract.xz)/shadowMapResolution + 0.25;
        vec3[2] waveStrengths = vec3[2](
            texture(shadowcolor2, interactiveWaterPos + vec2(0.0, 0.0)).xyz * waveStrengthCoeffs[0],
            texture(shadowcolor2, interactiveWaterPos + vec2(0.5, 0.0)).xyz * waveStrengthCoeffs[1]
        );

        int maxDetail = max(1, 4 - int(0.02 * length(playerPos)));
        vec3 distortion = texture(shadowcolor3, worldPos.xz / (1024.0 * 5)).rgb;

        float offset = 0.0;
        for (int i = 0; i < 3; i++) {
            vec2 thisPos = worldPos.xz;
            thisPos += 2 * (dot(thisPos, waveDirs[i]) + distortion[i]) * waveDirs[i];
            thisPos *= 0.3;
            for (int k = 0; k < min(2, maxDetail); k++) {
                float thisOffset = texture(colortex9, fract(
                    (thisPos / waveLengths[k] - waveSpeed * frameTimeCounter / sqrt(waveLengths[k]) * waveDirs[i] - 0.5) / 1024.0
                )).b - 0.5;
                offset += waveStrengths[k][i] * thisOffset;
            }
        }
        playerPos.y -= offset;
    #else
        float waterWaveTime = frameTimeCounter * 6.0 * WAVING_SPEED;
        worldPos.xz *= 14.0;

        float wave  = sin(waterWaveTime * 0.7 + worldPos.x * 0.14 + worldPos.z * 0.07);
              wave += sin(waterWaveTime * 0.5 + worldPos.x * 0.10 + worldPos.z * 0.05);

        #ifdef NO_WAVING_INDOORS
            wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
        #else
            wave *= 0.1;
        #endif

        playerPos.y += wave * 0.125 - 0.05;

        #if defined GBUFFERS_WATER && WATER_STYLE == 1
            normal = mix(normal, tangent, wave * 0.01);
        #endif
    #endif
}

void DoWave_Lava(inout vec3 playerPos, vec3 worldPos) {
    if (fract(worldPos.y + 0.005) > 0.06) {
        float lavaWaveTime = frameTimeCounter * 3.0 * WAVING_SPEED;
        worldPos.xz *= 14.0;

        float wave  = sin(lavaWaveTime * 0.7 + worldPos.x * 0.14 + worldPos.z * 0.07);
              wave += sin(lavaWaveTime * 0.5 + worldPos.x * 0.05 + worldPos.z * 0.10);

        playerPos.y += wave * 0.0125;
    }
}

void DoWave(inout vec3 playerPos, int mat) {
    vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
    #ifdef LEAVES_PHYSICS_ACTIVE
        vec3 physicsRelativePos = playerPos.xyz; // relative to camera, captured before any wave offset is applied

        // 0 at the base of the block, ramping to 1 by 62.5% of the way up,
        // so Leaves Physics only bends the upper part of the model and the
        // root stays anchored (fixes whole blocks sliding off their grid
        // position). smoothstep instead of a linear ramp keeps the curve
        // fully smooth with no kink where it saturates. 0.625 approximates
        // where short-grass models actually end; raise it if tips still
        // feel too weak, lower it if the bend starts too close to the ground.
        //
        // The "+ 0.05" matters: base vertices sit almost exactly on an
        // integer world Y (the block boundary), which is exactly where
        // fract() has its discontinuity -- it wraps from ~1 back to ~0.
        // worldPos.y is reconstructed as playerPos.y + cameraPosition.y,
        // and that reconstruction picks up a tiny bit of floating-point
        // rounding noise that changes as cameraPosition.y changes, i.e.
        // during vertical movement specifically. Sitting exactly at fract()'s
        // discontinuity, that noise was enough to flip the mask between ~0
        // and ~1 every frame while flying/falling -- the reported "chaotic"
        // jitter tied to vertical movement. Offsetting by a small constant
        // moves the discontinuity to a height with no real geometry on it,
        // so the actual base vertices land on a stable, flat part of the
        // curve instead of teetering on the edge of it.
        float physicsHeightMask = smoothstep(0.0, 0.625, fract(worldPos.y + 0.05));
    #endif

    #if defined GBUFFERS_TERRAIN || defined SHADOW
        #ifdef WAVING_FOLIAGE
            if (mat == 10005
                #ifdef DO_MORE_FOLIAGE_WAVING
                    || mat == 10769
                    || mat == 10924
                    || mat == 10972
                #endif
            ) { // Grounded Waving Foliage
                if (gl_MultiTexCoord0.t < mc_midTexCoord.t || fract(worldPos.y + 0.21) > 0.26)
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, true) * LEAVES_PHYSICS_STRENGTH;
                #endif
            }
            
            else if (mat == 10021) { // Upper Layer Waving Foliage
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, true) * LEAVES_PHYSICS_STRENGTH;
                #endif
            }

            #if defined WAVING_LEAVES || defined WAVING_LAVA || defined WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LEAVES
            if (mat == 10009) { // Leaves
                DoWave_Leaves(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, false) * LEAVES_PHYSICS_STRENGTH;
                #endif
            } else if (mat == 10013) { // Vine
                // Reduced waving on vines to prevent clipping through blocks
                DoWave_Leaves(playerPos.xyz, worldPos, 0.75);
            }
            #if defined NETHER || defined DO_NETHER_VINE_WAVING_OUTSIDE_NETHER
                else if (mat == 10884 || mat == 10885) { // Weeping Vines, Twisting Vines
                    float waveMult = 1.0;
                    #if COLORED_LIGHTING_INTERNAL > 0
                        vec3 playerPosP = playerPos + vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosP = SceneToVoxel(playerPosP);
                        vec3 playerPosN = playerPos - vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosN = SceneToVoxel(playerPosN);

                        if (CheckInsideVoxelVolume(voxelPosP)) {
                            int voxelP = int(texelFetch(voxel_sampler, ivec3(voxelPosP), 0).r);
                            int voxelN = int(texelFetch(voxel_sampler, ivec3(voxelPosN), 0).r);
                            if (voxelP != 0 && voxelP != 65 || voxelN != 0 && voxelN != 65) // not air, not weeping vines
                                waveMult = 0.0;
                        }
                        DoWave_Foliage(playerPos.xyz, worldPos, waveMult);
                    #endif
                }
            #endif

            #if defined WAVING_LAVA || defined WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LAVA
            if (mat == 10068) { // Lava
                DoWave_Lava(playerPos.xyz, worldPos);

                #ifdef GBUFFERS_TERRAIN
                    // G8FL735 Fixes Optifine-Iris parity. Optifine has 0.9 gl_Color.rgb on a lot of versions
                    glColorRaw.rgb = min(glColorRaw.rgb, vec3(0.9));
                #endif
            }

            #ifdef WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LILY_PAD
            if (mat == 10489) { // Lily Pad
                DoWave_Water(playerPos.xyz, worldPos);
            }
        #endif
    #endif

    #if defined GBUFFERS_WATER || defined SHADOW
        #ifdef WAVING_WATER_VERTEX
            #if defined WAVING_ANYTHING_TERRAIN && defined SHADOW
                else
            #endif

            if (mat == 32000) { // Water
                if (fract(worldPos.y + 0.005) > 0.06)
                DoWave_Water(playerPos.xyz, worldPos);
            }
        #endif
    #endif
}
