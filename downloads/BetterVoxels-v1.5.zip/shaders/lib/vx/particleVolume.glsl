#ifndef INCLUDE_PARTICLE_VOLUME_COMMON
#define INCLUDE_PARTICLE_VOLUME_COMMON

#define PVOL_DIM PARTICLE_SHADOW_RES
#define PVOL_LIGHT_CAP 256

float pvolScale = float(PARTICLE_SHADOW_RES) / (2.0 * PARTICLE_VOL_RADIUS);

vec3 pvolReadDelta = cameraPosition - previousCameraPosition;

bool pvolCell(vec3 playerPos, vec3 originDelta, out ivec3 cell) {
    cell = ivec3(floor((playerPos + originDelta) * pvolScale)) + PVOL_DIM / 2;
    return all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(PVOL_DIM)));
}

int pvolWriteY = (frameCounter % 2) * PVOL_DIM;
int pvolReadY = ((frameCounter + 1) % 2) * PVOL_DIM;

#endif

#ifdef PARTICLE_VOL_WRITE
#ifndef INCLUDE_PARTICLE_VOLUME_W
#define INCLUDE_PARTICLE_VOLUME_W

    layout(r32ui) uniform restrict uimage3D particleDensityVol;
    layout(r32ui) uniform restrict uimage3D particleLightVol;

    void pvolWriteDensity(vec3 playerPos, float density) {
        uint d = uint(clamp(density, 0.0, 1.0) * 255.0);
        if (d == 0u) return;
        ivec3 c;
        if (!pvolCell(playerPos, vec3(0.0), c)) return;
        c.y += pvolWriteY;
        imageAtomicMax(particleDensityVol, c, d);
    }

    void pvolWriteLight(vec3 playerPos, vec3 emissiveColor) {
        vec3 col = max(emissiveColor, vec3(0.0));
        float lum = dot(col, vec3(0.2125, 0.7154, 0.0721));
        if (lum <= 0.0) return;
        ivec3 c;
        if (!pvolCell(playerPos, vec3(0.0), c)) return;

        vec3 norm = col / max(lum, 0.0001);
        uint pvolBits = (uint(clamp(lum, 0.004, 1.0) * 255.0) << 24)
                      | (uint(clamp(norm.r, 0.0, 1.0) * 255.0) << 16)
                      | (uint(clamp(norm.g, 0.0, 1.0) * 255.0) << 8)
                      |  uint(clamp(norm.b, 0.0, 1.0) * 255.0);
        imageAtomicMax(particleLightVol, c, pvolBits);
    }
#endif
#endif

#ifdef PARTICLE_VOL_READ
#ifndef INCLUDE_PARTICLE_VOLUME_R
#define INCLUDE_PARTICLE_VOLUME_R

    uniform usampler3D particle_density_sampler;

    float pvolReadDensity(vec3 playerPos) {
        ivec3 c;
        if (!pvolCell(playerPos, pvolReadDelta, c)) return 0.0;
        c.y += pvolReadY;
        return float(texelFetch(particle_density_sampler, c, 0).r) * (1.0 / 255.0);
    }

    #if PARTICLE_SHADOWS == 1

        float GetParticleShadow(vec3 playerPos, vec3 lightDirPlayer, float dither) {
            float stepLen = PARTICLE_SHADOW_LENGTH / float(PARTICLE_SHADOW_STEPS);
            vec3 stepVec = lightDirPlayer * stepLen;
            vec3 p = playerPos + stepVec * (0.5 + 0.5 * dither);
            float acc = 0.0;
            for (int i = 0; i < PARTICLE_SHADOW_STEPS; i++) {
                acc += pvolReadDensity(p);
                p += stepVec;
            }

            return clamp(exp(-acc * stepLen * PARTICLE_SHADOW_DENSITY),
                         1.0 - PARTICLE_SHADOW_STRENGTH, 1.0);
        }
    #endif

    #if PARTICLE_LIGHT == 1
        uniform sampler2D particle_light_sampler;
        uniform usampler2D particle_count_sampler;

        vec3 GetParticleLight(vec3 playerPos, vec3 normal) {
            int count = int(min(texelFetch(particle_count_sampler, ivec2(0, 0), 0).r,
                                uint(PARTICLE_LIGHT_MAX)));
            vec3 sum = vec3(0.0);
            for (int i = 0; i < count; i++) {
                vec4 posRad = texelFetch(particle_light_sampler, ivec2(0, i), 0);
                vec3 delta = posRad.xyz - playerPos;
                float dist2 = dot(delta, delta);
                if (dist2 > posRad.w * posRad.w) continue;
                vec4 colInt = texelFetch(particle_light_sampler, ivec2(1, i), 0);

                float atten = colInt.w / (1.0 + dist2);
                float edge = 1.0 - dist2 / (posRad.w * posRad.w);
                float NdotL = max(dot(normal, delta * inversesqrt(max(dist2, 0.0001))), 0.0);
                sum += colInt.rgb * (atten * edge * edge * mix(1.0, NdotL, PARTICLE_LIGHT_DIRECTIONALITY));
            }
            return sum * PARTICLE_LIGHT_STRENGTH;
        }
    #endif
#endif
#endif
