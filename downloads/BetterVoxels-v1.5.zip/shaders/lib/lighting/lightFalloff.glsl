#ifndef INCLUDE_LIGHT_FALLOFF
#define INCLUDE_LIGHT_FALLOFF

#if STYLIZED_LIGHTS == 1
    #define LIGHT_SHAPE_TAU 6.28318530718

    float stylizedLightShape(vec3 dir) {
        #if STYLIZED_LIGHT_SHAPE == 0
            return 1.0;
        #else
            float ang = atan(dir.z, dir.x) + frameTimeCounter * STYLIZED_LIGHT_ROTATE;
            #if STYLIZED_LIGHT_SHAPE == 1
                #if STYLIZED_LIGHT_SIDES < 3

                    return abs(cos(ang));
                #else

                float seg = LIGHT_SHAPE_TAU / float(STYLIZED_LIGHT_SIDES);
                float halfSeg = 0.5 * seg;
                return cos(halfSeg) / cos(mod(ang, seg) - halfSeg);
                #endif
            #else

                return 1.0 - STYLIZED_LIGHT_STAR_DEPTH *
                       (1.0 - abs(cos(0.5 * float(STYLIZED_LIGHT_SIDES) * ang)));
            #endif
        #endif
    }
#endif

float lightFalloff(vec3 dir, float dirLen, float traceRange) {
    #if STYLIZED_LIGHTS == 1
        float shapedRange = traceRange * stylizedLightShape(dir);
        float x = dirLen / max(shapedRange, 0.001);
        if (x >= 1.0) return 0.0;

        float t = min((1.0 - x) / max(STYLIZED_LIGHT_SOFTNESS, 0.002), 1.0);
        float window = t * t * (3.0 - 2.0 * t);

        return window * STYLIZED_LIGHT_BRIGHTNESS / (x
            #if R2_FALLOFF == 1
                * x
            #endif
            + 0.01
        ) / (
            LIGHT_TRACE_LENGTH
            #if R2_FALLOFF == 1
                * sqrt(sqrt(LIGHT_TRACE_LENGTH))
            #endif
        );
    #else
        float x = dirLen / traceRange;

        float t = min((1.0 - x) * (1.0 / 0.35), 1.0);
        return distanceFalloff(x) * t * t * (3.0 - 2.0 * t);
    #endif
}

#endif
