#ifndef INCLUDE_COLOR_TEMPERATURE
#define INCLUDE_COLOR_TEMPERATURE

vec3 ccBlackbody(float kelvin) {
    float t = pow(kelvin, -1.5);
    float lt = log(kelvin);

    vec3 col;
    col.x = 220000.0 * t + 0.58039215686;
    col.y = kelvin > 6500.0 ? 138039.215686 * t + 0.72156862745
                            : 0.39231372549 * lt - 2.44549019608;
    col.z = 0.76078431372 * lt - 5.68078431373;
    col = clamp(col, vec3(0.0), vec3(1.0));
    if (kelvin < 1000.0) col *= kelvin * 0.001;

    col = pow(col, vec3(2.2));
    return col / max(dot(col, vec3(0.2125, 0.7154, 0.0721)), 0.0001);
}

#endif
