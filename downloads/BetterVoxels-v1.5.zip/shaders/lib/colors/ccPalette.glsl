#ifndef INCLUDE_CC_PALETTE
    #define INCLUDE_CC_PALETTE

    #if CC_MODE == 1

        const vec3 ccLightMorning = vec3(1.0000, 1.0000, 1.0000);
        const vec3 ccLightNoon    = vec3(1.0019, 1.0789, 1.0115);
        const vec3 ccLightNight   = vec3(0.9000, 0.9000, 0.9000);
        const vec3 ccLightRain    = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccAtmMorning   = vec3(0.9000, 0.9000, 0.8103);
        const vec3 ccAtmNoon      = vec3(0.8500, 0.9200, 0.8100);
        const vec3 ccAtmNight     = vec3(0.9000, 0.9000, 0.9000);
        const vec3 ccAtmRain      = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccBlocklight   = vec3(1.0000, 0.9630, 0.9935);

        const vec3 ccSkyHorizon   = vec3(1.0);
        const vec3 ccSkyZenith    = vec3(1.0);

        const vec3 ccSkyNoonUp     = vec3(1.0);
        const vec3 ccSkyNoonMid    = vec3(1.0);
        const vec3 ccSkyNoonDown   = vec3(1.0);
        const vec3 ccSkySunsetUp   = vec3(1.0);
        const vec3 ccSkySunsetMid  = vec3(1.0);

        const vec3 ccSkySunsetDown = vec3(1.0);

        const vec3 ccSkyNightUp    = vec3(1.0);
        const vec3 ccSkyNightMid   = vec3(1.0);
        const vec3 ccSkyNightDown  = vec3(1.0);

        const float ccBlocklightI  = 1.00;
        const float ccAmbientI     = 1.00;
        const float ccExposureI    = 1.00;

        const vec3  ccSkyRayleigh   = vec3(1.0);
        const float ccSkyExposureDay   = 1.00;
        const float ccSkyExposureNight = 1.00;
        const float ccSkySatBoost      = 1.00;
        const vec3  ccSkyZenithTint    = vec3(1.0);
        const float ccSkyMieStrength   = 1.00;
        const float ccSkyGradSat       = 1.0 / SKY_SATURATION_V13_NEUTRAL;
        const float ccSkyLevel         = 1.00;

        const float ccSkyBlueNeutral   = 1.50;
        const float ccSkyHorizonFade   = 0.0;
    #elif CC_MODE == 2

        const vec3 ccLightMorning = vec3(0.8107, 1.0762, 1.3505);
        const vec3 ccLightNoon    = vec3(0.8849, 1.0249, 1.2543);
        const vec3 ccLightNight   = vec3(0.9743, 1.0486, 0.7201);
        const vec3 ccLightRain    = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccAtmMorning   = vec3(0.9148, 1.0343, 1.1577);
        const vec3 ccAtmNoon      = vec3(0.9309, 1.0149, 1.1526);
        const vec3 ccAtmNight     = vec3(0.9846, 1.0291, 0.8320);
        const vec3 ccAtmRain      = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccBlocklight   = vec3(0.8535, 1.0520, 1.2705);

        const vec3 ccSkyHorizon   = vec3(1.03, 1.00, 0.97);
        const vec3 ccSkyZenith    = vec3(0.98, 0.99, 1.03);

        const vec3 ccSkyNoonUp     = vec3(0.8500, 0.9200, 0.8100);
        const vec3 ccSkyNoonMid    = vec3(0.9331, 1.0117, 1.0437);
        const vec3 ccSkyNoonDown   = vec3(0.9821, 0.9875, 0.9587);
        const vec3 ccSkySunsetUp   = vec3(0.9000, 0.9000, 0.8103);
        const vec3 ccSkySunsetMid  = vec3(1.0000, 0.9900, 1.0400);
        const vec3 ccSkySunsetDown = vec3(1.0000, 0.9600, 1.1200);
        const vec3 ccSkyNightUp    = vec3(1.0300, 1.0000, 0.9500);
        const vec3 ccSkyNightMid   = vec3(1.0200, 1.0000, 0.9650);
        const vec3 ccSkyNightDown  = vec3(1.0200, 1.0000, 0.9700);

        const float ccBlocklightI  = 0.92;
        const float ccAmbientI     = 1.00;
        const float ccExposureI    = 1.00;

        const vec3  ccSkyRayleigh   = vec3(0.7196, 0.8078, 0.8113);
        const float ccSkyExposureDay   = 0.0999;
        const float ccSkyExposureNight = 0.3500;
        const float ccSkySatBoost      = 1.0512;
        const vec3  ccSkyZenithTint    = vec3(0.287, 0.701, 2.544);
        const float ccSkyMieStrength   = 0.70;
        const float ccSkyGradSat       = 1.00;
        const float ccSkyLevel         = 1.00;

        const float ccSkyBlueNeutral   = 1.00;
        const float ccSkyHorizonFade   = 1.0;
    #elif CC_MODE == 3

        const vec3 ccLightMorning = vec3(1.1400, 1.0000, 0.8200);
        const vec3 ccLightNoon    = vec3(1.0600, 1.0000, 0.9200);
        const vec3 ccLightNight   = vec3(0.9200, 0.9700, 1.1200);
        const vec3 ccLightRain    = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccAtmMorning   = vec3(1.0600, 1.0000, 0.9200);
        const vec3 ccAtmNoon      = vec3(1.0200, 1.0000, 0.9700);
        const vec3 ccAtmNight     = vec3(0.9600, 0.9900, 1.0600);
        const vec3 ccAtmRain      = vec3(1.0000, 1.0000, 1.0000);

        const vec3 ccBlocklight   = vec3(1.0400, 1.0000, 0.9300);

        const vec3 ccSkyHorizon   = vec3(1.03, 1.00, 0.97);

        const vec3 ccSkyZenith    = vec3(1.020, 0.990, 0.481);

        const vec3 ccSkyNoonUp     = vec3(0.8500, 0.9200, 0.8100);
        const vec3 ccSkyNoonMid    = vec3(0.9331, 1.0117, 1.0437);
        const vec3 ccSkyNoonDown   = vec3(0.9821, 0.9875, 0.9587);
        const vec3 ccSkySunsetUp   = vec3(0.9000, 0.9000, 0.8103);
        const vec3 ccSkySunsetMid  = vec3(1.0000, 0.9900, 1.0400);
        const vec3 ccSkySunsetDown = vec3(1.0000, 0.9600, 1.1200);
        const vec3 ccSkyNightUp    = vec3(1.0300, 1.0000, 0.9500);
        const vec3 ccSkyNightMid   = vec3(1.0200, 1.0000, 0.9650);
        const vec3 ccSkyNightDown  = vec3(1.0200, 1.0000, 0.9700);

        const float ccBlocklightI  = 1.00;

        const float ccAmbientI     = 0.35;
        const float ccExposureI    = 0.75;

        const vec3  ccSkyRayleigh   = vec3(0.7196, 0.8078, 0.8113);
        const float ccSkyExposureDay   = 0.0999;
        const float ccSkyExposureNight = 0.3500;
        const float ccSkySatBoost      = 1.00;

        const vec3  ccSkyZenithTint    = vec3(1.0);
        const float ccSkyMieStrength   = 1.00;

        const float ccSkyGradSat       = 0.55;

        const float ccSkyLevel         = 0.865;
        const float ccSkyBlueNeutral   = 1.00;
        const float ccSkyHorizonFade   = 1.0;
    #else

        const vec3 ccLightMorning = vec3(1.0);
        const vec3 ccLightNoon    = vec3(1.0);
        const vec3 ccLightNight   = vec3(1.0);
        const vec3 ccLightRain    = vec3(1.0);

        const vec3 ccAtmMorning   = vec3(1.0);
        const vec3 ccAtmNoon      = vec3(1.0);
        const vec3 ccAtmNight     = vec3(1.0);
        const vec3 ccAtmRain      = vec3(1.0);

        const vec3 ccBlocklight   = vec3(1.0);

        const vec3 ccSkyHorizon   = vec3(1.0);
        const vec3 ccSkyZenith    = vec3(1.0);

        const vec3 ccSkyNoonUp     = vec3(1.0);
        const vec3 ccSkyNoonMid    = vec3(1.0);
        const vec3 ccSkyNoonDown   = vec3(1.0);
        const vec3 ccSkySunsetUp   = vec3(1.0);
        const vec3 ccSkySunsetMid  = vec3(1.0);
        const vec3 ccSkySunsetDown = vec3(1.0);
        const vec3 ccSkyNightUp    = vec3(1.0);
        const vec3 ccSkyNightMid   = vec3(1.0);
        const vec3 ccSkyNightDown  = vec3(1.0);

        const float ccBlocklightI  = 1.00;
        const float ccAmbientI     = 1.00;
        const float ccExposureI    = 1.00;

        const vec3  ccSkyRayleigh   = vec3(0.7196, 0.8078, 0.8113);
        const float ccSkyExposureDay   = 0.0999;
        const float ccSkyExposureNight = 0.3500;
        const float ccSkySatBoost      = 1.0512;
        const vec3  ccSkyZenithTint    = vec3(0.287, 0.701, 2.544);
        const float ccSkyMieStrength   = 0.70;
        const float ccSkyGradSat       = 1.0 / SKY_SATURATION_V13_NEUTRAL;
        const float ccSkyLevel         = 1.00;

        const float ccSkyBlueNeutral   = 1.50;
        const float ccSkyHorizonFade   = 0.0;
    #endif

#endif
