#ifndef INCLUDE_WATER_RIPPLES
#define INCLUDE_WATER_RIPPLES

const int rwRippleCells = 128;
const int rwRippleRes = rwRippleCells * RIPPLE_RES;
const float rwRippleSub = float(RIPPLE_RES);

bool rwRippleUpdateFrame() {
    #if RIPPLE_UPDATE_INTERVAL == 0
        return true;
    #else
        return frameCounter % (RIPPLE_UPDATE_INTERVAL + 1) == 0;
    #endif
}

ivec3 rwRippleCamInt() {
    return cameraPositionInt.y == -98257195
         ? ivec3(floor(cameraPosition) + 0.5 * sign(cameraPosition))
         : cameraPositionInt;
}

vec2 rwRippleRel(vec3 playerPos) {
    return playerPos.xz + (cameraPosition - vec3(rwRippleCamInt())).xz;
}

vec2 rwRippleUV(vec2 rel) {
    return (rel * rwRippleSub + float(rwRippleRes) * 0.5) / float(rwRippleRes);
}

vec2 rwRippleSlope(vec3 playerPos) {
    vec2 uv = rwRippleUV(rwRippleRel(playerPos));

    vec2 edge = min(uv, 1.0 - uv);
    float fade = min1(min(edge.x, edge.y) * 40.0);
    if (fade <= 0.0) return vec2(0.0);

    float px = 1.0 / float(rwRippleRes);
    vec4 h00 = texture2D(ripple_sampler, uv);
    vec4 hxp = texture2D(ripple_sampler, uv + vec2(px, 0.0));
    vec4 hxn = texture2D(ripple_sampler, uv - vec2(px, 0.0));
    vec4 hzp = texture2D(ripple_sampler, uv + vec2(0.0, px));
    vec4 hzn = texture2D(ripple_sampler, uv - vec2(0.0, px));

    float fragBlockY = floor(playerPos.y + (cameraPosition.y - float(rwRippleCamInt().y)));
    fade *= 1.0 - min1(max0(abs(h00.z - fragBlockY) - 0.5) * 1.5);
    if (fade <= 0.0) return vec2(0.0);

    vec2 grad = vec2(hxp.x - hxn.x, hzp.x - hzn.x) * 0.5;

    return grad * (-rwRippleSub * RIPPLE_NORMAL_I * fade);
}

#if RIPPLE_DEBUG > 0
    vec3 rwRippleDebug(vec3 playerPos) {
        vec2 uv = rwRippleUV(rwRippleRel(playerPos));
        if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) {
            return vec3(0.25, 0.0, 0.25);
        }
        #if RIPPLE_DEBUG == 1
            vec4 d = texture2D(ripple_sampler, uv);
            return vec3(max0(-d.x), max0(d.x), abs(d.y)) * 30.0 + 0.02;
        #elif RIPPLE_DEBUG == 2
            vec4 c = texture2D(ripple_cell_sampler, uv);
            return vec3(c.y, c.x > -9000.0 ? 0.35 : 0.0, 0.0);
        #else
            float h = texelFetch(ripple_sampler,
                                 clamp(ivec2(uv * float(rwRippleRes)),
                                       ivec2(0), ivec2(rwRippleRes - 1)), 0).z;
            float fragBlockY = floor(playerPos.y + (cameraPosition.y - float(rwRippleCamInt().y)));
            float gate = 1.0 - min1(max0(abs(h - fragBlockY) - 0.5) * 1.5);
            return vec3(gate, min1(length(rwRippleSlope(playerPos)) / 0.05), 0.0);
        #endif
    }
#endif

#endif
