#ifndef INCLUDE_REALISTIC_WATER
#define INCLUDE_REALISTIC_WATER

const float rwPI  = 3.14159265358979;
const float rwRPI = 1.0 / rwPI;

float rwValueNoise(vec2 coord) {
    vec2 cell = coord - 0.5;
    vec2 whole = floor(cell);
    vec2 part = cell - whole;

    part = part * part * part * (part * (part * 6.0 - 15.0) + 10.0);

    return texture2D(noisetex, (whole + part + 0.5) * (1.0 / 128.0)).r;
}

float rwWaveTime() {
    #if SMOOTH_TIME_ACTIVE >= 3
        return cloudSyncedTime * 1.2 * WATER_SPEED_MULT;
    #else
        return frameTimeCounter * 1.2 * WATER_SPEED_MULT;
    #endif
}

#ifdef FRAGMENT_SHADER

float rwWaterHeight(vec2 p) {
    float t = rwWaveTime();

    #if WATER_SIZE_MULT != 100
        p *= float(WATER_SIZE_MULT) * 0.01;
    #endif

    float h = rwValueNoise(vec2(dot(p, vec2(1.08779, 0.39708)) - 0.98332 * t,
                                dot(p, vec2(-0.13692, 0.37510))) + vec2(53.0, 97.0));

    h += 0.421000 * rwValueNoise(vec2(dot(p, vec2(1.06839, 1.87556)) - 1.34251 * t,
                                dot(p, vec2(-0.64674, 0.36841))) + vec2(106.0, 194.0));

    h += 0.177241 * rwValueNoise(vec2(dot(p, vec2(-0.74091, 3.95466)) - 1.83290 * t,
                                dot(p, vec2(-1.36368, -0.25549))) + vec2(159.0, 291.0));

    h += 0.074618 * rwValueNoise(vec2(dot(p, vec2(-5.81935, 4.73089)) - 2.50243 * t,
                                dot(p, vec2(-1.63134, -2.00667))) + vec2(212.0, 388.0));

    h += 0.031414 * rwValueNoise(vec2(dot(p, vec2(-13.97661, -0.28527)) - 3.41653 * t,
                                dot(p, vec2(0.09837, -4.81952))) + vec2(265.0, 485.0));

    h = h * 0.651304 + 0.571037;

    return h / (1.0 + dot(fwidth(p), vec2(100.0 / far)));
}

#define RW_WAVE_HEIGHT_M (WATER_BUMPINESS * 0.8)

vec3 rwWavesNormal(vec2 position) {
    const vec2 e = vec2(0.02, 0.0);

    vec2 slope = vec2(rwWaterHeight(position + e.xy) - rwWaterHeight(position - e.xy),
                      rwWaterHeight(position + e.yx) - rwWaterHeight(position - e.yx));

    return normalize(vec3(-slope * (RW_WAVE_HEIGHT_M * 2.0), 1.0));
}

vec2 rwWaterParallaxCoord(vec3 position, vec3 tangentViewVector) {
    vec2 flatCoord = position.xz - position.y;

    if (RW_PARALLAX < 0.001) return flatCoord;

    vec3 marchStep = tangentViewVector * vec3(vec2(0.1 * RW_WAVE_HEIGHT_M * RW_PARALLAX), 1.0);
    marchStep *= 0.02 / max(abs(marchStep.z), 1e-4);

    vec2 coord = flatCoord + marchStep.xy;
    float rayHeight = 1.0 + marchStep.z;

    for (int i = 0; i < 60; i++) {
        if (rwWaterHeight(coord) >= rayHeight) break;

        coord += marchStep.xy;
        rayHeight += marchStep.z;
    }

    return coord;
}

#endif

float rwFresnel(float cosI, float n) {
    float sinT2 = (1.0 - cosI * cosI) / (n * n);
    if (sinT2 >= 1.0) return 1.0;

    float cosT = sqrt(1.0 - sinT2);
    float rs = (cosI - n * cosT) / (cosI + n * cosT);
    float rp = (n * cosI - cosT) / (n * cosI + cosT);

    return clamp(0.5 * (rs * rs + rp * rp), 0.0, 1.0);
}

float rwReflectance(float cosTheta, float n) {
    float f = rwFresnel(cosTheta, n);

    if (RW_REFLECT_I <= 1.001) return f;

    return 1.0 - pow(1.0 - f, RW_REFLECT_I);
}

float rwPhaseHG(float cosTheta, float g) {
    float g2 = g * g;
    float denom = 1.0 + g2 - 2.0 * g * cosTheta;

    return (1.0 - g2) / (4.0 * rwPI * denom * sqrt(denom));
}

const float rwPhaseIso = 1.0 / (4.0 * rwPI);

float rwWaterPhase(float LdotV) {
    return rwPhaseHG(LdotV, 0.65) + 0.4 * rwPhaseIso;
}

vec3 rwAbsorption() {
    return vec3(RW_ABSORB_R, RW_ABSORB_G, RW_ABSORB_B);
}

vec3 rwExtinction() {
    #ifdef OVERWORLD
        float density = RW_FOG_DENSITY * (1.0 + 0.625 * rainFactor * eyeBrightnessM);
    #else
        float density = RW_FOG_DENSITY;
    #endif

    vec3 sigma = rwAbsorption() * density;

    sigma /= max(RW_CLARITY, 0.05);

    #if WATER_FOG_MULT != 100
        sigma *= float(WATER_FOG_MULT) * 0.01;
    #endif

    return sigma;
}

vec3 rwExtinctionUnderwater() {
    #ifdef OVERWORLD
        float density = RW_FOG_DENSITY * (0.625 + 0.3125 * rainFactor * eyeBrightnessM);
    #else
        float density = RW_FOG_DENSITY * 0.625;
    #endif

    vec3 sigma = rwAbsorption() * density;

    sigma /= max(RW_CLARITY, 0.05);

    #if WATER_FOG_MULT != 100
        sigma *= float(WATER_FOG_MULT) * 0.01;
    #endif

    return sigma / max(RW_UNDERWATER_RANGE, 0.01);
}

const vec3 rwLumaWeights = vec3(0.2126, 0.7152, 0.0722);

float rwExtinctionRef(vec3 sigma) {
    return dot(sigma, rwLumaWeights);
}

vec3 rwChromaShift(vec3 sigma, float dist) {
    vec3 t = exp(-sigma * max(dist, 0.0));
    return t / max(dot(t, rwLumaWeights), 0.0001);
}

const float rwScatterCoef = 0.0207;

vec3 rwBodyAlbedo() {
    return rwScatterCoef / max(rwAbsorption(), vec3(0.001)) * RW_SCATTER;
}

vec3 rwFogColorBase(vec3 skyAmbient) {
    #ifdef OVERWORLD

        float storm = rainFactor * eyeBrightnessM;

        vec3 c = mix(skyAmbient, vec3(GetLuminance(skyAmbient)), 0.5 * storm);
        c *= 1.0 - 0.6 * storm;

        return c * rwBodyAlbedo();
    #else

        return rwBodyAlbedo() * 1.87;
    #endif
}

vec3 rwFogColor(vec3 skyAmbient, vec3 sunLight, float LdotV) {
    vec3 c = rwFogColorBase(skyAmbient);

    #ifdef OVERWORLD

        float direct = 5.3 * RW_SUN_SCATTER * (1.0 - 0.8 * rainFactor);

        c *= 1.0 + direct * sunLight * rwWaterPhase(LdotV);
    #endif

    return c;
}

vec3 rwVoxelScatter() {
    return rwSurfaceBlockLight * rwBodyAlbedo() * (RW_VOXEL_SCATTER * 6.0);
}

#endif
