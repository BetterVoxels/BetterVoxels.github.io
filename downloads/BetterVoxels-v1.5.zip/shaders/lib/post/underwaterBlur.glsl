
#ifndef INCLUDE_UNDERWATER_BLUR
#define INCLUDE_UNDERWATER_BLUR

#define UNDERWATER_BLUR 0 //[0 25 50 75 100 125 150 200 250 300 400]

#ifdef PPP_UNDERWATER_BLUR
    #define PPX_UNDERWATER_BLUR PPP_UNDERWATER_BLUR
#else
    #define PPX_UNDERWATER_BLUR UNDERWATER_BLUR
#endif

#if PPX_UNDERWATER_BLUR > 0

vec3 ApplyUnderwaterBlur(vec3 color, sampler2D src, vec2 uv) {
    if (isEyeInWater != 1) return color;

    float ubRadius = float(PPX_UNDERWATER_BLUR) * 0.01 * 0.0075;
    vec2 ubScale = vec2(viewHeight / viewWidth, 1.0) * ubRadius;

    vec3 ubSum = color;
    for (int i = 1; i <= 12; i++) {
        float ubAngle = float(i) * 2.39996;
        float ubR = sqrt(float(i) / 12.0);
        ubSum += texture2D(src, uv + vec2(cos(ubAngle), sin(ubAngle)) * ubR * ubScale).rgb;
    }
    return ubSum / 13.0;
}

#endif

#endif
