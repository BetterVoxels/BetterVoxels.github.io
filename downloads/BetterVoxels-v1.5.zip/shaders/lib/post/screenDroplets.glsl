#ifndef INCLUDE_SCREEN_DROPLETS
#define INCLUDE_SCREEN_DROPLETS

#define WATER_DROPLETS

#ifdef WATER_DROPLETS

uniform float exitWater;

float wdHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float wdNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = wdHash12(i);
    float b = wdHash12(i + vec2(1.0, 0.0));
    float c = wdHash12(i + vec2(0.0, 1.0));
    float d = wdHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

#define WD_NOISE_RES (512.0 / 20.0)

vec3 ApplyWaterDroplets(vec3 color, sampler2D src, vec2 uv) {
    if (isEyeInWater == 1 || exitWater <= 0.01) return color;

    float wdAspect = viewWidth / viewHeight;

    vec2 wdScaleXY = vec2(0.5, 0.25 + (exitWater * exitWater) * 0.25) * vec2(wdAspect, 1.0);
    float wdSlide = exitWater;

    float waterDrops = wdNoise((uv - vec2(0.0, wdSlide)) * wdScaleXY * WD_NOISE_RES);
    waterDrops = sqrt(min(max(waterDrops - (1.0 - sqrt(exitWater)) * 0.7, 0.0) * (1.0 + exitWater), 1.0)) * 0.3;

    waterDrops *= exitWater;

    vec2 wdZoomUV = vec2(0.5) + (uv - vec2(0.5)) * (1.0 - waterDrops);
    return texture2D(src, wdZoomUV).rgb;
}

#endif

#endif
