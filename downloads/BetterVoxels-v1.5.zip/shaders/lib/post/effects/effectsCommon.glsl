
#ifndef INCLUDE_FX_COMMON
#define INCLUDE_FX_COMMON

float fxHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 fxHash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

float fxNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = fxHash12(i);
    float b = fxHash12(i + vec2(1.0, 0.0));
    float c = fxHash12(i + vec2(0.0, 1.0));
    float d = fxHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fxFbm2(vec2 p) {
    return fxNoise(p) * 0.65 + fxNoise(p * 2.03 + 17.7) * 0.35;
}

float fxLuma(vec3 c) {
    return dot(c, vec3(0.2125, 0.7154, 0.0721));
}

vec2 fxAspect() {
    return vec2(viewWidth / viewHeight, 1.0);
}

vec3 fxViewDir() {
    return -normalize(gbufferModelViewInverse[2].xyz);
}

float fxLinearDepth(float depth) {
    return 2.0 * near * far / (far + near - (2.0 * depth - 1.0) * (far - near));
}

float fxEaseOutExpo(float t) {
    t = clamp(t, 0.0, 1.0);
    return t >= 1.0 ? 1.0 : 1.0 - exp2(-10.0 * t);
}
float fxEaseInExpo(float t) {
    t = clamp(t, 0.0, 1.0);
    return t <= 0.0 ? 0.0 : exp2(10.0 * (t - 1.0));
}

float fxRetimeApproach(float P, float tauFixed, float tauTarget) {
    return 1.0 - pow(max(1.0 - clamp(P, 0.0, 1.0), 0.0), tauFixed / max(tauTarget, 0.0001));
}
float fxRetimeDecay(float P, float tauFixed, float tauTarget) {
    return pow(clamp(P, 0.0, 1.0), tauFixed / max(tauTarget, 0.0001));
}

#endif
