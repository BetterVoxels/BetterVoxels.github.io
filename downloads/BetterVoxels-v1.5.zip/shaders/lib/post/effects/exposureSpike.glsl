
#ifndef INCLUDE_FX_EXPOSURE_SPIKE
#define INCLUDE_FX_EXPOSURE_SPIKE

#define EXPOSURE_SPIKE 1 //[0 1]
#define EXPOSURE_SPIKE_MODE 0 //[0 1 2]
#define EXPOSURE_RECOVERY_SPEED 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
#define EXPOSURE_MAX_INTENSITY 3.0 //[1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0]
#define EXPOSURE_TINT_PRESET 0 //[0 1 2 3 4]
#define EXPOSURE_TINT_R 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define EXPOSURE_TINT_G 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define EXPOSURE_TINT_B 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTNING_DISTANCE_ATTENUATION 1 //[0 1]
#define LIGHTNING_MAX_DISTANCE 128 //[10 16 24 32 48 64 80 96 112 128 160 192 224 256 320 384 448 500]
#define LIGHTNING_MIN_FLASH_MULT 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LIGHTNING_FALLOFF_CURVE 2 //[0 1 2]

#if EXPOSURE_SPIKE == 1

uniform float fxBoltFlash;

#if LIGHTNING_DISTANCE_ATTENUATION == 1

    uniform float fxBoltDistSq;

    float fxLightningAtten() {
        float d2 = fxBoltDistSq / max(fxBoltFlash, 0.0001);
        float dn = clamp(sqrt(max(d2, 0.0)) / float(LIGHTNING_MAX_DISTANCE), 0.0, 1.0);
        float dimming;
        #if LIGHTNING_FALLOFF_CURVE == 0
            dimming = dn;
        #elif LIGHTNING_FALLOFF_CURVE == 1
            dimming = 1.0 - exp2(-6.0 * dn);
        #else
            dimming = dn * dn;
        #endif
        return mix(1.0, float(LIGHTNING_MIN_FLASH_MULT), clamp(dimming, 0.0, 1.0));
    }
#endif

vec3 fxExposureTint() {
    #if EXPOSURE_TINT_PRESET == 0
        return vec3(1.0, 1.0, 1.0);
    #elif EXPOSURE_TINT_PRESET == 1
        return vec3(0.62, 0.78, 1.0);
    #elif EXPOSURE_TINT_PRESET == 2
        return vec3(1.0, 0.86, 0.66);
    #elif EXPOSURE_TINT_PRESET == 3
        return vec3(1.0, 0.45, 0.16);
    #else
        return vec3(EXPOSURE_TINT_R, EXPOSURE_TINT_G, EXPOSURE_TINT_B);
    #endif
}

float fxExposureEvent() {
    float boltEvent = clamp(fxBoltFlash, 0.0, 1.0);
    #if LIGHTNING_DISTANCE_ATTENUATION == 1

        if (boltEvent > 0.0001) boltEvent *= fxLightningAtten();
    #endif

    return boltEvent;
}

float fxExposureCurve(float e) {
    #if EXPOSURE_SPIKE_MODE == 0

        return e * e * (3.0 - 2.0 * e);
    #elif EXPOSURE_SPIKE_MODE == 1

        return sqrt(e);
    #else

        return e * e * e;
    #endif
}

vec3 ApplyExposureSpike(vec3 color) {
    float event = fxExposureEvent();
    if (event <= 0.001) return color;

    float shaped = pow(event, 1.0 / EXPOSURE_RECOVERY_SPEED);
    float strength = fxExposureCurve(clamp(shaped, 0.0, 1.0));

    float gain = mix(1.0, EXPOSURE_MAX_INTENSITY, strength);
    vec3 tint = fxExposureTint();

    vec3 lifted = color * gain;

    vec3 added = max(lifted - color, vec3(0.0));
    return color + added * tint;
}

#endif

#endif
