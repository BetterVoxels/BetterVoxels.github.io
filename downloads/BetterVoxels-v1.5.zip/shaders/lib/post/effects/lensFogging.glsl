
#ifndef INCLUDE_FX_LENS_FOGGING
#define INCLUDE_FX_LENS_FOGGING

#define LENS_FOGGING 0 //[0 1]
#define LENS_FOG_RADIUS 1 //[0 1 2]
#define LENS_FOG_FADE_IN 1 //[0 1 2]
#define LENS_FOG_DISSIPATION 2 //[0 1 2 3]
#define LENS_FOG_ENVIRONMENTAL 1 //[0 1]
#define LENS_FOG_BLUR_AMOUNT 1 //[0 1 2 3]

#if LENS_FOGGING == 1

uniform float fxFogFast;
uniform float fxFogMed;
uniform float fxFogSlow;

#if LENS_FOG_RADIUS == 0
    #define FX_FOG_INNER 0.72
    #define FX_FOG_OUTER 1.05
#elif LENS_FOG_RADIUS == 1
    #define FX_FOG_INNER 0.42
    #define FX_FOG_OUTER 0.98
#else
    #define FX_FOG_INNER 0.04
    #define FX_FOG_OUTER 0.92
#endif

#if LENS_FOG_BLUR_AMOUNT == 0
    #define FX_FOG_BLUR_PX 0.0
#elif LENS_FOG_BLUR_AMOUNT == 1
    #define FX_FOG_BLUR_PX 2.0
#elif LENS_FOG_BLUR_AMOUNT == 2
    #define FX_FOG_BLUR_PX 4.5
#else
    #define FX_FOG_BLUR_PX 8.0
#endif

float fxFogSignal() {
    #if LENS_FOG_FADE_IN == 0
        float riseSrc = fxFogSlow;
        #define FX_FOG_RISE_RANK 0
    #elif LENS_FOG_FADE_IN == 1
        float riseSrc = fxFogMed;
        #define FX_FOG_RISE_RANK 1
    #else
        float riseSrc = fxFogFast;
        #define FX_FOG_RISE_RANK 2
    #endif

    #if LENS_FOG_DISSIPATION == 0
        float fallSrc = fxFogSlow;
        #define FX_FOG_FALL_RANK 0
    #elif LENS_FOG_DISSIPATION == 1
        float fallSrc = fxFogSlow;
        #define FX_FOG_FALL_RANK 0
    #elif LENS_FOG_DISSIPATION == 2
        float fallSrc = fxFogMed;
        #define FX_FOG_FALL_RANK 1
    #else
        float fallSrc = fxFogFast;
        #define FX_FOG_FALL_RANK 2
    #endif

    #if FX_FOG_RISE_RANK >= FX_FOG_FALL_RANK
        return max(riseSrc, fallSrc);
    #else
        return min(riseSrc, fallSrc);
    #endif
}

float fxFogEnvironment() {
    #if LENS_FOG_ENVIRONMENTAL == 1

        float altitude = clamp((eyeAltitude - 80.0) / 120.0, 0.0, 1.0);

        float climate = clamp(inSnowy * 1.0 + rainFactor * 0.45, 0.0, 1.0);

        return clamp(0.35 + 0.65 * max(altitude, climate), 0.0, 1.0);
    #else
        return 1.0;
    #endif
}

vec3 ApplyLensFogging(vec3 color, sampler2D src, vec2 uv) {
    float fog = clamp(fxFogSignal(), 0.0, 1.0) * fxFogEnvironment();

    if (fog <= 0.01 || isEyeInWater != 0) return color;

    vec2 centred = (uv - 0.5) * fxAspect();
    float radial = length(centred) / length(fxAspect() * 0.5);

    float breath = fxFbm2(uv * fxAspect() * 3.5 + vec2(0.0, frameTimeCounter * 0.035));
    breath = 0.55 + 0.45 * breath;

    float coverage = smoothstep(FX_FOG_INNER, FX_FOG_OUTER, radial * breath) * fog;
    if (coverage <= 0.002) return color;

    if (FX_FOG_BLUR_PX > 0.0) {
        vec2 texel = FX_FOG_BLUR_PX * coverage / vec2(viewWidth, viewHeight);
        vec3 blurred = color;
        blurred += texture2D(src, clamp(uv + vec2( 0.866,  0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.000,  1.000) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2(-0.866,  0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2(-0.866, -0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.000, -1.000) * texel, vec2(0.0), vec2(1.0))).rgb;
        blurred += texture2D(src, clamp(uv + vec2( 0.866, -0.500) * texel, vec2(0.0), vec2(1.0))).rgb;
        color = mix(color, blurred / 7.0, clamp(coverage, 0.0, 1.0));
    }

    float milk = coverage * (0.55 + 0.45 * breath);
    vec3 condensate = mix(color, vec3(fxLuma(color) * 0.55 + 0.45), 0.85);
    return mix(color, condensate, clamp(milk * 0.75, 0.0, 1.0));
}

#endif

#endif
