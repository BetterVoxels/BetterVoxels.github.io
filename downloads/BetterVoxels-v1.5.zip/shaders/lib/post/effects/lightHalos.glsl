
#ifndef INCLUDE_FX_LIGHT_HALOS
#define INCLUDE_FX_LIGHT_HALOS

#define LIGHT_HALOS 0 //[0 1]
#define HALO_SIZE 1 //[0 1 2]
#define HALO_BRIGHTNESS_THRESHOLD 1 //[0 1 2]
#define ANAMORPHIC_STREAKS 0 //[0 1 2 3]
#define HALO_COLOR_DISPERSION 0.30 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_R 0.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_G 0.55 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define ANAMORPHIC_TINT_B 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#if LIGHT_HALOS == 1

#if HALO_SIZE == 0
    #define FX_HALO_RADIUS 0.020
    #define FX_HALO_TAPS 10
#elif HALO_SIZE == 1
    #define FX_HALO_RADIUS 0.045
    #define FX_HALO_TAPS 16
#else
    #define FX_HALO_RADIUS 0.090
    #define FX_HALO_TAPS 24
#endif

#if HALO_BRIGHTNESS_THRESHOLD == 0
    #define FX_HALO_KNEE 1.15
#elif HALO_BRIGHTNESS_THRESHOLD == 1
    #define FX_HALO_KNEE 0.72
#else
    #define FX_HALO_KNEE 0.38
#endif

#if ANAMORPHIC_STREAKS > 0
    #if ANAMORPHIC_STREAKS == 1
        #define FX_STREAK_AXIS vec2(1.0, 0.0)
    #elif ANAMORPHIC_STREAKS == 2
        #define FX_STREAK_AXIS vec2(0.0, 1.0)
    #else
        #define FX_STREAK_AXIS vec2(1.0, 0.0)
    #endif
#endif

vec3 fxBrightPass(vec3 c) {
    float l = fxLuma(c);
    float w = clamp((l - FX_HALO_KNEE) / max(FX_HALO_KNEE * 0.5, 0.001), 0.0, 1.0);
    return c * (w * w);
}

vec3 ApplyLightHalos(vec3 color, sampler2D src, vec2 uv) {
    vec2 aspect = fxAspect();

    vec2 radiusScale = vec2(1.0 / aspect.x, 1.0) * FX_HALO_RADIUS;

    vec3 halo = vec3(0.0);
    float weightSum = 0.0;

    for (int i = 0; i < FX_HALO_TAPS; i++) {
        float fi = float(i) + 0.5;
        float t = fi / float(FX_HALO_TAPS);
        float ang = fi * 2.39996323;
        float rad = sqrt(t);
        vec2 dir = vec2(cos(ang), sin(ang)) * rad;

        float disp = HALO_COLOR_DISPERSION * 0.35;
        vec2 offR = dir * radiusScale * (1.0 + disp);
        vec2 offG = dir * radiusScale;
        vec2 offB = dir * radiusScale * (1.0 - disp);

        vec3 tapR = fxBrightPass(texture2D(src, clamp(uv + offR, vec2(0.0), vec2(1.0))).rgb);
        vec3 tapG = fxBrightPass(texture2D(src, clamp(uv + offG, vec2(0.0), vec2(1.0))).rgb);
        vec3 tapB = fxBrightPass(texture2D(src, clamp(uv + offB, vec2(0.0), vec2(1.0))).rgb);

        float w = exp(-2.5 * t);
        halo += vec3(tapR.r, tapG.g, tapB.b) * w;
        weightSum += w;
    }
    halo /= max(weightSum, 0.0001);

    #if ANAMORPHIC_STREAKS > 0

        vec3 streak = vec3(0.0);
        float streakWeight = 0.0;
        for (int j = 1; j <= 6; j++) {
            float fj = float(j) / 6.0;
            vec2 off = FX_STREAK_AXIS * radiusScale * fj * 4.0;
            float w = 1.0 - fj;
            streak += fxBrightPass(texture2D(src, clamp(uv + off, vec2(0.0), vec2(1.0))).rgb) * w;
            streak += fxBrightPass(texture2D(src, clamp(uv - off, vec2(0.0), vec2(1.0))).rgb) * w;
            streakWeight += 2.0 * w;
        }
        streak /= max(streakWeight, 0.0001);

        #if ANAMORPHIC_STREAKS == 3

            streak *= vec3(ANAMORPHIC_TINT_R, ANAMORPHIC_TINT_G, ANAMORPHIC_TINT_B) * 1.6;
        #endif
        halo += streak * 0.75;
    #endif

    return color + halo;
}

#endif

#endif
