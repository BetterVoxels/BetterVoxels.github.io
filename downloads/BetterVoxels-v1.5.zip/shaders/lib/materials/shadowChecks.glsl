bool isEmissive(int mat) {
    return (
        mat == 10836 ||
        mat == 10056 ||
        mat == 10068 ||
        mat == 10072 ||
        mat == 10076 ||
        mat == 10216 ||
        mat == 10224 ||
#ifdef GLOWING_ORE_IRON
        mat == 10272 ||
        mat == 10276 ||
#endif
#ifdef GLOWING_ORE_COPPER
        mat == 10284 ||
        mat == 10288 ||
#endif
#ifdef GLOWING_ORE_GOLD
        mat == 10300 ||
        mat == 10304 ||
#endif
#ifdef GLOWING_ORE_DIAMOND
        mat == 10320 ||
        mat == 10324 ||
#endif
#ifdef GLOWING_ORE_EMERALD
        mat == 10340 ||
        mat == 10344 ||
#endif
#ifdef GLOWING_ORE_LAPIS
        mat == 10356 ||
        mat == 10360 ||
#endif
#ifdef GLOWING_ORE_REDSTONE
        mat == 10612 ||
        mat == 10620 ||
#endif
#ifdef GLOWING_ORE_NETHERQUARTZ
        mat == 10368 ||
#endif
#ifdef GLOWING_ORE_NETHERGOLD
        mat == 10308 ||
#endif
#ifdef GLOWING_ORE_GILDEDBLACKSTONE
        mat == 10484 ||
#endif
#ifdef GLOWING_ORE_ANCIENTDEBRIS
        mat == 10252 ||
#endif
#ifdef GLOWING_ORE_MODDED
        mat == 10024 ||
#endif
        mat == 10616 ||
        mat == 10624 ||
#ifdef EMISSIVE_EMERALD_BLOCK
        mat == 10336 ||
#endif
#ifdef EMISSIVE_LAPIS_BLOCK
        mat == 10352 ||
#endif
#ifdef EMISSIVE_REDSTONE_BLOCK
        mat == 10608 ||
#endif
        mat == 10332 ||

        mat == 10396 ||
        mat == 10404 ||
        mat == 10412 ||
        mat == 10448 ||
        mat == 10452 ||
        mat == 10476 ||
        mat == 10496 ||
        mat == 10500 ||
        mat == 10512 ||
        mat == 10516 ||
        mat == 10528 ||
        mat == 10544 ||
        mat == 10548 ||
        mat == 10556 ||
        mat == 10560 ||
        mat == 10564 ||
        mat == 10572 ||
        mat == 10576 ||
        mat == 10580 ||
        (mat >= 10900 && mat < 10924) ||
        mat == 10592 ||
        mat == 10596 ||
        mat == 10604 ||
        mat == 10632 ||
        mat == 10640 ||
        mat == 10648 ||
        mat == 10652 ||
        mat == 10656 ||
        mat == 10680 ||
        mat == 10684 ||
        mat == 10688 ||
        mat == 10704 ||
        mat == 10788 ||
        mat == 10708 ||
        mat == 10852 ||
        mat == 10856 ||
        mat == 10924 ||
        mat == 10948 ||
        mat == 10996 ||

        mat == 30020 ||
        mat == 32016 ||
        mat == 60025 ||
        mat == 60012 ||
        mat == 60020 ||
        mat == 50000 ||
        mat == 50004 ||
        mat == 50010 ||
        mat == 50020 ||
        #ifdef EXPLODING_CREEPER
        mat == 50024 ||
        #endif
        mat == 50048 ||
        mat == 50052 ||
        mat == 50072 ||
        mat == 50080 ||
        mat == 50088 ||
        mat == 50116 ||
        mat == 1235  ||
        mat == 10028
    );
}

#include "/lib/materials/lightColorSettings.glsl"

vec3 getLightCol(int mat) {
    vec3 lightcol = vec3(0);
        switch (mat) {
        case 1235:
        case 10996:
            lightcol = blocklightCol;
            break;
        case 10056:
            #ifdef CAULDRON_HARDCODED_LAVA_COL
            lightcol = vec3(LAVA_COL_R, LAVA_COL_G, LAVA_COL_B);
            #endif
            break;
        case 10068:
            #ifdef HARDCODED_LAVA_COL
            lightcol = vec3(LAVA_COL_R, LAVA_COL_G, LAVA_COL_B);
            #endif
            break;
        case 10072:
            #ifdef HARDCODED_FIRE_COL
            lightcol = vec3(FIRE_COL_R, FIRE_COL_G, FIRE_COL_B);
            #endif
            break;
        case 10652:
            #ifdef CAMPFIRE_HARDCODED_FIRE_COL
            lightcol = vec3(FIRE_COL_R, FIRE_COL_G, FIRE_COL_B);
            #endif
            break;
        case 10656:
            #ifdef CAMPFIRE_HARDCODED_SOULFIRE_COL
            lightcol = vec3(SOULFIRE_COL_R, SOULFIRE_COL_G, SOULFIRE_COL_B);
            #endif
            break;
        case 10076:
            #ifdef HARDCODED_SOULFIRE_COL
            lightcol = vec3(SOULFIRE_COL_R, SOULFIRE_COL_G, SOULFIRE_COL_B);
            #endif
            break;
        case 10216:
        case 10224:
            break;
        case 10252:
            #ifdef HARDCODED_DEBRIS_COL
            lightcol = vec3(DEBRIS_COL_R, DEBRIS_COL_G, DEBRIS_COL_B);
            #endif
            break;
    #ifdef GLOWING_ORE_IRON
        case 10272:
        case 10276:
            #ifdef ORE_HARDCODED_IRON_COL
            lightcol = vec3(IRON_COL_R, IRON_COL_G, IRON_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_COPPER
        case 10284:
        case 10288:
            #ifdef ORE_HARDCODED_COPPER_COL
            lightcol = vec3(COPPER_COL_R, COPPER_COL_G, COPPER_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_NETHERGOLD
        case 10308:
    #endif
    #ifdef GLOWING_ORE_GILDEDBLACKSTONE
        case 10484:
    #endif
    #ifdef GLOWING_ORE_GOLD
        case 10300:
        case 10304:
            #ifdef ORE_HARDCODED_GOLD_COL
            lightcol = vec3(GOLD_COL_R, GOLD_COL_G, GOLD_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_DIAMOND
        case 10320:
        case 10324:
            #ifdef ORE_HARDCODED_DIAMOND_COL
            lightcol = vec3(DIAMOND_COL_R, DIAMOND_COL_G, DIAMOND_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_EMERALD
        case 10340:
        case 10344:
            #ifdef ORE_HARDCODED_EMERALD_COL
            lightcol = vec3(EMERALD_COL_R, EMERALD_COL_G, EMERALD_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_LAPIS
        case 10356:
        case 10360:
            #ifdef ORE_HARDCODED_LAPIS_COL
            lightcol = vec3(LAPIS_COL_R, LAPIS_COL_G, LAPIS_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_QUARTZ
        case 10368:
            #ifdef ORE_HARDCODED_QUARTZ_COL
            lightcol = vec3(QUARTZ_COL_R, QUARTZ_COL_G, QUARTZ_COL_B);
            #endif
            break;
    #endif
    #ifdef GLOWING_ORE_REDSTONE
        case 10612:
        case 10620:
    #endif
    case 10616:
    case 10624:
        #ifdef ORE_HARDCODED_REDSTONE_COL
        lightcol = vec3(REDSTONE_COL_R, REDSTONE_COL_G, REDSTONE_COL_B);
        #endif
        break;
    #ifdef EMISSIVE_EMERALD_BLOCK
        case 10336:
            #ifdef BLOCK_HARDCODED_EMERALD_COL
            lightcol = vec3(EMERALD_COL_R, EMERALD_COL_G, EMERALD_COL_B);
            #endif
            break;
    #endif
    #ifdef EMISSIVE_LAPIS_BLOCK
        case 10352:
            #ifdef BLOCK_HARDCODED_LAPIS_COL
            lightcol = vec3(LAPIS_COL_R, LAPIS_COL_G, LAPIS_COL_B);
            #endif
            break;
    #endif
    #ifdef EMISSIVE_REDSTONE_BLOCK
        case 10608:
            #ifdef BLOCK_HARDCODED_REDSTONE_COL
            lightcol = vec3(REDSTONE_COL_R, REDSTONE_COL_G, REDSTONE_COL_B);
            #endif
            break;
    #endif
        case 10332:
            #ifdef HARDCODED_AMETHYST_COL
            lightcol = vec3(AMETHYST_COL_R, AMETHYST_COL_G, AMETHYST_COL_B);
            #endif
            break;
        case 10388:
            #ifdef HARDCODED_ICE_COL
            lightcol = vec3(ICE_COL_R, ICE_COL_G, ICE_COL_B);
            #endif
            break;
        case 10396:
            #ifdef HARDCODED_PUMPKIN_COL
            lightcol = vec3(PUMPKIN_COL_R, PUMPKIN_COL_G, PUMPKIN_COL_B);
            #endif
            break;
        case 10404:
            #ifdef HARDCODED_PICKLE_COL
            lightcol = vec3(PICKLE_COL_R, PICKLE_COL_G, PICKLE_COL_B);
            #endif
            break;
        case 10412:
            #ifdef HARDCODED_GLOWSTONE_COL
            lightcol = vec3(GLOWSTONE_COL_R, GLOWSTONE_COL_G, GLOWSTONE_COL_B);
            #endif
            break;
        case 10448:
            #ifdef HARDCODED_SEALANTERN_COL
            lightcol = vec3(SEALANTERN_COL_R, SEALANTERN_COL_G, SEALANTERN_COL_B);
            #endif
            break;
        case 10452:
        case 50052:
            #ifdef HARDCODED_MAGMA_COL
            lightcol = vec3(MAGMA_COL_R, MAGMA_COL_G, MAGMA_COL_B);
            #endif
            break;
        case 10476:
            #ifdef HARDCODED_CRYING_COL
            lightcol = vec3(CRYING_COL_R, CRYING_COL_G, CRYING_COL_B);
            #endif
            break;
        case 10496:
            #ifdef HARDCODED_TORCH_COL
            lightcol = vec3(TORCH_COL_R, TORCH_COL_G, TORCH_COL_B);
            #endif
            break;
        case 10500:
            #ifdef HARDCODED_ENDROD_COL
            lightcol = vec3(ENDROD_COL_R, ENDROD_COL_G, ENDROD_COL_B);
            #endif
            break;
        case 10512:
            #ifdef HARDCODED_CHORUS_COL
            lightcol = vec3(CHORUS_COL_R, CHORUS_COL_G, CHORUS_COL_B);
            #endif
            break;
        case 10516:
            #ifdef HARDCODED_FURNACE_COL
            lightcol = vec3(FURNACE_COL_R, FURNACE_COL_G, FURNACE_COL_B);
            #endif
            break;
        case 10528:
            #ifdef HARDCODED_SOULTORCH_COL
            lightcol = vec3(SOULTORCH_COL_R, SOULTORCH_COL_G, SOULTORCH_COL_B);
            #endif
            break;
        case 10544:
            #ifdef HARDCODED_LICHEN_COL
            lightcol = vec3(LICHEN_COL_R, LICHEN_COL_G, LICHEN_COL_B);
            #endif
            break;
        case 10548:
            #ifdef HARDCODED_TABLE_COL
            lightcol = vec3(TABLE_COL_R, TABLE_COL_G, TABLE_COL_B);
            #endif
            break;
        case 10556:
            #ifdef HARDCODED_END_COL
            lightcol = vec3(END_COL_R, END_COL_G, END_COL_B);
            #endif
            break;
        case 10560:
            #ifdef LANTERN_HARDCODED_TORCH_COL
            lightcol = vec3(TORCH_COL_R, TORCH_COL_G, TORCH_COL_B);
            #endif
            break;
        case 10564:
            #ifdef LANTERN_HARDCODED_SOULTORCH_COL
            lightcol = vec3(SOULTORCH_COL_R, SOULTORCH_COL_G, SOULTORCH_COL_B);
            #endif
            break;
        case 10572:
            #ifdef HARDCODED_DRAGON_COL
            lightcol = vec3(DRAGON_COL_R, DRAGON_COL_G, DRAGON_COL_B);
            #endif
            break;
        case 10576:
            #ifdef HARDCODED_FURNACE_COL
            lightcol = vec3(FURNACE_COL_R, FURNACE_COL_G, FURNACE_COL_B);
            #endif
            break;
        case 10580:
            #ifdef HARDCODED_FURNACE_COL
            lightcol = vec3(FURNACE_COL_R, FURNACE_COL_G, FURNACE_COL_B);
            #endif
            break;
        case 10900:
        case 10902:
        case 10904:
        case 10906:
        case 10908:
        case 10910:
        case 10912:
        case 10914:
        case 10916:
        case 10918:
        case 10920:
        case 10922:
            #ifdef HARDCODED_CANDLE_COL
            lightcol = vec3(CANDLE_COL_R, CANDLE_COL_G, CANDLE_COL_B);
            #endif
            break;
        case 10592:
            #ifdef ANCHOR_HARDCODED_PORTAL_COL
            lightcol = vec3(PORTAL_COL_R, PORTAL_COL_G, PORTAL_COL_B);
            #endif
            break;
        case 10596:
            #ifdef WIRE_HARDCODED_REDSTONE_COL
            lightcol = vec3(REDSTONE_COL_R, REDSTONE_COL_G, REDSTONE_COL_B);
            #endif
            break;
        case 10604:
            #ifdef TORCH_HARDCODED_REDSTONE_COL
            lightcol = vec3(REDSTONE_COL_R, REDSTONE_COL_G, REDSTONE_COL_B);
            #endif
            break;
        case 10632:
            #ifdef HARDCODED_BERRY_COL
            lightcol = vec3(BERRY_COL_R, BERRY_COL_G, BERRY_COL_B);
            #endif
            break;
        case 10640:
            #ifdef HARDCODED_REDSTONELAMP_COL
            lightcol = vec3(REDSTONELAMP_COL_R, REDSTONELAMP_COL_G, REDSTONELAMP_COL_B);
            #endif
            break;
        case 10648:
            #ifdef HARDCODED_SHROOMLIGHT_COL
            lightcol = vec3(SHROOMLIGHT_COL_R, SHROOMLIGHT_COL_G, SHROOMLIGHT_COL_B);
            #endif
            break;
        case 10680:
            #ifdef HARDCODED_YELLOWFROG_COL
            lightcol = vec3(PPX_YELLOWFROG_COL_R, PPX_YELLOWFROG_COL_G, PPX_YELLOWFROG_COL_B);
            #endif
            break;
        case 10684:
            #ifdef HARDCODED_GREENFROG_COL
            lightcol = vec3(PPX_GREENFROG_COL_R, PPX_GREENFROG_COL_G, PPX_GREENFROG_COL_B);
            #endif
            break;
        case 10688:
            #ifdef HARDCODED_PINKFROG_COL
            lightcol = vec3(PPX_PINKFROG_COL_R, PPX_PINKFROG_COL_G, PPX_PINKFROG_COL_B);
            #endif
            break;
        case 10704:
        case 10788:
            #ifdef HARDCODED_SCULK_COL
            lightcol = vec3(SCULK_COL_R, SCULK_COL_G, SCULK_COL_B);
            #endif
            break;
        case 10708:
            #ifdef HARDCODED_SPAWNER_COL
            lightcol = vec3(SPAWNER_COL_R, SPAWNER_COL_G, SPAWNER_COL_B);
            #endif
            break;
        case 10836:
            #ifdef HARDCODED_BREWINGSTAND_COL
            lightcol = vec3(BREWINGSTAND_COL_R, BREWINGSTAND_COL_G, BREWINGSTAND_COL_B);
            #endif
            break;
        case 12740:
            #ifdef CAKE_HARDCODED_CANDLE_COL
            lightcol = vec3(CANDLE_COL_R, CANDLE_COL_G, CANDLE_COL_B);
            #endif
            break;
        case 10924:
            #ifdef BLOSSOM_HARDCODED_RESIN_COL
            lightcol = vec3(RESIN_COL_R, RESIN_COL_G, RESIN_COL_B);
            #endif
            break;
        case 10948:
            #ifdef HEART_HARDCODED_RESIN_COL
            lightcol = vec3(RESIN_COL_R, RESIN_COL_G, RESIN_COL_B);
            #endif
            break;
        case 30020:
            #ifdef HARDCODED_PORTAL_COL
            lightcol = vec3(PORTAL_COL_R, PORTAL_COL_G, PORTAL_COL_B);
            #endif
            break;
        case 32016:
            #ifdef HARDCODED_BEACON_COL
            lightcol = vec3(BEACON_COL_R, BEACON_COL_G, BEACON_COL_B);
            #endif
            break;
        case 60025:
            #ifdef PORTAL_HARDCODED_END_COL
            lightcol = vec3(END_COL_R, END_COL_G, END_COL_B);
            #endif
            break;
        case 60012:
            #ifdef CHEST_HARDCODED_END_COL
            lightcol = vec3(END_COL_R, END_COL_G, END_COL_B);
            #endif
            break;
        case 60020:
            #ifdef HARDCODED_CONDUIT_COL
            lightcol = vec3(CONDUIT_COL_R, CONDUIT_COL_G, CONDUIT_COL_B);
            #endif
            break;
        case 50000:
            #ifdef HARDCODED_ENDCRYSTAL_COL
            lightcol = vec3(ENDCRYSTAL_COL_R, ENDCRYSTAL_COL_G, ENDCRYSTAL_COL_B);
            #endif
            break;
        case 50004:
            #ifdef HARDCODED_LIGHTNING_COL
            lightcol = vec3(LIGHTNING_COL_R, LIGHTNING_COL_G, LIGHTNING_COL_B);
            #endif
            break;
        case 50010:
            #ifdef HARDCODED_ITEMFRAME_COL
            lightcol = vec3(ITEMFRAME_COL_R, ITEMFRAME_COL_G, ITEMFRAME_COL_B);
            #endif
            break;
        case 50020:
            #ifdef HARDCODED_BLAZE_COL
            lightcol = vec3(BLAZE_COL_R, BLAZE_COL_G, BLAZE_COL_B);
            #endif
            break;
        #ifdef EXPLODING_CREEPER
        case 50024:
            #ifdef HARDCODED_CREEPER_COL
            lightcol = vec3(EXPLODING_COL_R, EXPLODING_COL_G, EXPLODING_COL_B);
            #endif
            break;
        #endif
        case 50048:
            #ifdef HARDCODED_SQUID_COL
            lightcol = vec3(SQUID_COL_R, SQUID_COL_G, SQUID_COL_B);
            #endif
            break;
        case 50080:
            #ifdef HARDCODED_ALLAY_COL
            lightcol = vec3(ALLAY_COL_R, ALLAY_COL_G, ALLAY_COL_B);
            #endif
            break;
        case 50116:
            #ifdef HARDCODED_TNT_COL
            lightcol = vec3(EXPLODING_COL_R, EXPLODING_COL_G, EXPLODING_COL_B);
            #endif
            break;
    }
    return lightcol;
}

int getLightLevel(int mat) {
    int lightlevel = 0;
    switch (mat) {
        case 1234:
        case 1235:
        case 10999:
            #ifdef LMCOORD_AVAILABLE
                lightlevel = int(24 * lmCoord.x);
            #else
                lightlevel = 20;
            #endif
            break;
        case 10056:
            lightlevel = CAULDRON_BRIGHTNESS_LAVA;
            break;
        case 10068:
            lightlevel = BRIGHTNESS_LAVA;
            break;
        case 10072:
            lightlevel = BRIGHTNESS_FIRE;
            break;
        case 10076:
            lightlevel = BRIGHTNESS_SOULFIRE;
            break;
        case 10216:
            lightlevel = BRIGHTNESS_CRIMSON;
            break;
        case 10224:
            lightlevel = BRIGHTNESS_WARPED;
            break;
    #ifdef GLOWING_ORE_IRON
        case 10272:
        case 10276:
            lightlevel = ORE_BRIGHTNESS_IRON;
            break;
    #endif
    #ifdef GLOWING_ORE_COPPER
        case 10284:
        case 10288:
            lightlevel = ORE_BRIGHTNESS_COPPER;
            break;
    #endif
    #ifdef GLOWING_ORE_GOLD
        case 10300:
        case 10304:
            lightlevel = ORE_BRIGHTNESS_GOLD;
            break;
    #endif
    #ifdef GLOWING_ORE_DIAMOND
        case 10320:
        case 10324:
            lightlevel = ORE_BRIGHTNESS_DIAMOND;
            break;
    #endif
    #ifdef GLOWING_ORE_EMERALD
        case 10340:
        case 10344:
            lightlevel = ORE_BRIGHTNESS_EMERALD;
            break;
    #endif
    #ifdef GLOWING_ORE_LAPIS
        case 10356:
        case 10360:
            lightlevel = ORE_BRIGHTNESS_LAPIS;
            break;
    #endif
    #ifdef GLOWING_ORE_REDSTONE
        case 10612:
        case 10620:
            lightlevel = OREUNLIT_BRIGHTNESS_REDSTONE;
            break;
    #endif
    #ifdef GLOWING_ORE_NETHERQUARTZ
        case 10368:
            lightlevel = ORE_BRIGHTNESS_QUARTZ;
            break;
    #endif
    #ifdef GLOWING_ORE_NETHERGOLD
        case 10308:
            lightlevel = ORE_BRIGHTNESS_GOLD;
            break;
    #endif
    #ifdef GLOWING_ORE_GILDEDBLACKSTONE
        case 10484:
            lightlevel = ORE_BRIGHTNESS_GOLD;
            break;
    #endif
    #ifdef GLOWING_ORE_ANCIENTDEBRIS
        case 10252:
            lightlevel = BRIGHTNESS_DEBRIS;
            break;
    #endif
    #ifdef GLOWING_ORE_MODDED
        case 10024:
            lightlevel = 10;
            break;
    #endif
        case 10616:
        case 10624:
            lightlevel = ORELIT_BRIGHTNESS_REDSTONE;
            break;
    #ifdef EMISSIVE_EMERALD_BLOCK
        case 10336:
            lightlevel = BLOCK_BRIGHTNESS_EMERALD;
            break;
    #endif
    #ifdef EMISSIVE_LAPIS_BLOCK
        case 10352:
            lightlevel = BLOCK_BRIGHTNESS_LAPIS;
            break;
    #endif
    #ifdef EMISSIVE_REDSTONE_BLOCK
        case 10608:
            lightlevel = BLOCK_BRIGHTNESS_REDSTONE;
            break;
    #endif
        case 10332:
            lightlevel = BRIGHTNESS_AMETHYST;
            break;
        case 10388:
            lightlevel = BRIGHTNESS_ICE;
            break;
        case 10396:
            lightlevel = BRIGHTNESS_PUMPKIN;
            break;
        case 10404:
            lightlevel = HIGH_BRIGHTNESS_PICKLE;
            break;
        case 10412:
            lightlevel = BRIGHTNESS_GLOWSTONE;
            break;
        case 10448:
            lightlevel = BRIGHTNESS_SEALANTERN;
            break;
        case 10452:
            lightlevel = BLOCK_BRIGHTNESS_MAGMA;
            break;
        case 50052:
            lightlevel = CUBE_BRIGHTNESS_MAGMA;
            break;
        case 10476:
            lightlevel = BRIGHTNESS_CRYING;
            break;
        case 10496:
            lightlevel = BRIGHTNESS_TORCH;
            break;
        case 10500:
            lightlevel = BRIGHTNESS_ENDROD;
            break;
        case 10512:
            lightlevel = BRIGHTNESS_CHORUS;
            break;
        case 10516:
            lightlevel = BRIGHTNESS_FURNACE;
            break;
        case 10528:
            lightlevel = BRIGHTNESS_SOULTORCH;
            break;
        case 10544:
            lightlevel = BRIGHTNESS_LICHEN;
            break;
        case 10548:
            lightlevel = BRIGHTNESS_TABLE;
            break;
        case 10556:
            lightlevel = FRAME_BRIGHTNESS_END;
            break;
        case 10560:
            lightlevel = LANTERN_BRIGHTNESS_TORCH;
            break;
        case 10564:
            lightlevel = LANTERN_BRIGHTNESS_SOULTORCH;
            break;
        case 10572:
            lightlevel = BRIGHTNESS_DRAGON;
            break;
        case 10576:
            lightlevel = BRIGHTNESS_FURNACE;
            break;
        case 10580:
            lightlevel = BRIGHTNESS_FURNACE;
            break;
        case 10900:
        case 10902:
        case 10904:
        case 10906:
        case 10908:
        case 10910:
        case 10912:
        case 10914:
        case 10916:
        case 10918:
        case 10920:
        case 10922:
            lightlevel = BRIGHTNESS_CANDLE;
            break;
        case 10592:
            lightlevel = ANCHOR_BRIGHTNESS_PORTAL;
            break;
        case 10596:
            lightlevel = WIRE_BRIGHTNESS_REDSTONE;
            break;
        case 10604:
            lightlevel = TORCH_BRIGHTNESS_REDSTONE;
            break;
        case 10632:
            lightlevel = BRIGHTNESS_BERRY;
            break;
        case 10640:
            lightlevel = BRIGHTNESS_REDSTONELAMP;
            break;
        case 10648:
            lightlevel = BRIGHTNESS_SHROOMLIGHT;
            break;
        case 10652:
            lightlevel = CAMPFIRE_BRIGHTNESS_FIRE;
            break;
        case 10656:
            lightlevel = CAMPFIRE_BRIGHTNESS_SOULFIRE;
            break;
        case 10680:
            lightlevel = PPX_BRIGHTNESS_YELLOWFROG;
            break;
        case 10684:
            lightlevel = PPX_BRIGHTNESS_GREENFROG;
            break;
        case 10688:
            lightlevel = PPX_BRIGHTNESS_PINKFROG;
            break;
        case 10704:
        case 10788:
            lightlevel = SENSOR_BRIGHTNESS_SCULK;
            break;
        case 10708:
            lightlevel = BRIGHTNESS_SPAWNER;
            break;
        case 12740:
            lightlevel = CAKE_BRIGHTNESS_CANDLE;
            break;
        case 10836:
            lightlevel = BRIGHTNESS_BREWINGSTAND;
            break;
        case 10924:
            lightlevel = BLOSSOM_BRIGHTNESS_RESIN;
            break;
        case 10948:
            lightlevel = HEART_BRIGHTNESS_RESIN;
            break;
        case 30020:
            lightlevel = BRIGHTNESS_PORTAL;
            break;
        case 32016:
            lightlevel = BRIGHTNESS_BEACON;
            break;
        case 60025:
            lightlevel = PORTAL_BRIGHTNESS_END;
            break;
        case 60012:
            lightlevel = CHEST_BRIGHTNESS_END;
            break;
        case 60020:
            lightlevel = BRIGHTNESS_CONDUIT;
            break;
        case 50000:
            lightlevel = BRIGHTNESS_ENDCRYSTAL;
            break;
        case 50004:
            lightlevel = BRIGHTNESS_LIGHTNING;
            break;
        case 50010:
            lightlevel = BRIGHTNESS_ITEMFRAME;
            break;
        case 50020:
            lightlevel = BRIGHTNESS_BLAZE;
            break;
        case 50024:
            lightlevel = BRIGHTNESS_CREEPER;
            break;
        case 50048:
            lightlevel = BRIGHTNESS_SQUID;
            break;
        case 50072:
            lightlevel = BRIGHTNESS_XP;
            break;
        case 50080:
            lightlevel = BRIGHTNESS_ALLAY;
            break;
        case 50116:
            lightlevel = BRIGHTNESS_TNT;
    }
    return lightlevel;
}

bool ignoreMat(int mat) {
    return (
        mat == 50016
    );
}
