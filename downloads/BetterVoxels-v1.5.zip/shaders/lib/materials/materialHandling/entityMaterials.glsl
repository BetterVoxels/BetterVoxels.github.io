if (entityId < 50064) {
    if (entityId < 50032) {
        if (entityId < 50016) {
            if (entityId < 50008) {
                if (entityId == 50000) {
                    lmCoordM.x *= 0.7;

                    if (color.g * 1.2 < color.r) {
                        emission = 12.0 * color.g;
                        color.r *= 1.1;
                    }
                } else if (entityId == 50004) {
                    #include "/lib/materials/specificMaterials/entities/lightningBolt.glsl"
                }
            } else {
                if (entityId == 50008) {
                    noSmoothLighting = true;
                } else  {
                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"

                    smoothnessD *= 0.4;
                }
            }
        } else {
            if (entityId < 50024) {
                if (entityId == 50016) {
                    if (entityColor.a < 0.001) {
                        #ifdef COATED_TEXTURES
                            noiseFactor = 0.5;
                        #endif

                        if (CheckForColor(texelFetch(tex, ivec2(0, 0), 0).rgb, vec3(23, 46, 92))) {
                            for (int i = 63; i >= 56; i--) {
                                vec3 dif = color.rgb - texelFetch(tex, ivec2(i, 0), 0).rgb;
                                if (dif == clamp(dif, vec3(-0.001), vec3(0.001))) {
                                    emission = 2.0 * texelFetch(tex, ivec2(i, 1), 0).r;
                                }
                            }
                        }
                    }
                } else  {
                    lmCoordM = vec2(0.9, 0.0);
                    emission = min(color.r, 0.7) * 1.4;

                    float dotColor = dot(color.rgb, color.rgb);
                    if (abs(dotColor - 1.5) > 1.4) {
                        emission = 5.0;
                    }
                }
            } else {
                if (entityId == 50024) {
                    emission = max0(color.b - color.g - color.r) * 10.0;
                } else  {
                    if (atlasSize.x < 900) {
                        if (CheckForColor(color.rgb, vec3(143, 241, 215)) ||
                            CheckForColor(color.rgb, vec3( 49, 173, 183)) ||
                            CheckForColor(color.rgb, vec3(101, 224, 221))) emission = 2.5;
                    }
                }
            }
        }
    } else {
        if (entityId < 50048) {
            if (entityId < 50040) {
                if (entityId == 50032) {
                    vec3 absDif = abs(vec3(color.r - color.g, color.g - color.b, color.r - color.b));
                    float maxDif = max(absDif.r, max(absDif.g, absDif.b));
                    if (maxDif < 0.1 && color.b > 0.5 && color.b < 0.88) {
                        emission = pow2(pow1_5(color.b)) * 5.0;
                        color.rgb *= color.rgb;
                    }
                } else  {
                    if (CheckForColor(color.rgb, vec3(203, 177, 165)) ||
                        CheckForColor(color.rgb, vec3(214, 155, 126))) {
                        emission = pow2(pow1_5(color.b)) * 10.0;
                        color.r *= 1.2;
                    }
                }
            } else {
                if (entityId == 50040) {
                    if (CheckForColor(color.rgb, vec3(87, 23, 50))) {
                        emission = 8.0;
                        color.rgb *= color.rgb;
                    }
                } else  {
                    if (entityColor.a < 0.001)
                        emission = max0(color.r - color.g - color.b) * 6.0;
                }
            }
        } else {
            if (entityId < 50056) {
                if (entityId == 50048) {
                    lmCoordM.x = 0.0;
                    float dotColor = dot(color.rgb, color.rgb);
                    emission = pow2(pow2(min(dotColor * 0.65, 1.5))) + 0.45;
                } else  {
                    emission = color.g * 6.0;
                }
            } else {
                if (entityId == 50056) {
                    if (CheckForColor(color.rgb, vec3(230, 242, 246)) && texCoord.y > 0.35)
                        emission = 2.5;
                } else  {
                    lmCoordM = vec2(0.0);
                    emission = pow2(pow2(color.r)) * 3.5 + 0.5;
                    color.a *= color.a;
                }
            }
        }
    }
} else {
    if (entityId < 50096) {
        if (entityId < 50080) {
            if (entityId < 50072) {
                if (entityId == 50064) {
                    emission = 2.0 * color.g * float(color.g * 1.5 > color.b + color.r);
                } else  {
                    lmCoordM.x = 0.9;
                    emission = 3.0 * float(dot(color.rgb, color.rgb) > 1.0);
                }
            } else {
                if (entityId == 50072) {
                    emission = 7.5;

                    color.rgb *= color.rgb;
                } else  {
                    playerPos.y += 0.38;
                }
            }
        } else {
            if (entityId < 50088) {
                if (entityId == 50080) {
                    if (atlasSize.x < 900) {
                        lmCoordM = vec2(0.0);
                        emission = float(color.r > 0.9 && color.b > 0.9) * 5.0 + color.g;
                    } else {
                        lmCoordM.x = 0.8;
                    }
                } else  {

                }
            } else {
                if (entityId == 50088) {
                    emission = 1.3;
                } else  {
                    #ifdef IS_IRIS

                        #include "/lib/materials/specificMaterials/others/trident.glsl"
                    #endif
                }
            }
        }
    } else {
        if (entityId < 50112) {
            if (entityId < 50104) {
                if (entityId == 50096) {
                    if (atlasSize.x < 900 && color.r * color.g * color.b + color.b > 0.3) {
                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"

                        smoothnessD *= 0.6;
                    }
                } else  {
                    if (CheckForColor(color.rgb, vec3(239, 254, 194)))
                        emission = 2.5;
                }
            } else {
                if (entityId == 50104) {
                    if (atlasSize.x < 900) {
                        if (CheckForColor(color.rgb, vec3(255)) || CheckForColor(color.rgb, vec3(255, 242, 246))) {
                            vec2 tSize = textureSize(tex, 0);
                            vec4 checkRightmostColor = texelFetch(tex, ivec2(texCoord * tSize) + ivec2(1, 0), 0);
                            if (
                                CheckForColor(checkRightmostColor.rgb, vec3(201, 130, 101)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(241, 158, 152)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(223, 127, 119)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(241, 158, 152)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(165, 99, 80)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(213, 149, 122)) ||
                                CheckForColor(checkRightmostColor.rgb, vec3(255))
                            ) {
                                emission = 1.0;
                            }
                        }
                    }
                } else  {
                    if (color.r > 0.7 && color.r > color.g * 1.2 && color.g > color.b * 2.0) {
                        lmCoordM.x = 0.5;
                        emission = 5.0 * color.g;
                        color.rgb *= color.rgb;
                    }
                }
            }
        } else {
            if (entityId < 50120) {
                if (entityId == 50112) {
                    noDirectionalShading = true;
                    color.rgb *= 1.5;
                    if (color.a < 0.5) {
                        color.a = 0.12;
                        color.rgb *= 5.0;
                    }
                } else  {

                }
            } else {
                if (entityId == 50120) {

                } else  {

                }
            }
        }
    }
}
