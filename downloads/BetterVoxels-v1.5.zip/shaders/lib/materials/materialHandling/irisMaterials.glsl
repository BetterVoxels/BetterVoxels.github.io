int mat = currentRenderedItemId;

#ifdef GBUFFERS_HAND
    float lViewPos = 0.0;
#endif

int subsurfaceMode;
bool centerShadowBias;
float noPuddles;

if (currentRenderedItemId < 45000) {
    #include "/lib/materials/materialHandling/terrainMaterials.glsl"
} else

if (currentRenderedItemId < 45064) {
    if (currentRenderedItemId < 45032) {
        if (currentRenderedItemId < 45016) {
            if (currentRenderedItemId < 45008) {
                if (currentRenderedItemId == 45000) {
                    smoothnessG = 0.5;
                    highlightMult = 2.0;
                    smoothnessD = 0.5;

                    #ifdef GLOWING_ARMOR_TRIM
                        emission = 1.0;
                    #endif
                } else if (currentRenderedItemId == 45004) {
                    #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                    smoothnessG = min(smoothnessG, 0.4);
                    smoothnessD = smoothnessG;
                }
            } else {
                if (currentRenderedItemId == 45008) {
                    if (CheckForStick(color.rgb)) {
                        #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                    } else {
                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                    }
                } else  {
                    if (CheckForStick(color.rgb)) {
                        #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                    } else {
                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                    }
                }
            }
        } else {
            if (currentRenderedItemId < 45024) {
                if (currentRenderedItemId == 45016) {
                    if (CheckForStick(color.rgb)) {
                        #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                    } else {
                        #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                    }
                } else  {
                    if (CheckForStick(color.rgb)) {
                        #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                    } else {
                        #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
                    }
                }
            } else {
                if (currentRenderedItemId == 45024) {
                    materialMask = OSIEBCA;
                    smoothnessG = color.r * 1.5;
                    smoothnessG = min1(smoothnessG);
                    highlightMult = smoothnessG * 2.0;
                    smoothnessD = smoothnessG * smoothnessG * 0.5;

                    #ifdef COATED_TEXTURES
                        noiseFactor = 0.33;
                    #endif
                } else  {
                    #include "/lib/materials/specificMaterials/others/trident.glsl"
                }
            }
        }
    } else {
        if (currentRenderedItemId < 45048) {
            if (currentRenderedItemId < 45040) {
                if (currentRenderedItemId == 45032) {
                    if (color.r + color.g > color.b * 2.0) {
                        emission = color.r + color.g - color.b * 1.5;
                        emission *= 1.8;
                        color.rg += color.b * vec2(0.4, 0.15);
                        color.b *= 0.8;
                    } else {
                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                    }
                } else  {
                    if (GetMaxColorDif(color.rgb) < 0.01) {
                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                    } else {
                        float factor = color.b;
                        smoothnessG = factor;
                        highlightMult = factor * 2.0;
                        smoothnessD = factor;
                    }
                }
            } else {
                if (currentRenderedItemId == 45040) {
                    noSmoothLighting = false;
                    lmCoordM.x = 0.85;
                    emission = color.g;
                    color.rgb = sqrt1(color.rgb);
                } else  {
                    emission = color.b * 2.0;
                }
            }
        } else {
            if (currentRenderedItemId < 45056) {
                if (currentRenderedItemId == 45048) {
                    emission = max0(color.r + color.g - color.b * 0.5);
                } else  {
                    emission = max0(color.b * 2.0 - color.r) * 1.5;
                }
            } else {
                if (currentRenderedItemId == 45056) {
                    materialMask = OSIEBCA;
                    float factor = pow2(color.r);
                    smoothnessG = 0.8 - factor * 0.3;
                    highlightMult = factor * 3.0;
                    smoothnessD = factor;
                } else  {
                    float factor = min(color.r * color.g * color.b * 4.0, 0.7) * 0.7;
                    smoothnessG = factor;
                    highlightMult = factor * 3.0;
                    smoothnessD = factor;
                }
            }
        }
    }
} else {
    if (currentRenderedItemId < 45096) {
        if (currentRenderedItemId < 45080) {
            if (currentRenderedItemId < 45072) {
                if (currentRenderedItemId == 45064) {
                    float factor = color.g * 0.7;
                    smoothnessG = factor;
                    highlightMult = factor * 3.0;
                    smoothnessD = factor;
                } else  {
                    smoothnessG = 1.0;
                    highlightMult = 2.0;
                    smoothnessD = 1.0;
                }
            } else {
                if (currentRenderedItemId == 45072) {
                    smoothnessG = 1.0;
                    highlightMult = 2.0;
                    smoothnessD = 1.0;
                    emission = max0(color.g - color.b * 0.25);
                    color.rgb = pow(color.rgb, vec3(1.0 - 0.75 * emission));
                } else  {
                    if (
                        CheckForColor(color.rgb, vec3(255, 255, 0)) ||
                        CheckForColor(color.rgb, vec3(204, 204, 0)) ||
                        CheckForColor(color.rgb, vec3(73, 104, 216)) ||
                        CheckForColor(color.rgb, vec3(58, 83, 172)) ||
                        CheckForColor(color.rgb, vec3(108, 108, 137)) ||
                        CheckForColor(color.rgb, vec3(86, 86, 109))
                    ) {
                        emission = 1.0;
                        color.rgb += vec3(0.1);
                    }

                    #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                }
            }
        } else {
            if (currentRenderedItemId < 45088) {
                if (currentRenderedItemId == 45080) {
                    if (color.r - 0.1 > color.b + color.g) {
                        emission = color.r * 1.5;
                    }

                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                } else  {
                    emission = max0(color.b + color.g - color.r * 2.0);

                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                }
            } else {
                if (currentRenderedItemId == 45088) {
                    emission = pow2(color.r + color.g) * 0.5;
                } else  {
                    if (color.g < color.r) {
                        emission = 3.0;
                        color.r *= 1.1;
                    }
                }
            }
        }
    } else {
        if (currentRenderedItemId < 45112) {
            if (currentRenderedItemId < 45104) {
                if (currentRenderedItemId == 45096) {

                } else  {
                    emission = dot(color.rgb, color.rgb) * 0.5 + 1.0;
                }
            } else {
                if (currentRenderedItemId == 45104) {
                    emission = pow1_5(color.r) * 2.5 + 0.2;
                } else  {
                    #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                }
            }
        } else {
            if (currentRenderedItemId < 45120) {
                if (currentRenderedItemId == 45112) {
                    emission = abs(color.r - color.b) * 3.0;
                    color.rgb = pow(color.rgb, vec3(1.0 + 0.5 * sqrt(emission)));
                } else  {

                }
            } else {
                if (currentRenderedItemId == 45120) {

                } else  {

                }
            }
        }
    }
}
