if (abs(materialMaskInt - 149.5) < 50.0) {
    materialMaskInt -= 100;
    entityOrHand = true;
}

if (materialMaskInt != 0) {
    if (materialMaskInt < 9) {
        if (materialMaskInt < 5) {
            if (materialMaskInt < 3) {
                if (materialMaskInt == 1) {
                    intenseFresnel = 1.0;
                } else  {
                    intenseFresnel = 1.0;
                    reflectColor = mix(vec3(0.5, 0.75, 0.5), vec3(1.0, 0.45, 0.3), sqrt1(smoothnessD));
                }
            } else {
                if (materialMaskInt == 3) {
                    intenseFresnel = 1.0;
                    reflectColor = vec3(1.0, 0.8, 0.5);
                } else  {

                }
            }
        } else {
            if (materialMaskInt < 7) {
                if (materialMaskInt == 5) {
                    intenseFresnel = 1.0;
                    reflectColor = vec3(1.0, 0.3, 0.2);
                } else  {

                }
            } else {
                if (materialMaskInt == 7) {

                } else  {

                }
            }
        }
    } else {
        if (materialMaskInt < 13) {
            if (materialMaskInt < 11) {
                if (materialMaskInt == 9) {

                } else  {

                }
            } else {
                if (materialMaskInt == 11) {

                } else  {

                }
            }
        } else {
            if (materialMaskInt < 15) {
                if (materialMaskInt == 13) {

                } else  {

                }
            } else {
                if (materialMaskInt == 15) {

                } else {

                }
            }
        }
    }
}
