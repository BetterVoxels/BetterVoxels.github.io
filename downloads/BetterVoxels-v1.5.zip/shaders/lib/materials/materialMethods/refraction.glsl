float GetApproxDistance(float depth) {
    return near * far / (far - depth * far);
}

void DoRefraction(inout vec3 color, inout float z0, inout float z1, vec3 viewPos, float lViewPos) {

    if (int(texelFetch(colortex6, texelCoord, 0).g * 255.1) != 241) return;

    float fovScale = gbufferProjection[1][1];

    vec3 playerPos = ViewToPlayer(viewPos.xyz);
    vec3 worldPos = playerPos.xyz + cameraPosition.xyz;

    #if WATER_STYLE >= 4

        vec3 rwWaves = rwWavesNormal(worldPos.xz - worldPos.y).xzy;
        vec3 rwNormalView = normalize(mat3(gbufferModelView) * rwWaves);
        vec2 rwUp = normalize(gbufferModelView[1].xyz).xy;

        vec2 refractNoise = (rwUp - rwNormalView.xy) * 0.5;
             refractNoise *= WATER_REFRACTION_INTENSITY * fovScale / (3.0 + lViewPos);
             refractNoise *= 0.02;
    #else
        vec2 worldPosRM = worldPos.xz * 0.02 + worldPos.y * 0.01 + 0.01 * frameTimeCounter;

        vec2 refractNoise = texture2D(noisetex, worldPosRM).rb - vec2(0.5);
             refractNoise *= WATER_REFRACTION_INTENSITY * fovScale / (3.0 + lViewPos);

        #if WATER_STYLE < 3
            refractNoise *= 0.015;
        #else
            refractNoise *= 0.02;
        #endif
    #endif

    float approxDif = GetApproxDistance(z1) - GetApproxDistance(z0);
    refractNoise *= clamp(approxDif, 0.0, 1.0);

    vec2 refractCoord = texCoord.xy + refractNoise;

    if (int(texture2D(colortex6, refractCoord).g * 255.1) != 241) return;

    float z0check = texture2D(depthtex0, refractCoord).r;
    float z1check = texture2D(depthtex1, refractCoord).r;
    float approxDifCheck = GetApproxDistance(z1check) - GetApproxDistance(z0check);
    refractNoise *= clamp(approxDifCheck, 0.0, 1.0);

    refractCoord = texCoord.xy + refractNoise;
    color = texture2D(colortex0, refractCoord).rgb;
    z0 = texture2D(depthtex0, refractCoord).r;
    z1 = texture2D(depthtex1, refractCoord).r;
}
