#include "/lib/misc/voxelization.glsl"

vec3 GetRawWave(in vec3 pos, float wind) {
    float magnitude = sin(wind * 0.0027 + pos.z + pos.y) * 0.04 + 0.04;
    float d0 = sin(wind * 0.0127);
    float d1 = sin(wind * 0.0089);
    float d2 = sin(wind * 0.0114);
    vec3 wave;
    wave.x = sin(wind*0.0063 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
    wave.z = sin(wind*0.0224 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
    wave.y = sin(wind*0.0015 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;

    return wave;
}

vec3 GetWave(in vec3 pos, float waveSpeed) {
    float wind = frameTimeCounter * waveSpeed * WAVING_SPEED;
    vec3 wave = GetRawWave(pos, wind);

    #define WAVING_I_RAIN_MULT_M WAVING_I_RAIN_MULT * 0.01

    #if WAVING_I_RAIN_MULT > 100
        float windRain = frameTimeCounter * waveSpeed * WAVING_I_RAIN_MULT_M * WAVING_SPEED;
        vec3 waveRain = GetRawWave(pos, windRain);
        wave = mix(wave, waveRain, rainFactor);
    #endif

    #ifdef NO_WAVING_INDOORS
        wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
    #else
        wave *= 0.1;
    #endif

    float wavingIntensity = WAVING_I * mix(1.0, WAVING_I_RAIN_MULT_M, rainFactor);

    return wave * wavingIntensity;
}

void DoWave_Foliage(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos.y *= 0.5;

    vec3 wave = GetWave(worldPos, 170.0);
    wave.x = wave.x * 8.0 + wave.y * 4.0;
    wave.y = 0.0;
    wave.z = wave.z * 3.0;

    playerPos.xyz += wave * waveMult;
}

void DoWave_Leaves(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos *= vec3(0.75, 0.375, 0.75);

    vec3 wave = GetWave(worldPos, 170.0);
    wave *= vec3(8.0, 3.0, 4.0);

    wave *= 1.0 - inSnowy;

    playerPos.xyz += wave * waveMult;
}

#if defined LEAVES_PHYSICS && (defined GBUFFERS_TERRAIN || (LEAVES_PHYSICS_SHADOWS == 1 && defined SHADOW))
    #define LEAVES_PHYSICS_ACTIVE
#endif

#ifdef LEAVES_PHYSICS_ACTIVE
vec3 GetLeavesPhysicsOffset(vec3 worldPos, vec3 relativePos, float heightMask, bool allowEntityPush) {
    vec3 offset = vec3(0.0);

    #ifdef LEAVES_PHYSICS_ENTITIES
        if (allowEntityPush) {

            vec2 toBlade = relativePos.xz;
            float distXZ = length(toBlade);

            float distY = max(abs(relativePos.y + 1.62) - 0.5, 0.0);
            float verticalFade = exp2(-distY * (4.0 / LEAVES_PHYSICS_REACH_Y));

            vec2 pushVector = toBlade * exp2(-1.8 * distXZ);

            offset.xz += pushVector * (0.9 * verticalFade);
        }
    #endif

    #ifdef LEAVES_PHYSICS_WEATHER
        const vec2 windDirection = vec2(1.0, 0.0);

        #ifdef NO_WAVING_INDOORS
            float skylightFactor = clamp(lmCoord.y - 0.87, 0.0, 0.1) * 10.0;
        #else
            float skylightFactor = 1.0;
        #endif

        float weatherAmount = (rainFactor + thunderStrength * 0.75) * skylightFactor;

        float t     = frameTimeCounter * WAVING_SPEED;
        float phase = worldPos.x * 0.4 + worldPos.z * 0.4;
        float sway  = sin(t * 1.1 + phase) + 0.5 * sin(t * 2.3 - phase * 1.7) + 0.25 * sin(t * 4.1 + phase * 0.6);
        sway *= 0.57;

        float gustPhase = t * 0.7 + worldPos.x * 0.13 - worldPos.z * 0.17;
        float gust = sin(gustPhase) * 0.5 + 0.5;
        gust *= gust;

        vec2 lean   = windDirection * weatherAmount * 0.22;
        vec2 motion = windDirection * (sway * 0.10 + gust * 0.12) * weatherAmount
                    + vec2(-windDirection.y, windDirection.x) * sway * weatherAmount * 0.05;

        offset.xz += lean + motion;
    #endif

    return offset * heightMask;
}
#endif

void DoWave_Water(inout vec3 playerPos, vec3 worldPos) {
    #ifdef INTERACTIVE_WATER
        #include "/lib/materials/specificMaterials/translucents/interactiveWaterConsts.glsl"

        vec2 interactiveWaterPos = (playerPos.xz + cameraPositionFract.xz)/shadowMapResolution + 0.25;
        vec3[2] waveStrengths = vec3[2](
            texture(shadowcolor2, interactiveWaterPos + vec2(0.0, 0.0)).xyz * waveStrengthCoeffs[0],
            texture(shadowcolor2, interactiveWaterPos + vec2(0.5, 0.0)).xyz * waveStrengthCoeffs[1]
        );

        int maxDetail = max(1, 4 - int(0.02 * length(playerPos)));
        vec3 distortion = texture(shadowcolor3, worldPos.xz / (1024.0 * 5)).rgb;

        float offset = 0.0;
        for (int i = 0; i < 3; i++) {
            vec2 thisPos = worldPos.xz;
            thisPos += 2 * (dot(thisPos, waveDirs[i]) + distortion[i]) * waveDirs[i];
            thisPos *= 0.3;
            for (int k = 0; k < min(2, maxDetail); k++) {
                float thisOffset = texture(colortex9, fract(
                    (thisPos / waveLengths[k] - waveSpeed * frameTimeCounter / sqrt(waveLengths[k]) * waveDirs[i] - 0.5) / 1024.0
                )).b - 0.5;
                offset += waveStrengths[k][i] * thisOffset;
            }
        }
        playerPos.y -= offset;
    #else
        float waterWaveTime = frameTimeCounter * 6.0 * WAVING_SPEED;
        worldPos.xz *= 14.0;

        float wave  = sin(waterWaveTime * 0.7 + worldPos.x * 0.14 + worldPos.z * 0.07);
              wave += sin(waterWaveTime * 0.5 + worldPos.x * 0.10 + worldPos.z * 0.05);

        #ifdef NO_WAVING_INDOORS
            wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
        #else
            wave *= 0.1;
        #endif

        playerPos.y += wave * 0.125 - 0.05;

        #if defined GBUFFERS_WATER && WATER_STYLE == 1
            normal = mix(normal, tangent, wave * 0.01);
        #endif
    #endif
}

void DoWave_Lava(inout vec3 playerPos, vec3 worldPos) {
    if (fract(worldPos.y + 0.005) > 0.06) {
        float lavaWaveTime = frameTimeCounter * 3.0 * WAVING_SPEED;
        worldPos.xz *= 14.0;

        float wave  = sin(lavaWaveTime * 0.7 + worldPos.x * 0.14 + worldPos.z * 0.07);
              wave += sin(lavaWaveTime * 0.5 + worldPos.x * 0.05 + worldPos.z * 0.10);

        playerPos.y += wave * 0.0125;
    }
}

void DoWave(inout vec3 playerPos, int mat) {
    vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
    #ifdef LEAVES_PHYSICS_ACTIVE
        vec3 physicsRelativePos = playerPos.xyz;

        float physicsHeightMask = smoothstep(0.0, 0.625, fract(worldPos.y + 0.05));
    #endif

    #if defined GBUFFERS_TERRAIN || defined SHADOW
        #ifdef WAVING_FOLIAGE
            if (mat == 10005
                #ifdef DO_MORE_FOLIAGE_WAVING
                    || mat == 10769
                    || mat == 10924
                    || mat == 10972
                #endif
            ) {
                if (gl_MultiTexCoord0.t < mc_midTexCoord.t || fract(worldPos.y + 0.21) > 0.26)
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, true) * LEAVES_PHYSICS_STRENGTH;
                #endif
            }

            else if (mat == 10021) {
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, true) * LEAVES_PHYSICS_STRENGTH;
                #endif
            }

            #if defined WAVING_LEAVES || defined WAVING_LAVA || defined WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LEAVES
            if (mat == 10009) {
                DoWave_Leaves(playerPos.xyz, worldPos, 1.0);

                #ifdef LEAVES_PHYSICS_ACTIVE
                    playerPos.xyz += GetLeavesPhysicsOffset(worldPos, physicsRelativePos, physicsHeightMask, false) * LEAVES_PHYSICS_STRENGTH;
                #endif
            } else if (mat == 10013) {

                DoWave_Leaves(playerPos.xyz, worldPos, 0.75);
            }
            #if defined NETHER || defined DO_NETHER_VINE_WAVING_OUTSIDE_NETHER
                else if (mat == 10884 || mat == 10885) {
                    float waveMult = 1.0;
                    #if COLORED_LIGHTING_INTERNAL > 0
                        vec3 playerPosP = playerPos + vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosP = SceneToVoxel(playerPosP);
                        vec3 playerPosN = playerPos - vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosN = SceneToVoxel(playerPosN);

                        if (CheckInsideVoxelVolume(voxelPosP)) {
                            int voxelP = int(texelFetch(voxel_sampler, ivec3(voxelPosP), 0).r);
                            int voxelN = int(texelFetch(voxel_sampler, ivec3(voxelPosN), 0).r);
                            if (voxelP != 0 && voxelP != 65 || voxelN != 0 && voxelN != 65)
                                waveMult = 0.0;
                        }
                        DoWave_Foliage(playerPos.xyz, worldPos, waveMult);
                    #endif
                }
            #endif

            #if defined WAVING_LAVA || defined WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LAVA
            if (mat == 10068) {
                DoWave_Lava(playerPos.xyz, worldPos);

                #ifdef GBUFFERS_TERRAIN

                    glColorRaw.rgb = min(glColorRaw.rgb, vec3(0.9));
                #endif
            }

            #ifdef WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef WAVING_LILY_PAD
            if (mat == 10489) {
                DoWave_Water(playerPos.xyz, worldPos);
            }
        #endif
    #endif

    #if defined GBUFFERS_WATER || defined SHADOW

        #ifdef WAVING_WATER_VERTEX
            #if WATER_STYLE < 4
                #if defined WAVING_ANYTHING_TERRAIN && defined SHADOW
                    else
                #endif

                if (mat == 32000) {
                    if (fract(worldPos.y + 0.005) > 0.06)
                        DoWave_Water(playerPos.xyz, worldPos);
                }
            #endif
        #endif
    #endif
}
