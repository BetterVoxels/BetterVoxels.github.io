
#if SAMSUNG_MOON_ZOOM == 1
#ifndef INCLUDE_MOON_ZOOM_STATE
#define INCLUDE_MOON_ZOOM_STATE

#define MZ_BLUR_PEAK 0.35

uniform sampler2D moonzoom_sampler;

float MoonZoomPhase() {
    return texelFetch(moonzoom_sampler, ivec2(0, 0), 0).g;
}

#ifdef CSH
    layout(rgba32f) uniform image2D moonzoom_img;

    void MoonZoomUpdateState() {

        float fov  = degrees(2.0 * atan(gbufferProjectionInverse[1][1]));
        float nowT = frameTimeCounter;

        vec4 s = imageLoad(moonzoom_img, ivec2(0, 0));

        if (s.x != 1234.5 || nowT < s.z - 0.5) {

            s = vec4(1234.5, 0.0, nowT, 0.0);
        } else {

            float dt = clamp(nowT - s.z, 0.0, 1.0);

            float target = fov <= MOON_ZOOM_TRIGGER_FOV ? 1.0 : 0.0;

            bool  lowSeg  = s.y < MZ_BLUR_PEAK;
            bool  goingIn = target > s.y;
            float tIn     = max(MOON_ZOOM_BLUR_IN_TIME, 0.05);
            float tOut    = max(MOON_ZOOM_BLUR_OUT_TIME, 0.05);
            float segLen  = lowSeg ? MZ_BLUR_PEAK : 1.0 - MZ_BLUR_PEAK;
            float segTime = lowSeg ? (goingIn ? tIn : tOut) : (goingIn ? tOut : tIn);

            s.y = clamp(s.y + sign(target - s.y) * dt * segLen / segTime, 0.0, 1.0);
            s.z = nowT;
        }

        imageStore(moonzoom_img, ivec2(0, 0), s);
    }
#endif

#endif
#endif
