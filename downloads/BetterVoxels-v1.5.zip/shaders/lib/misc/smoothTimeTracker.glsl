
#ifndef INCLUDE_SMOOTH_TIME_TRACKER
#define INCLUDE_SMOOTH_TIME_TRACKER

#define SMOOTH_TIME_JUMP_THRESHOLD 0.004

uniform sampler2D smooth_time_sampler;

float SmoothTimeVisualSunAngle() {
    return texelFetch(smooth_time_sampler, ivec2(1, 0), 0).r;
}

#ifdef CSH

    #include "/lib/misc/timeInterpolation.glsl"

    layout(rgba32f) uniform image2D smooth_time_img;

    void SmoothTimeUpdateState() {
        float nativeAngle = fract(sunAngle);
        float nowT = frameTimeCounter;

        float tIn  = max(TIME_TRANSITION_IN, 0.0);
        float tOut = max(TIME_TRANSITION_OUT, 0.0);
        float dur  = max(tIn + tOut, 0.05);

        vec4 s0 = imageLoad(smooth_time_img, ivec2(0, 0));
        vec4 s1 = imageLoad(smooth_time_img, ivec2(1, 0));

        if (s0.x != 1234.5 || nowT < s1.y - 0.5) {

            s0 = vec4(1234.5, nativeAngle, nowT - 2.0 * dur, nativeAngle);
            s1 = vec4(nativeAngle, nowT, 0.0, 0.0);
        } else {

            float dNative = fract(nativeAngle - s0.y + 0.5) - 0.5;
            if (abs(dNative) > SMOOTH_TIME_JUMP_THRESHOLD) {
                s0.z = nowT;
                s0.w = s1.x;

            }
            s0.y = nativeAngle;

            float elapsed = nowT - s0.z;
            float p;
            if (elapsed >= dur) {
                p = 1.0;
            } else if (elapsed < tIn) {

                p = tIn > 0.0001 ? 0.5 * (elapsed / tIn) : 0.5;
            } else {

                p = tOut > 0.0001 ? 0.5 + 0.5 * ((elapsed - tIn) / tOut) : 1.0;
            }
            p = clamp(p, 0.0, 1.0);

            if (p >= 1.0) {

                s1.x = nativeAngle;
                s0.w = nativeAngle;
            } else {
                float span = fract(nativeAngle - s0.w + 0.5) - 0.5;
                s1.x = fract(s0.w + span * smoothTimeCurve(p));
            }
            s1.y = nowT;
        }

        imageStore(smooth_time_img, ivec2(0, 0), s0);
        imageStore(smooth_time_img, ivec2(1, 0), s1);
    }
#endif

#endif
