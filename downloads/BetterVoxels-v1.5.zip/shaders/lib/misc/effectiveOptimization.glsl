#ifndef EFFECTIVE_OPTIMIZATION
#define EFFECTIVE_OPTIMIZATION

#if OPT_PRESET == 0

    #define EOPT_GI_DISTANT_THROTTLE   OPT_GI_DISTANT_THROTTLE
    #define EOPT_GI_TRANSLUCENT_TRACE  OPT_GI_TRANSLUCENT_TRACE
    #define EOPT_GI_RANGE_MULT         OPT_GI_RANGE_MULT
    #define EOPT_RAY_SKY_EARLY_OUT     OPT_RAY_SKY_EARLY_OUT
    #define EOPT_VOXEL_LOD_BIAS        OPT_VOXEL_LOD_BIAS
    #define EOPT_VOXEL_TRACE_LIMIT     OPT_VOXEL_TRACE_LIMIT
    #define EOPT_LIGHT_CULL            OPT_LIGHT_CULL
    #define EOPT_VL_SAMPLE_PCT         OPT_VL_SAMPLE_PCT
    #define EOPT_VL_TEMPORAL_ROTATE    OPT_VL_TEMPORAL_ROTATE
    #define EOPT_RT_REFLECTION_RANGE   OPT_RT_REFLECTION_RANGE
    #define EOPT_SSR_STEPS             OPT_SSR_STEPS
    #define EOPT_SSR_REFINE_HITS       OPT_SSR_REFINE_HITS
    #define EOPT_FAST_DISTANCE_TESTS   OPT_FAST_DISTANCE_TESTS
    #define EOPT_FAST_INTEGER_POW      OPT_FAST_INTEGER_POW
    #define EOPT_FUSE_LIGHTSHAFT_MATRIX OPT_FUSE_LIGHTSHAFT_MATRIX

#elif OPT_PRESET == 1

    #define EOPT_GI_DISTANT_THROTTLE   1
    #define EOPT_GI_TRANSLUCENT_TRACE  1
    #define EOPT_GI_RANGE_MULT         1.00
    #define EOPT_RAY_SKY_EARLY_OUT     1
    #define EOPT_VOXEL_LOD_BIAS        0
    #define EOPT_VOXEL_TRACE_LIMIT     2
    #define EOPT_LIGHT_CULL            1
    #define EOPT_VL_SAMPLE_PCT         85
    #define EOPT_VL_TEMPORAL_ROTATE    1
    #define EOPT_RT_REFLECTION_RANGE   40.0
    #define EOPT_SSR_STEPS             24
    #define EOPT_SSR_REFINE_HITS       5
    #define EOPT_FAST_DISTANCE_TESTS   1
    #define EOPT_FAST_INTEGER_POW      1
    #define EOPT_FUSE_LIGHTSHAFT_MATRIX 1

#elif OPT_PRESET == 2

    #define EOPT_GI_DISTANT_THROTTLE   2
    #define EOPT_GI_TRANSLUCENT_TRACE  1
    #define EOPT_GI_RANGE_MULT         0.90
    #define EOPT_RAY_SKY_EARLY_OUT     1
    #define EOPT_VOXEL_LOD_BIAS        0
    #define EOPT_VOXEL_TRACE_LIMIT     2
    #define EOPT_LIGHT_CULL            2
    #define EOPT_VL_SAMPLE_PCT         70
    #define EOPT_VL_TEMPORAL_ROTATE    1
    #define EOPT_RT_REFLECTION_RANGE   30.0
    #define EOPT_SSR_STEPS             20
    #define EOPT_SSR_REFINE_HITS       5
    #define EOPT_FAST_DISTANCE_TESTS   1
    #define EOPT_FAST_INTEGER_POW      1
    #define EOPT_FUSE_LIGHTSHAFT_MATRIX 1

#elif OPT_PRESET == 3

    #define EOPT_GI_DISTANT_THROTTLE   3
    #define EOPT_GI_TRANSLUCENT_TRACE  0
    #define EOPT_GI_RANGE_MULT         0.70
    #define EOPT_RAY_SKY_EARLY_OUT     1
    #define EOPT_VOXEL_LOD_BIAS        1
    #define EOPT_VOXEL_TRACE_LIMIT     3
    #define EOPT_LIGHT_CULL            3
    #define EOPT_VL_SAMPLE_PCT         55
    #define EOPT_VL_TEMPORAL_ROTATE    1
    #define EOPT_RT_REFLECTION_RANGE   20.0
    #define EOPT_SSR_STEPS             14
    #define EOPT_SSR_REFINE_HITS       4
    #define EOPT_FAST_DISTANCE_TESTS   1
    #define EOPT_FAST_INTEGER_POW      1
    #define EOPT_FUSE_LIGHTSHAFT_MATRIX 1

#else

    #define EOPT_GI_DISTANT_THROTTLE   3
    #define EOPT_GI_TRANSLUCENT_TRACE  0
    #define EOPT_GI_RANGE_MULT         0.50
    #define EOPT_RAY_SKY_EARLY_OUT     1

    #define EOPT_VOXEL_LOD_BIAS        1
    #define EOPT_VOXEL_TRACE_LIMIT     4
    #define EOPT_LIGHT_CULL            4
    #define EOPT_VL_SAMPLE_PCT         30
    #define EOPT_VL_TEMPORAL_ROTATE    1
    #define EOPT_RT_REFLECTION_RANGE   15.0
    #define EOPT_SSR_STEPS             8
    #define EOPT_SSR_REFINE_HITS       3
    #define EOPT_FAST_DISTANCE_TESTS   1
    #define EOPT_FAST_INTEGER_POW      1
    #define EOPT_FUSE_LIGHTSHAFT_MATRIX 1
#endif

#endif
