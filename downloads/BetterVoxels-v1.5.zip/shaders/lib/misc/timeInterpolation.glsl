#ifndef INCLUDE_TIME_INTERPOLATION
#define INCLUDE_TIME_INTERPOLATION

float smoothTimeEaseExpOut(float dt){
	return clamp(1.0 - exp(-dt / max(TIME_TRANSITION_SPEED, 0.0001)), 0.0, 1.0);
}

float smoothTimeAdvance(float storedVisual, float target, float dt){
	return mix(storedVisual, target, smoothTimeEaseExpOut(dt));
}
vec3 smoothTimeAdvanceVec(vec3 storedVisual, vec3 target, float dt){
	return mix(storedVisual, target, smoothTimeEaseExpOut(dt));
}

#include "/lib/misc/easeCurves.glsl"

float smoothTimeCurve(float p) {
    return bvEaseCurve(p, TIME_TRANSITION_CURVE);
}

float GetVisualWorldTime(){ return float(worldDay) * 24000.0 + float(worldTime); }

float GetVisualTimeFract(){
	return fract(GetVisualWorldTime() / 24000.0);
}

#endif
