
if (participateInSorting) {
    flipPair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 4);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 5);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 4);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 6);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 5);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 4);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 7);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 6);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 5);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 4);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();

if (participateInSorting) {
    flipPair(index, 8);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 7);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 6);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 5);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 4);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 3);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 2);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 1);
}
barrier();
memoryBarrierShared();
if (participateInSorting) {
    dispersePair(index, 0);
}
barrier();
memoryBarrierShared();
