
#if SAMSUNG_MOON_ZOOM == 1
#ifndef INCLUDE_MOON_ZOOM
#define INCLUDE_MOON_ZOOM

uniform sampler2D colortex10;

float mzPhaseShade(vec3 nViewPosM) {
    #if SUN_MOON_STYLE >= 2
        if (moonPhase < 1) return 1.0;

        #if SUN_MOON_STYLE == 2
            float moonCrescentOffset = 0.0055;
            float moonPhaseFactor1 = 2.45;
            float moonPhaseFactor2 = 750.0;
        #else
            float moonCrescentOffset = 0.0042;
            float moonPhaseFactor1 = 2.2;
            float moonPhaseFactor2 = 1000.0;
        #endif

        float moonPhaseOffset = moonPhase != 4 ? moonCrescentOffset : 0.0;
        if (moonPhase > 4) moonPhaseOffset = -moonPhaseOffset;

        float ang = fract(timeAngle - (0.25 + moonPhaseOffset));
        ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
        vec2 sunRotationData2 = vec2(cos(sunPathRotation * 0.01745329251994),
                                    -sin(sunPathRotation * 0.01745329251994));
        vec3 rawSunVec2 = (gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData2) * 2000.0, 1.0)).xyz;

        float moonPhaseVdosS = dot(nViewPosM, normalize(rawSunVec2));
        return pow2(1.0 - min1(pow(abs(moonPhaseVdosS), moonPhaseFactor2) * moonPhaseFactor1));
    #else
        return 1.0;
    #endif
}

vec3 ApplyMoonZoom(vec3 sky, vec3 nViewPos, vec3 sunVecM, vec3 upVecM, float sunVisibilityM) {

    float phase = MoonZoomPhase();
    if (phase <= 0.001 || sunVisibilityM > 0.5) return sky;

    float darkT = sin(min(phase / 0.40, 1.0) * 1.5707963);

    float blurAmount;
    if (phase < MZ_BLUR_PEAK) {
        blurAmount = sin(phase / MZ_BLUR_PEAK * 1.5707963);
    } else {
        blurAmount = 1.0 - sin((phase - MZ_BLUR_PEAK) / (1.0 - MZ_BLUR_PEAK) * 1.5707963);
    }

    float revealT = sin(clamp((phase - 0.20) / 0.80, 0.0, 1.0) * 1.5707963);

    sky *= mix(vec3(1.0), vec3(0.62, 0.72, 1.0) * MOON_ZOOM_SKY_DARKNESS, darkT);

    vec3 moonDir = -sunVecM;
    float VdotMoon = dot(nViewPos, moonDir);
    float moonCos = cos(radians(MOON_ZOOM_DISK_SIZE));

    float centerAng = acos(clamp(VdotMoon, -1.0, 1.0));
    float diskR     = radians(MOON_ZOOM_DISK_SIZE);
    float bloomOut  = diskR * MOON_ZOOM_BLOOM_SIZE;
    float bt        = clamp((centerAng - diskR) / max(bloomOut - diskR, 1e-4), 0.0, 1.0);
    float glow      = exp(-bt * bt * 3.5) * MOON_ZOOM_BLOOM * revealT;
    sky += vec3(0.68, 0.76, 0.90) * glow;

    float fd       = (phase - MZ_BLUR_PEAK) / 0.28;
    float diskFall = 1.0 - smoothstep(diskR * 0.85, diskR * 1.25, centerAng);
    float flash    = exp(-fd * fd * 3.0) * diskFall * MOON_ZOOM_FLASH;

    vec3 result = sky;

    if (VdotMoon > moonCos) {

        vec3 mUp    = normalize(upVecM - moonDir * dot(upVecM, moonDir));
        vec3 mRight = cross(moonDir, mUp);
        float scale = sqrt(max(1.0 - moonCos * moonCos, 1e-5));
        vec2 diskUV = vec2(dot(nViewPos, mRight), dot(nViewPos, mUp)) / scale * 0.5 + 0.5;

        if (!(any(lessThan(diskUV, vec2(0.0))) || any(greaterThan(diskUV, vec2(1.0))))) {

            float blurRad = blurAmount * MOON_ZOOM_FOCUS_BLUR;
            vec4 hd = texture2D(colortex10, diskUV);
            if (blurRad > 0.0005) {
                for (int i = 0; i < 8; i++) {
                    float a = float(i) * 0.7853981634;
                    vec2 dir = vec2(cos(a), sin(a));
                    hd += texture2D(colortex10, diskUV + dir * blurRad);
                    hd += texture2D(colortex10, diskUV + dir * blurRad * 0.55);
                }
                hd *= 0.058823529;
            }

            vec3 hdCol = hd.rgb * mzPhaseShade(nViewPos) * MOON_ZOOM_BRIGHTNESS * vec3(0.82, 0.88, 1.03);

            float textureMix = revealT * clamp(hd.a, 0.0, 1.0);
            result = mix(sky, hdCol, textureMix);
        }
    }

    return result * (1.0 + flash);
}

#endif
#endif
