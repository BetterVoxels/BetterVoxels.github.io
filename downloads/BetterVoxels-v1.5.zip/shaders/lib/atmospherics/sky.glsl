#ifndef INCLUDE_SKY
    #define INCLUDE_SKY

    #include "/lib/colors/lightAndAmbientColors.glsl"
    #include "/lib/colors/skyColors.glsl"

    #ifdef CAVE_FOG
        #include "/lib/atmospherics/fog/caveFactor.glsl"
    #endif

    vec3 GetGradientSky(float VdotU, float VdotS) {

        float nightFactorSqrt2 = sqrt2(nightFactor);
        float nightFactorM = sqrt2(nightFactorSqrt2) * 0.4;
        float VdotSM1 = pow2(max(VdotS, 0.0));
        float VdotSM2 = pow2(VdotSM1);
        float VdotSM3 = pow2(pow2(max(-VdotS, 0.0)));

        float VdotUmax0 = max(VdotU, 0.0);

        vec3 upColor = mix(nightUpSkyColor * (1.5 - 0.5 * nightFactorSqrt2 + nightFactorM * VdotSM3 * 1.5), dayUpSkyColor, sunFactor);
        vec3 middleColor = mix(nightMiddleSkyColor * (3.0 - 2.0 * nightFactorSqrt2), dayMiddleSkyColor * (1.0 + VdotSM2 * 0.3), sunFactor);
        vec3 downColor = mix(nightDownSkyColor, dayDownSkyColor, (sunFactor + sunVisibility) * 0.5);

            float VdotUM1 = pow2(1.0 - VdotUmax0);
                  VdotUM1 = pow(VdotUM1, 1.0 - VdotSM2 * 0.4);
                  VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.15);
            vec3 finalSky = mix(upColor, middleColor, VdotUM1);

            float VdotUM2 = pow2(1.0 - abs(VdotU));
                  VdotUM2 = VdotUM2 * VdotUM2 * (3.0 - 2.0 * VdotUM2);
                  VdotUM2 *= (0.7 - nightFactorM + VdotSM1 * (0.3 + nightFactorM)) * invNoonFactor * sunFactor;
            finalSky = mix(finalSky, sunsetDownSkyColorP * (1.0 + VdotSM1 * 0.3), VdotUM2 * invRainFactor);

            float VdotUM3 = min(max0(-VdotU + 0.08) / 0.35, 1.0);
                  VdotUM3 = smoothstep1(VdotUM3);
            vec3 scatteredGroundMixer = vec3(VdotUM3 * VdotUM3, sqrt1(VdotUM3), sqrt3(VdotUM3));
                 scatteredGroundMixer = mix(vec3(VdotUM3), scatteredGroundMixer, 0.75 - 0.5 * rainFactor);
            finalSky = mix(finalSky, downColor, scatteredGroundMixer);

        return finalSky;
    }

    vec3 ApplySkyBalance(vec3 sky, float VdotU) {
        float up = pow(clamp(VdotU, 0.0, 1.0), CC_SKY_BLEND);
        vec3 horizonTint = vec3(CC_HORIZON_R, CC_HORIZON_G, CC_HORIZON_B) * CC_HORIZON_I * ccSkyHorizon;
        vec3 zenithTint  = vec3(CC_ZENITH_R,  CC_ZENITH_G,  CC_ZENITH_B)  * CC_ZENITH_I  * ccSkyZenith;
        return sky * mix(horizonTint, zenithTint, up);
    }

    vec3 ApplySkySaturation(vec3 sky) {
        float sat = SKY_SATURATION * ccSkyGradSat;
        if (sat == 1.0) return sky;

        return max(mix(vec3(GetLuminance(sky)), sky, sat), vec3(0.0));
    }

    vec3 ApplySkyBlue(vec3 sky, float blueAmt) {
        float amt = (blueAmt - 1.0) * invRainFactor;
        if (amt == 0.0) return sky;

        vec3 tinted = sky * vec3(1.0 - 0.65 * amt, 1.0 - 0.30 * amt, 1.0 + 0.50 * amt);

        float lum  = GetLuminance(sky);
        float lumT = GetLuminance(tinted);
        float keep = 1.0 / (1.0 + 0.6 * max(amt, 0.0));
        return tinted * mix(1.0, lum / max(lumT, 1e-5), keep);
    }

    vec3 GetSkyBase(float VdotU, float VdotS, float blueAmt) {
        return ApplySkyBlue(ApplySkySaturation(ApplySkyBalance(GetGradientSky(VdotU, VdotS), VdotU)), blueAmt);
    }

    vec3 GetSkyTinted(float VdotU, float VdotS, float dither, bool doGlare, bool doGround, float blueAmt) {
        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);
        float VdotSML = sunVisibility > 0.5 ? VdotS : -VdotS;

        vec3 finalSky = GetSkyBase(VdotU, VdotS, blueAmt);

        if (doGround)
            finalSky *= smoothstep1(pow2(1.0 + min(VdotU, 0.0)));

        if (isEyeInWater == 1)
            finalSky = mix(finalSky * 3.0, waterFogColor, VdotUmax0M);

        if (doGlare) {
            if (0.0 < VdotSML) {
                float glareScatter = 4.0 * (2.0 - clamp01(VdotS * 1000.0));
                float VdotSM4 = pow(abs(VdotS), glareScatter);

                float visfactor = 0.075;
                float glare = visfactor / (1.0 - (1.0 - visfactor) * VdotSM4) - visfactor;

                glare *= 0.5 + pow2(noonFactor) * 1.2;
                glare *= 1.0 - rainFactor * 0.5;

                float glareWaterFactor = isEyeInWater * sunVisibility;
                vec3 glareColor = mix(vec3(0.38, 0.4, 0.5) * 0.7, vec3(0.5), sunVisibility);
                     glareColor = glareColor + glareWaterFactor * vec3(7.0);

                glare *= mix(SKY_GLARE, 1.0, rainFactor);

                finalSky += glare * shadowTime * glareColor;
            }
        }

        #ifdef CAVE_FOG

            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        finalSky += (dither - 0.5) / 128.0;

        return finalSky;
    }

    vec3 GetSky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {
        vec3 sky = GetSkyTinted(VdotU, VdotS, dither, doGlare, doGround,
                                 1.0 + (SKY_BLUE - ccSkyBlueNeutral));

        #if CC_SKY_HORIZON_FADE > 0
            float skyFadeUp = 1.0 - smoothstep(0.0, 0.45, clamp(VdotU, 0.0, 1.0));
            sky = mix(sky, vec3(GetLuminance(sky)),
                      CC_SKY_HORIZON_FADE * 0.01 * ccSkyHorizonFade * skyFadeUp);
        #endif

        return sky * ccSkyLevel;
    }

    vec3 GetLowQualitySky(float VdotU, float VdotS, float dither, bool doGlare, bool doGround) {

        float VdotUmax0 = max(VdotU, 0.0);
        float VdotUmax0M = 1.0 - pow2(VdotUmax0);

            vec3 upColor = mix(nightUpSkyColor, dayUpSkyColor, sunFactor);
            vec3 middleColor = mix(nightMiddleSkyColor, dayMiddleSkyColor, sunFactor);

                float VdotUM1 = pow2(1.0 - VdotUmax0);
                      VdotUM1 = mix(VdotUM1, 1.0, rainFactor2 * 0.2);
                vec3 finalSky = mix(upColor, middleColor, VdotUM1);

                float VdotUM2 = pow2(1.0 - abs(VdotU));
                      VdotUM2 *= invNoonFactor * sunFactor * (0.8 + 0.2 * VdotS);
                finalSky = mix(finalSky, sunsetDownSkyColorP * (shadowTime * 0.6 + 0.2), VdotUM2 * invRainFactor);

            finalSky *= pow2(pow2(1.0 + min(VdotU, 0.0)));

            if (isEyeInWater == 1)
                finalSky = mix(finalSky, waterFogColor, VdotUmax0M);

            finalSky *= 1.0 + mix(nightFactor, 0.5 + 0.7 * noonFactor, VdotS * 0.5 + 0.5) * pow2(pow2(pow2(VdotS)));

            finalSky = ApplySkyBlue(ApplySkySaturation(ApplySkyBalance(finalSky, VdotU)),
                                  1.0 + (SKY_BLUE - ccSkyBlueNeutral));

        #ifdef CAVE_FOG

            finalSky = mix(finalSky, caveFogColor, GetCaveFactor() * VdotUmax0M);
        #endif

        #if CC_SKY_HORIZON_FADE > 0
            float lqFadeUp = 1.0 - smoothstep(0.0, 0.45, clamp(VdotU, 0.0, 1.0));
            finalSky = mix(finalSky, vec3(GetLuminance(finalSky)),
                           CC_SKY_HORIZON_FADE * 0.01 * ccSkyHorizonFade * lqFadeUp);
        #endif

        return finalSky * ccSkyLevel;
    }

#endif
