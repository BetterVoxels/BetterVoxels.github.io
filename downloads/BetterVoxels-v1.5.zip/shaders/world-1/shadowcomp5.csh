#version 430 compatibility
#define NETHER
#define CSH
#include "/program/shadowcomp5.glsl"
