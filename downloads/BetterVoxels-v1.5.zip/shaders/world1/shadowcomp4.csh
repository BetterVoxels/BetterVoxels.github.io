#version 430 compatibility
#define END
#define CSH
#include "/program/shadowcomp4.glsl"
