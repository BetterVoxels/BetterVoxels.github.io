#include "/lib/common.glsl"

#ifdef CSH

//     Failed to process ConstDirective { IVEC3 workGroups = ivec3(128 / 8); }:

#if PARTICLE_SHADOWS == 1 || PARTICLE_LIGHT == 1

    #if PARTICLE_SHADOW_RES == 64
        const ivec3 workGroups = ivec3(8, 8, 8);
    #elif PARTICLE_SHADOW_RES == 96
        const ivec3 workGroups = ivec3(12, 12, 12);
    #elif PARTICLE_SHADOW_RES == 128
        const ivec3 workGroups = ivec3(16, 16, 16);
    #elif PARTICLE_SHADOW_RES == 160
        const ivec3 workGroups = ivec3(20, 20, 20);
    #elif PARTICLE_SHADOW_RES == 192
        const ivec3 workGroups = ivec3(24, 24, 24);
    #else
        const ivec3 workGroups = ivec3(32, 32, 32);
    #endif
#else
    const ivec3 workGroups = ivec3(1, 1, 1);
#endif
layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;

#if PARTICLE_SHADOWS == 1 || PARTICLE_LIGHT == 1
    #define PARTICLE_VOL_WRITE
    #include "/lib/vx/particleVolume.glsl"

    layout(rgba32f) uniform restrict writeonly image2D particleLightList;
    layout(r32ui) uniform restrict uimage2D particleLightCount;

    void main() {
        ivec3 cell = ivec3(gl_GlobalInvocationID);

        #if PARTICLE_LIGHT == 1

            uint pvolBits = imageLoad(particleLightVol, cell).r;
            if (pvolBits != 0u) {
                imageStore(particleLightVol, cell, uvec4(0u));

                float lum = float(pvolBits >> 24) * (1.0 / 255.0);
                if (lum >= PARTICLE_LIGHT_THRESHOLD) {
                    uint index = imageAtomicAdd(particleLightCount, ivec2(0, 0), 1u);
                    if (index < uint(PVOL_LIGHT_CAP)) {

                        vec3 playerPos = (vec3(cell - PVOL_DIM / 2) + 0.5) / pvolScale
                                       - pvolReadDelta;

                        vec3 col = vec3((pvolBits >> 16) & 0xffu,
                                        (pvolBits >> 8) & 0xffu,
                                        pvolBits & 0xffu) * (1.0 / 255.0);

                        imageStore(particleLightList, ivec2(0, int(index)),
                                   vec4(playerPos, PARTICLE_LIGHT_RADIUS));
                        imageStore(particleLightList, ivec2(1, int(index)),
                                   vec4(col, lum));
                    }
                }
            }
        #endif

        #if PARTICLE_SHADOWS == 1
            imageStore(particleDensityVol, cell + ivec3(0, pvolWriteY, 0), uvec4(0u));
        #endif
    }
#else
    void main() {}
#endif

#endif
