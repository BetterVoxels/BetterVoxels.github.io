
#ifndef BLISS_CLOUDS_COMPAT_GLSL
#define BLISS_CLOUDS_COMPAT_GLSL

#define VOLUMETRIC_CLOUDS
#define HQ_CLOUDS
#define SKY_GROUND
#define CLOUDS_SHADOWS
#define CloudLayer0
#define CloudLayer1
#define CloudLayer2

#define minRayMarchSteps 15
#define maxRayMarchSteps 15
#define minRayMarchStepsLQ 10
#define maxRayMarchStepsLQ 30
#define cloud_LevelOfDetail 1
#define cloud_ShadowLevelOfDetail 0
#define cloud_LevelOfDetailLQ 1
#define cloud_ShadowLevelOfDetailLQ 0

#define CLOUD_SHADOW_STRENGTH 1.0

#define fbmAmount 0.5
#define fbmPower1 3.00
#define fbmPower2 2.50

#define Sky_Brightness 1.0
#define sky_coefficientRayleighR 5.8
#define sky_coefficientRayleighG 1.35
#define sky_coefficientRayleighB 3.31

vec3  WsunVec      = vec3(0.0, 1.0, 0.0);
float sunElevation = 1.0;

#endif
