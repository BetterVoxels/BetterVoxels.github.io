#ifndef INCLUDE_PHOTONICS
#define INCLUDE_PHOTONICS

#ifdef PHOTONICS_LIGHTING

/*
    How much of the lighting at a point Photonics is answering for.

    Nothing here traces anything. This is only the crossfade between two engines
    that both light block sources, and it exists because neither one covers the
    whole scene:

    - Photonics has to build its voxel structure before it has anything to
      trace against. photonicsMasterTimer is the engine's own readiness,
      smoothed in shaders.properties over fifteen seconds, so a world load
      brightens rather than snapping.
    - Its structure only extends so far. Past that edge there is no traced
      light at all, while this pack's voxel volume is still going, so the
      handover has to be a ramp in distance and not a boundary.
    - Far enough from the origin the mod's own coordinates stop being usable;
      photonicsOutsideRange reports that, and the pack takes the lighting back.

    Returns 1 where Photonics is fully responsible and 0 where this pack is.
    Everything that reads it fades toward PHOTONICS_VANILLA_LIGHT_FALLBACK
    rather than to zero, so voxel colour that Photonics has no notion of does
    not vanish along with the rest.
*/
float GetPhotonicsCoverage(vec3 playerPos) {
    #if PHOTONICS_MAX_ALLOWED_DISTANCE < 100
        float reach = min(max(far, 16.0), 16.0 * float(PHOTONICS_MAX_ALLOWED_DISTANCE));
    #else
        float reach = max(far, 16.0);
    #endif

    // Ramped over the last sixteen blocks of the reach rather than cut, since a
    // cut would draw a ring on the ground at exactly that radius.
    float coverage = clamp((reach - length(playerPos)) * (1.0 / 16.0), 0.0, 1.0);

    return coverage * photonicsMasterTimer * (1.0 - photonicsOutsideRange);
}

// The factor this pack's own block light is scaled by inside that coverage.
float GetPhotonicsLightHandover(float coverage) {
    return 1.0 - (1.0 - PHOTONICS_VANILLA_LIGHT_FALLBACK * 0.01) * coverage;
}

#endif

#endif
