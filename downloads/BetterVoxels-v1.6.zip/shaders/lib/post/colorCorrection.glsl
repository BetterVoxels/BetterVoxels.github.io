#if AUTO_EXPOSURE == 1
    #include "/lib/misc/autoExposure.glsl"
    #define BV_EXPOSURE (T_EXPOSURE * ccExposureI * bvAutoExposure())
#else
    #define BV_EXPOSURE (T_EXPOSURE * ccExposureI)
#endif

#include "/lib/colors/colorTemperature.glsl"

#ifndef INCLUDE_COLOR_CORRECTION
    #define INCLUDE_COLOR_CORRECTION

    #if CC_MODE == 0 || CC_MODE == 1
        const float ccModeSaturation = 0.07;
        const float ccModeCrosstalk  = 0.00;
        const float ccModeCurveLower = 0.00;
        const float ccModeCurveUpper = 0.00;
        const vec3  ccModeShadows    = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.00, 1.00, 1.00);
    #elif CC_MODE == 2

        const float ccModeSaturation = 0.00;
        const float ccModeCrosstalk  = 0.20;
        const float ccModeCurveLower = -0.10;
        const float ccModeCurveUpper = 0.10;
        const vec3  ccModeShadows    = vec3(0.98, 1.00, 1.06);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.05, 1.01, 0.96);
    #elif CC_MODE == 3

        const float ccModeSaturation = 0.15;
        const float ccModeCrosstalk  = 0.00;
        const float ccModeCurveLower = 0.00;
        const float ccModeCurveUpper = 0.00;
        const vec3  ccModeShadows    = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.00, 1.00, 1.00);
    #else
        const float ccModeSaturation = 0.00;
        const float ccModeCrosstalk  = 0.00;
        const float ccModeCurveLower = 0.00;
        const float ccModeCurveUpper = 0.00;
        const vec3  ccModeShadows    = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeMids       = vec3(1.00, 1.00, 1.00);
        const vec3  ccModeHighlights = vec3(1.00, 1.00, 1.00);
    #endif

    void ccLinearToRGB(inout vec3 color) {
        const vec3 k = vec3(0.055);
        color = mix((vec3(1.0) + k) * pow(color, vec3(1.0 / 2.4)) - k, 12.92 * color,
                    lessThan(color, vec3(0.0031308)));
    }


    void ccTonemapComplementary(inout vec3 color) {
        color = BV_EXPOSURE * color;

        float initialLuminance = GetLuminance(color);

        vec3 a      = vec3(TM_CONTRAST);
        vec3 d      = vec3(1.0);
        vec3 hdrMax = vec3(8.0);
        vec3 midIn  = vec3(0.25);
        vec3 midOut = vec3(0.25);

        vec3 a_d = a * d;
        vec3 hdrMaxA = pow(hdrMax, a);
        vec3 hdrMaxAD = pow(hdrMax, a_d);
        vec3 midInA = pow(midIn, a);
        vec3 midInAD = pow(midIn, a_d);
        vec3 HM1 = hdrMaxA * midOut;
        vec3 HM2 = hdrMaxAD - midInAD;

        vec3 b = (-midInA + HM1) / (HM2 * midOut);
        vec3 c = (hdrMaxAD * midInA - HM1 * midInAD) / (HM2 * midOut);

        vec3 colorOut = pow(color, a) / (pow(color, a_d) * b + c);

        ccLinearToRGB(colorOut);

        const float darkLiftStart = 0.1;
        const float darkLiftMix = 0.75;
        float darkLift = smoothstep(darkLiftStart, 0.0, initialLuminance);
        vec3 smoothColor = pow(color, vec3(1.0 / 2.2));
        colorOut = mix(colorOut, smoothColor,
                       darkLift * darkLiftMix * max(0.55 - abs(1.05 - TM_CONTRAST), 0.0) / 0.55);

        const float wpInputCurveStart = 0.0;
        const float wpInputCurveMax = 16.0;
        float modifiedLuminance = pow(initialLuminance / wpInputCurveMax, 2.0 - TM_WHITE_PATH) * wpInputCurveMax;
        float whitePath = smoothstep(wpInputCurveStart, wpInputCurveMax, modifiedLuminance);
        colorOut = mix(colorOut, vec3(1.0), whitePath);

        const float dpInputCurveStart = 0.1;
        const float dpInputCurveMax = 0.0;
        float desaturatePath = smoothstep(dpInputCurveStart, dpInputCurveMax, initialLuminance);
        colorOut = mix(colorOut, vec3(GetLuminance(colorOut)), desaturatePath * TM_DARK_DESATURATION);

        color = clamp01(colorOut);
    }

    // Default now carries what this pack shipped as Complementary: the same
    // Lottes curve with one extra gamma pass on top. That pass is the whole
    // difference - it is what lifts the brightness and saturation - and the
    // mode above is the original with nothing added. Applying it after the
    // clamp is identical, since the curve is a power on an already clamped
    // range and anything above one was being clamped either way.
    void ccTonemapDefault(inout vec3 color) {
        ccTonemapComplementary(color);
        color = pow(color, mix(vec3(T_LOWER_CURVE - 0.10), vec3(T_UPPER_CURVE - 0.30), sqrt(color)));
    }

    vec3 ccAgxContrastApprox(vec3 x) {
        vec3 x2 = x * x;
        vec3 x4 = x2 * x2;

        return + 15.5 * x4 * x2
            - 40.14 * x4 * x
            + 31.96 * x4
            - 6.868 * x2 * x
            + 0.4298 * x2
            + 0.1191 * x
            - 0.00232;
    }

    vec3 ccAgxLook(vec3 val) {
        const vec3 lw = vec3(0.2126, 0.7152, 0.0722);
        float luma = dot(val, lw);
        const float sat = 1.25;

        return luma + sat * (val - luma);
    }

    void ccTonemapRealistic(inout vec3 color) {

        const mat3 agxInset = mat3(
            0.842479062253094, 0.0423282422610123, 0.0423756549057051,
            0.0784335999999992, 0.878468636469772, 0.0784336,
            0.0792237451477643, 0.0791661274605434, 0.879142973793104);

        const mat3 agxOutset = mat3(
            1.19687900512017, -0.0528968517574562, -0.0529716355144438,
            -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
            -0.0990297440797205, -0.0989611768448433, 1.15107367264116);

        const float agxMinEv = -12.47393;
        const float agxMaxEv = 4.026069;

        color = max(BV_EXPOSURE * color, vec3(0.0));

        #if CC_EMITTER_CHROMA > 0

            vec3  preAgx = color;
            float preLum = max(GetLuminance(preAgx), 0.0001);
            float preMax = max(preAgx.r, max(preAgx.g, preAgx.b));
            float preSat = (preMax - min(preAgx.r, min(preAgx.g, preAgx.b))) / max(preMax, 0.0001);
        #endif

        color = agxInset * color;

        color = clamp(log2(color), agxMinEv, agxMaxEv);
        color = (color - agxMinEv) / (agxMaxEv - agxMinEv);

        color = ccAgxContrastApprox(color);
        color = ccAgxLook(color);

        color = agxOutset * color;

        color = clamp01(color);

        #if CC_EMITTER_CHROMA > 0

            float outMax = max(color.r, max(color.g, color.b));
            float outSat = (outMax - min(color.r, min(color.g, color.b))) / max(outMax, 0.0001);

            float chromaLoss = clamp01((preSat - outSat) * 3.0);
            float emitter    = chromaLoss * smoothstep(0.5, 2.0, preLum);

            if (emitter > 0.0) {

                vec3 restored = clamp01(preAgx * (GetLuminance(color) / preLum));
                color = mix(color, restored, emitter * CC_EMITTER_CHROMA * 0.01);
            }
        #endif
    }

    //     [-12.474, +4.026] -- a full stop narrower at the bottom and 0.8 at

    void ccTonemapVivid(inout vec3 color) {
        const mat3 agxInset = mat3(
            0.842479062253094, 0.0423282422610123, 0.0423756549057051,
            0.0784335999999992, 0.878468636469772, 0.0784336,
            0.0792237451477643, 0.0791661274605434, 0.879142973793104);

        const mat3 agxOutset = mat3(
            1.19687900512017, -0.0528968517574562, -0.0529716355144438,
            -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
            -0.0990297440797205, -0.0989611768448433, 1.15107367264116);

        const float agxMinEv = -11.47393;
        const float agxMaxEv = 3.226069;

        color = max(BV_EXPOSURE * color, vec3(0.0));

        color = agxInset * color;
        color = clamp(log2(color), agxMinEv, agxMaxEv);
        color = (color - agxMinEv) / (agxMaxEv - agxMinEv);

        color = ccAgxContrastApprox(color);
        color = ccAgxLook(color);

        color = agxOutset * color;

        color = pow(clamp01(color), vec3(2.2));
        ccLinearToRGB(color);
        color = clamp01(color);
    }

    #if (CC_MODE == 2 || CC_MODE == 3) && CC_SKY_CHROMA > 0

        void ccRestoreSkyChroma(inout vec3 color, vec3 preTonemap, float skyUp) {

            float cool = clamp01((preTonemap.b - preTonemap.r)
                              / max(preTonemap.b, 0.0001));
            float amount = CC_SKY_CHROMA * 0.01
                         * smoothstep(0.05, 0.35, cool)
                         * smoothstep(0.0, 0.45, skyUp);
            if (amount <= 0.0) return;

            float preLum = max(GetLuminance(preTonemap), 0.0001);
            vec3 restored = clamp01(preTonemap * (GetLuminance(color) / preLum));
            color = mix(color, restored, amount);
        }
    #endif

    void DoTonemap(inout vec3 color) {
        #if CC_WHITE_BALANCE != 6500

            color *= ccBlackbody(float(CC_WHITE_BALANCE));
        #endif
        #if CC_MODE == 1
            ccTonemapComplementary(color);
        #elif CC_MODE == 2
            ccTonemapRealistic(color);
        #elif CC_MODE == 3
            ccTonemapVivid(color);
        #else
            ccTonemapDefault(color);
        #endif
    }

    float ccLowerCurve(float x) {
        return clamp(16.0 * x * (0.5 - x) * 0.1, 0.0, 1.0);
    }

    float ccUpperCurve(float x) {
        return clamp(16.0 * (0.5 - x) * (x - 1.0) * 0.1, 0.0, 1.0);
    }

    vec3 ccGradeTarget(vec3 t) {
        float len = length(t);
        return len < 0.001 ? vec3(0.0) : t * (1.7320508076 / len);
    }

    void DoColorGrade(inout vec3 color) {

        float saturationFactor = T_SATURATION * CC_SATURATION + ccModeSaturation;

        float grayVibrance = (color.r + color.g + color.b) / 3.0;
        float graySaturation = grayVibrance;
        if (saturationFactor < 1.00) graySaturation = dot(color, vec3(0.299, 0.587, 0.114));

        float mn = min(color.r, min(color.g, color.b));
        float mx = max(color.r, max(color.g, color.b));
        float sat = (1.0 - (mx - mn)) * (1.0 - mx) * grayVibrance * 5.0;
        vec3 lightness = vec3((mn + mx) * 0.5);

        color = mix(color, mix(color, lightness, 1.0 - T_VIBRANCE), sat);
        color = mix(color, lightness, (1.0 - lightness) * (2.0 - T_VIBRANCE) / 2.0 * abs(T_VIBRANCE - 1.0));
        color = color * saturationFactor - graySaturation * (saturationFactor - 1.0);

        float crosstalk = CC_CROSSTALK + ccModeCrosstalk;
        if (crosstalk != 0.0) {
            float luminance = GetLuminance(color);
            color += (color - luminance) * (-luminance * crosstalk);
        }

        float contrast = CC_CONTRAST - 1.0;
        float curveLower = ccModeCurveLower + CC_CURVE_LOWER - contrast;
        float curveUpper = ccModeCurveUpper + CC_CURVE_UPPER + contrast;
        if (curveLower != 0.0 || curveUpper != 0.0) {
            color.r += curveLower * ccLowerCurve(color.r) + curveUpper * ccUpperCurve(color.r);
            color.g += curveLower * ccLowerCurve(color.g) + curveUpper * ccUpperCurve(color.g);
            color.b += curveLower * ccLowerCurve(color.b) + curveUpper * ccUpperCurve(color.b);
        }

        color *= CC_BRIGHTNESS;

        vec3 shadowTint = vec3(CC_SHADOW_R, CC_SHADOW_G, CC_SHADOW_B) * ccModeShadows;
        vec3 midTint    = vec3(CC_MID_R,    CC_MID_G,    CC_MID_B)    * ccModeMids;
        vec3 highTint   = vec3(CC_HIGH_R,   CC_HIGH_G,   CC_HIGH_B)   * ccModeHighlights;

        float gradeLuma = dot(color, vec3(1.0 / 3.0));
        float shadowsAmount    = clamp(-6.0 * gradeLuma + 2.75, 0.0, 1.0);
        float midsAmount       = clamp(-abs(6.0 * gradeLuma - 3.0) + 1.25, 0.0, 1.0);
        float highlightsAmount = clamp(6.0 * gradeLuma - 3.25, 0.0, 1.0);

        color = color * (ccGradeTarget(shadowTint) * (CC_SHADOW_I * shadowsAmount)
                       + ccGradeTarget(midTint)    * (CC_MID_I    * midsAmount)
                       + ccGradeTarget(highTint)   * (CC_HIGH_I   * highlightsAmount));
    }

#endif
