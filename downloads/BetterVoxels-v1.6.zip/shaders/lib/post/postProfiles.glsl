#ifndef INCLUDE_POST_PROFILES
#define INCLUDE_POST_PROFILES

#if POST_PROFILE == 1

    #define PPP_BODYCAM           1
    #define PPP_BC_BRIGHTNESS     -0.40
    #define PPP_BC_DISTORTION     1.15
    #define PPP_UNDERWATER_BLUR   75
    #define PPP_PINKFROG_LEVEL    12
    #define PPP_PINKFROG_R        1.0
    #define PPP_PINKFROG_G        1.0
    #define PPP_YELLOWFROG_LEVEL  12
    #define PPP_YELLOWFROG_G      1.0
    #define PPP_YELLOWFROG_B      1.0
    #define PPP_GREENFROG_LEVEL   12
    #define PPP_GREENFROG_R       1.0
    #define PPP_GREENFROG_B       1.0
#elif POST_PROFILE == 2

    #define PPP_UNDERWATER_BLUR   50
#elif POST_PROFILE == 3

    #define PPP_RETRO_COLOR_DEPTH 1
    #define PPP_RETRO_MONOCHROME  1
#elif POST_PROFILE == 4

    #define PPP_RETRO_PIXELATE    1

    // Not routed through a PPP override: these three are plain booleans tested
    // with #ifdef, and this file is read at the top of common.glsl, before the
    // lines that declare them. Defining them here simply gets there first, and
    // if the option is also switched on by hand the second definition is
    // identical and harmless.
    #define PIXELATED_AO
    #define PIXELATED_BLOCKLIGHT
    #define PIXELATED_SHADOWS
#endif

#endif
