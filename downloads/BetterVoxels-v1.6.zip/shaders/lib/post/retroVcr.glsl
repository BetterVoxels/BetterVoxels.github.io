
#ifndef INCLUDE_RETRO_VCR
#define INCLUDE_RETRO_VCR

// Every setting below defaults to the value that was hardcoded before it
// existed, so turning a mode on and leaving its submenu alone reproduces
// exactly what it did previously. Anything genuinely new is off at its default.

#define PP_CRT_CURVATURE 0      //[0 1]
#define PP_CRT_CURVE_I 5        //[1 2 3 4 5 6 8 10 13 16 20 25 30]
#define PP_CRT_CURVE_ZOOM 100   //[0 25 50 75 100 125 150 175 200]
#define PP_CRT_CURVE_POWER 2    //[1 2 3 4 6]
#define PP_CRT_CURVE_ASPECT 100 //[0 25 50 75 100 125 150 200]
#define PP_CRT_CURVE_SHIFT 0    //[-20 -15 -10 -5 0 5 10 15 20]
#define PP_CRT_CURVE_MASK 0     //[0 10 25 50 75 100]
#define PP_CRT_CURVE_MASK_SOFT 20 //[0 5 10 20 35 50 75 100]

#define PP_VHS_ABERRATION 0     //[0 1]
#define PP_VHS_AB_SIZE 100      //[10 20 30 40 50 65 80 100 125 150 200 250 300]
#define PP_VHS_AB_DRIFT 100     //[0 25 50 75 100 150 200 300]
#define PP_VHS_AB_SPEED 100     //[10 25 50 100 200 400 800]
#define PP_VHS_AB_EDGE 0        //[0 25 50 75 100 150 200]
#define PP_VHS_AB_RED 100       //[0 25 50 75 100 150 200]
#define PP_VHS_AB_BLUE 100      //[0 25 50 75 100 150 200]
#define PP_VHS_AB_BLEND 100     //[10 25 50 75 100]

#define PP_CRT_SCANLINES 0      //[0 1]
#define PP_CRT_SCAN_I 25        //[5 10 15 20 25 30 40 50 60 75]
#define PP_CRT_SCAN_STEP 2      //[2 3 4 6 8]
#define PP_CRT_SCAN_SOFT 0      //[0 25 50 75 100]
#define PP_CRT_SCAN_ROLL 0      //[0 10 25 50 100 200 400]
#define PP_CRT_SCAN_GAIN 100    //[50 75 90 100 110 125 150 200]
#define PP_CRT_SCAN_MASK 0      //[0 10 25 50 75 100]
#define PP_CRT_SCAN_MASK_STEP 3 //[2 3 4 6]

#define PP_VHS_NOISE 0          //[0 1]
#define PP_VHS_NOISE_I 100      //[10 25 50 75 100 150 200 300 500 800]
#define PP_VHS_NOISE_BRIGHT 100 //[10 25 50 75 100 150 200 300]
#define PP_VHS_NOISE_SPEED 100  //[10 25 50 100 200 400 800]
#define PP_VHS_NOISE_SIZE 1     //[1 2 3 4 6 8 12]
#define PP_VHS_NOISE_TINT 0     //[0 25 50 75 100]
#define PP_VHS_NOISE_DARK 0     //[0 25 50 75 100]
#define PP_VHS_NOISE_EDGE 0     //[0 25 50 75 100 150 200]

#define PP_CRT_VIGNETTE 0       //[0 1]
#define PP_CRT_VIG_I 100        //[10 25 50 75 100 125 150 200]
#define PP_CRT_VIG_SIZE 100     //[25 50 75 100 125 150 200 300]
#define PP_CRT_VIG_VERTICAL 0   //[0 25 50 75 100 150 200]
#define PP_CRT_VIG_POWER 100    //[25 50 75 100 150 200 300]
#define PP_CRT_VIG_NOISE 100    //[0 25 50 75 100 150 200 300]
#define PP_CRT_VIG_TINT 0       //[0 1 2 3]
#define PP_CRT_VIG_TINT_I 50    //[0 25 50 75 100]

#define PP_VHS_TAPE_DISTORTION 0 //[0 1]
#define PP_VHS_TEAR_SIZE 8      //[1 2 3 5 8 12 16 22 30]
#define PP_VHS_TEAR_SPEED 130   //[10 25 50 80 130 200 300 400]
#define PP_VHS_TEAR_SHIFT 0     //[0 5 10 20 35 50 75 100]
#define PP_VHS_TEAR_COUNT 1     //[1 2 3 4 6]
#define PP_VHS_TEAR_JITTER 0    //[0 25 50 75 100]
#define PP_VHS_TEAR_WOBBLE 0    //[0 10 25 50 75 100]
#define PP_VHS_TEAR_WOBBLE_SPEED 100 //[10 25 50 100 200 400]

#define PP_CRT_BLOOM 0          //[0 1]
#define PP_CRT_GLOW_I 50        //[0 10 20 30 40 50 65 80 100]
#define PP_CRT_GLOW_RADIUS 40   //[5 10 20 30 40 60 80 110 150]
#define PP_CRT_GLOW_THRESHOLD 0 //[0 10 25 40 55 70 85]
#define PP_CRT_GLOW_GAIN 100    //[10 25 50 75 100 150 200 300 400]
#define PP_CRT_GLOW_TINT 0      //[0 1 2 3]
#define PP_CRT_GLOW_JITTER 100  //[0 25 50 75 100 150 200]
#define PP_CRT_GLOW_STEPS 6     //[2 3 4 6 8 12]

#define PP_VHS_TRACKING 0       //[0 1]
#define PP_VHS_TRACK_SIZE 40    //[5 10 20 40 70 100 150 200]
#define PP_VHS_TRACK_FADE 50    //[5 15 30 50 80 120 200]
#define PP_VHS_TRACK_RATE 100   //[10 25 50 100 200 400 800]
#define PP_VHS_TRACK_SHIFT 0    //[0 5 10 20 35 50 75 100]
#define PP_VHS_TRACK_BRIGHT 100 //[10 25 50 75 100 150 200 300]
#define PP_VHS_TRACK_DRIFT 0    //[0 25 50 75 100 150 200]
#define PP_VHS_TRACK_COUNT 1    //[1 2 3 4]

#define PP_RETRO_PIXELATE 0     //[0 1]
#ifdef PPP_RETRO_PIXELATE
    #define PPX_RETRO_PIXELATE PPP_RETRO_PIXELATE
#else
    #define PPX_RETRO_PIXELATE PP_RETRO_PIXELATE
#endif
#define PP_RETRO_PIXEL_SIZE 4   //[2 3 4 6 8 12 16 24 32]
#define PP_RETRO_PIXEL_ASPECT 100 //[50 75 100 150 200 300]
#define PP_RETRO_PIXEL_GRID 0   //[0 10 25 50 75 100]
#define PP_RETRO_PIXEL_GRID_W 20 //[5 10 15 20 30 40 50]
#define PP_RETRO_PIXEL_GRID_TINT 0 //[0 1 2 3]
#define PP_RETRO_PIXEL_SCANLINE 0 //[0 10 25 50 75 100]
#define PP_RETRO_PIXEL_GAIN 100 //[50 75 100 125 150 200]

#define PP_VHS_GRAIN 0          //[0 1]
#define PP_VHS_GRAIN_I 30       //[5 10 20 30 45 60 80 110 150]
#define PP_VHS_GRAIN_SPEED 100  //[10 25 50 100 200 400 800]
#define PP_VHS_GRAIN_SIZE 1     //[1 2 3 4 6 8 12]
#define PP_VHS_GRAIN_SHADOW 100 //[0 25 50 75 100 150 200 300]
#define PP_VHS_GRAIN_HIGHLIGHT 100 //[0 25 50 75 100 150 200 300]
#define PP_VHS_GRAIN_TINT 0     //[0 25 50 75 100]
#define PP_VHS_GRAIN_STATIC 0   //[0 1]

#define PP_RETRO_COLOR_DEPTH 0  //[0 1]
#ifdef PPP_RETRO_COLOR_DEPTH
    #define PPX_RETRO_COLOR_DEPTH PPP_RETRO_COLOR_DEPTH
#else
    #define PPX_RETRO_COLOR_DEPTH PP_RETRO_COLOR_DEPTH
#endif
#define PP_RETRO_LEVELS 32      //[2 3 4 6 8 12 16 24 32 48 64 128]
#define PP_RETRO_DITHER 100     //[0 25 50 75 100 150 200]
#define PP_RETRO_LEVELS_R 100   //[25 50 75 100 150 200 300]
#define PP_RETRO_LEVELS_G 100   //[25 50 75 100 150 200 300]
#define PP_RETRO_LEVELS_B 100   //[25 50 75 100 150 200 300]
#define PP_RETRO_DITHER_SIZE 4  //[2 4 8]
#define PP_RETRO_DEPTH_GAMMA 100 //[50 75 100 150 200 250]

#define PP_RETRO_MONOCHROME 0   //[0 1]
#ifdef PPP_RETRO_MONOCHROME
    #define PPX_RETRO_MONOCHROME PPP_RETRO_MONOCHROME
#else
    #define PPX_RETRO_MONOCHROME PP_RETRO_MONOCHROME
#endif
#define PP_RETRO_MONO_TINT 0    //[0 1 2 3]
#define PP_RETRO_MONO_I 100     //[10 25 50 75 100]
#define PP_RETRO_MONO_R 33      //[0 10 20 33 50 75 100]
#define PP_RETRO_MONO_G 33      //[0 10 20 33 50 75 100]
#define PP_RETRO_MONO_B 33      //[0 10 20 33 50 75 100]
#define PP_RETRO_MONO_CONTRAST 100 //[25 50 75 100 150 200 300]
#define PP_RETRO_MONO_LIFT 0    //[0 5 10 20 30 50]

/*
    Retro Camera, the half of it that lives in this file.

    Here rather than in common.glsl with the rest of the profile because every
    option below is declared in THIS file: Iris substitutes the chosen value at
    the declaration line, so an override written anywhere above one is quietly
    overwritten by it a moment later. This sits after the last declaration and
    before the first line that reads any of them.

    Grain is turned down to the bottom of its range - the tape effects stack,
    and at their defaults the noise buries the picture rather than sitting on it.
*/
#if POST_PROFILE == 6
    #undef PP_CRT_CURVATURE
    #define PP_CRT_CURVATURE 1
    #undef PP_CRT_VIGNETTE
    #define PP_CRT_VIGNETTE 1
    #undef PP_CRT_BLOOM
    #define PP_CRT_BLOOM 1

    #undef PP_VHS_ABERRATION
    #define PP_VHS_ABERRATION 1
    #undef PP_VHS_NOISE
    #define PP_VHS_NOISE 1
    #undef PP_VHS_TAPE_DISTORTION
    #define PP_VHS_TAPE_DISTORTION 1
    #undef PP_VHS_GRAIN
    #define PP_VHS_GRAIN 1
    #undef PP_VHS_GRAIN_I
    #define PP_VHS_GRAIN_I 5

    #undef PP_RETRO_COLOR_DEPTH
    #define PP_RETRO_COLOR_DEPTH 1
#endif

#if PP_VHS_ABERRATION == 1 || PP_CRT_SCANLINES == 1 || PP_VHS_NOISE == 1 || PP_CRT_VIGNETTE == 1 || PP_CRT_BLOOM == 1 || PP_VHS_TRACKING == 1 || PP_VHS_GRAIN == 1 || PPX_RETRO_COLOR_DEPTH == 1 || PPX_RETRO_MONOCHROME == 1 || PP_CRT_CURVATURE == 1 && PP_CRT_CURVE_MASK > 0 || PPX_RETRO_PIXELATE == 1 && (PP_RETRO_PIXEL_GRID > 0 || PP_RETRO_PIXEL_SCANLINE > 0)
    #define PP_RETRO_COLOR_STAGE
#endif

float ppRandom(vec2 seed) {
    return fract(sin(dot(seed, vec2(12.9898, 78.233))) * 43758.5453123);
}
float ppHash(vec2 p, float t) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y + t);
}

// The three phosphor tints are shared by every mode that offers a colour
// choice, so a green monitor stays the same green whichever knob picked it.
vec3 ppTintOf(int mode) {
    if (mode == 1) return vec3(0.35, 1.00, 0.42);
    if (mode == 2) return vec3(1.00, 0.72, 0.30);
    if (mode == 3) return vec3(0.45, 0.72, 1.00);
    return vec3(1.0);
}

#if PPX_RETRO_COLOR_DEPTH == 1

    float ppDither4(vec2 p) {
        ivec2 ip = ivec2(mod(p * vec2(viewWidth, viewHeight), 4.0));
        ivec4 ppRow;
        if (ip.y == 0)      ppRow = ivec4( 0,  8,  2, 10);
        else if (ip.y == 1) ppRow = ivec4(12,  4, 14,  6);
        else if (ip.y == 2) ppRow = ivec4( 3, 11,  1,  9);
        else                ppRow = ivec4(15,  7, 13,  5);
        return float(ppRow[ip.x]) / 16.0;
    }

    // A 2x2 grid is coarse and obvious, an 8x8 one nearly invisible; the 4x4
    // above is the classic. The other two are built from a hash so the file
    // does not have to carry three tables.
    float ppDitherN(vec2 p) {
        #if PP_RETRO_DITHER_SIZE == 4
            return ppDither4(p);
        #else
            float n = float(PP_RETRO_DITHER_SIZE);
            vec2 ip = floor(mod(p * vec2(viewWidth, viewHeight), n));
            return fract(ppRandom(ip * 0.0173 + 0.5) + (ip.x + ip.y) / n);
        #endif
    }
#endif

vec2 RetroPostUV(vec2 uv) {
    #if PP_CRT_CURVATURE == 1

        // Power is the shape of the bulge - squared is a tube face, higher
        // keeps the middle flat and bends only near the rim. Aspect splits it
        // between the two axes, since a real tube is not equally round both
        // ways. The zoom in front keeps the bulged corners inside the frame;
        // past 100 it crops, the way a tube's mask does.
        float ppCurve = PP_CRT_CURVE_I * 0.01;
        vec2 ppDir = uv - vec2(0.5, 0.5 + PP_CRT_CURVE_SHIFT * 0.01);
        float ppDist = length(ppDir);
        float ppBend = ppDist;
        for (int i = 1; i < PP_CRT_CURVE_POWER; i++) ppBend *= ppDist;
        float ppDistortion = 1.0 + ppCurve * ppBend;
        vec2 ppAxis = vec2(PP_CRT_CURVE_ASPECT * 0.01, 1.0);
        ppDir *= mix(vec2(1.0), vec2(ppDistortion), ppAxis);
        uv = vec2(0.5, 0.5 + PP_CRT_CURVE_SHIFT * 0.01) + ppDir * (1.0 - ppCurve / 3.0 * (PP_CRT_CURVE_ZOOM * 0.01));
    #endif
    #if PP_VHS_TAPE_DISTORTION == 1

        // Several bands can roll at once, each offset along the same clock, and
        // jitter breaks the regularity so it stops reading as a metronome.
        float ppTearSize = PP_VHS_TEAR_SIZE * 0.01;
        float ppTearTime = mod(frameTimeCounter, 8192.0);

        #if PP_VHS_TEAR_WOBBLE > 0
            uv.x += sin(ppTearTime * (PP_VHS_TEAR_WOBBLE_SPEED * 0.01) * 3.7 + uv.y * 24.0)
                  * (PP_VHS_TEAR_WOBBLE * 0.0004);
        #endif

        for (int ppT = 0; ppT < PP_VHS_TEAR_COUNT; ppT++) {
            float ppSeed = float(ppT) * 37.13;
            float ppJit = 1.0;
            #if PP_VHS_TEAR_JITTER > 0
                ppJit = 1.0 + (ppRandom(vec2(floor(ppTearTime * 2.0) + ppSeed, 3.0)) - 0.5)
                            * (PP_VHS_TEAR_JITTER * 0.02);
            #endif
            float ppY1 = mod((PP_VHS_TEAR_SPEED * 0.01) * ppJit * ppTearTime + ppTearSize + ppSeed,
                             100.0 + ppTearSize);
            float ppY2 = uv.y - ppY1;
            if (ppY2 < 0.0 && ppY2 > -ppTearSize) {
                uv.y = fract(ppY1);
                #if PP_VHS_TEAR_SHIFT > 0
                    uv.x = fract(uv.x + (ppRandom(vec2(floor(ppTearTime * 8.0) + ppSeed, 7.0)) - 0.5)
                                      * (PP_VHS_TEAR_SHIFT * 0.01));
                #endif
            }
        }
    #endif
    #if PPX_RETRO_PIXELATE == 1

        vec2 ppRes = vec2(viewWidth, viewHeight);
        vec2 ppBlock = float(PP_RETRO_PIXEL_SIZE) * vec2(PP_RETRO_PIXEL_ASPECT * 0.01, 1.0);
        uv -= mod(uv, ppBlock / ppRes);
    #endif
    return uv;
}

void ApplyRetroVcr(inout vec3 color, sampler2D src, vec2 uv, vec2 uvRaw) {
    #ifdef PP_RETRO_COLOR_STAGE
        float ppTime = mod(frameTimeCounter, 8192.0);
        float ppTime8 = mod(frameTimeCounter * 7.987, 8192.0);
        float ppV = ppHash(uvRaw, ppTime8);
        float ppV2 = ppHash(uvRaw, ppTime8 + 456.789);

        #if PP_CRT_BLOOM == 1

            // Threshold decides what is bright enough to glow at all, gain how
            // hard what passes it burns, and steps how many rings of samples
            // the halo is built from.
            float ppGlowR = PP_CRT_GLOW_RADIUS * 0.0001;
            float ppGlowJ = PP_CRT_GLOW_JITTER * 0.01;
            vec3 ppSum = vec3(0.0);
            for (int i = -PP_CRT_GLOW_STEPS / 2; i < PP_CRT_GLOW_STEPS / 2; i++) {
                float ppI3 = float(i) * 3.0;
                float ppV3 = (0.5 - ppRandom(uv + vec2(1.0 + ppI3, 0.0) + ppTime)) * ppGlowJ + float(i);
                float ppV4 = (0.5 - ppRandom(uv + vec2(2.0 + ppI3, 0.0) + (ppTime + 100.2))) * ppGlowJ;
                float ppV5 = (0.5 - ppRandom(uv + vec2(3.0 + ppI3, 0.0) + (ppTime + 200.5))) * ppGlowJ;
                ppSum += texture2D(src, uv + vec2(-1.0 + ppV4, ppV3) * ppGlowR).rgb * 0.009;
                ppSum += texture2D(src, uv + vec2(ppV5, ppV3) * ppGlowR).rgb * 0.009;
                ppSum += texture2D(src, uv + vec2(1.0 + ppV5, ppV3) * ppGlowR).rgb * 0.009;
            }
            #if PP_CRT_GLOW_THRESHOLD > 0
                ppSum = max(ppSum - PP_CRT_GLOW_THRESHOLD * 0.01, vec3(0.0));
            #endif
            #if PP_CRT_GLOW_TINT > 0
                ppSum *= ppTintOf(PP_CRT_GLOW_TINT);
            #endif
            float ppGlowG = PP_CRT_GLOW_GAIN * 0.01;
            vec3 ppBloom;
            if (color.r < 0.3 && color.g < 0.3 && color.b < 0.3)      ppBloom = ppSum * ppSum * (0.012 * ppGlowG) + color;
            else if (color.r < 0.5 && color.g < 0.5 && color.b < 0.5) ppBloom = ppSum * ppSum * (0.009 * ppGlowG) + color;
            else                                                      ppBloom = ppSum * ppSum * (0.0075 * ppGlowG) + color;
            color = mix(color, ppBloom, PP_CRT_GLOW_I * 0.01);
        #endif

        #if PP_VHS_ABERRATION == 1

            // Size is how far the channels part, drift how much of that parting
            // runs vertically, and edge bias makes the split grow towards the
            // rim the way a real lens does rather than sitting flat everywhere.
            float ppAbV = ppHash(uvRaw, mod(frameTimeCounter * 7.987 * (PP_VHS_AB_SPEED * 0.01), 8192.0));
            float ppBSize = 0.01 * (PP_VHS_AB_SIZE * 0.01);
            #if PP_VHS_AB_EDGE > 0
                ppBSize *= 1.0 + length(uvRaw - 0.5) * 2.0 * (PP_VHS_AB_EDGE * 0.01);
            #endif
            float ppDrift = PP_VHS_AB_DRIFT * 0.01;
            float ppVS = ppAbV * ppBSize;
            float ppVHalf = ppVS * 0.5;
            float ppRedS = ppVS * (PP_VHS_AB_RED * 0.01);
            float ppBlueS = ppVS * (PP_VHS_AB_BLUE * 0.01);
            vec3 ppLeft1  = texture2D(src, vec2(uv.x - ppRedS,  uv.y + ppVS / 3.0 * ppDrift)).rgb;
            vec3 ppLeft2  = texture2D(src, vec2(uv.x - ppVHalf * (PP_VHS_AB_RED * 0.01) + ppLeft1.r * ppBSize * 0.25, uv.y + ppVS / 6.0 * ppDrift)).rgb;
            vec3 ppRight1 = texture2D(src, vec2(uv.x + ppBlueS, uv.y + ppVS * ppDrift)).rgb;
            float ppRO = ppVHalf * (PP_VHS_AB_BLUE * 0.01) - ppRight1.r * ppBSize * 0.25;
            vec3 ppRight2 = texture2D(src, vec2(uv.x + ppRO, uv.y + ppRO * ppDrift)).rgb;
            vec3 ppSplit = vec3((ppLeft1.r + ppLeft2.r + color.r) / 3.0,
                                color.g,
                                (ppRight1.b + ppRight2.b + color.b) / 3.0);
            color = mix(color, ppSplit, PP_VHS_AB_BLEND * 0.01);
        #endif

        #if PP_VHS_GRAIN == 1

            // Grain that sits equally on shadows and highlights reads as a
            // filter; real stock carries it in the mid tones and shadows, which
            // is what the two weights below are for.
            #if PP_VHS_GRAIN_STATIC == 1
                float ppGrainT = 0.0;
            #else
                float ppGrainT = mod(frameTimeCounter * 7.987 * (PP_VHS_GRAIN_SPEED * 0.01), 8192.0);
            #endif
            vec2 ppGrainUv = floor(uvRaw * vec2(viewWidth, viewHeight) / float(PP_VHS_GRAIN_SIZE));
            float ppGrainV = ppHash(ppGrainUv * 0.01, ppGrainT);
            float ppGrainLum = dot(color, vec3(0.2125, 0.7154, 0.0721));
            float ppGrainW = mix(PP_VHS_GRAIN_SHADOW * 0.01, PP_VHS_GRAIN_HIGHLIGHT * 0.01,
                                 clamp(ppGrainLum, 0.0, 1.0));
            vec3 ppGrainC = vec3(0.5 - ppGrainV);
            #if PP_VHS_GRAIN_TINT > 0
                ppGrainC = mix(ppGrainC, vec3(0.5 - ppGrainV,
                                              0.5 - ppHash(ppGrainUv * 0.01 + 11.0, ppGrainT),
                                              0.5 - ppHash(ppGrainUv * 0.01 + 23.0, ppGrainT)),
                               PP_VHS_GRAIN_TINT * 0.01);
            #endif
            color += color * ppGrainC * (PP_VHS_GRAIN_I * 0.01) * ppGrainW;
        #endif

        #if PP_VHS_NOISE == 1 || PP_VHS_TRACKING == 1
            #if PP_VHS_NOISE == 1
                vec2 ppNoiseUv = floor(uvRaw * vec2(viewWidth, viewHeight) / float(PP_VHS_NOISE_SIZE)) * 0.01;
                float ppNoiseV = ppHash(ppNoiseUv, mod(frameTimeCounter * 7.987 * (PP_VHS_NOISE_SPEED * 0.01), 8192.0));
                float ppStatic = 0.00001 * PP_VHS_NOISE_I;
                #if PP_VHS_NOISE_EDGE > 0
                    ppStatic *= 1.0 + length(uvRaw - 0.5) * 2.0 * (PP_VHS_NOISE_EDGE * 0.01);
                #endif
            #else
                float ppNoiseV = ppV;
                float ppStatic = 0.0;
            #endif
            #if PP_VHS_TRACKING == 1
                // Size is how tall the rolling band is, fade how sharply it dies
                // out from its middle - a wide band with a slow fade is a tape
                // fault, a narrow one with a fast fade a single dropout.
                for (int ppK = 0; ppK < PP_VHS_TRACK_COUNT; ppK++) {
                    float ppRowT = floor(ppTime * (PP_VHS_TRACK_RATE * 0.01)) + float(ppK) * 17.0;
                    float ppVRow = ppRandom(vec2(ppRowT, 0.0));
                    #if PP_VHS_TRACK_DRIFT > 0
                        ppVRow = fract(ppVRow + ppTime * (PP_VHS_TRACK_DRIFT * 0.002));
                    #endif
                    float ppL = abs(ppVRow - uv.y) * 0.75;
                    if (ppL < 0.0001 * PP_VHS_TRACK_SIZE * ppNoiseV)
                        ppStatic = max(ppStatic, 1.0 - min(ppL, 0.05 * ppNoiseV) * float(PP_VHS_TRACK_FADE) / max(ppNoiseV, 0.0001));
                }
                ppStatic *= PP_VHS_TRACK_BRIGHT * 0.01;
                #if PP_VHS_TRACK_SHIFT > 0
                    if (ppStatic > 0.001) {
                        color = texture2D(src, vec2(fract(uv.x + (ppV2 - 0.5) * ppStatic * (PP_VHS_TRACK_SHIFT * 0.01)), uv.y)).rgb;
                    }
                #endif
            #endif
            if (ppNoiseV < ppStatic) {
                float ppSV = (ppStatic + 0.5) * ppV2 * (PP_VHS_NOISE_BRIGHT * 0.01);
                vec3 ppSpeck = vec3(ppSV);
                #if PP_VHS_NOISE_TINT > 0
                    ppSpeck = mix(ppSpeck, vec3(ppSV * ppV2, ppSV * ppV, ppSV * fract(ppV + ppV2)),
                                  PP_VHS_NOISE_TINT * 0.01);
                #endif
                color = (color + ppSpeck) * (1.0 - ppStatic) + vec3(ppNoiseV * ppStatic);
                #if PP_VHS_NOISE_DARK > 0
                    if (ppV2 < 0.5) color *= 1.0 - (PP_VHS_NOISE_DARK * 0.01) * ppStatic;
                #endif
            }
        #endif

        #if PPX_RETRO_PIXELATE == 1 && (PP_RETRO_PIXEL_GRID > 0 || PP_RETRO_PIXEL_SCANLINE > 0)

            // The gap between the cells is what separates a low resolution
            // picture from a panel made of discrete lamps.
            vec2 ppPxBlock = float(PP_RETRO_PIXEL_SIZE) * vec2(PP_RETRO_PIXEL_ASPECT * 0.01, 1.0);
            vec2 ppPxLocal = fract(uvRaw * vec2(viewWidth, viewHeight) / ppPxBlock);
            #if PP_RETRO_PIXEL_GRID > 0
                float ppPxW = PP_RETRO_PIXEL_GRID_W * 0.01;
                float ppPxEdge = min(min(ppPxLocal.x, 1.0 - ppPxLocal.x),
                                     min(ppPxLocal.y, 1.0 - ppPxLocal.y));
                float ppPxLine = 1.0 - smoothstep(0.0, max(ppPxW, 0.001), ppPxEdge);
                vec3 ppPxTint = ppTintOf(PP_RETRO_PIXEL_GRID_TINT);
                color = mix(color, color * ppPxTint * (1.0 - PP_RETRO_PIXEL_GRID * 0.01), ppPxLine);
            #endif
            #if PP_RETRO_PIXEL_SCANLINE > 0
                color *= 1.0 - (PP_RETRO_PIXEL_SCANLINE * 0.01) * abs(ppPxLocal.y - 0.5) * 2.0;
            #endif
            color *= PP_RETRO_PIXEL_GAIN * 0.01;
        #endif

        #if PPX_RETRO_MONOCHROME == 1

            // The weights decide which colours survive as bright - a low blue
            // weight is what made old film stock render skies almost white.
            float ppWSum = max(float(PP_RETRO_MONO_R + PP_RETRO_MONO_G + PP_RETRO_MONO_B), 1.0);
            float ppGrey = dot(color, vec3(PP_RETRO_MONO_R, PP_RETRO_MONO_G, PP_RETRO_MONO_B) / ppWSum);
            ppGrey = clamp((ppGrey - 0.5) * (PP_RETRO_MONO_CONTRAST * 0.01) + 0.5, 0.0, 4.0);
            ppGrey = ppGrey * (1.0 - PP_RETRO_MONO_LIFT * 0.01) + PP_RETRO_MONO_LIFT * 0.01;
            vec3 ppMono = ppGrey * ppTintOf(PP_RETRO_MONO_TINT);
            color = mix(color, ppMono, PP_RETRO_MONO_I * 0.01);
        #endif

        #if PPX_RETRO_COLOR_DEPTH == 1

            // Quantising in gamma space rather than linear puts the steps where
            // the eye can see them, which is what a real palette did.
            float ppGam = PP_RETRO_DEPTH_GAMMA * 0.01;
            vec3 ppLevels = float(PP_RETRO_LEVELS)
                          * vec3(PP_RETRO_LEVELS_R, PP_RETRO_LEVELS_G, PP_RETRO_LEVELS_B) * 0.01;
            ppLevels = max(ppLevels, vec3(2.0));
            float ppDit = (ppDitherN(uv) - 0.5) * (PP_RETRO_DITHER * 0.01);
            vec3 ppQ = pow(max(color, vec3(0.0)), vec3(1.0 / ppGam));
            ppQ = floor(ppQ * ppLevels + ppDit) / max(ppLevels - 1.0, vec3(1.0));
            color = pow(max(ppQ, vec3(0.0)), vec3(ppGam));
        #endif

        #if PP_CRT_SCANLINES == 1

            // Hard lines are a mask over the picture; softening them into a
            // wave is what a tube's beam actually left behind.
            float ppStep = float(PP_CRT_SCAN_STEP);
            float ppScanI = PP_CRT_SCAN_I * 0.01;
            float ppRow = gl_FragCoord.y;
            #if PP_CRT_SCAN_ROLL > 0
                ppRow += ppTime * (PP_CRT_SCAN_ROLL * 0.1);
            #endif
            float ppPhase = mod(ppRow, ppStep) / ppStep;
            float ppHard = ppPhase > 0.5 ? 1.0 + ppScanI : 1.0 - ppScanI;
            float ppSoftL = 1.0 + ppScanI * cos(ppPhase * 6.2831853);
            color *= mix(ppHard, ppSoftL, PP_CRT_SCAN_SOFT * 0.01);
            #if PP_CRT_SCAN_MASK > 0
                float ppMaskP = mod(gl_FragCoord.x, float(PP_CRT_SCAN_MASK_STEP)) / float(PP_CRT_SCAN_MASK_STEP);
                vec3 ppMask = vec3(step(ppMaskP, 0.334),
                                   step(0.333, ppMaskP) * step(ppMaskP, 0.667),
                                   step(0.666, ppMaskP));
                color *= mix(vec3(1.0), ppMask * 3.0, PP_CRT_SCAN_MASK * 0.01);
            #endif
            color *= PP_CRT_SCAN_GAIN * 0.01;
        #endif

        #if PP_CRT_VIGNETTE == 1

            // The original darkened only the left and right edges, which is why
            // the vertical amount starts at zero: turning it up closes the frame
            // on all four sides instead.
            float ppVigSize = PP_CRT_VIG_SIZE * 0.01;
            float ppVigN = PP_CRT_VIG_NOISE * 0.01;
            float ppA = uvRaw.x * 100.0 * ppVigSize;
            float ppVigL = min(ppA * 3.0 + ppV * 0.2 * ppVigN, 2.0) - min(ppA * ppA + ppV2 * 0.2 * ppVigN, 1.0);
            ppA = (1.0 - uvRaw.x) * 150.0 * ppVigSize;
            float ppVigR = min(ppA + ppV2 * 0.2 * ppVigN, 1.0);
            float ppVigF = ppVigL * ppVigR;
            #if PP_CRT_VIG_VERTICAL > 0
                float ppB = min(uvRaw.y, 1.0 - uvRaw.y) * 200.0 * ppVigSize;
                ppVigF *= mix(1.0, min(ppB, 1.0), PP_CRT_VIG_VERTICAL * 0.01);
            #endif
            ppVigF = pow(clamp(ppVigF, 0.0, 1.0), PP_CRT_VIG_POWER * 0.01);
            color = max(color, vec3(0.0));
            #if PP_CRT_VIG_TINT > 0
                color = mix(color * ppTintOf(PP_CRT_VIG_TINT), color,
                            mix(1.0, ppVigF, PP_CRT_VIG_TINT_I * 0.01));
            #endif
            color *= mix(1.0, ppVigF, PP_CRT_VIG_I * 0.01);
        #endif

        #if PP_CRT_CURVATURE == 1 && PP_CRT_CURVE_MASK > 0

            // Anything the bulge pushed past the edge of the frame was being
            // clamped into a smeared border. Masking it is what gives the tube
            // an edge to end at.
            vec2 ppOut = max(vec2(0.0) - uv, uv - vec2(1.0));
            float ppOff = max(ppOut.x, ppOut.y);
            float ppSoft = max(PP_CRT_CURVE_MASK_SOFT * 0.001, 0.0002);
            color *= 1.0 - (PP_CRT_CURVE_MASK * 0.01) * smoothstep(-ppSoft, ppSoft, ppOff);
        #endif
    #endif
}

#endif
