#ifndef INCLUDE_CINEMATIC
#define INCLUDE_CINEMATIC

/*
    The two things a frame needs to read as film that this pack had no control
    for: the shape of the frame, and grain.

    Everything else a cinematic look is made of already exists here - the AgX
    tonemap, the colour temperature, bloom, motion blur, the tonemap's dark
    desaturation - so this file deliberately adds nothing that duplicates them.

    Both run dead last in final.glsl, after every effect that replaces the frame
    rather than adding to it. Neither reads a buffer, only the colour it is
    handed, so nothing here can be wiped by an effect that re-reads colortex3.
*/

#define CINEMA_LETTERBOX 0 //[0 1]
#define CINEMA_LETTERBOX_RATIO 239 //[166 178 185 200 220 235 239 255 276 300]

#define CINEMA_GRAIN 0 //[0 1]
#define CINEMA_GRAIN_I 30 //[5 10 15 20 25 30 40 50 65 80 100 130]
#define CINEMA_GRAIN_SIZE 1 //[1 2 3]

// Cinematic, the half declared here. Same rule as everywhere else: after the
// declarations, before anything reads them.
#if POST_PROFILE == 7
    #undef CINEMA_LETTERBOX
    #define CINEMA_LETTERBOX 1
    #undef CINEMA_LETTERBOX_RATIO
    #define CINEMA_LETTERBOX_RATIO 239
    #undef CINEMA_GRAIN
    #define CINEMA_GRAIN 1
    #undef CINEMA_GRAIN_I
    #define CINEMA_GRAIN_I 30
#endif

#if CINEMA_GRAIN == 1
    float bvCinemaHash(vec2 p) {
        p = fract(p * vec2(443.8975, 397.2973));
        p += dot(p, p.yx + 19.19);
        return fract((p.x + p.y) * p.x);
    }
#endif

void ApplyCinematic(inout vec3 color) {
    #if CINEMA_GRAIN == 1
        /*
            Grain is strongest in the midtones and falls away at both ends.

            That is not a stylistic choice, it is how film behaves: grain is the
            statistics of how many silver halide crystals happened to develop,
            so where almost none or almost all of them did - the deep shadows
            and the blown highlights - there is nothing left to vary. Applying
            it flat is what makes digital "film grain" look like screen noise
            sitting on top of the picture instead of being part of it.

            Achromatic, for the same reason: scanned colour negative grain is
            dominated by luminance, and per channel noise reads as chroma error.
        */
        vec2 grainCoord = floor(gl_FragCoord.xy / float(CINEMA_GRAIN_SIZE));
        float grain = bvCinemaHash(grainCoord + fract(float(frameCounter) * 0.618034) * 71.0) - 0.5;

        float lum = clamp(GetLuminance(color), 0.0, 1.0);
        color += grain * (CINEMA_GRAIN_I * 0.001) * (4.0 * lum * (1.0 - lum));
        color = max(color, vec3(0.0));
    #endif

    #if CINEMA_LETTERBOX == 1
        /*
            Bars sized from the real aspect of the window, so the frame inside
            them is the chosen ratio on any display rather than a fixed fraction
            of the height that only happens to be right on one.

            Nothing is drawn if the window is already wider than the target -
            an ultrawide monitor at 2.39 gets no bars, which is correct.
        */
        float target = float(CINEMA_LETTERBOX_RATIO) * 0.01;
        float bar = 0.5 * max(0.0, 1.0 - (viewWidth / max(viewHeight, 1.0)) / target);
        float y = gl_FragCoord.y / max(viewHeight, 1.0);
        if (y < bar || y > 1.0 - bar) color = vec3(0.0);
    #endif
}

#endif
