#ifndef INCLUDE_FILTERS
#define INCLUDE_FILTERS

/*
    Photographic filters, applied to the finished frame.

    Two kinds are mixed in here on purpose. Some are processes - what a real
    stock, a real chemical treatment or a real piece of glass in front of the
    lens actually does to an image - and those are named for the process rather
    than for anyone's brand, because the process is the thing being reproduced.
    The rest are ordinary grades that simply look good.

    Every one is a compile time branch, so only the selected filter exists in the
    shader; the others cost nothing. The strength slider crossfades against the
    ungraded frame, which is what makes a look usable at ten percent instead of
    being all or nothing.

    They run before the grain and the letterbox: grain belongs on top of a graded
    image the way it does on top of a print, and matte bars are not something a
    filter gets to tint.
*/

#define PP_FILTERS 0 //[0 1]
#define PP_FILTER_LOOK 1 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24]
#define PP_FILTER_I 100 //[5 10 15 20 25 30 40 50 60 70 80 90 100]

/*
    Cinematic, the half declared here.

    The preset leans on Golden Hour rather than doing the same warmth with the
    colour correction sliders, because a filter and a grade are not the same
    operation: the sliders act on the whole image evenly, while a split tone
    puts the warmth in the highlights and lets the shadows go the other way.
    That separation is most of what reads as cinematography.

    At seventy percent, because at full it stops being light and starts being
    a colour.
*/
#if POST_PROFILE == 7
    #undef PP_FILTERS
    #define PP_FILTERS 1
    #undef PP_FILTER_LOOK
    #define PP_FILTER_LOOK 19
    #undef PP_FILTER_I
    #define PP_FILTER_I 70
#endif

#if PP_FILTERS == 1

// Saturation about the pixel's own luminance.
vec3 bvFxSat(vec3 c, float s) {
    return max(mix(vec3(GetLuminance(c)), c, s), vec3(0.0));
}

// Contrast about mid grey. This runs on the displayed image, not on scene
// light, so the pivot is 0.5 rather than 0.18.
vec3 bvFxCon(vec3 c, float k) {
    return max((c - 0.5) * k + 0.5, vec3(0.0));
}

// Split toning: one tint carried in the shadows, another in the highlights,
// crossfaded by luminance. This is what most film "looks" actually are.
vec3 bvFxSplit(vec3 c, vec3 shadowTint, vec3 highTint) {
    return c * mix(shadowTint, highTint, clamp(GetLuminance(c), 0.0, 1.0));
}

// Raises the black point without touching white - a print viewed in a room.
vec3 bvFxLift(vec3 c, float l) {
    return c * (1.0 - l) + l;
}

// Monochrome through a chosen channel response. Weights are normalised, so a
// filter is described by the RATIO it favours and cannot change exposure.
vec3 bvFxMono(vec3 c, vec3 w) {
    return vec3(dot(c, w / max(w.r + w.g + w.b, 0.0001)));
}

void ApplyFilters(inout vec3 color) {
    vec3 src = color;
    vec3 c = color;

    #if PP_FILTER_LOOK == 1
        // Warm Chrome. The archetypal saturated reversal look: strong reds and
        // yellows, shadows that cool off rather than going neutral.
        c = bvFxSat(c, 1.30);
        c = bvFxSplit(c, vec3(0.90, 0.98, 1.12), vec3(1.10, 1.02, 0.90));
        c = bvFxCon(c, 1.12);

    #elif PP_FILTER_LOOK == 2
        // Vivid Slide. Landscape reversal film - the most saturated thing in
        // photography, with almost no shadow detail to spare.
        c = bvFxSat(c, 1.55);
        c = bvFxCon(c, 1.28);
        c *= vec3(1.03, 1.01, 0.98);

    #elif PP_FILTER_LOOK == 3
        // Portrait Negative. Wide latitude, gentle contrast, warmth held in the
        // midtones where skin sits.
        c = bvFxSat(c, 0.95);
        c = bvFxCon(c, 0.90);
        c = bvFxLift(c, 0.030);
        c = bvFxSplit(c, vec3(1.02, 0.99, 0.98), vec3(1.05, 1.01, 0.95));

    #elif PP_FILTER_LOOK == 4
        // Consumer Negative. The drugstore film look: green sitting in the
        // shadows, highlights running warm.
        c = bvFxSplit(c, vec3(0.95, 1.04, 0.97), vec3(1.08, 1.02, 0.92));
        c = bvFxSat(c, 1.08);
        c = bvFxLift(c, 0.018);

    #elif PP_FILTER_LOOK == 5
        // Tungsten Night. Stock balanced for lamplight, used in daylight -
        // everything goes cold, and only the actual lights stay warm.
        c = bvFxSplit(c, vec3(0.82, 0.94, 1.25), vec3(1.12, 1.00, 0.88));
        c = bvFxSat(c, 1.12);
        c = bvFxCon(c, 1.08);

    #elif PP_FILTER_LOOK == 6
        // Bleach Bypass. Silver left in the print: contrast climbs, colour
        // drains, and the blacks go hard.
        c = bvFxSat(c, 0.32);
        c = bvFxCon(c, 1.45);
        c *= vec3(0.99, 1.00, 1.03);

    #elif PP_FILTER_LOOK == 7
        // Cross Process. Reversal film run through negative chemistry: cyan
        // shadows, acid yellow highlights, contrast through the roof.
        c = bvFxSplit(c, vec3(0.78, 1.02, 1.20), vec3(1.18, 1.10, 0.72));
        c = bvFxSat(c, 1.35);
        c = bvFxCon(c, 1.30);

    #elif PP_FILTER_LOOK == 8
        // Three-Strip. Colour recorded on three separate negatives and
        // recombined - primaries that do not exist anywhere in nature.
        c = vec3(dot(c, vec3( 1.35, -0.22, -0.13)),
                 dot(c, vec3(-0.18,  1.32, -0.14)),
                 dot(c, vec3(-0.12, -0.20,  1.32)));
        c = max(c, vec3(0.0));
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 9
        // Day for Night. Shot at noon, printed down and blued to read as
        // moonlight - contrast has to drop or the sun gives it away.
        c = bvFxSat(c, 0.55);
        c *= vec3(0.55, 0.68, 1.00);
        c = bvFxCon(c, 0.88);
        c *= 0.72;

    #elif PP_FILTER_LOOK == 10
        // Black and White, on the eye's own weighting.
        c = bvFxMono(c, vec3(0.2126, 0.7152, 0.0722));

    #elif PP_FILTER_LOOK == 11
        // Orthochromatic. Early emulsions could not see red at all: skin goes
        // dark and heavy, skies go pale.
        c = bvFxMono(c, vec3(0.05, 0.60, 0.75));
        c = bvFxCon(c, 1.08);

    #elif PP_FILTER_LOOK == 12
        // Red Filter Mono. Deep red glass on panchromatic film - the classic
        // black sky with white clouds.
        c = bvFxMono(c, vec3(1.55, 0.45, 0.02));
        c = bvFxCon(c, 1.22);

    #elif PP_FILTER_LOOK == 13
        // Infrared. Chlorophyll reflects almost everything past the visible, so
        // foliage burns to white while the sky collapses to black.
        float ir = dot(c, vec3(0.10, 1.45, -0.30));
        c = vec3(clamp(ir, 0.0, 1.6));
        c = bvFxCon(c, 1.18);

    #elif PP_FILTER_LOOK == 14
        // Sepia. Silver replaced with silver sulphide.
        c = bvFxMono(c, vec3(0.30, 0.59, 0.11));
        c *= vec3(1.20, 1.00, 0.74);
        c = bvFxLift(c, 0.030);

    #elif PP_FILTER_LOOK == 15
        // Cyanotype. Iron salts rather than silver - Prussian blue and paper.
        c = bvFxMono(c, vec3(0.30, 0.59, 0.11));
        c = mix(vec3(0.06, 0.16, 0.34), vec3(0.86, 0.93, 1.00), c);

    #elif PP_FILTER_LOOK == 16
        // Selenium Tone. An archival treatment that shifts the shadows cold and
        // faintly purple while leaving the highlights alone.
        c = bvFxMono(c, vec3(0.2126, 0.7152, 0.0722));
        c = bvFxSplit(c, vec3(0.94, 0.92, 1.10), vec3(1.02, 1.00, 1.00));
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 17
        // Faded Print. Decades in the light: black point risen, colour gone
        // shallow, contrast flattened.
        c = bvFxSat(c, 0.72);
        c = bvFxCon(c, 0.84);
        c = bvFxLift(c, 0.085);
        c *= vec3(1.02, 1.00, 0.98);

    #elif PP_FILTER_LOOK == 18
        // Teal and Orange. The blockbuster grade: push everything that is not
        // skin toward cyan and let skin keep the warm side to itself.
        c = bvFxSplit(c, vec3(0.80, 1.00, 1.18), vec3(1.16, 1.02, 0.84));
        c = bvFxSat(c, 1.18);
        c = bvFxCon(c, 1.12);

    #elif PP_FILTER_LOOK == 19
        // Golden Hour. Low warm sun held across the whole frame.
        c = bvFxSplit(c, vec3(1.04, 0.98, 0.92), vec3(1.16, 1.04, 0.82));
        c = bvFxSat(c, 1.10);
        c = bvFxLift(c, 0.020);

    #elif PP_FILTER_LOOK == 20
        // Cold Morning. Overcast blue hour - low contrast, a little green in
        // the shadows, nothing saturated anywhere.
        c = bvFxSat(c, 0.85);
        c = bvFxSplit(c, vec3(0.92, 1.00, 1.10), vec3(0.98, 1.00, 1.06));
        c = bvFxCon(c, 0.92);

    #elif PP_FILTER_LOOK == 21
        // Sunset Push. Magenta through the highlights, deep blue underneath.
        c = bvFxSplit(c, vec3(0.78, 0.86, 1.20), vec3(1.22, 0.92, 0.94));
        c = bvFxSat(c, 1.22);
        c = bvFxCon(c, 1.10);

    #elif PP_FILTER_LOOK == 22
        // Noir. Hard monochrome with nothing kept in reserve at either end.
        c = bvFxMono(c, vec3(0.28, 0.62, 0.10));
        c = bvFxCon(c, 1.65);

    #elif PP_FILTER_LOOK == 23
        // Expired Film. Dyes decay at different rates, so the balance drifts
        // magenta and the base fog lifts the blacks.
        c = bvFxSplit(c, vec3(1.06, 0.94, 1.04), vec3(1.04, 0.96, 1.10));
        c = bvFxSat(c, 0.88);
        c = bvFxLift(c, 0.065);
        c = bvFxCon(c, 0.90);

    #else
        // Instant Print. Warm midtones, cyan shadows, a black point that never
        // reaches black and highlights that give up early.
        c = bvFxSplit(c, vec3(0.90, 0.98, 1.10), vec3(1.12, 1.04, 0.94));
        c = bvFxSat(c, 1.05);
        c = bvFxLift(c, 0.055);
        c = bvFxCon(c, 0.88);
    #endif

    color = mix(src, c, PP_FILTER_I * 0.01);
}

#endif

#endif
