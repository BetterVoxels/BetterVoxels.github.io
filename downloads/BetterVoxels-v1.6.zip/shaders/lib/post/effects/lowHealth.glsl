#ifndef INCLUDE_FX_LOW_HEALTH
#define INCLUDE_FX_LOW_HEALTH

#include "/lib/misc/easeCurves.glsl"

// Health arrives as a fraction of the maximum rather than as hearts, and a
// negative reading is the engine saying there is nobody to read yet - the title
// screen, and the first frames after a world loads.
uniform float currentPlayerHealth;
uniform float maxPlayerHealth;

// The reading itself is smoothed engine-side, because regeneration arrives in
// discrete half hearts: without it the effect would step out of the frame
// rather than drain out of it. fxDeath is the same trick pointed the other way -
// a ramp that starts the moment you go down, which is what the death stage
// animates against, since the shader has no clock of its own to start.
uniform float fxHealth;
uniform float fxHurt;
uniform float fxHurtAmount;
uniform float fxDeath;

// Two thumps and a rest, not a sine. A heart does not beat evenly, and it is
// the gap that makes the rhythm read as a pulse instead of a flicker: a narrow
// bump, a softer one close behind it, then silence for most of the cycle.
float fxHeartbeat(float t) {
    float phase = fract(t);
    float lub = phase - 0.06;
    float dub = phase - 0.30;
    return exp2(-260.0 * lub * lub) + exp2(-190.0 * dub * dub) * 0.62;
}

// Deep reds in the shadows, pink rather than white in the highlights. Mapping
// brightness onto a ramp is what keeps the tinted frame readable as an image;
// a flat red laid over the top just hides it.
//
// The top is rolled off before the mapping, and that part is not cosmetic. The
// droplets and halos earlier in this pass are additive - a lit droplet arrives
// at close to twice scene brightness - and a straight multiply drove the whole
// disc past one, so it clipped to a flat patch of red with a hard rim: the
// shape of the droplet stamped onto the frame. Compressed first, the brightest
// specks stay inside the ramp and stay specks.
vec3 fxBloodRamp(float luma) {
    float l = max(luma, 0.0);
    l /= 1.0 + l * 0.9;
    return vec3(l * 1.30 + 0.06, l * l * 0.55, l * l * 0.47);
}

/*
    How far under you are, and how far into dying.

    Split out from the state below because two passes outside this file want the
    weight and nothing else: the motion blur in composite2 and the ghosting in
    final. Neither has a screen position to give, and neither needs one - this
    part depends on health alone.
*/
void bvLowHealthDangerDeath(out float danger, out float death) {
    danger = 0.0;
    death = 0.0;
    if (currentPlayerHealth < 0.0) return;

    bool dead = currentPlayerHealth * maxPlayerHealth <= 0.0;

    float ramp = 1.0 - clamp(fxHealth / max(float(LOW_HEALTH_START), 1.0), 0.0, 1.0);
    danger = bvEaseCurve(ramp, LOW_HEALTH_CURVE);

    // Coming back is its own animation, not the absence of one. smooth() only
    // carries one fixed rate, so the engine lets the signal down over a known
    // three seconds and the slider is honoured by retiming that curve here - the
    // same identity the droplet lifecycle uses. Only the way back up is retimed;
    // going under keeps the engine's own rise.
    death = clamp(fxDeath, 0.0, 1.0);
    if (!dead) death = fxRetimeDecay(death, 3.0, max(LOW_HEALTH_REVIVE_TIME, 0.05));

    // Health snaps to full the instant you respawn, so left alone the grey and
    // the red band would pop out seconds before the glitching and the rings had
    // finished letting go. Holding danger up to the death curve is what keeps
    // the whole recovery on one clock.
    danger = max(danger, death);
}

float bvLowHealthDanger() {
    float danger, death;
    bvLowHealthDangerDeath(danger, death);
    return danger;
}

// The two halves below share this, so they cannot drift apart. It is a handful
// of arithmetic and no texture reads, which is why running it twice per frame is
// cheaper than plumbing the results between two programs.
void bvLowHealthState(vec2 uv, out float danger, out float death, out float hurt,
                      out float beat, out float vig, out float radius) {
    hurt = 0.0;
    beat = 0.0;
    vig = 0.0;
    radius = length(uv * 2.0 - 1.0);

    bvLowHealthDangerDeath(danger, death);
    if (currentPlayerHealth < 0.0) return;

    // A scratch and a near-fatal hit should not land the same way, so the flash
    // is triggered by the hurt frame and sized by how much was actually lost.
    hurt = clamp(fxHurt, 0.0, 1.0)
         * clamp(0.3 + fxHurtAmount / 7.0, 0.0, 1.0)
         * (LOW_HEALTH_HURT * 0.01);

    beat = fxHeartbeat(frameTimeCounter * LOW_HEALTH_PULSE_RATE * (0.75 + 0.7 * danger));

    // Everything red happens inside this band and nowhere else. It widens as the
    // reading falls and breathes with the beat, but it never reaches in and takes
    // the middle of the frame: what happens there is the colour draining out,
    // which is a different thing and reads as a different thing.
    //
    // Zero at the centre, one across the middle of each edge, saturated in the
    // corners - so the band hugs the whole frame rather than only its corners.
    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);
    float reach = max(LOW_HEALTH_VIGNETTE * 0.01, 0.001)
                * (0.55 + 0.45 * danger)
                * (1.0 + (beat - 0.2) * 0.30 * pulseK);
    vig = clamp((radius - (1.0 - reach)) / max(reach, 0.001), 0.0, 1.0);
    vig *= vig;
}

/*
    Everything that is nothing but a change of sample point.

    It is its own function because several effects further down the chain do not
    add to the frame - they resample colortex3 through a lens of their own and
    throw away whatever was graded before them. The bodycam is the loudest of
    them: with it on, a frame warped here is simply discarded, which is why the
    swaying stopped at low health as soon as it was switched on. The only way
    through is for those effects to stack this onto their own sample points
    instead, so this has to be available as a transform rather than as a filter.

    Reads no texture, so calling it once per sample point costs arithmetic only.
*/
vec2 bvLowHealthWarpUV(vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && death < 0.002) return uv;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);
    float edge = vig * danger * mix(1.0, 0.5 + 0.85 * beat, pulseK);

    vec2 outward = uv - 0.5;

    #if LOW_HEALTH_DIZZY > 0
        float dizzy = danger * (LOW_HEALTH_DIZZY * 0.01);
        if (dizzy > 0.002) {
            float t = frameTimeCounter * LOW_HEALTH_DIZZY_RATE;
            float aspect = fxAspect().x;
            vec2 c = outward * vec2(aspect, 1.0);

            float swirl = sin(t * 6.2831853) * dizzy * 0.10 * (0.30 + length(c));
            float sn = sin(swirl);
            float cs = cos(swirl);
            c = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
            c *= (1.0 - dizzy * 0.05) * (1.0 + sin(t * 4.1 + 1.7) * dizzy * 0.045);

            outward = c / vec2(aspect, 1.0);
        }
    #endif

    #if LOW_HEALTH_ZOOM > 0
        outward *= 1.0 - edge * (LOW_HEALTH_ZOOM * 0.01) * 0.035;
    #endif

    vec2 warped = 0.5 + outward;

    #if LOW_HEALTH_DEATH_GLITCH > 0
        float glitch = death * (LOW_HEALTH_DEATH_GLITCH * 0.01);
        if (glitch > 0.004) {
            // Held in steps rather than slid: a tear that moves smoothly is a
            // wobble, and a wobble is not what a broken signal looks like.
            float tick = floor(frameTimeCounter * 11.0);
            float band = floor(uv.y * 38.0);
            if (fxHash12(vec2(band, tick)) > 1.0 - 0.35 * glitch) {
                warped.x += (fxHash12(vec2(band, tick + 31.0)) - 0.5) * 0.12 * glitch;
            }
            if (fxHash12(vec2(tick, 7.0)) > 1.0 - 0.20 * glitch) {
                warped.y += (fxHash12(vec2(tick, 19.0)) - 0.5) * 0.05 * glitch;
            }
        }
    #endif

    return clamp(warped, vec2(0.001), vec2(0.999));
}

// How far apart the death glitch pulls the channels, in uv. Zero unless dying.
float bvLowHealthSplit() {
    #if LOW_HEALTH_DEATH_GLITCH > 0
        float danger, death, hurt, beat, vig, radius;
        bvLowHealthState(vec2(0.5), danger, death, hurt, beat, vig, radius);
        float glitch = death * (LOW_HEALTH_DEATH_GLITCH * 0.01);
        if (glitch <= 0.004) return 0.0;
        float tick = floor(frameTimeCounter * 11.0);
        // Pulled apart on purpose here - this one is meant to read as the
        // signal failing, not as an eye.
        return 0.005 * glitch * (0.4 + fxHash12(vec2(tick, 3.0)));
    #else
        return 0.0;
    #endif
}

// Anything that bends the frame has to read a texture back, so this half runs
// where that read still returns everything drawn so far. It is the same warp as
// bvLowHealthWarpUV, plus the one part of it that cannot be expressed as a
// change of sample point - the radial smear needs several reads, not one.
vec3 ApplyLowHealthWarp(vec3 color, sampler2D src, vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && death < 0.002) return color;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);

    // The single weight every edge effect is driven by. Its size pulses through
    // reach, its strength pulses here, and both die with danger.
    float edge = vig * danger * mix(1.0, 0.5 + 0.85 * beat, pulseK);

    vec2 warped = bvLowHealthWarpUV(uv);
    float split = bvLowHealthSplit();

    float smear = 0.0;
    #if LOW_HEALTH_BLUR > 0
        // A radial smear, the same for all three channels. Splitting them would
        // be chromatic aberration, which reads as a lens fault; kept colourless
        // it reads as vision going soft, and the offset copies leave the doubled
        // edge that comes with it.
        smear = edge * (LOW_HEALTH_BLUR * 0.01) * 0.055;
    #endif

    bool moved = warped != uv || split > 0.0;
    if (!moved && smear <= 0.0005) return color;

    vec3 acc;
    if (split > 0.0) {
        acc = vec3(texture2D(src, clamp(warped + vec2(split, 0.0), vec2(0.001), vec2(0.999))).r,
                   texture2D(src, warped).g,
                   texture2D(src, clamp(warped - vec2(split, 0.0), vec2(0.001), vec2(0.999))).b);
    } else {
        acc = texture2D(src, warped).rgb;
    }
    float weight = 1.0;

    #if LOW_HEALTH_BLUR > 0
        if (smear > 0.0005) {
            vec2 outward = warped - 0.5;
            for (int i = 1; i <= 3; i++) {
                vec2 pulled = warped - outward * (smear * float(i) * 0.33333);
                acc += texture2D(src, clamp(pulled, vec2(0.001), vec2(0.999))).rgb;
                weight += 1.0;
            }
        }
    #endif

    return acc / weight;
}

// The colour half touches no texture, so it can sit at the very end of the
// chain and grade whatever survived it - which is the whole point: the tint
// belongs on top of everything, not buried under the next effect that decides
// to re-read the frame.
vec3 ApplyLowHealthColour(vec3 color, vec2 uv) {
    float danger, death, hurt, beat, vig, radius;
    bvLowHealthState(uv, danger, death, hurt, beat, vig, radius);
    if (danger < 0.002 && hurt < 0.004 && death < 0.002) return color;

    float pulseK = clamp(LOW_HEALTH_PULSE * 0.01, 0.0, 2.0);

    // The colour gets a much flatter version of the beat. Swinging the red as
    // hard as the geometry read as the frame flashing red rather than as
    // something beating; most of the throb belongs in the size of the band and
    // in the darkening below, not in the hue.
    float edgeTint = vig * danger * mix(1.0, 0.78 + 0.34 * beat, pulseK);

    // ----------------------------------------------------------------- colour
    #if LOW_HEALTH_DARKEN > 0
        // Vision closing down does not dim everything by the same amount: the
        // eye gives up on the dark end long before the bright end. Weighting
        // the rolloff by how bright a pixel already is leaves the sun and the
        // sky roughly where they were while the ground drops away under them,
        // which is what makes the light start to hurt rather than just fade.
        float dark = danger * (LOW_HEALTH_DARKEN * 0.01);
        if (dark > 0.002) {
            float keep = sqrt(clamp(fxLuma(color), 0.0, 1.0));
            color *= mix(1.0 - 0.85 * dark, 1.0, keep);
        }
    #endif

    float grey = fxLuma(color);

    // Draining the colour is the one part that covers the whole frame - that is
    // what it is for, and it is also what keeps the middle from going red.
    vec3 drained = mix(color, vec3(grey), clamp(danger * LOW_HEALTH_DESAT * 0.01, 0.0, 1.0));
    vec3 blood = fxBloodRamp(grey);

    color = mix(drained, blood, clamp(edgeTint * (LOW_HEALTH_TINT * 0.01), 0.0, 1.0));

    // The energy taken out of the colour goes here instead: each thump pulls the
    // edges down rather than lighting them up, which is what a pulse in the
    // corner of your vision actually does.
    color *= 1.0 - vig * danger * beat * 0.20 * pulseK;

    if (hurt > 0.004) {
        // A hit is the one moment allowed past the band, and only a heavy one.
        float spread = mix(vig, 1.0, clamp(fxHurtAmount / 12.0, 0.0, 0.85));
        color = mix(color, blood, clamp(hurt * spread, 0.0, 0.95));
    }

    if (death > 0.002) {
        // Nothing is held back here. The band that spent the whole fight at the
        // edges walks inwards until only a small window is left, and it keeps
        // closing for as long as you are down.
        float inner = mix(0.60, 0.05, clamp(LOW_HEALTH_DEATH_CLOSE * 0.01, 0.0, 1.0))
                    * (1.0 - 0.45 * death);
        float shut = clamp((radius - inner) / max(1.0 - inner, 0.001), 0.0, 1.0);
        shut = shut * shut * (3.0 - 2.0 * shut);

        vec3 gone = vec3(grey) * vec3(0.42, 0.03, 0.025) + vec3(0.04, 0.0, 0.0);
        float wash = clamp(death * (LOW_HEALTH_DEATH * 0.01), 0.0, 1.0);
        color = mix(color, gone, clamp(shut * wash + 0.25 * wash, 0.0, 1.0));
        color *= 1.0 - 0.45 * wash;

        #if LOW_HEALTH_DEATH_BLACK > 0
            // A second ring, tighter than the red and set further out, so the
            // red is left as a band between the two rather than as a flat wash.
            // One radius gives you a filter over the frame; two give it depth -
            // the red says wounded, the black says the lights are going out.
            float blackAmt = clamp(LOW_HEALTH_DEATH_BLACK * 0.01, 0.0, 1.0);
            float blackInner = mix(0.95, 0.55, blackAmt) * (1.0 - 0.35 * death);
            float dark = clamp((radius - blackInner) / max(1.0 - blackInner, 0.001), 0.0, 1.0);
            color = mix(color, vec3(0.0), clamp(dark * dark * death * blackAmt * 0.9, 0.0, 1.0));
        #endif
    }

    return color;
}

#endif
