#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

vec3 ScreenToView(vec3 pos) {
    vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x,
                          gbufferProjectionInverse[1].y,
                          gbufferProjectionInverse[2].zw);
    vec3 p3 = pos * 2.0 - 1.0;
    vec4 viewPos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return viewPos.xyz / viewPos.w;
}

// Deliberately does NOT undo world curvature, though the inverse is exact and
// it is tempting. This function does not only convert surface positions: for a
// sky pixel it reconstructs a point on the far plane, where x and z run to
// hundreds of blocks and a term in their squares throws y by more than the
// whole scene is tall. Undoing the bend here bent the sky far harder than the
// ground, which is the one thing the effect must not do.
//
// So everything downstream sees the bent world and agrees with itself: the
// shadow map was drawn bent, so a lookup from a bent position lands correctly,
// and screen space effects are consistent by construction. The cost is that fog
// altitude and the voxel volume read a position up to a block or so low at the
// edge of their range, which is well under a voxel where it matters.
vec3 ViewToPlayer(vec3 pos) {
    return mat3(gbufferModelViewInverse) * pos + gbufferModelViewInverse[3].xyz;
}

// No curvature term here either, and for the same reason: what arrives is
// already a bent position, because ViewToPlayer left it bent. Bending it again
// would double the drop, and for the cloud trace - which passes points hundreds
// of blocks out through here - it would double a very large number.
vec3 PlayerToShadow(vec3 pos) {
    #ifdef SMOOTH_SHADOW_ROTATION

        pos = stShadowRotation * pos;
    #endif
    vec3 shadowpos = mat3(shadowModelView) * pos + shadowModelView[3].xyz;
    return projMAD(shadowProjection, shadowpos);
}

vec3 ShadowClipToShadowView(vec3 pos) {
    return mat3(shadowProjectionInverse) * pos;
}

vec3 ShadowViewToPlayer(vec3 pos) {
    #ifdef SMOOTH_SHADOW_ROTATION

        return (mat3(shadowModelViewInverse) * pos) * stShadowRotation;
    #else
        return mat3(shadowModelViewInverse) * pos;
    #endif
}
