
#ifndef INCLUDE_SMOOTH_TIME_TRACKER
#define INCLUDE_SMOOTH_TIME_TRACKER

#define SMOOTH_TIME_JUMP_THRESHOLD 0.004

uniform sampler2D smooth_time_sampler;

float SmoothTimeVisualSunAngle() {
    return texelFetch(smooth_time_sampler, ivec2(1, 0), 0).r;
}

// skyColor is handed to us by the game and snaps the instant world time does,
// so on a time jump the sky recoloured while the sun was still gliding. It
// rides the same jump detection and the same progress as the angle.
vec3 SmoothTimeVisualSkyColor() {
    return texelFetch(smooth_time_sampler, ivec2(3, 0), 0).rgb;
}

#ifdef CSH

    #include "/lib/misc/timeInterpolation.glsl"

    layout(rgba32f) uniform image2D smooth_time_img;

    void SmoothTimeUpdateState() {
        float nativeAngle = fract(sunAngle);
        float nowT = frameTimeCounter;

        float tIn  = max(TIME_TRANSITION_IN, 0.0);
        float tOut = max(TIME_TRANSITION_OUT, 0.0);
        float dur  = max(tIn + tOut, 0.05);

        vec4 s0 = imageLoad(smooth_time_img, ivec2(0, 0));
        vec4 s1 = imageLoad(smooth_time_img, ivec2(1, 0));
        vec4 cStart = imageLoad(smooth_time_img, ivec2(2, 0));
        vec4 cEased = imageLoad(smooth_time_img, ivec2(3, 0));

        if (s0.x != 1234.5 || nowT < s1.y - 0.5) {

            s0 = vec4(1234.5, nativeAngle, nowT - 2.0 * dur, nativeAngle);
            s1 = vec4(nativeAngle, nowT, 0.0, 0.0);
            cStart = vec4(skyColor, 0.0);
            cEased = vec4(skyColor, 0.0);
        } else {

            float dNative = fract(nativeAngle - s0.y + 0.5) - 0.5;
            if (abs(dNative) > SMOOTH_TIME_JUMP_THRESHOLD) {
                s0.z = nowT;
                s0.w = s1.x;
                cStart.rgb = cEased.rgb;

                // Latch which way round the sky travels, once. Recomputing it
                // per frame flipped its sign mid-glide on a half-day jump -
                // noon to midnight sits exactly on the +-0.5 boundary and
                // ordinary time passage pushes it over - which threw the sun,
                // moon, stars and clouds half a turn across the sky together.
                float latched = fract(nativeAngle - s1.x + 0.5) - 0.5;
                // An exact antipode is direction-agnostic; go forwards, so the
                // sun sets rather than reversing back up over the horizon.
                s1.z = abs(abs(latched) - 0.5) < 0.001 ? 0.5 : latched;
            }
            s0.y = nativeAngle;

            float elapsed = nowT - s0.z;
            float p;
            if (elapsed >= dur) {
                p = 1.0;
            } else if (elapsed < tIn) {

                p = tIn > 0.0001 ? 0.5 * (elapsed / tIn) : 0.5;
            } else {

                p = tOut > 0.0001 ? 0.5 + 0.5 * ((elapsed - tIn) / tOut) : 1.0;
            }
            p = clamp(p, 0.0, 1.0);

            if (p >= 1.0) {

                s1.x = nativeAngle;
                s0.w = nativeAngle;
                cEased.rgb = skyColor;
                cStart.rgb = skyColor;
            } else {
                s1.x = fract(s0.w + s1.z * smoothTimeCurve(p));
                cEased.rgb = mix(cStart.rgb, skyColor, smoothTimeCurve(p));
            }
            s1.y = nowT;
        }

        imageStore(smooth_time_img, ivec2(0, 0), s0);
        imageStore(smooth_time_img, ivec2(1, 0), s1);
        imageStore(smooth_time_img, ivec2(2, 0), cStart);
        imageStore(smooth_time_img, ivec2(3, 0), cEased);
    }
#endif

#endif
