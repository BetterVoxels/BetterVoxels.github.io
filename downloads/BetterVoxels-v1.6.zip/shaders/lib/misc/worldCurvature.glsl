/*
    World curvature.

    Bends the ground away from you with distance, so the horizon reads as the
    edge of something round rather than the edge of the render distance.

    A parabola rather than a sphere. Over the distance Minecraft actually draws
    the two differ by less than a pixel, and the parabola buys something a
    sphere does not: it moves y only, so it inverts in one multiply. That is
    what makes the rest of the pipeline honest. The depth buffer ends up holding
    where a vertex was *put*, and every deferred pass that reads a position back
    out of it - fog, biome tint, the voxel volume the lighting is traced
    through - wants to know where the block actually is. Undoing the bend there
    is exact, so those systems never learn the world was bent at all.

    Two places therefore have to agree with the vertex stage, and both are
    single functions in spaceConversion.glsl:
      ViewToPlayer   removes the bend, because it is reading the depth buffer;
      PlayerToShadow puts it back, because the shadow map was drawn bent too.

    Left out on purpose: the sky, which is at infinity and would tear at the
    horizon, and the held item, which is attached to your hand and not to the
    world.
*/

#ifndef INCLUDE_WORLD_CURVATURE
#define INCLUDE_WORLD_CURVATURE

#ifdef WORLD_CURVATURE_ACTIVE

// How far the ground has fallen away at a given horizontal offset from the
// camera. The offset is squared, so this is flat underfoot and steepens with
// distance - which is the whole shape of the effect.
/*
    The bend, per block of horizontal distance squared.

    Under Auto it is tied to how high the eye is. That is the honest version of
    the effect: from the ground a planet's curve is not visible at all, and it
    only opens up as you climb - so the world flattens out when you land and
    rounds off again on the way up, rather than being bent by a fixed amount
    everywhere. Measured from sea level, so being at the bottom of a ravine
    reads the same as standing on the shore.
*/
float bvCurveScale() {
    #if WORLD_CURVATURE == 2
        // Sea level written out rather than taken from oceanAltitude: this
        // header is pulled in by every program including the prepare passes,
        // and common.glsl declares that constant further down than some of
        // them read. One number is not worth an ordering dependency.
        return clamp((cameraPosition.y - 62.0) / float(WORLD_CURVATURE_AUTO_ALT), 0.0, 4.0);
    #else
        return 1.0;
    #endif
}

float bvCurveDrop(vec2 offsetXZ) {
    // Scaled so that 100 drops the ground about four blocks at a hundred out
    // and about fifteen at the edge of a twelve chunk view - enough to read as
    // a curve rather than as a slope you might have mistaken for terrain.
    //
    // Signed on purpose. Negative values lift the ground instead of dropping
    // it, which turns the dome into a bowl with the horizon rising around you.
    return dot(offsetXZ, offsetXZ) * (WORLD_CURVATURE_I * 0.01) * 0.0004 * bvCurveScale();
}

vec3 bvCurveWorld(vec3 playerPos) {
    playerPos.y -= bvCurveDrop(playerPos.xz);
    return playerPos;
}

// For the programs that hand their vertices straight to ftransform(). The route
// through player space is the same one gbuffers_terrain already takes, so a
// bent entity and the bent block it is standing on are bent by the same
// arithmetic rather than by two that merely look alike.
//
// Vertex stage only - gl_Vertex does not exist in a fragment shader, and a
// function naming it would fail to compile even where nothing calls it.
#ifdef VERTEX_SHADER
    vec4 bvCurveFTransform() {
        vec4 p = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
        p.xyz = bvCurveWorld(p.xyz);
        return gl_ProjectionMatrix * (gbufferModelView * p);
    }
#endif

#endif

#endif
