#if AUTO_EXPOSURE == 1
#ifndef INCLUDE_AUTO_EXPOSURE
#define INCLUDE_AUTO_EXPOSURE

uniform sampler2D autoexp_sampler;

// Read by every pixel in the frame, and deliberately reading a value that was
// settled at the end of the previous one. Measuring and applying inside a
// single pass would grade the top of the screen with a different number than
// the bottom, because the pixels do not run in a known order.
float bvAutoExposure() {
    float stored = texelFetch(autoexp_sampler, ivec2(0, 0), 0).g;
    if (stored <= 0.0) return 1.0;
    return mix(1.0, stored, AE_STRENGTH * 0.01);
}

#ifdef BV_AUTO_EXPOSURE_WRITER
    layout(rgba32f) uniform image2D autoexp_img;

    void bvAutoExposureUpdate(sampler2D scene) {
        // A log average rather than a plain one. Brightness is perceived
        // multiplicatively, so a single torch in a dark cave should not drag
        // the reading the way it does in a linear mean - which is exactly the
        // failure that leaves a cave looking evenly lit instead of black with
        // one bright shaft in it.
        float logSum = 0.0;
        float weight = 0.0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                vec2 uv = (vec2(float(x), float(y)) + 0.5) * 0.125;
                float w = 1.0;
                #if AE_METER == 1
                    w = 1.0 - 0.75 * clamp(length(uv - 0.5) * 2.0, 0.0, 1.0);
                #elif AE_METER == 2
                    w = length(uv - 0.5) < 0.28 ? 1.0 : 0.0;
                #endif
                float l = dot(texture2D(scene, uv).rgb, vec3(0.2125, 0.7154, 0.0721));
                logSum += log(max(l, 0.0001)) * w;
                weight += w;
            }
        }
        float measured = exp(logSum / max(weight, 0.0001));
        float want = clamp((AE_TARGET * 0.01) / max(measured, 0.0001),
                           AE_MIN * 0.01, AE_MAX * 0.01);

        // Darken Only is the mode that answers "the cave should stay dark".
        // Ordinary metering does the opposite of what you want down there: it
        // sees a dark scene and opens up, which is what washes the shaft out.
        #if AE_MODE == 1
            want = min(want, 1.0);
        #elif AE_MODE == 2
            want = max(want, 1.0);
        #endif

        vec4 s = imageLoad(autoexp_img, ivec2(0, 0));
        float now = frameTimeCounter;
        float adapted = want;

        // A pupil closes down fast and opens slowly. The two speeds are
        // separate for that reason, not for tidiness.
        if (s.r == 4321.5 && now >= s.b - 0.5 && s.g > 0.0) {
            float dt = clamp(now - s.b, 0.0, 1.0);
            float tau = want < s.g ? max(AE_SPEED_DOWN * 0.01, 0.02)
                                   : max(AE_SPEED_UP * 0.01, 0.02);
            adapted = mix(s.g, want, clamp(1.0 - exp(-dt / tau), 0.0, 1.0));
        }

        imageStore(autoexp_img, ivec2(0, 0), vec4(4321.5, adapted, now, 0.0));
    }
#endif

#endif
#endif
