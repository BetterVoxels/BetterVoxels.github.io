#ifndef INCLUDE_BETTER_SELECTION_OUTLINE
#define INCLUDE_BETTER_SELECTION_OUTLINE

#ifdef BETTER_SELECTION_OUTLINE_ACTIVE

/*
    An outline that follows the block's own texture instead of its box.

    Glow lichen, vines, a ladder, a rail: all of them are a cutout painted on a
    full sized quad, so the vanilla outline draws a rectangle around a shape that
    fills almost none of it. This traces the shape itself - its silhouette and
    the holes inside it - and leaves the box where it is.

    The whole thing turns on one uniform. currentSelectedBlockPos is Iris
    reporting the centre of the block under the crosshair, in the same player
    space the terrain pass already works in, so a fragment can simply ask whether
    it belongs to that block. No second raycast, and no frame of lag.

    That matters more than it sounds: this pack has twice tried to find the
    selected block by other means. Re-deriving Minecraft's pick with a voxel ray
    was measured to disagree with it, persistently and by whole blocks, and
    reading the outline's own geometry back out of an image was never confirmed
    to work at all. Neither is needed - the answer was a uniform.

    ---

    Drawn on the EMPTY side of the boundary, in fragments the alpha test was
    about to throw away, and measured in screen pixels rather than texels.

    Both of those are corrections. Painting the opaque texels next to a hole
    instead fills the shape in solid, because lichen and vines are drawn as
    strands one or two texels wide - every lit texel in them is already next to
    an empty one, so "on the edge" selects the entire plant. And a radius
    measured in texels is a radius that grows on screen as you walk towards the
    block, so the line is a hairline from across the room and a slab up close.

    A screen space radius gives a line of the same weight as the box it sits
    inside, at any distance, and taking the empty side means what is drawn is a
    rim around the shape rather than the shape itself.
*/

uniform vec3 currentSelectedBlockPos;

/*
    True if this fragment is empty, belongs to the selected block, and has solid
    texture within a hairline of it - i.e. it is just outside the silhouette.

    texGrad has to be measured before anything discards. A derivative is taken
    across neighbouring fragments, and once they are gone there is nothing left
    to take it from.
*/
bool BvSelectionOutlineRim(vec3 playerPos, vec3 worldNormal, int matId, vec2 texCoordM,
                           vec2 midCoordM, vec2 absMidM, vec2 texGrad) {
    // Iris parks the uniform at -256 in every component when nothing is
    // selected, which no real block is ever near.
    if (currentSelectedBlockPos.x < -255.0) return false;

    #if SELECT_OUTLINE_BETTER_IGNORE_LEAVES == 1
        // A leaf block is holes all the way through, so tracing it draws a rim
        // around every gap in the canopy and reads as noise rather than as an
        // outline. Off by material rather than by any measure of busyness,
        // because that is a decision with an obvious right answer per block.
        if (matId == 10009 || matId == 10013) return false;
    #endif

    /*
        Inside the selected block, or not our business.

        Stepped a hair along the surface normal first, INTO whatever the
        fragment is a face of. Without that step the test is a comparison
        against exactly half a block, and the face a neighbour shares with the
        selected block sits exactly there - so aiming at a flowerbed also lit up
        the top of the grass block holding it, and every other shared face
        besides.

        The step settles it by direction rather than by tolerance: the selected
        block's own faces move inward, a neighbour's face moves further out.
    */
    vec3 inward = playerPos - 0.012 * worldNormal;
    if (any(greaterThan(abs(inward - currentSelectedBlockPos), vec3(0.5)))) return false;

    /*
        The sprite's own bounds in the atlas.

        Every sample is clamped into them, and that clamp is what keeps this
        from firing along the seams of the atlas: a step past the edge of a
        sprite lands in whatever sprite the packer put next door, and finding
        solid texture there would draw a rim around the whole quad.

        Degenerate bounds - the pass zeroes absMidCoordPos for some geometry -
        collapse every sample onto one point, which reads as "no edge" and is
        the right way to fail.
    */
    vec2 lo = midCoordM - absMidM;
    vec2 hi = midCoordM + absMidM;
    vec2 radius = texGrad * SELECT_OUTLINE_BETTER_WIDTH;

    for (int k = 0; k < 8; k++) {
        float a = float(k) * 0.7853981634;
        vec2 p = clamp(texCoordM + vec2(cos(a), sin(a)) * radius, lo, hi);
        // Level zero on purpose: a mipmapped or anisotropic sample softens the
        // cutout edge into a gradient, and this needs the hard one.
        if (textureLod(tex, p, 0.0).a > 0.1) return true;
    }
    return false;
}

vec3 BvSelectionOutlineColor(vec3 playerPos) {
    #if SELECT_OUTLINE == 2
        // Matches the animated box rather than sitting a different colour
        // inside it. Same expression gbuffers_basic uses, on the same inputs.
        float posFactor = playerPos.x + playerPos.y + playerPos.z
                        + cameraPosition.x + cameraPosition.y + cameraPosition.z;
        return clamp(abs(mod(fract(frameTimeCounter * 0.25 + posFactor * 0.2) * 6.0
                             + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0,
                     0.0, 1.0) * vec3(3.0, 2.0, 3.0) * SELECT_OUTLINE_I;
    #else
        /*
            The colour from this screen, in every other mode - including
            Default, where the box itself is vanilla black. A black line traced
            against a dark texture would be invisible, which is not a useful
            thing for this to do, so the one colour on the page that was chosen
            to be seen is the one it uses.
        */
        return vec3(SELECT_OUTLINE_R, SELECT_OUTLINE_G, SELECT_OUTLINE_B) * SELECT_OUTLINE_I;
    #endif
}

#endif

#endif
