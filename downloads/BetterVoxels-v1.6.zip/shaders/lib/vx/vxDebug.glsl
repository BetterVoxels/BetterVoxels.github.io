#ifndef INCLUDE_VX_DEBUG
#define INCLUDE_VX_DEBUG

/*
    Views onto the voxel tracer itself.

    The GI debug view already in the pack shows the irradiance cache - the
    finished product. These show the machinery that fills it: the colour the
    bounce reflects off, the field the rays walk, the cascade that field is
    stored in, and the rays themselves.

    Everything here reads structures the tracer already built this frame. No
    pass is added and nothing is written back; the whole file compiles away when
    the option is Off.

    One probe ray per pixel, fired along the surface normal. Deliberately not a
    random hemisphere direction like the real GI uses: a stochastic ray makes an
    image that crawls, and the point of a debug view is to hold still while you
    look at it. What it shows is what lies directly in front of this surface,
    which is what dominates the bounce anyway.
*/

#include "/lib/vx/voxelReading.glsl"

// Blue through green to red.
vec3 bvDebugRamp(float t) {
    t = clamp(t, 0.0, 1.0);
    return clamp(vec3(t * 3.0 - 1.5, 1.5 - abs(t * 3.0 - 1.5), 1.5 - t * 3.0), 0.0, 1.0);
}

/*
    rayTrace with a step counter and an honest answer about how it ended.

    A copy rather than an extra output on the real one, because the real one is
    called from the GI compute for every sample of every active voxel and is not
    somewhere to add a parameter for the sake of a debug view. The loop is kept
    identical - same seeding, same early out under the same option, same hit
    test - so the step count is the tracer's real cost and not an approximation
    of it.
*/
vec3 bvDebugTrace(vec3 start, vec3 dir, float dither, out int steps, out bool hit) {
    float dirLen = infnorm(dir);
    dir /= dirLen;
    float w = 0.001 + dither * getDistanceField(start + 0.001 * dir);
    steps = 0;
    hit = false;
    for (int k = 0; k < RT_STEPS; k++) {
        steps = k + 1;
        vec3 p = start + w * dir;

        #if EOPT_RAY_SKY_EARLY_OUT == 1
            if (infnorm(p / voxelVolumeSize) > 0.5) break;
        #endif
        float thisdist = getDistanceField(p);
        if (abs(thisdist) < 0.0001) {
            hit = true;
            break;
        }
        w += thisdist;
        if (w > dirLen) break;
    }
    return start + min(w, dirLen) * dir;
}

vec3 BvVoxelDebug(vec3 vxPos, vec3 worldNormal, float dither) {
    /*
        Outside the volume there is nothing to show, and saying so plainly beats
        showing whatever a clamped lookup happens to return.

        The same test the cache reader uses, written out rather than called:
        that one lives in irradianceCache.glsl, which also declares the cache
        sampler, and this pass has no other reason to carry it.
    */
    if (any(lessThanEqual(vxPos, -0.5 * vec3(voxelVolumeSize)))
     || any(greaterThanEqual(vxPos, 0.5 * vec3(voxelVolumeSize)))) return vec3(0.0);

    #if VX_DEBUG == 1
        // What the bounce actually reflects off. A surface whose voxel colour
        // is wrong throws wrong coloured light no matter how good the trace is.
        return getColorFine(vxPos, worldNormal).rgb;

    #elif VX_DEBUG == 2
        /*
            The distance field the rays walk, in blocks: how far the tracer
            believes it can step without hitting anything.

            Shown as contours rather than a gradient because the useful question
            is where the field is wrong, and a wrong field shows up as a kink in
            a contour long before it shows up as a shade.
        */
        float df = getDistanceField(vxPos + 0.5 * worldNormal);
        vec3 base = bvDebugRamp(df / 8.0);
        float band = abs(fract(df) - 0.5) * 2.0;
        return base * (0.45 + 0.55 * band);

    #elif VX_DEBUG == 3
        /*
            Which cascade of the field this point is read from. The field is
            stored at several resolutions and the level is picked by distance
            from the camera, so this comes out as boxes nested around you - the
            seams between them are where detail drops, and where an artefact
            that follows you around is likely to be coming from.
        */
        int res = getVoxelResolution(vxPos);
        return bvDebugRamp(float(res) / float(max(VOXEL_DETAIL_AMOUNT - 1, 1)));

    #elif VX_DEBUG == 4
        /*
            Sky exposure per voxel, two bits, as the GI reads it: black none,
            white full.

            Worth its own view because it is stored permuted rather than in
            order, and combining neighbours wrongly puts a one voxel dark line
            along every seam where an open cell meets a shaded one. Here that
            line is visible directly, instead of through the lighting.
        */
        ivec3 coords = ivec3(vxPos + 0.5 * worldNormal + 0.5 * voxelVolumeSize);
        if (vxOutOfRange(coords)) return vec3(0.0);
        int code = imageLoad(occupancyVolume, coords).r >> 28 & 3;
        return vec3(float(ivec4(0, 1, 3, 2)[code]) / 3.0);

    #else
        int steps;
        bool hit;
        vec3 origin = vxPos + 0.5 * worldNormal;
        vec3 traceVec = (LIGHT_TRACE_LENGTH * EOPT_GI_RANGE_MULT) * worldNormal;
        vec3 hitPos = bvDebugTrace(origin, traceVec, dither, steps, hit);

        #if VX_DEBUG == 5
            // Where the light in front of this surface is coming from: the
            // colour of whatever the probe landed on. Ray escaped to open sky
            // is drawn dark blue rather than black, so "nothing there" reads
            // differently from "black block there".
            if (!hit) return vec3(0.02, 0.04, 0.12);
            vec3 hitNormal = vec3(0.0);
            for (int k = 0; k < 3; k++) {
                hitNormal[k] = getDistanceField(hitPos + mat3(0.5)[k])
                             - getDistanceField(hitPos - mat3(0.5)[k]);
            }
            hitNormal = normalize(hitNormal);
            if (any(isnan(hitNormal))) hitNormal = vec3(0.0);
            return getColorFine(hitPos, hitNormal).rgb;

        #elif VX_DEBUG == 6
            // How far that probe got, against the range the GI is allowed.
            // Blue is close, red is the far end, black escaped without hitting.
            if (!hit) return vec3(0.0);
            return bvDebugRamp(length(hitPos - origin)
                             / max(LIGHT_TRACE_LENGTH * EOPT_GI_RANGE_MULT, 0.001));

        #else
            /*
                What the ray cost, as a fraction of the step budget. Green is
                cheap, red is a ray that spent its whole allowance.

                This is the view to read when the question is frame time rather
                than correctness. A sphere tracer is fast in open space and slow
                along surfaces it is grazing, so red tends to gather in narrow
                gaps and along walls - and every one of those pixels is paying
                for it once per GI sample, not once per frame.
            */
            return bvDebugRamp(float(steps) / float(RT_STEPS));
        #endif
    #endif
}

#endif
