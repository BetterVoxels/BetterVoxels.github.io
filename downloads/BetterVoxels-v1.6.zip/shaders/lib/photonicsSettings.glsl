#ifndef INCLUDE_PHOTONICS_SETTINGS
#define INCLUDE_PHOTONICS_SETTINGS

/*
    Photonics is an Iris extension that ray traces block light against its own
    voxel structure. It covers the same ground this pack's voxel engine does, so
    the two have to be told about each other or every torch is lit twice.

    They are not simply swapped. Photonics reaches as far as its structure is
    built and no further, while the voxel engine here reaches as far as its
    volume; so the handover is by coverage rather than by a switch. Where
    Photonics is live this pack's own block light and bounce fade down to the
    fallback below, and past its edge they come back up on their own. Nothing is
    compiled out, which means the pack behaves exactly as it does today the
    moment the mode goes back to Off or the mod is not installed.

    Every value here is handed to the mod through shaders.properties. The pack
    does not implement any of the tracing.

    ---

    Its own file, guarded, holding options and nothing else - no uniforms, no
    includes of its own.

    That is not tidiness. The modifier files under photonics/ are compiled into
    the mod's shaders, not the pack's, and two of them need the render scale.
    Reaching it through common.glsl pulled the entire pack in with it, twice
    over, because common.glsl has no include guard: every uniform, constant and
    function in it came out declared once per modifier and the mod's shader
    would not build. This file is what those two are allowed to see.
*/

#define PHOTONICS_LIGHTING_MODE 0 //[0 1 2]

#define PHOTONICS_MAX_LIGHTS 1000 //[0 250 500 1000 1500 2000 3000 4000 5000 6000 8000 10000]
#define PHOTONICS_MAX_SAMPLES 20 //[5 10 20 30 40 50 60 70 80 90 100]
#define PHOTONICS_ALPHA_MODE BLOCK //[NONE BLOCK VOXEL]
#define PHOTONICS_RENDER_SCALE 1.00 //[0.25 0.35 0.50 0.65 0.75 0.85 1.00]
#define PHOTONICS_MAX_ALLOWED_DISTANCE 100 //[2 4 6 8 10 12 16 20 24 32 100]

// How much of this pack's own light survives inside Photonics' reach. Zero
// hands the lighting over completely; a little keeps the voxel colour that
// Photonics has no notion of from disappearing.
#define PHOTONICS_VANILLA_LIGHT_FALLBACK 10 //[0 5 10 15 20 25 30 35 40 45 50 60 70 80 90 100]
#define PHOTONICS_INDIRECT_INTENSITY 10 //[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]
#define PHOTONICS_AMBIENT_LIGHT_MULT 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0]
#define PHOTONICS_ENCHANTING_GLINT_STRENGTH 0.2 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define PHOTONICS_RESTIR_INITIAL_SAMPLES 32 //[1 2 4 8 16 32]
#define PHOTONICS_RESTIR_SPATIAL_REUSE_SAMPLES 5 //[0 1 2 3 4 5 6 7 8 9 10]
#define PHOTONICS_RESTIR_SPATIAL_REUSE_RADIUS 5 //[5 10 15 20 25 30]
#define PHOTONICS_RESTIR_ACCUMULATION_FRAMES 32 //[1 2 4 8 16 32 64]
#define PHOTONICS_RESTIR_DENOISER_PASSES 5 //[0 1 2 3 4 5 6 7]
#define PHOTONICS_RESTIR_SOFT_SHADOWS 1 //[0 1]
#define PHOTONICS_COMBINED_GI 0 //[0 1]
#define PHOTONICS_SEPARATE_HANDHELD_RAYS 1 //[0 1]

#endif
