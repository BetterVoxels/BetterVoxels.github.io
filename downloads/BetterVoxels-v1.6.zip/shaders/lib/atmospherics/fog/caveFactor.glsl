#ifndef INCLUDE_CAVE_FACTOR
    #define INCLUDE_CAVE_FACTOR

    // How much a bright patch of sky at the eye is allowed to convince the pack
    // it is no longer underground. This used to be able to cancel the whole
    // thing: the clamp was bounded by 1 - eyeBrightnessM, so standing in a shaft
    // read as leaving the cave however deep you were, and the cave fog that was
    // hiding the far side of the cavern simply switched off. The deeper you are,
    // the less say it gets.
    float bvCaveSkyRelease(float camY) {
        float depth = clamp(1.0 - camY / oceanAltitude, 0.0, 1.0);
        float say = mix(1.0, CAVE_FOG_SKY_RELEASE * 0.01, depth);
        return clamp(1.0 - eyeBrightnessM * say, 0.0, 1.0);
    }

    float GetCaveFactor() {
        return clamp(1.0 - cameraPosition.y / oceanAltitude, 0.0, bvCaveSkyRelease(cameraPosition.y));
    }
    float GetCaveFactor(float yPos) {
        return clamp(1.0 - yPos / oceanAltitude, 0.0, bvCaveSkyRelease(cameraPosition.y));
    }
#endif
