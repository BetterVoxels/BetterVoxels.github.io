#ifndef INCLUDE_VOLUMETRIC_SEA
#define INCLUDE_VOLUMETRIC_SEA

#if defined VOL_FOG_ACTIVE || defined VOLCAVE_ACTIVE

#include "/lib/vx/irradianceCache.glsl"

// Three things decide whether a marched fog reads as volume or as a grey wall:
// extinction around 0.005 per block rather than 0.2, an exponential vertical
// falloff rather than a hard slab, and a gate wider than the spread of the
// noise so most of the volume lands in gradation instead of at the ceiling.

float bvVolNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    vec2 base = i.xz + f.xz + 0.5;
    vec2 uv0 = (base + vec2(37.0, 17.0) * i.y) / 256.0;
    vec2 uv1 = (base + vec2(37.0, 17.0) * (i.y + 1.0)) / 256.0;

    return mix(texture2D(noisetex, uv0).r, texture2D(noisetex, uv1).r, f.y);
}

vec3 bvVolCoord(vec3 wp) {
    // Y is scaled finer than X and Z, so density changes as you rise through a
    // single cloud rather than the whole column sharing one value.
    vec3 q = wp * vec3(0.022, 0.055, 0.022);
    q.x += frameTimeCounter * 0.010 * (VOL_FOG_SPEED * 0.01);
    return q;
}

// Thickness sets a gentle falloff, not a hard edge. Dividing straight by it
// made the field collapse below the density gate within a few blocks of sea
// level - at 24 blocks up only 0.6% of the volume still held any fog, which is
// why the layer looked like it had vanished. Spreading it over four times the
// thickness keeps 43% of the volume alive at the same height.
float bvVolFalloff(float y) {
    return exp2(-abs(y - float(VOL_FOG_ALT)) / max(float(VOL_FOG_THICK) * 4.0, 1.0));
}

// Sampling the shadow map inside the march is what puts real shadow volumes in
// the fog - the dark shaft trailing away from anything solid, the player
// included. shadowtex1 is unconditionally a shadow sampler, unlike shadowtex0
// whose type depends on a build flag.
float bvVolShadow(vec3 wp) {
    #if SHADOW_QUALITY > -1
        vec4 sp = vec4(wp - cameraPosition, 1.0);
        #ifdef SMOOTH_SHADOW_ROTATION
            sp.xyz = stShadowRotation * sp.xyz;
        #endif
        sp = shadowProjection * (shadowModelView * sp);
        sp /= sp.w;

        // The same distortion the pack applies everywhere else, so the shadow
        // in the air lines up with the one already on the ground.
        float distb = sqrt(sp.x * sp.x + sp.y * sp.y);
        float distortFactor = 1.0 - shadowMapBias + distb * shadowMapBias;
        sp.xy *= 1.0 / distortFactor;
        sp.z *= 0.2;
        sp = sp * 0.5 + 0.5;

        if (any(greaterThan(abs(sp.xy - 0.5), vec2(0.5)))) return 1.0;
        return shadow2D(shadowtex1, sp.xyz).z;
    #else
        return 1.0;
    #endif
}

// Block light for a point in the volume, straight out of the pack's own
// irradiance cache. The cache is built by tracing through the voxel volume, so
// it already knows what is in the way - which is what gives a torch a real
// shadow volume behind anything solid, the player included. Sampling it is one
// texture fetch; tracing to each nearby light per march step would not be.
vec3 bvVolBlockLight(vec3 wp) {
    vec3 camFloor = cameraPositionInt.y == -98257195
                  ? floor(cameraPosition) : vec3(cameraPositionInt);
    return readVolumetricBlocklight(wp - camFloor);
}

float bvVolHG(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (12.566370614 * pow(max(1.0 + g2 - 2.0 * g * c, 0.0001), 1.5));
}

#ifdef VOL_FOG_ACTIVE

float bvVolDensity(vec3 wp, out float lift) {
    float falloff = bvVolFalloff(wp.y);
    lift = clamp((wp.y - float(VOL_FOG_ALT)) / max(float(VOL_FOG_THICK), 1.0) * 0.5 + 0.5,
                 0.0, 1.0);

    // Bail before the noise taps, not after - this is what keeps a march that
    // crosses mostly empty air affordable.
    if (falloff < 0.02) return 0.0;

    vec3 q = bvVolCoord(wp);
    float n = bvVolNoise(q)         * 0.500
            + bvVolNoise(q *  2.1)  * 0.250
            + bvVolNoise(q *  4.3)  * 0.125
            + bvVolNoise(q *  8.7)  * 0.075
            + bvVolNoise(q * 17.1)  * 0.050;

    // Banks have to be bigger than the view is long, or nothing about them is
    // visible. A ray 192 blocks long crosses about four of the base cells and
    // more than one of the old macro cells, and averaging that many independent
    // values halves the spread of the total - so every direction ended up with
    // the same integrated density however varied the field was inside. These
    // cells are roughly 450 and 150 blocks, so a ray stays inside one of them
    // and neighbouring directions genuinely differ.
    float macro = smoothstep(0.30, 0.72, bvVolNoise(q * 0.10) * 0.65
                                       + bvVolNoise(q * 0.30) * 0.35);

    float coverage = clamp(VOL_FOG_DENSITY * 0.01, 0.0, 1.0);

    // The gate has to be WIDER than the spread of the noise, not narrower. At
    // nine it was 0.12 across against a spread of 0.17, so the field came out
    // almost binary - 49% empty, 27% at the ceiling, only 24% anywhere in
    // between - and a region sitting at the ceiling has no variation left to
    // see. At three it is 0.37 across and 69% of the volume is graded.
    float d = clamp(falloff * n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);
    d *= 0.12 + 1.90 * macro;

    return d * (0.006 + coverage * 0.018);
}

float bvVolDensityCheap(vec3 wp) {
    float falloff = bvVolFalloff(wp.y);
    if (falloff < 0.02) return 0.0;

    vec3 q = bvVolCoord(wp);
    float n = bvVolNoise(q) * 0.65 + bvVolNoise(q * 2.1) * 0.35;

    float coverage = clamp(VOL_FOG_DENSITY * 0.01, 0.0, 1.0);
    float d = clamp(falloff * n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);
    d *= 0.12 + 1.90 * smoothstep(0.30, 0.72, bvVolNoise(q * 0.10) * 0.65
                                            + bvVolNoise(q * 0.30) * 0.35);
    return d * (0.006 + coverage * 0.018);
}

void bvVolumetricSea(inout vec3 color, vec3 worldDir, vec3 sunDirWorld,
                     float sceneDist, float dither) {
    float range = min(sceneDist, float(VOL_FOG_DIST));
    if (range < 1.0) return;

    vec3 lit = skyColor * 0.75 + fogColor * 0.35;

    #ifdef BIOME_ATMOSPHERE_ACTIVE
        vec3 bvSeaTint;
        float bvSeaMult;
        bvBiomeAtmosphere(bvSeaTint, bvSeaMult);
        // Colour and strength both, so the fog matches the biome light
        // shafts rather than only sharing their hue.
        lit *= bvSeaTint * bvSeaMult;
    #endif

    lit *= VOL_FOG_I * 0.01;

    // Two lobes: a forward one for the silver rim towards the sun and a weak
    // backward one so the away side keeps some glow instead of going flat.
    float c = dot(worldDir, sunDirWorld);
    float phase = (bvVolHG(c, 0.60) + bvVolHG(c, -0.30)) * 4.0;

    float trans = 1.0;
    vec3 acc = vec3(0.0);
    float prevEdge = 0.0;

    for (int i = 0; i < VOL_FOG_STEPS; i++) {
        // Segments grow with the square of the index. Even spacing put every
        // sample 12 blocks apart, which cannot resolve anything smaller than
        // about 24 blocks - so the wisps were always there and never sampled.
        // This puts the first segment under a block and still reaches the same
        // range, at the cost of nothing but arithmetic.
        float f = float(i + 1) / float(VOL_FOG_STEPS);
        float edge = range * f * f;
        float dt = edge - prevEdge;
        float t = prevEdge + dt * dither;
        prevEdge = edge;

        vec3 wp = cameraPosition + worldDir * t;

        float lift;
        float d = bvVolDensity(wp, lift);
        if (d > 0.0) {
            // Four short steps towards the sun. This is the term that separates
            // a lit crown from a shaded underside.
            float sunOD = 0.0;
            for (int k = 1; k <= 4; k++) {
                sunOD += bvVolDensityCheap(wp + sunDirWorld * (float(k) * 5.0));
            }
            sunOD *= 5.0;

            float beer = exp(-sunOD * 4.0);
            // Without the powder term a thin edge is as bright as a solid core
            // and the whole thing reads as fog rather than cloud.
            float powder = 1.0 - exp(-d * dt * 90.0);

            // Only the direct term is shadowed; the ambient share has to
            // survive, or anything in shadow inside the fog goes black.
            float shade = bvVolShadow(wp);

            vec3 sampleCol = lit * (beer * powder * phase * shade
                                  + 0.20 + 0.25 * lift);

            // Torches and lanterns reach ground fog too.
            sampleCol += bvVolBlockLight(wp) * (VOL_FOG_I * 0.01) * 1.2;
            sampleCol *= 1.0 - smoothstep(range * 0.65, range, t);

            float a = 1.0 - exp(-d * dt);
            acc += sampleCol * a * trans;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    color = color * trans + acc;
}
#endif

#ifdef VOLCAVE_ACTIVE

// Same machinery as the sea above, with the vertical shape turned upside down:
// instead of a band around sea level it thickens with depth below a ceiling you
// set. The shadow lookup is what earns its keep here - a shaft coming through a
// hole in the roof is exactly the case this exists for, and without it the
// cave would just be evenly murky.
float bvCaveDensity(vec3 wp, out float skyReach) {
    float below = float(VOLCAVE_TOP) - wp.y;
    skyReach = exp2(-max(below, 0.0) / 24.0);
    if (below <= 0.0) return 0.0;

    // Ramps in under the ceiling rather than starting at full strength, so the
    // mouth of a cave does not show a flat plane where the fog begins.
    float depth = 1.0 - exp2(-below / 20.0);

    vec3 q = wp * vec3(0.035, 0.070, 0.035);
    q.y += frameTimeCounter * 0.004;

    float n = bvVolNoise(q) * 0.50
            + bvVolNoise(q * 2.3) * 0.30
            + bvVolNoise(q * 5.1) * 0.20;

    float coverage = clamp(VOLCAVE_DENSITY * 0.01, 0.0, 1.0);
    float d = clamp(n * 3.0 - (1.35 - coverage * 0.9), 0.0, 1.0);

    return d * depth * (0.002 + coverage * 0.007);
}

void bvCaveFog(inout vec3 color, vec3 worldDir, vec3 sunDirWorld,
               float sceneDist, float dither) {
    float range = min(sceneDist, float(VOLCAVE_DIST));
    if (range < 1.0) return;
    if (cameraPosition.y - 8.0 > float(VOLCAVE_TOP) && worldDir.y >= 0.0) return;

    // Lit off the daytime sky, this read as milk a hundred blocks down: the
    // sky colour has no idea there is rock overhead. Weighted towards fogColor
    // instead, and the ambient share below fades out with depth so only a shaft
    // that actually reaches the fog lights it.
    vec3 lit = skyColor * 0.12 + fogColor * 0.45;

    #ifdef BIOME_ATMOSPHERE_ACTIVE
        vec3 bvCaveTint;
        float bvCaveMult;
        bvBiomeAtmosphere(bvCaveTint, bvCaveMult);
        lit *= bvCaveTint * bvCaveMult;
    #endif

    lit *= VOLCAVE_I * 0.01;

    float c = dot(worldDir, sunDirWorld);
    float phase = (bvVolHG(c, 0.60) + bvVolHG(c, -0.30)) * 4.0;

    float trans = 1.0;
    vec3 acc = vec3(0.0);
    float prevEdge = 0.0;

    for (int i = 0; i < VOLCAVE_STEPS; i++) {
        float f = float(i + 1) / float(VOLCAVE_STEPS);
        float edge = range * f * f;
        float dt = edge - prevEdge;
        float t = prevEdge + dt * dither;
        prevEdge = edge;

        vec3 wp = cameraPosition + worldDir * t;

        float skyReach;
        float d = bvCaveDensity(wp, skyReach);
        if (d > 0.0) {
            float shade = bvVolShadow(wp);
            float powder = 1.0 - exp(-d * dt * 90.0);

            // The direct term is the point of this effect - a beam through a
            // hole in the roof. The ambient floor is deliberately tiny, and what
            // is left of it dies off with depth.
            vec3 sampleCol = lit * (powder * phase * shade * 2.2
                                  + 0.05 + 0.30 * skyReach);

            // Underground this is what you actually see by, and it carries
            // whatever occlusion the cache holds with it. Not multiplied by
            // powder: that term suppresses thin fog, which is exactly where a
            // shadow cast into the air has to be visible.
            sampleCol += bvVolBlockLight(wp) * (VOLCAVE_I * 0.01) * 3.0;
            sampleCol *= 1.0 - smoothstep(range * 0.7, range, t);

            float a = 1.0 - exp(-d * dt);
            acc += sampleCol * a * trans;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    color = color * trans + acc;
}
#endif

#endif

#endif
