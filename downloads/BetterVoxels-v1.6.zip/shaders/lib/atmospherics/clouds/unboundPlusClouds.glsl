/*
    Unbound+ - the Unbound cloud deck with a second one above it.

    This is unboundClouds.glsl again, with its own constants. Deliberately a
    copy rather than a parameterised version of it: the original's shape
    constants are file scope const floats folded out of Cloud Quality, and
    threading a second set of them through would have meant rewriting the deck
    everyone already uses to add a deck they can switch off. A copy leaves the
    lower deck exactly as it was.

    What is changed here is the shape. The slab is a fraction of the height,
    the features are broader, and the drift is quicker - which between them
    turn the same field from something piled into something laid out flat. It
    is the same cloud seen from a different part of the sky, not a new one.

    Noise3D comes from unboundClouds.glsl, which mainClouds.glsl includes
    first. There is no reason for two copies of it.
*/

#if UBP2_SIZE != 100
    #define UBP2_SIZE_M UBP2_SIZE * 0.01
#endif

#if CLOUD_QUALITY == 1 || !defined DEFERRED1
    const float ubp2StretchRaw = 11.0;
#elif CLOUD_QUALITY == 2
    const float ubp2StretchRaw = 16.0;
#elif CLOUD_QUALITY == 3
    const float ubp2StretchRaw = 18.0;
#endif

#if UBP2_SIZE <= 100
    const float ubp2Stretch = max(ubp2StretchRaw * (UBP2_FLATNESS * 0.01), 1.5);
#else
    const float ubp2Stretch = max(ubp2StretchRaw * (UBP2_FLATNESS * 0.01) / float(UBP2_SIZE_M), 1.5);
#endif

const float ubp2Height = ubp2Stretch * 2.0;
const int ubp2Alt = int(UBP2_ALT);

float Ubp2CloudNoise(vec3 tracePos, int cloudAltitude, float lTracePosXZ, float cloudPlayerPosY) {
    vec3 tracePosM = tracePos.xyz * 0.00016;
    float wind = 0.0006;
    float noise = 0.0;
    float currentPersist = 1.0;
    float total = 0.0;

    // Offset so the two decks are not the same cloud drawn at two altitudes.
    tracePosM.z += 37.19;

    #if UBP2_SPEED == 100
        wind *= cloudSyncedTime;
    #else
        wind *= frameTimeCounter * (UBP2_SPEED * 0.01);
        #if SMOOTH_TIME_ACTIVE >= 2
            if (stActive) wind = 0.0006 * cloudSyncedTime * (UBP2_SPEED * 0.01);
        #endif
    #endif
    #if UBP2_SIZE != 100
        tracePosM *= UBP2_SIZE_M;
        wind *= UBP2_SIZE_M;
    #endif

    #if CLOUD_QUALITY == 1
        int sampleCount = 2;
        float persistance = 0.6;
        float noiseMult = 0.95;
        tracePosM *= 0.5; wind *= 0.5;
    #elif CLOUD_QUALITY == 2 || !defined DEFERRED1
        int sampleCount = 4;
        float persistance = 0.5;
        float noiseMult = 1.07;
    #elif CLOUD_QUALITY == 3
        int sampleCount = 4;
        float persistance = 0.5;
        float noiseMult = 1.0;
    #endif

    #ifndef DEFERRED1
        noiseMult *= 1.2;
    #endif

    for (int i = 0; i < sampleCount; i++) {
        #if CLOUD_QUALITY >= 2
            noise += Noise3D(tracePosM + vec3(wind, 0.0, 0.0)) * currentPersist;
        #else
            noise += texture2D(noisetex, tracePosM.xz + vec2(wind, 0.0)).b * currentPersist;
        #endif
        total += currentPersist;

        tracePosM *= 3.0;
        wind *= 0.5;
        currentPersist *= persistance;
    }
    noise = pow2(noise / total);

    noiseMult *= CLOUD_BASE_ADD
                + CLOUD_FAR_ADD * sqrt(lTracePosXZ + 10.0)
                + CLOUD_ABOVE_ADD * clamp01(-cloudPlayerPosY / ubp2Height)
                + (UBP2_RAIN_ADD * 0.01) * rainFactor;
    noise *= noiseMult * (UBP2_AMOUNT * 0.01);

    float threshold = clamp(abs(cloudAltitude - tracePos.y) / ubp2Stretch, 0.001, 0.999);
    threshold = pow2(pow2(pow2(threshold)));

    float cutoff = threshold * 0.2 + 0.25;
    cutoff *= 1.0 - UBP2_RAIN_OVERCAST * 0.01 * rainFactor;

    return noise - cutoff;
}

vec4 Ubp2VolumetricClouds(int cloudAltitude, float distanceThreshold, out float firstHitPos, float skyFade, float skyMult0, vec3 cameraPos, vec3 nPlayerPos, float lViewPosM, float VdotS, float VdotU, float dither) {
    vec4 volumetricClouds = vec4(0.0);
    firstHitPos = 0.0;

    float higherPlaneAltitude = cloudAltitude + ubp2Stretch;
    float lowerPlaneAltitude  = cloudAltitude - ubp2Stretch;

    float lowerPlaneDistance  = (lowerPlaneAltitude - cameraPos.y) / nPlayerPos.y;
    float higherPlaneDistance = (higherPlaneAltitude - cameraPos.y) / nPlayerPos.y;
    float minPlaneDistance = min(lowerPlaneDistance, higherPlaneDistance);
          minPlaneDistance = max(minPlaneDistance, 0.0);
    float maxPlaneDistance = max(lowerPlaneDistance, higherPlaneDistance);
    if (maxPlaneDistance < 0.0) return vec4(0.0);
    float planeDistanceDif = maxPlaneDistance - minPlaneDistance;

    #ifndef DEFERRED1
        float stepMult = 32.0;
    #elif CLOUD_QUALITY == 1
        float stepMult = 16.0;
    #elif CLOUD_QUALITY == 2
        float stepMult = 24.0;
    #elif CLOUD_QUALITY == 3
        float stepMult = 16.0;
    #endif

    // A thin slab is crossed in a step or two overhead, so the step is pulled
    // in with the thickness - otherwise a flat deck would be sampled once and
    // read as a hard edged cutout.
    stepMult = min(stepMult, max(ubp2Height * 0.5, 3.0));

    #if UBP2_SIZE > 100
        stepMult = stepMult / sqrt(float(UBP2_SIZE_M));
    #endif

    int sampleCount = int(planeDistanceDif / stepMult + dither + 1);
    vec3 traceAdd = nPlayerPos * stepMult;
    vec3 tracePos = cameraPos + minPlaneDistance * nPlayerPos;
    tracePos += traceAdd * dither;
    tracePos.y -= traceAdd.y;

    float VdotSM1 = max0(sunVisibility > 0.5 ? VdotS : - VdotS);
    float VdotSM1M = VdotSM1 * invRainFactor;
    float VdotSM2 = pow2(VdotSM1) * abs(sunVisibility - 0.5) * 2.0;
    float VdotSM3 = VdotSM2 * (2.5 + rainFactor) + 1.5 * rainFactor;

    #ifdef FIX_AMD_REFLECTION_CRASH
        sampleCount = min(sampleCount, 30);
    #endif

    for (int i = 0; i < sampleCount; i++) {
        tracePos += traceAdd;

        if (abs(tracePos.y - cloudAltitude) > ubp2Stretch) break;

        vec3 cloudPlayerPos = tracePos - cameraPos;
        float lTracePos = length(cloudPlayerPos);
        float lTracePosXZ = length(cloudPlayerPos.xz);
        float cloudMult = 1.0;
        if (lTracePosXZ > distanceThreshold) break;
        if (lTracePos > lViewPosM) {
            if (skyFade < 0.7) continue;
            else cloudMult = skyMult0;
        }

        float cloudNoise = Ubp2CloudNoise(tracePos, cloudAltitude, lTracePosXZ, cloudPlayerPos.y);

        if (cloudNoise > 0.00001) {
            #if defined CLOUD_CLOSED_AREA_CHECK && SHADOW_QUALITY > -1
                float shadowLength = min(shadowDistance, far) * 0.9166667;
                if (shadowLength < lTracePos)
                if (GetShadowOnCloud(tracePos, cameraPos, cloudAltitude, lowerPlaneAltitude, higherPlaneAltitude)) {
                    if (eyeBrightness.y != 240) continue;
                }
            #endif

            if (firstHitPos < 1.0) firstHitPos = lTracePos;

            float opacityFactor = min1(cloudNoise * 8.0);

            // Height within the slab, exactly as the lower deck reads it - but
            // pulled towards the middle in proportion to how flat this one is.
            //
            // That gradient runs its full range from the underside to the top,
            // which is fine across thirty-six blocks: a ray crosses many
            // samples and averages them. Across ten it does not. A ray looking
            // up enters at the bottom and locks onto the dark underside almost
            // at once, while a ray clipping the edge of a cloud never gathers
            // enough alpha to stop averaging and keeps climbing into the bright
            // top - so the middle of every cloud came out darker than its rim,
            // and the rim read as an outline drawn around it. Compressing the
            // gradient removes the two extremes it was picking between. At a
            // Flatness of 100 this is the lower deck's shading untouched.
            float cloudShading = 1.0 - (higherPlaneAltitude - tracePos.y) / ubp2Height;
            cloudShading = mix(0.62, cloudShading, clamp(UBP2_FLATNESS * 0.01, 0.0, 1.0));
            cloudShading *= 1.0 + 0.75 * VdotSM3 * (1.0 - opacityFactor);

            vec3 colorSample = cloudAmbientColor * (0.7 + 0.3 * cloudShading) + cloudLightColor * cloudShading;
            vec3 cloudSkyColor = GetSky(VdotU, VdotS, dither, true, false);
            #ifdef ATM_COLOR_MULTS
                cloudSkyColor *= sqrtAtmColorMult;
            #endif
            float distanceRatio = (distanceThreshold - lTracePosXZ) / distanceThreshold;
            float cloudDistanceFactor = clamp(distanceRatio, 0.0, 0.8) * 1.25;
            #ifndef DISTANT_HORIZONS
                float cloudFogFactor = cloudDistanceFactor;
            #else
                float cloudFogFactor = clamp(distanceRatio, 0.0, 1.0);
            #endif
            float skyMult1 = 1.0 - 0.2 * (1.0 - skyFade) * max(sunVisibility2, nightFactor);
            float skyMult2 = 1.0 - 0.33333 * skyFade;
            colorSample = mix(cloudSkyColor, colorSample * skyMult1, cloudFogFactor * skyMult2 * 0.72);
            colorSample *= pow2(1.0 - maxBlindnessDarkness);

            volumetricClouds.rgb = mix(volumetricClouds.rgb, colorSample, 1.0 - min1(volumetricClouds.a));
            volumetricClouds.a += opacityFactor * pow(cloudDistanceFactor, 0.5 + 10.0 * pow(abs(VdotSM1M), 90.0))
                                * cloudMult;

            if (volumetricClouds.a > 0.9) {
                volumetricClouds.a = 1.0;
                break;
            }
        }
    }

    // Opacity is taken off the finished alpha, not off each step's share of it.
    // Per step it also moved the colour: the colour blend is weighted by the
    // alpha accumulated so far, so a slower alpha kept averaging in more of the
    // deck - including the samples near its underside, which are the dark ones.
    // Thin edges reach the end of the march with the least alpha, so they took
    // the most of that, and every cloud came out ringed with a darker outline.
    volumetricClouds.a = min1(volumetricClouds.a) * (UBP2_OPACITY * 0.01);
    return volumetricClouds;
}

/*
    Lay the upper deck in with the lower one already in hand.

    Which of the two is in front depends only on where the camera is looking:
    on the way up the ray meets the lower deck first, on the way down the
    higher one. If the camera is between them the far one contributes nothing
    anyway, because its slab is behind the ray, so the same rule covers that.
*/
vec4 bvuAddUpperDeck(vec4 clouds, inout float cloudLinearDepth, float distanceThreshold,
                     float skyFade, float skyMult0, vec3 cameraPos, vec3 dir,
                     float lViewPosM, float VdotS, float VdotU, float dither) {
    #if UBP2_LAYER == 1
        float upperHit = 0.0;
        vec4 upper = Ubp2VolumetricClouds(ubp2Alt, distanceThreshold, upperHit, skyFade, skyMult0,
                                          cameraPos, dir, lViewPosM, VdotS, VdotU, dither);
        if (upper.a < 0.002) return clouds;

        bool lookUp = dir.y >= 0.0;
        vec4 front = lookUp ? clouds : upper;
        vec4 back  = lookUp ? upper : clouds;

        float alpha = front.a + (1.0 - front.a) * back.a;
        if (alpha < 0.002) return clouds;
        vec3 color = (front.rgb * front.a + (1.0 - front.a) * back.rgb * back.a) / alpha;

        // Only claim the depth if the upper deck is what the eye actually lands
        // on; the lower one has already written its own otherwise.
        if (upper.a > 0.5 && upperHit > 0.001 && (!lookUp || clouds.a <= 0.5)) {
            cloudLinearDepth = sqrt(upperHit / renderDistance);
        }

        return vec4(color, alpha);
    #else
        return clouds;
    #endif
}
