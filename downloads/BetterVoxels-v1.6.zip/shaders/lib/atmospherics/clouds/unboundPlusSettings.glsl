/*
    Unbound+ cloud settings.

    Unbound+ is the Unbound cloud deck with a second one of its own above it.
    The lower deck is Unbound's renderer, untouched, and everything under
    "Unbound Cloud Settings" still drives it. What follows here is the same
    renderer again with its own numbers, set up flat: a higher, wider, thinner
    sheet that the puffy deck below passes under.

    Every value here is an integer, including the ones the lower deck spends as
    floats. The preprocessor cannot compare floats, so keeping them whole means
    the shape can be branched on with #if and folded by the driver as a
    constant, which is what lets a switched-off second deck cost nothing.
*/

#ifndef INCLUDE_UNBOUND_PLUS_SETTINGS
#define INCLUDE_UNBOUND_PLUS_SETTINGS

#define UBP2_LAYER 1 //[0 1]

// World height. Wants to sit clear of the lower deck; overlapping them just
// reads as one thick deck with a seam in it.
#define UBP2_ALT 416 //[64 80 96 112 128 144 160 176 192 208 224 240 256 272 288 304 320 336 352 384 416 448 480 512 544 576 608 640 704 768]

// Coverage, on the same scale as Cloud Amount below. 100 matches the lower deck.
#define UBP2_AMOUNT 115 //[70 75 80 85 90 95 100 105 110 115 120 130 140 150 160 175 200 225 250 300]

// Higher is smaller, as with Cloud Smallness. A flat deck wants broad shapes,
// so this starts well under the lower deck's 100.
#define UBP2_SIZE 55 //[25 30 35 40 45 50 55 60 65 70 75 80 90 100 110 120 140 160 180 200 250 300]

// How much of the lower deck's thickness this one keeps. This is the setting
// that makes it flat rather than puffy: at 100 it is the same slab Unbound
// draws, at 25 it is a quarter as deep and reads as a sheet.
#define UBP2_FLATNESS 30 //[10 15 20 25 30 35 40 45 50 60 70 80 90 100 120 140]

// Drift, on the same scale as Cloud Speed. Higher decks really do run faster,
// and two decks sliding apart is what makes the sky read as layered.
#define UBP2_SPEED 130 //[0 5 10 15 20 25 30 40 50 60 70 80 90 100 110 120 130 140 150 175 200 250 300 400]

// How solid the deck is. A high sheet you can see blue through is the point of
// it, so this starts below the lower deck's full opacity.
#define UBP2_OPACITY 60 //[10 20 30 40 50 60 70 80 90 100 110 120 130 140 150]

// Weather, matching the two settings the lower deck has: how much thicker it
// gets in rain, and how completely rain closes the gaps between the clouds.
#define UBP2_RAIN_ADD 25 //[0 5 10 15 20 25 30 35 40 45 50 60 70 80 90 100 120 140]
#define UBP2_RAIN_OVERCAST 80 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95]

#endif
