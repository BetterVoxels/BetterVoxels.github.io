
#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER

in vec2 texCoord;

in vec4 glColor;

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/misc/colorCodedPrograms.glsl"
#endif

void main() {
    vec4 color = texture2D(tex, texCoord) * glColor;

    #ifdef IPBR
        if (CheckForColor(color.rgb, vec3(224, 121, 250))) {
            color.rgb = vec3(0.8, 0.25, 0.8);
        }
    #endif

    // The roll-off here is meant to stop a saturated eye - an enderman's, a
    // warden's - from blowing out, but it keyed on brightness alone. That made
    // it read a plain white texture as the worst offender of all and cut it to
    // forty percent, which is exactly backwards: white is the one case the game
    // draws at full brightness on purpose. It is why modded white eyes did not
    // glow at all. Keyed on saturation as well, it still tames the colours it
    // was written for and leaves a neutral texture alone.
    float maxChannel = max(max(color.r, color.g), color.b);
    float eyeSaturation = (maxChannel - min(min(color.r, color.g), color.b)) / max(maxChannel, 0.0001);
    color.rgb *= 1.0 - 0.6 * eyeSaturation * pow2(pow2(min1(GetLuminance(color.rgb) * 1.2)));

    color.rgb = pow1_5(color.rgb);

    // The boost below leans on blue and green, so a neutral texture used to come
    // out of it on the base term alone and land below one - under the bloom
    // threshold, which is the difference between glowing and merely being pale.
    // Giving the neutral case a level of its own leaves every coloured eye
    // within a tenth of where it already was.
    color.rgb *= mix(2.2, pow2(1.0 + color.b + 0.5 * color.g) * 1.5, eyeSaturation);

    #ifdef COLOR_CODED_PROGRAMS
        ColorCodeProgram(color, -1);
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}

#endif

#ifdef VERTEX_SHADER

out vec2 texCoord;

out vec4 glColor;

void main() {
    #ifdef WORLD_CURVATURE_ACTIVE
        gl_Position = bvCurveFTransform();
    #else
        gl_Position = ftransform();
    #endif

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    glColor = gl_Color;
}

#endif
