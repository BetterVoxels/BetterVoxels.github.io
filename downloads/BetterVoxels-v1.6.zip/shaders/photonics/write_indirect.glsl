/*
    Where Photonics puts its traced result.

    The mod owns the shader this is compiled into; the pack owns the choice of
    buffer, because only the pack knows which of its own targets are free.
    colortex15 is the one slot this pack never allocated - every other target
    from 0 to 14 already carries something, so anything else would be silently
    overwriting a stage of the pack's own pipeline.

    The RENDERTARGETS line has to stay a comment: that is the form Iris parses,
    and a pass that writes to no declared target writes to colortex0 instead,
    which is the finished frame.

    shaders.properties scales this buffer to PHOTONICS_RENDER_SCALE, so anything
    reading it has to scale the coordinate to match rather than assume screen
    size.
*/

layout(location = 0) out vec4 fragColor;

void write_indirect(vec3 color) {
    /* RENDERTARGETS:15 */
    fragColor = vec4(color, 1.0);
}
