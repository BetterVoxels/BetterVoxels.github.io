/*
    How Photonics reads this pack.

    The mod compiles this file into its own shaders, so everything below is the
    pack answering questions asked from the other side: where is this pixel in
    the world, what colour is the surface, which way does it face, is there a
    surface here at all. The mod owns the tracing; this file owns nothing but
    the translation.

    Two consequences worth keeping in mind while reading:

    - There is no vertex stage of the pack here. Values the pack's own fragment
      programs receive as varyings - the sun and up vectors above all - have to
      be rebuilt from uniforms, and then the whole chain of time-of-day
      derivations rebuilt on top of them, because the light colour depends on
      it. The block below is the same derivation deferred1 uses, from the same
      inputs, so the two cannot drift.

    - Everything is read at PHOTONICS_RENDER_SCALE. The mod's passes run at that
      scale while the pack's buffers are full size, so every lookup goes through
      ph_tex_coord rather than the raw fragment coordinate.
*/

#define PHOTONICS_SHADER_INTERFACE
#define FRAGMENT_SHADER

// The mod's shaders are core profile. The pack is written against the legacy
// sampler names, which Iris rewrites for the pack's own programs but not for
// somebody else's, so the same mapping is applied here by hand.
#define shadow2D texture
#define texture2D texture
#define texture2DLod textureLod

#include "/lib/common.glsl"
#include "/lib/util/spaceConversion.glsl"
#include "/lib/antialiasing/jitter.glsl"

uniform vec3 sunPosition;
uniform vec3 upPosition;

vec3 sunVec = normalize(sunPosition);
vec3 upVec = normalize(upPosition);

float SdotU = dot(sunVec, upVec);
float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75
                              : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;

#ifdef OVERWORLD
    vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#else
    vec3 lightVec = sunVec;
#endif

#include "/lib/colors/lightAndAmbientColors.glsl"

const float rcp_render_scale = 1.0 / PHOTONICS_RENDER_SCALE;
ivec2 ph_tex_coord = ivec2(vec2(texelCoord) * rcp_render_scale + 0.5);

vec3 load_world_position() {
    /*
        Depth comes from depthtex1 in Basic mode and depthtex0 otherwise. That
        split is the reference behaviour for this API rather than something
        derived here - depthtex1 excludes translucents, and the Basic path
        evidently wants the surface behind them. Noted as unverified: it is one
        of the few things in this file that could not be checked against how the
        pack itself works.
    */
    #if PHOTONICS_LIGHTING_MODE == 1
        float depth = texelFetch(depthtex1, ph_tex_coord, 0).r;
    #else
        float depth = texelFetch(depthtex0, ph_tex_coord, 0).r;
    #endif

    // Against the scaled viewport, not the real one: gl_FragCoord here counts
    // pixels of the mod's smaller target.
    vec2 phTexCoord = gl_FragCoord.xy / floor(vec2(viewWidth, viewHeight) * PHOTONICS_RENDER_SCALE);

    #ifdef TAA
        // The depth was written by a jittered frame, so the coordinate that
        // reconstructs it has to carry the same jitter back out.
        vec3 screenPos = vec3(TAAJitter(phTexCoord, -0.5), depth);
    #else
        vec3 screenPos = vec3(phTexCoord, depth);
    #endif

    return ViewToPlayer(ScreenToView(screenPos)) + cameraPosition;
}

void load_fragment_variables(out vec3 albedo, out vec3 world_pos,
                             out vec3 world_normal, out vec3 world_normal_mapped) {
    /*
        colortex4 and colortex5 under DRAWBUFFERS:0654 in the terrain pass:
        gl_FragData[3] is the albedo and gl_FragData[2] is
        mat3(gbufferModelViewInverse) * normalM, already in world space and in a
        signed normalised target, so it comes back in -1..1 without decoding.

        Both normals are the same one. This pack keeps a single normal in the
        gbuffer - the mapped one - and no separate geometric copy, so there is
        nothing truthful to put in the second slot. Handing over the mapped
        normal twice means the mod offsets its ray origin along a normal that
        can disagree with the actual face by whatever the normal map does; on
        flat blocks that is nothing, on a strongly mapped texture it is a
        fraction of a voxel.
    */
    albedo = texelFetch(colortex4, ph_tex_coord, 0).rgb;
    world_normal = texelFetch(colortex5, ph_tex_coord, 0).rgb;
    world_normal_mapped = world_normal;

    // Lifted off the surface so the first trace step does not immediately hit
    // the face it started on.
    world_pos = load_world_position() - 0.01 * world_normal;
}

// The pack keeps its light direction in view space and flips it at dusk. The
// mod wants it in world space, and this is the conversion the pack already uses
// elsewhere for exactly that.
vec3 sun_direction = normalize(ViewToPlayer(lightVec * 1000000000.0));

/*
    The colour the traced bounce is tinted with.

    Mostly desaturated, because a bounce that has been round a room more than
    once has lost most of the sun's own tint, and lifted at night, where the
    direct term is gone and what is left would otherwise be almost nothing.

    Both constants are a starting point rather than a measurement - like the
    magnitude in deferred1, they are the part of this integration that cannot be
    settled without looking at it.
*/
vec3 indirect_light_color = mix(lightColor, vec3(GetLuminance(lightColor)), 0.75)
                          * mix(2.5, 1.0, sunVisibility2);

// The pack does its own jittering in its own passes and the coordinates handed
// to the mod are already resolved, so there is nothing to add here.
vec2 get_taa_jitter() { return vec2(0.0); }

// Sky is the pack's business: it draws its own, with its own atmosphere, fog
// and clouds. Returning black keeps the mod from adding a second one on top.
vec3 get_sky_color(ivec2 gBufferLoc, vec3 worldPos, vec3 newNormal) {
    return vec3(0.0);
}

// Anything at the far plane is sky, and there is no surface to light.
bool is_in_world() {
    return texelFetch(depthtex0, ph_tex_coord, 0).x <= 0.99999;
}
