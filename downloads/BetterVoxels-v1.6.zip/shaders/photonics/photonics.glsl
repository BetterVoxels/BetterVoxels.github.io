/*
    Photonics API surface. The mod replaces the contents of this file at load
    time; shipping it empty is what lets the pack compile and run normally when
    the mod is absent, which is the usual case.

    Do not put anything here. Anything written would be discarded the moment
    someone installs the mod, and would be the only thing present when they
    do not - the two states could never agree.
*/
