/*
    Photonics sampler declarations. Provided by the mod at load time; empty here
    so the pack builds without it. See photonics.glsl.
*/
