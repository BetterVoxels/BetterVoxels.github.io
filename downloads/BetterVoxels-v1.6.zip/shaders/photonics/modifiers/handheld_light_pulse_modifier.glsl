/*
    Per frame multiplier on the held light, for packs that make a torch in the
    hand flicker. This one does not - its held light is steady - so the traced
    held light stays steady too and matches it.
*/
float modify_handheld_pulse() {
    return 1.0;
}
