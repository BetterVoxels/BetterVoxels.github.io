/*
    Settings only. This file is compiled into the mod's shader, not the pack's,
    and reaching for common.glsl here drags the whole pack in behind it - it
    carries no include guard, so with two modifiers doing it every uniform and
    function in the pack ends up declared twice and nothing builds.
*/
#include "/lib/photonicsSettings.glsl"

/*
    Whether the pixel Photonics is about to shade belongs to the held item.

    The hand is drawn into a sliver of the depth range in front of everything
    else, so a depth test separates it from the world without needing a mask.
    The coordinate has to be lifted back to full resolution first: Photonics
    runs at PHOTONICS_RENDER_SCALE while depthtex0 is always the real frame.
*/
bool modify_is_hand() {
    const float renderFactor = 1.0 / PHOTONICS_RENDER_SCALE;

    return texelFetch(depthtex0, ivec2(gl_FragCoord.xy * renderFactor + 0.5), 0).x < 0.56;
}
