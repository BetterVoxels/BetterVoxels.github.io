// Settings only - see the note in is_hand_modifier.glsl.
#include "/lib/photonicsSettings.glsl"

/*
    Same rescale as is_hand_modifier, for the denoiser's own depth lookups: the
    reservoirs live at render scale, the depth buffer does not.
*/
ivec2 modify_denoiser_depth_fetch(ivec2 texCoord) {
    const float renderFactor = 1.0 / PHOTONICS_RENDER_SCALE;

    return ivec2(texCoord * renderFactor + 0.5);
}
