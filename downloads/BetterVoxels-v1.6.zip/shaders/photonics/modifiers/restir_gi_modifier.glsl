/*
    Last look at the traced bounce before Photonics writes it out.

    Deliberately a pass through. The pack's own conversion into its light units
    happens where it reads the buffer back, in deferred1, together with the
    coverage fade that decides how much of the pack's own bounce is stepping
    aside for this one. Scaling in both places would mean two constants that
    have to be kept in step, and only one of them is visible next to the thing
    it is balanced against.
*/
void modify_restir_gi(inout vec3 color) {
}
