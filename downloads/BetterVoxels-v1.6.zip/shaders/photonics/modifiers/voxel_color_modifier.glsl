/*
    A chance to correct the colour Photonics reads out of its own voxel
    structure before it bounces light off it.

    Nothing to correct here: this pack's per block recolouring - seasons, snow
    cover, the material tweaks - happens in the gbuffer on the rendered surface,
    not in a block colour table Photonics could be pointed at. Kept as a stub
    because the mod includes the file unconditionally, and a missing one is a
    compile failure rather than a skipped feature.
*/
void voxel_color_modifier(inout vec4 color, vec3 rt_pos, ivec3 rt_block_pos) {
}
